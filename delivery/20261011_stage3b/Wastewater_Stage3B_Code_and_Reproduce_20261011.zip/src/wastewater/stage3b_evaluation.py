"""Matched-date, SiteID-level evaluation for the fixed Stage 3B Ridge round.

The calendar bootstrap is the Stage 2/3A design: noncircular moving blocks
inside each predeclared 60-origin episode, synchronized across sites, budgets
and policies, followed by whole-SiteID cluster resampling. No daily row,
budget, episode or random seed is treated as an independent physical facility.
"""
from __future__ import annotations

import itertools
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

from .common import sha256, write_json

MODELS = [
    'persistence', 'weekly_persistence', 'local_ridge_lags_tuned',
    'shared_ridge_lags', 'shared_ridge_lags_bias',
    'local_residual_ridge_unshrunk', 'local_residual_ridge_selected',
    'shared_residual_ridge_unshrunk', 'shared_residual_ridge_selected',
    'shared_residual_ridge_bias_unshrunk', 'shared_residual_ridge_bias_selected',
]
PRIMARY_MODEL = 'shared_residual_ridge_bias_selected'
KEYS = ['site_id', 'episode', 'horizon', 'origin', 'target_date']
TASK_KEYS = ['site_id', 'episode', 'budget', 'horizon', 'model']
TIE_TOLERANCE = 1e-12


def nanmean(values, axis=None):
    """Do not flood logs when a prespecified subgroup has no usable labels."""
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', RuntimeWarning)
        return np.nanmean(values, axis=axis)


def evaluation_origins(cfg):
    origins = list(cfg.get('evaluation_origins', cfg['origins']))
    if len(origins) != len(set(origins)):
        raise ValueError('Duplicate evaluation episode')
    if cfg.get('additional_window_authorized'):
        additional = cfg.get('additional_origin', '2023-10-01')
        if additional != '2023-10-01':
            raise ValueError('The only predeclared additional origin is 2023-10-01')
        if additional not in origins:
            origins.append(additional)
    extras = [date for date in origins if date not in cfg['origins']]
    if extras and (not cfg.get('additional_window_authorized') or extras != ['2023-10-01']):
        raise ValueError('Additional time validation was not authorized by the history-use audit')
    for date in origins:
        if pd.Timestamp(date) + pd.Timedelta(days=cfg['evaluation_days'] - 1 + max(cfg['horizons'])) > pd.Timestamp('2023-12-31'):
            raise ValueError('Forbidden final-period evaluation')
    return origins


def prepare_predictions(frame, cfg):
    """Materialize missing tasks and one common date mask across all policies/B.

    Missing jobs are retained as rows with NaN predictions and explicit
    ``prediction_row_present=False``. Truth is only copied from another saved
    forecast of the same site/date; no truth is interpolated or fabricated.
    """
    p = frame.rename(columns={
        'prediction_raw': 'prediction_m3', 'prediction_nonnegative': 'prediction_nonnegative_m3',
        'truth': 'truth_m3', 'threshold': 'high_threshold_m3', 'target': 'target_date',
    }).copy()
    required = KEYS + ['budget', 'model', 'truth_m3', 'prediction_m3', 'high_threshold_m3']
    missing = [name for name in required if name not in p]
    if missing:
        raise ValueError(f'Missing prediction columns: {missing}')
    p['site_id'] = p.site_id.astype(str)
    p['budget'] = p.budget.astype(int)
    p['horizon'] = p.horizon.astype(int)
    for name in ['episode', 'origin', 'target_date']:
        p[name] = pd.to_datetime(p[name]).dt.strftime('%Y-%m-%d')
    if 'seed' not in p:
        p['seed'] = 0
    if not p.seed.eq(0).all():
        raise ValueError('Deterministic Stage 3B must contain exactly seed=0; no seed ensemble')
    if p.duplicated(KEYS + ['budget', 'model']).any():
        raise ValueError('Duplicate deterministic forecast')
    models = list(cfg.get('models', MODELS))
    origins = evaluation_origins(cfg)
    if not set(p.model) <= set(models):
        raise ValueError('Unregistered model in predictions')
    if not set(p.site_id) <= set(map(str, cfg['development_ids'])):
        raise ValueError('Unregistered target SiteID')
    if not set(p.episode) <= set(origins) or not set(p.budget) <= set(cfg['budgets']) or not set(p.horizon) <= set(cfg['horizons']):
        raise ValueError('Unregistered evaluation condition')
    delta = (pd.to_datetime(p.target_date) - pd.to_datetime(p.origin)).dt.days
    if not delta.eq(p.horizon).all():
        raise ValueError('Target must be origin+h, not a cumulative volume')
    day = (pd.to_datetime(p.origin) - pd.to_datetime(p.episode)).dt.days
    if not day.between(0, cfg['evaluation_days'] - 1).all():
        raise ValueError('Origin outside frozen deployment episode')
    if 'latest_input_date' in p:
        if (pd.to_datetime(p.latest_input_date) > pd.to_datetime(p.origin)).any():
            raise ValueError('Future input date')
    if {'last_train_target', 'fit_end'} <= set(p):
        if (pd.to_datetime(p.last_train_target) > pd.to_datetime(p.fit_end)).any():
            raise ValueError('Training label crosses calibration cutoff')
    # These are float round-trip checks, not a claim of bitwise equality.
    bounds = p.groupby(KEYS).truth_m3.agg(['min', 'max'])
    if ((bounds['max'] - bounds['min']) > 1e-8 + 1e-12 * bounds['min'].abs()).any():
        raise ValueError('Different truths for matched forecast conditions')
    thresholds = p.groupby(KEYS).high_threshold_m3.agg(['min', 'max'])
    if ((thresholds['max'] - thresholds['min']) > 1e-8 + 1e-12 * thresholds['min'].abs()).any():
        raise ValueError('High-volume threshold differs across history budgets/models')
    clipped = np.maximum(0., p.prediction_m3.to_numpy(float))
    if 'prediction_nonnegative_m3' in p:
        if not np.allclose(p.prediction_nonnegative_m3.to_numpy(float), clipped, rtol=0., atol=0., equal_nan=True):
            raise ValueError('Nonnegative constraint was not applied uniformly/exactly')
    else:
        p['prediction_nonnegative_m3'] = clipped
    if 'prediction_row_present' in p:
        p['prediction_row_present'] = p.prediction_row_present.eq(True)
    else:
        p['prediction_row_present'] = True
    expected = []
    for site, episode, budget, horizon in itertools.product(map(str, cfg['development_ids']), origins, cfg['budgets'], cfg['horizons']):
        for origin in pd.date_range(episode, periods=cfg['evaluation_days']):
            expected.extend(dict(site_id=site, episode=episode, budget=budget, horizon=horizon,
                                 origin=str(origin.date()), target_date=str((origin + pd.Timedelta(days=horizon)).date()), model=model)
                            for model in models)
    expected = pd.DataFrame(expected)
    p = expected.merge(p, on=KEYS + ['budget', 'model'], how='left', validate='one_to_one')
    p['prediction_row_present'] = p.prediction_row_present.eq(True)
    p['seed'] = p.seed.fillna(0).astype(int)
    # Preserve missing tasks, while using an already saved identical-date truth.
    for column in ['truth_m3', 'high_threshold_m3']:
        p[column] = p[column].fillna(p.groupby(KEYS)[column].transform('first'))
    p['evaluation_set'] = np.where(p.episode.isin(cfg['origins']), 'original_development', 'additional_time_validation')
    p['finite_truth'] = np.isfinite(p.truth_m3)
    p['finite_prediction'] = np.isfinite(p.prediction_m3)
    valid = (p.finite_truth & p.finite_prediction & p.prediction_row_present).groupby([p[k] for k in KEYS]).all()
    p['common_evaluation'] = p.set_index(KEYS).index.map(valid).astype(bool)
    p['prediction_failure_reason'] = np.select(
        [~p.prediction_row_present, ~p.finite_truth, ~p.finite_prediction],
        ['missing_prediction_row_or_failed_task', 'missing_true_target', 'nonfinite_prediction'], default='')
    return p


def station_metrics(daily, cfg):
    keys = ['evaluation_set', 'constraint', 'site_id', 'budget', 'horizon', 'model']
    metric = daily.groupby(keys).agg(n_dates=('absolute_error', 'size'),
                                    mae_m3=('absolute_error', 'mean'), mse=('squared_error', 'mean')).reset_index()
    sets = ['original_development']
    if any(x not in cfg['origins'] for x in evaluation_origins(cfg)):
        sets.append('additional_time_validation')
    expected = pd.DataFrame(itertools.product(sets, ['raw', 'all_models_nonnegative'], map(str, cfg['development_ids']),
                                              cfg['budgets'], cfg['horizons'], cfg.get('models', MODELS)), columns=keys)
    metric = expected.merge(metric, how='left', on=keys, validate='one_to_one')
    metric['n_dates'] = metric.n_dates.fillna(0).astype(int)
    metric['rmse_m3'] = np.sqrt(metric.pop('mse'))
    reference_keys = [k for k in keys if k != 'model']
    baseline = metric[metric.model.eq('persistence')][reference_keys + ['mae_m3']].rename(columns={'mae_m3': 'persistence_mae'})
    metric = metric.merge(baseline, on=reference_keys, validate='many_to_one')
    metric['zero_reference_mae'] = metric.persistence_mae.eq(0)
    metric['skill_vs_persistence'] = 1 - metric.mae_m3 / metric.persistence_mae.where(metric.persistence_mae.gt(0))
    return metric


def aggregate_station_metrics(metric):
    keys = ['evaluation_set', 'constraint', 'budget', 'horizon', 'model']
    rows = []
    for condition, g in metric.groupby(keys, sort=True):
        skill = g.skill_vs_persistence.dropna()
        wins = int(skill.gt(TIE_TOLERANCE).sum())
        losses = int(skill.lt(-TIE_TOLERANCE).sum())
        ties = int(skill.abs().le(TIE_TOLERANCE).sum())
        denominator = len(skill)
        rows.append(dict(zip(keys, condition), stations=len(g), stations_with_dates=int(g.n_dates.gt(0).sum()),
                         equal_station_mae_m3=float(g.mae_m3.mean()), equal_station_rmse_m3=float(g.rmse_m3.mean()),
                         mean_skill=float(skill.mean()), median_skill=float(skill.median()),
                         winning_stations=wins, tied_stations=ties, worse_stations=losses,
                         win_fraction=wins / denominator if denominator else np.nan,
                         tie_fraction=ties / denominator if denominator else np.nan,
                         loss_fraction=losses / denominator if denominator else np.nan,
                         defined_skill_stations=denominator, zero_reference_stations=int(g.zero_reference_mae.sum()),
                         min_dates=int(g.n_dates.min()), max_dates=int(g.n_dates.max())))
    return pd.DataFrame(rows)


def contrasts(cfg):
    models = cfg.get('models', MODELS)
    pairs = []
    def add(model, budget, reference, reference_budget, horizon, kind):
        if model not in models or reference not in models:
            return
        pairs.append(dict(id=f'{model}_B{budget}_vs_{reference}_B{reference_budget}_H{horizon}',
                          model=model, budget=budget, reference=reference, reference_budget=reference_budget,
                          horizon=horizon, kind=kind))
    shared_local = {
        'shared_ridge_lags': 'local_ridge_lags_tuned', 'shared_ridge_lags_bias': 'local_ridge_lags_tuned',
        'shared_residual_ridge_unshrunk': 'local_residual_ridge_unshrunk',
        'shared_residual_ridge_bias_unshrunk': 'local_residual_ridge_unshrunk',
        'shared_residual_ridge_selected': 'local_residual_ridge_selected',
        'shared_residual_ridge_bias_selected': 'local_residual_ridge_selected',
    }
    for horizon in cfg['horizons']:
        for budget in cfg['budgets']:
            for model in models:
                if model != 'persistence':
                    add(model, budget, 'persistence', budget, horizon, 'vs_persistence')
            for model, local in shared_local.items():
                add(model, budget, local, budget, horizon, 'same_budget_transfer')
            for family in ['local_residual_ridge', 'shared_residual_ridge', 'shared_residual_ridge_bias']:
                add(f'{family}_selected', budget, f'{family}_unshrunk', budget, horizon, 'selection_and_shrinkage_diagnostic')
            for model, reference in [
                ('local_residual_ridge_selected', 'local_ridge_lags_tuned'),
                ('shared_residual_ridge_selected', 'shared_ridge_lags'),
                ('shared_residual_ridge_bias_selected', 'shared_ridge_lags_bias'),
            ]:
                add(model, budget, reference, budget, horizon, 'residual_vs_direct_parameterization')
            add(PRIMARY_MODEL, budget, 'shared_residual_ridge_selected', budget, horizon, 'bias_and_selection_diagnostic')
            # Prespecified strengthened local-direct reference, in addition to
            # the matched local residual reference. Both share the date mask.
            add(PRIMARY_MODEL, budget, 'local_ridge_lags_tuned', budget, horizon, 'same_budget_transfer')
        for budget, reference_budget in [(30, 90), (30, 180), (90, 180)]:
            for model, local in shared_local.items():
                add(model, budget, local, reference_budget, horizon, 'history_budget_comparison')
            # The primary candidate must also beat a fairly tuned direct local method.
            add(PRIMARY_MODEL, budget, 'local_ridge_lags_tuned', reference_budget, horizon, 'history_budget_comparison')
    return pairs


def calendar_draw_indices(n_sites, n_episodes, length, block, replicates, seed):
    """Draw exactly in the old time-then-SiteID RNG order, retaining calendars."""
    if not 1 <= block <= length:
        raise ValueError('Block length exceeds fixed episode length')
    rng = np.random.default_rng(seed)
    for _ in range(replicates):
        time_indices = []
        for episode in range(n_episodes):
            starts = rng.integers(0, length - block + 1, size=int(np.ceil(length / block)))
            indices = (starts[:, None] + np.arange(block)[None, :]).ravel()[:length]
            time_indices.extend((indices + episode * length).tolist())
        yield rng.integers(0, n_sites, size=n_sites), np.asarray(time_indices)


def paired_block_intervals(daily, cfg, evaluation_set, constraint='raw', subset='all_dates'):
    sites = list(map(str, cfg['development_ids']))
    all_origins = evaluation_origins(cfg)
    episodes = [x for x in all_origins if (x in cfg['origins']) == (evaluation_set == 'original_development')]
    budgets = cfg['budgets']; models = list(cfg.get('models', MODELS)); length = cfg['evaluation_days']
    rows = []; station_rows = []
    if not episodes:
        return pd.DataFrame(), pd.DataFrame()
    comparisons = contrasts(cfg)
    part = daily[daily.evaluation_set.eq(evaluation_set) & daily.constraint.eq(constraint)]
    site_index = {v: i for i, v in enumerate(sites)}
    episode_index = {v: i for i, v in enumerate(episodes)}
    budget_index = {v: i for i, v in enumerate(budgets)}
    model_index = {v: i for i, v in enumerate(models)}
    for horizon in cfg['horizons']:
        shape = (len(sites), len(episodes) * length, len(budgets), len(models))
        errors = np.full(shape, np.nan)
        q = part[part.horizon.eq(horizon)]
        if not q.empty:
            day = (pd.to_datetime(q.origin) - pd.to_datetime(q.episode)).dt.days.to_numpy()
            errors[q.site_id.map(site_index).to_numpy(), q.episode.map(episode_index).to_numpy() * length + day,
                   q.budget.map(budget_index).to_numpy(), q.model.map(model_index).to_numpy()] = q.absolute_error
        original = nanmean(errors, axis=1)
        counts = np.isfinite(errors).sum(axis=1)
        active = [c for c in comparisons if c['horizon'] == horizon]
        for comparison in active:
            a = original[:, budget_index[comparison['budget']], model_index[comparison['model']]]
            b = original[:, budget_index[comparison['reference_budget']], model_index[comparison['reference']]]
            for index, site in enumerate(sites):
                skill = float(1 - a[index] / b[index]) if np.isfinite(a[index]) and b[index] > 0 else np.nan
                station_rows.append(dict(comparison, evaluation_set=evaluation_set, constraint=constraint, subset=subset,
                                         site_id=site, mae_m3=float(a[index]), reference_mae_m3=float(b[index]), skill=skill,
                                         n_dates=int(counts[index, budget_index[comparison['budget']], model_index[comparison['model']]]),
                                         reference_n_dates=int(counts[index, budget_index[comparison['reference_budget']], model_index[comparison['reference']]]),
                                         zero_reference_mae=bool(b[index] == 0),
                                         negative_transfer=bool(np.isfinite(skill) and skill < -TIE_TOLERANCE),
                                         win=bool(np.isfinite(skill) and skill > TIE_TOLERANCE),
                                         tie=bool(np.isfinite(skill) and abs(skill) <= TIE_TOLERANCE)))
        for block in cfg['bootstrap']['blocks']:
            seed = cfg['bootstrap']['seed'] + horizon * 100 + block
            replicates = cfg['bootstrap']['replicates']
            draws = np.empty((replicates, len(sites), len(budgets), len(models)))
            for replicate, (station_indices, time_indices) in enumerate(calendar_draw_indices(len(sites), len(episodes), length, block, replicates, seed)):
                draws[replicate] = nanmean(errors[station_indices][:, time_indices], axis=1)
            for comparison in active:
                model_budget = budget_index[comparison['budget']]; ref_budget = budget_index[comparison['reference_budget']]
                model_policy = model_index[comparison['model']]; ref_policy = model_index[comparison['reference']]
                a = draws[:, :, model_budget, model_policy]; b = draws[:, :, ref_budget, ref_policy]
                a0 = original[:, model_budget, model_policy]; b0 = original[:, ref_budget, ref_policy]
                with np.errstate(divide='ignore', invalid='ignore'):
                    samples = nanmean(np.where(b > 0, 1 - a / b, np.nan), axis=1)
                    station_skill = np.where(b0 > 0, 1 - a0 / b0, np.nan)
                usable = samples[np.isfinite(samples)]
                bounds = np.quantile(usable, [.025, .975, .0125, .9875, .00625, .99375]) if len(usable) else np.full(6, np.nan)
                primary = (comparison['model'] == PRIMARY_MODEL and comparison['budget'] == 30 and
                           comparison['reference'] == 'persistence' and constraint == 'raw' and subset == 'all_dates')
                rows.append(dict(comparison, evaluation_set=evaluation_set, constraint=constraint, subset=subset,
                                 block_days=block, replicates=replicates, finite_replicates=len(usable), bootstrap_seed=seed,
                                 mean_station_skill=float(nanmean(station_skill)),
                                 lower_95=float(bounds[0]), upper_95=float(bounds[1]),
                                 lower_bonferroni_2=float(bounds[2]) if primary else np.nan,
                                 upper_bonferroni_2=float(bounds[3]) if primary else np.nan,
                                 lower_bonferroni_4=float(bounds[4]) if primary else np.nan,
                                 upper_bonferroni_4=float(bounds[5]) if primary else np.nan,
                                 lower_ci=float(bounds[2 if primary else 0]), upper_ci=float(bounds[3 if primary else 1]),
                                 confidence_level=.975 if primary else .95, co_primary=primary,
                                 multiplicity_family='two horizons within evaluation set' if primary else 'exploratory pointwise',
                                 winning_stations=int(np.sum(station_skill > TIE_TOLERANCE)),
                                 tied_stations=int(np.sum(np.abs(station_skill) <= TIE_TOLERANCE)),
                                 negative_transfer_stations=int(np.sum(station_skill < -TIE_TOLERANCE)),
                                 defined_skill_stations=int(np.isfinite(station_skill).sum()),
                                 zero_reference_stations=int(np.sum(b0 == 0)),
                                 minimum_paired_dates=int(counts[:, model_budget, model_policy].min())))
    return pd.DataFrame(rows), pd.DataFrame(station_rows)


def summarize_predictions(frame, cfg, output):
    output = Path(output); output.mkdir(parents=True, exist_ok=True)
    p = prepare_predictions(frame, cfg)
    p.to_csv(output / 'predictions_all.csv.gz', index=False, compression={'method': 'gzip', 'mtime': 0})
    availability = p.groupby(['evaluation_set'] + TASK_KEYS).agg(
        planned_origins=('origin', 'size'), saved_prediction_rows=('prediction_row_present', 'sum'),
        valid_truths=('finite_truth', 'sum'), finite_predictions=('finite_prediction', 'sum'),
        common_dates=('common_evaluation', 'sum'),
        negative_predictions=('prediction_m3', lambda x: int(x.lt(0).sum()))).reset_index()
    availability['prediction_coverage'] = availability.finite_predictions / availability.planned_origins
    availability['matched_evaluation_coverage'] = availability.common_dates / availability.planned_origins
    availability.to_csv(output / 'availability.csv', index=False)
    p.loc[p.prediction_failure_reason.ne(''), ['evaluation_set'] + TASK_KEYS + ['origin', 'target_date', 'prediction_failure_reason']].to_csv(output / 'missing_or_failed_predictions.csv.gz', index=False, compression={'method': 'gzip', 'mtime': 0})
    paired = p.groupby(['evaluation_set'] + KEYS).agg(
        expected_condition_rows=('model', 'size'), common_evaluation=('common_evaluation', 'first'),
        saved_rows=('prediction_row_present', 'sum'), finite_predictions=('finite_prediction', 'sum'),
        truth_m3=('truth_m3', 'first'), high_threshold_m3=('high_threshold_m3', 'first')).reset_index()
    paired['high_volume'] = paired.truth_m3.ge(paired.high_threshold_m3) & paired.high_threshold_m3.notna()
    paired.to_csv(output / 'paired_evaluation_index.csv.gz', index=False, compression={'method': 'gzip', 'mtime': 0})
    common = p[p.common_evaluation].copy(); daily_frames = []
    for constraint, column in [('raw', 'prediction_m3'), ('all_models_nonnegative', 'prediction_nonnegative_m3')]:
        daily = common[['evaluation_set'] + KEYS + ['budget', 'model', 'seed', 'truth_m3', 'high_threshold_m3']].copy()
        error = common[column] - common.truth_m3
        daily['absolute_error'] = error.abs(); daily['squared_error'] = error ** 2
        daily['constraint'] = constraint; daily['seed_count'] = 1
        daily_frames.append(daily)
    daily = pd.concat(daily_frames, ignore_index=True)
    daily.to_csv(output / 'daily_losses.csv.gz', index=False, compression={'method': 'gzip', 'mtime': 0})
    metric = station_metrics(daily, cfg); metric.to_csv(output / 'metrics_by_station.csv', index=False)
    aggregate_station_metrics(metric).to_csv(output / 'summary.csv', index=False)
    high = daily[daily.truth_m3.ge(daily.high_threshold_m3) & daily.high_threshold_m3.notna()].copy()
    high_metric = station_metrics(high, cfg); high_metric.to_csv(output / 'high_volume_metrics_by_station.csv', index=False)
    aggregate_station_metrics(high_metric).to_csv(output / 'high_volume_summary.csv', index=False)
    all_ci = []; all_paired = []; high_ci = []; high_paired = []
    sets = list(p.evaluation_set.unique())
    for evaluation_set in sets:
        for constraint in ['raw', 'all_models_nonnegative']:
            ci, comparisons = paired_block_intervals(daily, cfg, evaluation_set, constraint, 'all_dates')
            all_ci.append(ci); all_paired.append(comparisons)
            ci, comparisons = paired_block_intervals(high, cfg, evaluation_set, constraint, 'historical_high_volume')
            high_ci.append(ci); high_paired.append(comparisons)
    ci = pd.concat(all_ci, ignore_index=True); comparisons = pd.concat(all_paired, ignore_index=True)
    ci.to_csv(output / 'paired_block_intervals.csv', index=False)
    comparisons.to_csv(output / 'paired_comparisons_by_station.csv', index=False)
    pd.concat(high_ci, ignore_index=True).to_csv(output / 'high_volume_block_intervals.csv', index=False)
    pd.concat(high_paired, ignore_index=True).to_csv(output / 'high_volume_paired_by_station.csv', index=False)
    transfer = comparisons[comparisons.kind.eq('same_budget_transfer')].groupby(
        ['evaluation_set', 'constraint', 'model', 'budget', 'horizon', 'reference']).agg(
        stations=('site_id', 'size'), defined_skill_stations=('skill', 'count'),
        mean_skill_vs_local=('skill', 'mean'), median_skill_vs_local=('skill', 'median'),
        negative_transfer_stations=('negative_transfer', 'sum'), winning_stations=('win', 'sum'), tied_stations=('tie', 'sum')).reset_index()
    transfer['negative_transfer_fraction'] = transfer.negative_transfer_stations / transfer.defined_skill_stations.where(transfer.defined_skill_stations.gt(0))
    transfer.to_csv(output / 'negative_transfer_summary.csv', index=False)
    zero_reference = comparisons[comparisons.zero_reference_mae].copy()
    zero_reference.to_csv(output / 'zero_reference_comparisons.csv', index=False)
    write_json(output / 'evaluation_validation.json', dict(
        status='completed', planned_prediction_rows=len(p), missing_prediction_rows=int((~p.prediction_row_present).sum()),
        common_groups=int(paired.common_evaluation.sum()), planned_groups=len(paired),
        deterministic_seed=0, seed_aggregation='No random-seed repetition or prediction ensemble; deterministic Ridge forecasts.',
        station_aggregation='Compute station MAE ratios first, then equally average finite station skills.',
        date_matching='One common mask across all registered methods and budgets; all missing calendars retained in paired index.',
        main_constraint='raw', sensitivity_constraint='max(0,prediction) uniformly for every method',
        zero_reference='Skill undefined when reference MAE=0; cases explicitly listed, not silently counted as wins.',
        numerical_truth_tolerance={'absolute_m3': 1e-8, 'relative': 1e-12}, tie_skill_tolerance=TIE_TOLERANCE,
        intervals='Synchronized noncircular calendar moving blocks per episode + whole-SiteID resampling. Conditional on this small development cohort.',
        multiplicity='Two co-primary horizons per evaluation set: 97.5% individual intervals; four-comparison sensitivity 98.75%. All other analyses pointwise exploratory.',
        physical_facility_independence_verified=False, final_2024_2025_performance_used=False,
        files_sha256={f.name: sha256(f) for f in sorted(output.iterdir()) if f.is_file() and f.name != 'evaluation_validation.json'}))
    return p, daily, metric, ci
