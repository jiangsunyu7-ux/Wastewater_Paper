"""Archive-integrity fixtures; these are not scientific observations."""
import gzip
import importlib.util
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


def module(name):
    spec = importlib.util.spec_from_file_location(name, ROOT/'scripts'/f'{name}.py')
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


pack = module('package_stage3b')
unpack = module('import_stage3b_delivery')


class DeliveryTests(unittest.TestCase):
    def test_checked_import_gzip_materialization_and_same_content_repeat(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            original = root/'original.csv'
            original.write_text('date,volume\n2022-01-01,1\n')
            compressed = root/'original.csv.gz'
            with gzip.open(compressed, 'wb') as f:
                f.write(original.read_bytes())
            name = 'reports/fixture.csv.gz'
            record = {name: dict(original_path='reports/fixture.csv', original_bytes=original.stat().st_size,
                                 original_sha256=unpack.digest(original))}
            receipt = pack.archive(root, 'Fixture', 1, 1, {name: compressed}, record)
            outer = root/'SHA256SUMS'
            outer.write_text(f"{receipt['sha256']}  {receipt['filename']}\n")
            target = root/'imported'
            result = unpack.import_archives([root/receipt['filename']], target, outer)
            self.assertEqual(result['status'], 'passed')
            self.assertEqual((target/'reports/fixture.csv').read_bytes(), original.read_bytes())
            unpack.import_archives([root/receipt['filename']], target, outer)
            (target/'reports/fixture.csv').write_text('different original')
            with self.assertRaises(FileExistsError):
                unpack.import_archives([root/receipt['filename']], target, outer)
            self.assertEqual((target/'reports/fixture.csv').read_text(), 'different original')

    def test_outer_hash_and_unsafe_paths_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            original = root/'original.txt'
            original.write_text('fixture only')
            receipt = pack.archive(root, 'Fixture', 1, 1, {'reports/fixture.txt': original}, {})
            outer = root/'SHA256SUMS'
            outer.write_text('0'*64+f"  {receipt['filename']}\n")
            with self.assertRaises(ValueError):
                unpack.import_archives([root/receipt['filename']], root/'imported', outer)
            for name in ['../escape', '/absolute', 'drive:file', 'a\\escape']:
                with self.assertRaises(ValueError):
                    unpack.safe_path(name)


if __name__ == '__main__':
    unittest.main()
