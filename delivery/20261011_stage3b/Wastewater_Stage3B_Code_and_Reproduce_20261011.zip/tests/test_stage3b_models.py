"""Meaningful software invariants, not scientific results from synthetic fixtures."""
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
import pandas as pd

from wastewater.shared_data import build_samples, load_series
from wastewater.stage3a_data import compact
from wastewater.stage3b_models import (FAMILIES, LinearModel, calibration_fold, candidate_scores,
    choose_parameters, estimate_bias, initial_data, reconstruct, residual_target, ridge_fit)
from wastewater.stage3b_experiment import run_cached, source_pool, validate

ROOT = Path(__file__).resolve().parents[1]


class Stage3BTests(unittest.TestCase):
    def setUp(self):
        self.cfg = json.loads((ROOT / "configs/stage3b_20261011_v1/full.json").read_text())

    def test_real_initial_budget_and_future_perturbation(self):
        series = load_series(ROOT / self.cfg["canonical_csv"], ["13013", "13015"])
        for site, s in series.items():
            for date in self.cfg["origins"]:
                for budget in self.cfg["budgets"]:
                    for horizon in self.cfg["horizons"]:
                        train, test, diag = initial_data(s, date, budget, horizon, self.cfg)
                        self.assertLessEqual(train.targets.max(), pd.Timestamp(date) - pd.Timedelta(days=1))
                        self.assertTrue((test.targets - test.origins == pd.Timedelta(days=horizon)).all())
                        changed = s.copy()
                        changed.loc[pd.Timestamp(date) + pd.Timedelta(days=1):] = 9e9
                        train2, test2, diag2 = initial_data(changed, date, budget, horizon, self.cfg)
                        np.testing.assert_array_equal(train.X, train2.X)
                        np.testing.assert_array_equal(train.y, train2.y)
                        np.testing.assert_array_equal(train.persistence, train2.persistence)
                        self.assertEqual(diag, diag2)
                        model = ridge_fit(compact(train.X), residual_target(train), .01)
                        model2 = ridge_fit(compact(train2.X), residual_target(train2), .01)
                        np.testing.assert_array_equal(model.coef_, model2.coef_)
                        np.testing.assert_array_equal(test.X[0], test2.X[0])
                        pred = reconstruct(test.persistence[:1], model.predict(compact(test.X[:1])), 0., .5, test.scale)
                        pred2 = reconstruct(test2.persistence[:1], model2.predict(compact(test2.X[:1])), 0., .5, test2.scale)
                        np.testing.assert_array_equal(pred, pred2)

    def test_validation_scaling_bias_and_choice_ignore_post_budget(self):
        s = load_series(ROOT / self.cfg["canonical_csv"], ["13013"])["13013"]
        source = {a: LinearModel(np.array([.1, -.1, 0., 0., 0., 0.]), .005) for a in self.cfg["ridge_alphas"]}
        for budget in [90, 180]:
            for horizon in [1, 3]:
                tr, val, d = calibration_fold(s, "2022-01-01", budget, horizon, self.cfg)
                self.assertTrue(d["valid"])
                self.assertLess(tr.targets.max(), val.origins.min())
                self.assertLessEqual(val.targets.max(), pd.Timestamp("2021-12-31"))
                changed = s.copy(); changed.loc["2022-01-01":] = 1e8
                tr2, val2, d2 = calibration_fold(changed, "2022-01-01", budget, horizon, self.cfg)
                self.assertEqual(d, d2)
                choices = choose_parameters(candidate_scores(tr, val, source, self.cfg))
                choices2 = choose_parameters(candidate_scores(tr2, val2, source, self.cfg))
                self.assertEqual(choices, choices2)
                changed_validation = s.copy(); changed_validation.loc[d["validation_start"]:d["budget_end"]] = 1e8
                tr3, _, d3 = calibration_fold(changed_validation, "2022-01-01", budget, horizon, self.cfg)
                self.assertEqual(d["scale_m3"], d3["scale_m3"])
                self.assertEqual(estimate_bias(source[.01], tr), estimate_bias(source[.01], tr3))
                np.testing.assert_array_equal(tr.X, tr3.X)

    def test_residual_formula_lambda_zero_and_weekly_h3_alignment(self):
        s = pd.Series(np.arange(1., 101.), index=pd.date_range("2020-01-01", periods=100))
        s.loc["2020-02-10"] = np.nan
        data = build_samples(s, [pd.Timestamp("2020-02-10")], 3, "2020-01-01", 10.)
        self.assertEqual(data.persistence[0], s.loc["2020-02-09"])
        self.assertEqual(data.weekly[0], s.loc["2020-02-06"])
        self.assertEqual(data.targets[0], pd.Timestamp("2020-02-13"))
        residual = residual_target(data)
        reconstructed = reconstruct(data.persistence, residual, 0., 1., 10.)
        np.testing.assert_array_equal(reconstructed, data.y * 10.)
        baseline = np.array([0., 4., np.nan])
        np.testing.assert_array_equal(reconstruct(baseline, [np.nan, np.nan, np.nan], np.nan, 0., 3.), baseline)

    def test_weighted_mean_mse_and_intercept_unpenalized(self):
        rng = np.random.default_rng(137)
        X = rng.normal(size=(23, 6)); y = rng.normal(size=23); w = np.arange(1., 24.); w /= w.sum()
        alpha = .1
        model = ridge_fit(X, y, alpha, w)
        xmean, ymean = w @ X, float(w @ y)
        centered = X - xmean
        expected = np.linalg.solve(centered.T @ (w[:, None] * centered) + alpha * np.eye(6),
                                   centered.T @ (w * (y-ymean)))
        np.testing.assert_allclose(model.coef_, expected, atol=1e-12, rtol=1e-12)
        self.assertAlmostEqual(model.intercept_, ymean - xmean @ expected)
        shifted = ridge_fit(X, y + 20., alpha, w)
        np.testing.assert_allclose(shifted.coef_, model.coef_, atol=1e-12, rtol=1e-12)
        self.assertAlmostEqual(shifted.intercept_ - model.intercept_, 20.)
        with self.assertRaises(ValueError): ridge_fit(X, y, alpha, w * 2)
        series = load_series(ROOT / self.cfg["canonical_csv"], self.cfg["source_ids"])
        _, _, _, weights, diagnostics = source_pool(series, self.cfg, 3, "2020-12-31", self.cfg["source_ids"])
        self.assertAlmostEqual(weights.sum(), 1.)
        for d in diagnostics: self.assertAlmostEqual(d["weight_sum"], 1/3)

    def test_tie_selection_and_immutable_resume(self):
        rows = [dict(family=family, alpha=a, shrinkage=lam, validation_mae=1.)
                for family in FAMILIES for a in self.cfg["ridge_alphas"] for lam in self.cfg["lambdas"]]
        choices = choose_parameters(rows)
        for name, choice in choices.items():
            self.assertEqual(choice["alpha"], .0001)
            self.assertEqual(choice["shrinkage"], 1. if name.endswith("unshrunk") else 0.)
        with tempfile.TemporaryDirectory() as temp:
            folder = Path(temp) / "job"
            calls = []
            def operation(p):
                calls.append("fit")
                m = ridge_fit(np.arange(30.).reshape(5, 6), np.arange(5.), .1)
                np.savez(p / "fit.npz", coef=m.coef_, intercept=m.intercept_)
            self.assertEqual(run_cached(folder, "frozen", operation), "completed")
            self.assertEqual(run_cached(folder, "frozen", lambda _: self.fail("Cached task was recalculated")), "cached")
            self.assertEqual(len(calls), 1)
            with self.assertRaises(ValueError): run_cached(folder, "changed", operation)
            (folder / "fit.npz").write_bytes(b"corrupt")
            with self.assertRaises(ValueError): run_cached(folder, "frozen", operation)
            reference = Path(temp) / "reference"
            partial = Path(temp) / "partial"
            self.assertEqual(run_cached(reference, "same", operation), "completed")
            self.assertEqual(run_cached(partial, "same", lambda _: (_ for _ in ()).throw(RuntimeError("simulated interruption"))), "failed")
            self.assertEqual(run_cached(partial, "same", operation), "completed")
            with np.load(reference / "fit.npz") as a, np.load(partial / "fit.npz") as b:
                np.testing.assert_array_equal(a["coef"], b["coef"])
                np.testing.assert_array_equal(a["intercept"], b["intercept"])

    def test_frozen_boundaries_and_final_period_rejected(self):
        validate(self.cfg)
        invalid = dict(self.cfg, origins=["2024-01-01"])
        with self.assertRaises(ValueError): validate(invalid)
        invalid = dict(self.cfg, source_selection_train_end="2021-12-31")
        with self.assertRaises(ValueError): validate(invalid)


if __name__ == "__main__":
    unittest.main()
