import unittest

import numpy as np
import pandas as pd

from wastewater.stage3b_evaluation import (
    PRIMARY_MODEL, aggregate_station_metrics, calendar_draw_indices,
    paired_block_intervals, prepare_predictions, station_metrics,
)


class Stage3BEvaluationTests(unittest.TestCase):
    def config(self):
        return dict(development_ids=['a', 'b'], origins=['2023-01-01'],
                    budgets=[30, 90, 180], horizons=[1, 3], evaluation_days=4,
                    models=['persistence', PRIMARY_MODEL],
                    bootstrap=dict(blocks=[2], replicates=30, seed=17))

    def predictions(self):
        cfg = self.config(); rows = []
        for site, truth, reference_error, candidate_error in [('a', 10., 1., .5), ('b', 1000., 100., 150.)]:
            for budget in cfg['budgets']:
                for horizon in cfg['horizons']:
                    for origin in pd.date_range(cfg['origins'][0], periods=cfg['evaluation_days']):
                        for model, error in [('persistence', reference_error), (PRIMARY_MODEL, candidate_error)]:
                            rows.append(dict(site_id=site, episode=cfg['origins'][0], budget=budget,
                                             horizon=horizon, origin=str(origin.date()),
                                             target_date=str((origin + pd.Timedelta(days=horizon)).date()),
                                             model=model, seed=0, truth_m3=truth, prediction_m3=truth + error,
                                             high_threshold_m3=truth, fit_end='2022-12-31',
                                             last_train_target='2022-12-31', latest_input_date=str(origin.date())))
        return pd.DataFrame(rows)

    def daily(self, p):
        p = p[p.common_evaluation].copy()
        p['constraint'] = 'raw'; error = p.prediction_m3 - p.truth_m3
        p['absolute_error'] = error.abs(); p['squared_error'] = error ** 2
        return p

    def test_equal_station_skill_not_ratio_of_pooled_volumes(self):
        cfg = self.config(); daily = self.daily(prepare_predictions(self.predictions(), cfg))
        metric = station_metrics(daily, cfg)
        summary = aggregate_station_metrics(metric)
        result = summary[summary.model.eq(PRIMARY_MODEL) & summary.budget.eq(30) & summary.horizon.eq(1) & summary.constraint.eq('raw')].iloc[0]
        self.assertAlmostEqual(result.mean_skill, 0.)  # (+.5 -.5)/2.
        self.assertNotAlmostEqual(result.mean_skill, 1 - 150.5 / 101.)
        self.assertEqual(result.winning_stations, 1); self.assertEqual(result.worse_stations, 1)

    def test_missing_task_rows_preserved_and_dates_matched_across_budgets(self):
        cfg = self.config(); p = self.predictions()
        # Entire model condition missing: it cannot silently change its date set.
        absent = p.site_id.eq('a') & p.model.eq(PRIMARY_MODEL) & p.budget.eq(30) & p.horizon.eq(1)
        result = prepare_predictions(p[~absent], cfg)
        self.assertEqual(len(result), len(p))
        self.assertEqual(int((~result.prediction_row_present).sum()), 4)
        self.assertFalse(result[result.site_id.eq('a') & result.horizon.eq(1)].common_evaluation.any())
        self.assertTrue(result[result.site_id.eq('b')].common_evaluation.all())

    def test_zero_reference_is_undefined_and_reported(self):
        cfg = self.config(); p = self.predictions()
        baseline = p.model.eq('persistence') & p.site_id.eq('a')
        p.loc[baseline, 'prediction_m3'] = p.loc[baseline, 'truth_m3']
        metric = station_metrics(self.daily(prepare_predictions(p, cfg)), cfg)
        candidate = metric[metric.site_id.eq('a') & metric.model.eq(PRIMARY_MODEL) & metric.constraint.eq('raw')]
        self.assertTrue(candidate.zero_reference_mae.all())
        self.assertTrue(candidate.skill_vs_persistence.isna().all())

    def test_calendar_blocks_and_bonferroni_point_are_correct(self):
        cfg = self.config(); p = prepare_predictions(self.predictions(), cfg)
        ci, pairs = paired_block_intervals(self.daily(p), cfg, 'original_development')
        primary = ci[ci.co_primary]
        self.assertEqual(len(primary), 2)
        self.assertTrue(primary.confidence_level.eq(.975).all())
        np.testing.assert_allclose(primary.mean_station_skill, 0.)
        self.assertTrue((primary.lower_bonferroni_2 <= primary.lower_95).all())
        self.assertTrue((primary.upper_bonferroni_2 >= primary.upper_95).all())
        self.assertTrue(pairs.n_dates.eq(4).all())
        draws = list(calendar_draw_indices(2, 2, 4, 2, 3, 9))
        repeat = list(calendar_draw_indices(2, 2, 4, 2, 3, 9))
        for (sites, dates), (sites2, dates2) in zip(draws, repeat):
            np.testing.assert_array_equal(sites, sites2); np.testing.assert_array_equal(dates, dates2)
            self.assertTrue((dates[:4] < 4).all()); self.assertTrue((dates[4:] >= 4).all())

    def test_alignment_and_uniform_constraint_reject_invalid_values(self):
        cfg = self.config(); p = self.predictions()
        p.loc[0, 'target_date'] = '2023-01-04'
        with self.assertRaises(ValueError): prepare_predictions(p, cfg)
        p = self.predictions(); p['prediction_nonnegative_m3'] = p.prediction_m3
        p.loc[0, 'prediction_nonnegative_m3'] += .01
        with self.assertRaises(ValueError): prepare_predictions(p, cfg)

    def test_unauthorized_extra_window_rejected_and_missing_rows_survive_recompute(self):
        cfg = self.config(); p = self.predictions()
        cfg['evaluation_origins'] = cfg['origins'] + ['2023-10-01']
        with self.assertRaises(ValueError): prepare_predictions(p, cfg)
        cfg = self.config()
        missing = p.site_id.eq('a') & p.horizon.eq(1) & p.budget.eq(30) & p.model.eq(PRIMARY_MODEL)
        first = prepare_predictions(p[~missing], cfg)
        second = prepare_predictions(first, cfg)
        self.assertEqual(int((~second.prediction_row_present).sum()), 4)
        np.testing.assert_array_equal(first.common_evaluation, second.common_evaluation)


if __name__ == '__main__':
    unittest.main()
