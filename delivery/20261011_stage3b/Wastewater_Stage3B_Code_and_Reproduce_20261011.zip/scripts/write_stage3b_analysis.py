"""Write the Chinese interpretation and English claim ledger from saved results.

This script reads completed results. It does not train, select policies, change
the frozen protocol, or generate any quantitative experimental observations.
"""
import argparse
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd

from wastewater.common import sha256


PRIMARY = 'shared_residual_ridge_bias_selected'
WINDOWS = ['original_development', 'additional_time_validation']
WINDOW_NAMES = {'original_development': '重复使用的开发窗口', 'additional_time_validation': '追加时间验证'}
LOCAL_RESIDUAL = 'local_residual_ridge_selected'
LOCAL_DIRECT = 'local_ridge_lags_tuned'


def percent(value):
    return f'{float(value) * 100:+.2f}%' if pd.notna(value) else '未定义'


def interval(row, suffix='ci'):
    return f'[{percent(row[f"lower_{suffix}"])}, {percent(row[f"upper_{suffix}"])}]'


def table(headers, rows):
    return '\n'.join(['| ' + ' | '.join(headers) + ' |', '| ' + ' | '.join(['---'] * len(headers)) + ' |'] +
                     ['| ' + ' | '.join(map(str, row)) + ' |' for row in rows])


def load_json(path):
    return json.loads(Path(path).read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--version', default='stage3b_20261011_v1')
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    out = root / 'reports' / args.version
    results = out / 'results'
    cfg_path = root / 'configs' / args.version / 'full.json'
    cfg = load_json(cfg_path)
    manifest = load_json(root / cfg['output'] / 'manifest.json')
    evaluation = load_json(results / 'evaluation_validation.json')
    independent = load_json(out / 'audit' / 'STAGE3B_INDEPENDENT_CHECK.json')
    if manifest['status'] != 'completed' or evaluation['status'] != 'completed' or independent['status'] != 'passed':
        raise ValueError('Actual full execution, evaluation and independent checks are required')
    for filename, expected in evaluation['files_sha256'].items():
        if sha256(results / filename) != expected:
            raise ValueError(f'Evaluation artifact changed: {filename}')
    summary = pd.read_csv(results / 'summary.csv')
    metrics = pd.read_csv(results / 'metrics_by_station.csv', dtype={'site_id': str})
    comparisons = pd.read_csv(results / 'paired_comparisons_by_station.csv', dtype={'site_id': str})
    ci = pd.read_csv(results / 'paired_block_intervals.csv')
    high_metric = pd.read_csv(results / 'high_volume_metrics_by_station.csv', dtype={'site_id': str})
    high_ci = pd.read_csv(results / 'high_volume_block_intervals.csv')
    params = pd.read_csv(results / 'parameter_selections.csv', dtype={'site_id': str})
    diagnoses = pd.read_csv(results / 'training_diagnostics.csv', dtype={'site_id': str})
    quality = load_json(root / 'data' / 'provenance' / args.version / 'data_provenance_audit.json')
    facility = load_json(root / 'data' / 'provenance' / args.version / 'FACILITY_REVIEW_STATUS.json')
    history = load_json(out / 'audit' / 'historical_window_eligibility.json')
    collection = load_json(results / 'DIAGNOSTIC_COLLECTION_CHECK.json')
    first_run = load_json(out / 'software' / 'full_first_run_manifest.json')
    eval_run = load_json(out / 'software' / 'EVALUATION_RUN_RECEIPT.json')
    resume = load_json(out / 'software' / 'FULL_RESUME_CHECK.json')
    smoke = load_json(out / 'software' / 'SMOKE_CHECK.json')
    notebook = load_json(out / 'software' / 'NOTEBOOK_LOCAL_CHECK.json')
    stage3a_summary = pd.read_csv(root / 'reports/stage3a_20261010/results/summary.csv')
    qcounts = quality['quality_counts']
    models = cfg['models']
    raw_ci = ci[ci.constraint.eq('raw') & ci.block_days.eq(14)]

    def ci_row(window, model=PRIMARY, budget=30, horizon=1, reference='persistence', reference_budget=None):
        reference_budget = budget if reference_budget is None else reference_budget
        q = raw_ci[raw_ci.evaluation_set.eq(window) & raw_ci.model.eq(model) & raw_ci.budget.eq(budget) &
                   raw_ci.horizon.eq(horizon) & raw_ci.reference.eq(reference) & raw_ci.reference_budget.eq(reference_budget)]
        if len(q) != 1:
            raise ValueError('Expected one predeclared comparison: ' + str((window, model, budget, horizon, reference, reference_budget)))
        return q.iloc[0]

    def metric_rows(window, model=PRIMARY, budget=30, horizon=1):
        return metrics[metrics.evaluation_set.eq(window) & metrics.constraint.eq('raw') & metrics.model.eq(model) &
                       metrics.budget.eq(budget) & metrics.horizon.eq(horizon)]

    primary_rows = []
    for window in WINDOWS:
        if window not in summary.evaluation_set.unique():
            continue
        for horizon in cfg['horizons']:
            c = ci_row(window, horizon=horizon)
            m = metric_rows(window, horizon=horizon)
            primary_rows.append([WINDOW_NAMES[window], horizon, f'{m.mae_m3.mean():.2f}', f'{m.rmse_m3.mean():.2f}',
                                 percent(c.mean_station_skill), interval(c),
                                 f'{int(c.winning_stations)}/{int(c.tied_stations)}/{int(c.negative_transfer_stations)}'])
    primary_table = table(['窗口', 'h', '等权MAE(m³)', '等权RMSE(m³)', '平均逐SiteID技能', '97.5%区间', '胜/平/负'], primary_rows)
    original_h3 = ci_row('original_development', horizon=3)
    additional_h3 = ci_row('additional_time_validation', horizon=3)
    original_h1 = ci_row('original_development', horizon=1)
    additional_h1 = ci_row('additional_time_validation', horizon=1)

    selected_primary = params[params.model.eq(PRIMARY)]
    b30 = selected_primary[selected_primary.budget.eq(30)]
    b30_h1 = b30[b30.horizon.eq(1)]
    b30_h3 = b30[b30.horizon.eq(3)]
    negative_rows = []; negative_groups = {}
    for window in WINDOWS:
        for horizon in cfg['horizons']:
            for reference in [LOCAL_RESIDUAL, LOCAL_DIRECT]:
                q = comparisons[comparisons.evaluation_set.eq(window) & comparisons.constraint.eq('raw') &
                                comparisons.model.eq(PRIMARY) & comparisons.budget.eq(30) & comparisons.horizon.eq(horizon) &
                                comparisons.reference.eq(reference) & comparisons.reference_budget.eq(30)]
                negative = q.loc[q.negative_transfer, 'site_id'].tolist()
                negative_groups[(window, horizon, reference)] = set(negative)
                negative_rows.append([WINDOW_NAMES[window], horizon, '本地残差' if reference == LOCAL_RESIDUAL else '本地直接体积',
                                      percent(q.skill.mean()), f'{len(negative)}/{q.skill.notna().sum()}', ', '.join(negative) or '无'])
    negative_table = table(['窗口', 'h', '相同B30参照', '平均技能', '负迁移站数', '负迁移SiteID'], negative_rows)
    persistent_h1 = sorted(negative_groups[('original_development', 1, LOCAL_RESIDUAL)] & negative_groups[('additional_time_validation', 1, LOCAL_RESIDUAL)])
    persistent_h3 = sorted(negative_groups[('original_development', 3, LOCAL_RESIDUAL)] & negative_groups[('additional_time_validation', 3, LOCAL_RESIDUAL)])
    below_p_extra = metric_rows('additional_time_validation', horizon=3).query('skill_vs_persistence < -1e-12').site_id.tolist()

    cross_rows = []
    for window in WINDOWS:
        for budget, reference_budget in [(30, 90), (30, 180), (90, 180)]:
            for horizon in cfg['horizons']:
                for reference in [LOCAL_RESIDUAL, LOCAL_DIRECT]:
                    c = ci_row(window, budget=budget, horizon=horizon, reference=reference, reference_budget=reference_budget)
                    cross_rows.append([WINDOW_NAMES[window], f'{budget}→{reference_budget}', horizon,
                                       '本地残差' if reference == LOCAL_RESIDUAL else '本地直接体积',
                                       percent(c.mean_station_skill), interval(c), f'{int(c.winning_stations)}/{int(c.defined_skill_stations)}'])
    cross_table = table(['窗口', '共享B→本地B', 'h', '本地参照', '平均技能', '探索性95%区间', '获益站数'], cross_rows)

    all_budget_rows = []
    for window in WINDOWS:
        for budget in [90, 180]:
            for horizon in cfg['horizons']:
                c = ci_row(window, budget=budget, horizon=horizon)
                f = selected_primary[selected_primary.budget.eq(budget) & selected_primary.horizon.eq(horizon)]
                f = f[f.episode.isin(cfg['origins'])] if window == 'original_development' else f[~f.episode.isin(cfg['origins'])]
                all_budget_rows.append([WINDOW_NAMES[window], budget, horizon, percent(c.mean_station_skill), interval(c),
                                        f'{int(c.winning_stations)}/{int(c.defined_skill_stations)}',
                                        f'{int(f.shrinkage.eq(0).sum())}/{len(f)}'])
    budget_table = table(['窗口', 'B', 'h', '对Persistence技能', '探索性95%区间', '获益站数', 'λ=0条件数'], all_budget_rows)

    policy_rows = []
    for model in models:
        values = []
        for window in WINDOWS:
            for horizon in cfg['horizons']:
                q = summary[summary.evaluation_set.eq(window) & summary.constraint.eq('raw') & summary.budget.eq(30) &
                            summary.horizon.eq(horizon) & summary.model.eq(model)]
                values.append(percent(q.iloc[0].mean_skill))
        policy_rows.append([model, *values])
    policy_table = table(['B30策略', '原h1', '原h3', '追加h1', '追加h3'], policy_rows)
    no_bias_extra = ci_row('additional_time_validation', model='shared_residual_ridge_selected', horizon=3)
    no_bias_original = ci_row('original_development', model='shared_residual_ridge_selected', horizon=3)

    high_rows = []
    for window in WINDOWS:
        for horizon in cfg['horizons']:
            q = high_metric[high_metric.evaluation_set.eq(window) & high_metric.constraint.eq('raw') &
                            high_metric.model.eq(PRIMARY) & high_metric.budget.eq(30) & high_metric.horizon.eq(horizon)]
            c = high_ci[high_ci.evaluation_set.eq(window) & high_ci.constraint.eq('raw') & high_ci.block_days.eq(14) &
                        high_ci.model.eq(PRIMARY) & high_ci.budget.eq(30) & high_ci.horizon.eq(horizon) &
                        high_ci.reference.eq('persistence') & high_ci.reference_budget.eq(30)].iloc[0]
            high_rows.append([WINDOW_NAMES[window], horizon, percent(c.mean_station_skill), interval(c, '95'),
                              f'{int(q.n_dates.min())}–{int(q.n_dates.max())}', int(q.n_dates.sum())])
    high_table = table(['窗口', 'h', '高体积技能', '探索性95%区间', '逐SiteID日期数', '总SiteID-日期数'], high_rows)
    unique_diagnostics = diagnoses.drop_duplicates(['site_id', 'episode', 'budget', 'horizon'])
    budget_rows = []
    for (budget, horizon), g in unique_diagnostics.groupby(['budget', 'horizon']):
        budget_rows.append([budget, horizon, f'{int(g.initial_training_labels.min())}–{int(g.initial_training_labels.max())}',
                            f'{int(g.attempted_target_cv_fitting_labels.min())}–{int(g.attempted_target_cv_fitting_labels.max())}',
                            f'{int(g.attempted_target_cv_validation_labels.min())}–{int(g.attempted_target_cv_validation_labels.max())}',
                            '6折源辅助伪部署；每折14标签' if budget == 30 else '预算内时间顺序验证'])
    training_table = table(['日历B', 'h', '最终目标拟合标签', '尝试的本地CV拟合标签', '尝试的本地CV验证标签', '实际选择来源'], budget_rows)

    primary_raw = summary[summary.constraint.eq('raw') & summary.model.eq(PRIMARY)].set_index(['evaluation_set', 'budget', 'horizon'])
    primary_clip = summary[summary.constraint.eq('all_models_nonnegative') & summary.model.eq(PRIMARY)].set_index(['evaluation_set', 'budget', 'horizon'])
    primary_clip_change = float((primary_raw.mean_skill - primary_clip.mean_skill).abs().max())
    negative_prediction_count = int(pd.read_csv(results / 'availability.csv').negative_predictions.sum())
    old_learning = stage3a_summary[stage3a_summary.constraint.eq('raw') & ~stage3a_summary.model.isin(['persistence', 'weekly_persistence'])]
    test_text = (out / 'software' / 'full_unit_tests.log').read_text()
    n_tests = int(re.findall(r'Ran (\d+) tests', test_text)[-1])
    prose = f'''# Stage3A证据核验与Stage3B受控开发实验分析

当前没有支持主要候选稳定超越Persistence的证据。B30共享残差Ridge+bias+合法验证选择λ，在h1对全部条件选择回退，逐条返回Persistence；h3在原窗口为{percent(original_h3.mean_station_skill)}、追加窗口为{percent(additional_h3.mean_station_skill)}，两项区间均跨零。加强后的本地残差对照也使“共享一定节省历史”的判断变为参照与窗口依赖。所有固定设施、预算、时距、失败记录和负结果保留；本轮停止，不追搜正收益。

## 实际完成与Stage3A核验结论

实际接受的Stage3A版本为stage3a_20261010_v3，已运行共享Ridge、紧凑GRU、本地拟合/冻结头适应及有限选参，不再沿用“只有三个基线”的旧描述。本轮从388800条预测独立重算逐日损失、1800项逐SiteID指标、180项汇总、高体积与同步日历块区间；独立重拟合960项Ridge并从保存的所选权重执行2160项GRU前向预测。未发现改变主要结论的数值、日期配对或时间泄漏错误；原{len(old_learning)}项学习策略—预算—时距等权技能均为负。没有重新训练全部GRU优化轨迹，不能称所有实验均从原始输入从头复现。

需要修正的是复现措辞与证据范围：Stage2/Stage3A跨执行存在微小GRU端点漂移，接受容差发生在源阶段预检之后、目标部署评价之前，不能写原始预注册或逐位一致。原缓存只核验顶层文件；本轮另做前向和冻结编码器检查，Stage3B递归核验成员。新审计元数据曾有SHA自引用问题，旧失败副本保留后只修正审计元数据，没有改变科学数组。完整详情见[STAGE3A_EVIDENCE_AUDIT.md](../../STAGE3A_EVIDENCE_AUDIT.md)。

Stage3B实际完成原13013/13015的{smoke['smoke_conditions']}个两站流程检查，以及{manifest['completed_conditions']}/{manifest['expected_conditions']}完整条件：10 SiteID×5窗口×3预算×2时距。固定11策略，无新增GRU种子或网络；{evaluation['planned_prediction_rows']}条逐条预测、{independent['daily_losses']}条原始/统一非负逐日损失、{independent['station_metric_checks']}项逐站指标，科学任务失败{manifest['failed_conditions']}，缺失任务行{evaluation['missing_prediction_rows']}。共同评价日期为原4713/4800组、追加1180/1200组；缺失位置保留在日历块与配对索引中。原五个直接体积/简单基线对照重新跑在同一规则上，72000归档行数值复现最大差约{collection['archived_controls']['compared_columns'][0]['maximum_absolute_difference_m3']:.3g}m³，按归一化1e-10容差通过，并非逐位一致；原窗口日期掩码完全一致。

独立核验{independent['linear_prediction_reconstruction_checks']}项线性预测重构、{independent['independent_source_normal_equation_checks']}项带权源正规方程、{independent['lambda_zero_exact_prediction_checks']}条λ=0精确回退均通过。{n_tests}项自动化测试通过，另有缓存、来源摘录清理及安全导入检查。完整续跑{resume['counts_this_call']['cached']}条件全部缓存、无重新拟合，{resume['verified_members']}成员SHA不变。Colab notebook有{notebook['code_cells_compiled']}个代码单元本地编译，配置/核心测试单元实际执行；真实Colab登录、Drive挂载、安装单元与云端科研重跑未核验。未执行最终2024–2025性能、源池扩充实验、GRU重训、预测区间、集成、正式App或论文重写。

## 信息预算、目标与数据

源SiteID为{', '.join(cfg['source_ids'])}；目标为{', '.join(cfg['development_ids'])}。最终共享源训练为2016–2021；2021伪部署采用其他两个源站且训练≤2020的代理，伪目标不进入共享训练。B90/180目标CV也采用≤2020代理以避免迟2021目标验证看到未来源数据。最终代理与全部2016–2021源拟合时期不同，已明确披露。

B是首个起点前初始连续日历建模历史，不是每日起点重新拟合最近B天。尺度、模型、bias、alpha和λ冻结60日起点；部署中新到达且起点已知的体积仅更新输入滞后。训练标签≤各自截止日，内部验证训练标签严格早于验证起点；验证尺度/bias只用该折拟合前缀。源辅助选参意味着本地模型并非完全不用源信息，但其系数仍只在预算内本地拟合。h3是第3天当天体积，weekly baseline读origin+h−7。

{training_table}

B30本地CV标签不足，上表为尝试的目标CV计数，不能冒充实际源辅助验证数。源辅助各时距实际用3个留出源站×2个2021起点×14日期={int(b30_h1.actual_selection_validation_labels.iloc[0])}标签，按6折等权选择。B30主要候选h1统一α={b30_h1.alpha.iloc[0]:g},λ={b30_h1.shrinkage.iloc[0]:g}；h3统一α={b30_h3.alpha.iloc[0]:g},λ={b30_h3.shrinkage.iloc[0]:g}。它们对各{len(b30_h1)}/{len(b30_h3)}设施—窗口条件相同，是冻结源辅助规则的结果，不是根据目标部署误差逐站挑回退。

官方TDV定义是WRC许可排口处理后每日体积，单位m³；模型评价对象是发布数据的有效观测，而非独立仪表真值。固定13站{qcounts['raw_rows']}记录中保留{qcounts['valid_good_targets']}个Good非负目标、{qcounts['Good_zero_retained']}个Good真实零；屏蔽Missing零{qcounts['Missing_zero']}、Missing非零{qcounts['Missing_nonzero']}、Good负值{qcounts['Good_negative']}、Suspect{qcounts['Suspect']}。输入和标签同规则，不插值目标、不未来填输入；所选队列重复/冲突为0，不意味着全库没有冲突。

这是发布后质量标记的历史回顾实验。{facility['official_requests']}次官方查询、{facility['valid_json_successes']}次有效响应仍未建立TDV正常处理后排口与物理设施身份。暴雨溢流结构关联不能补成TDV排口或新特征；全部物理ID仍unknown，不能称独立水厂外部验证。每日体积/QA首次到达与修订记录未知，日终可读是情景假设，不是实时部署证明。曾全量描述性检查2024–2025须披露；本轮未计算该时期预测性能或用其选模。

## 是否超过Persistence，以及其他预算

主要候选始终是共享残差+bias+selected，B30/h1和h3。下表技能先每SiteID算1−MAE/参考MAE，再等权汇总，不是总体体积误差比。RMSE也是逐SiteID先计算后等权平均。14日同步日历块+整SiteID重采样1000次；两时距采用97.5%个别Bonferroni区间。参考MAE=0时技能明示未定义，本轮未出现该情况。

{primary_table}

h1的0区间来自显式返回同一Persistence预测，是算法上的逐条相同，不是对未知总体的统计等效证明，也不是共享信息的预测增益。h3原窗口只有{int(original_h3.winning_stations)}/10站胜、追加{int(additional_h3.winning_stations)}/10站胜；追加低于Persistence的是{', '.join(below_p_extra)}。共同覆盖两套时间窗口与两个时距的四比较98.75%个别区间，原h3{interval(original_h3, 'bonferroni_4')}、追加h3{interval(additional_h3, 'bonferroni_4')}，仍跨零。7/28日块敏感性全部保存，不能挑最窄区间替代14日主结果。

B90/180属于预定次要、探索性评价；不将其最好结果改成B30主要候选：

{budget_table}

原B180/h1有一个小幅正向探索性区间，但追加窗口不支持稳定正区间，且大量比较未统一控制错误率。不能由某一预算胜出声称普遍工程实用。区间跨零也不能解释为等效，现阶段没有经过工程依据验证的最小有用改善阈值。

## 是否超过公平本地模型、负迁移是否一致

{negative_table}

对加强的本地残差参照，原与追加都负迁移的h1 SiteID为{', '.join(persistent_h1)}；h3为{', '.join(persistent_h3)}。这是各窗口日期汇总的关联，不是每一天都失败或已查明物理原因。相对Persistence的负技能、相对本地残差的负迁移、相对较弱本地直接模型的正数是三种不同事实，不能混写。h1回退Persistence仍可能输给真正改善的本地残差模型；λ=0绝不保证没有负迁移。

## 是否减少本地建模历史：全部预定跨预算比较

下表保留30→90、30→180、90→180及两个时距，两套窗口；使用相同设施、预测日期、阈值与允许的信息。区间为探索性95%，不是非劣性或等效检验。

{cross_table}

共享短预算超过本地直接体积Ridge的比较较多，但对更强本地残差参照，原窗口共享30天普遍不能获得正技能或正区间。追加部分比较变正，其他区间仍宽且跨零。h1主要策略就是Persistence回退，因此其相对弱模型的历史效率不能归因为共享系数。能够保留的是**特定方法参照下的相对历史效率**；应放弃“已证明跨厂信息普遍减少达到实用质量所需历史”的表述。

## 改善来自什么、训练设置仍有哪些不确定性

{policy_table}

以上完整B30消融/对照表不事后更换主要候选。共享无bias残差selected的h3在追加窗口为{percent(no_bias_extra.mean_station_skill)}、点态95%区间{interval(no_bias_extra, '95')}；原窗口为{percent(no_bias_original.mean_station_skill)}、区间{interval(no_bias_original, '95')}。它是次要探索信号，不能用追加成绩反选其替代主方法。bias在原B30不见得有益，说明从短历史均值修正未来60日可能存在时间不稳定，尚不是因果证据。

残差与直接线性预测的差异首先是参数化与惩罚中心：当Persistence等于观察到的lag0时，直接预测系数以零为L2中心，而残差系数把Persistence作为预测起点；缺测时的合法回退可能不在六列线性特征张成空间。因此不能将已知Ridge/残差/收缩包装成新算法。设施尺度取允许历史正值中位数；源样本权重和为1、每源1/3，长记录和大体积不主导目标；截距不惩罚。选中的alpha和λ可能同时变化，selected与unshrunk并非纯粹固定模型收缩效应，完整{collection['validation_grid_rows']}验证网格与{collection['learned_policy_rows']}参数/诊断行可复核。

Stage3A审计表明原42列有共线结构，短历史有效标签少，来源alpha并非本地最佳；六列和合法调参修正了部分弱基线。旧本地GRU40轮损失仍下降，可能训练未充分，但40/120/300合法验证并未单调改善部署，追加轮数经常验证过拟合；不能再将差成绩简单归因于轮数不足。共享/本地样本数、批量和优化步数本就不同，相同epochs不是训练充分程度相同，也无需机械匹配所有更新数。本轮不新增深度网络。

MSE拟合与MAE评价不同，短历史截距/尺度、缺失、变化量信噪比、三源代表性与窗口天气可能共同影响结果。现在强本地残差常接近或优于共享，而h1共享频繁选择λ0，提示惩罚/基线起点比来源信息本身更能解释部分表面改善；这些是与结果相容的探索解释，不是经过单因素因果消融的归因。缺少起点真实可用天气、设施/仪表信息及独立目标证据，不能确认主要失败机制。

## 高体积、统一裁零与证据限制

高体积阈值来自每SiteID/窗口初始30天有效历史的Q90，各预算一致，阈值日期和观测数在training_diagnostics中；未来真实值只定义报告子集，不选择模型。B30主要候选如下；全部模型/预算的完整逐站高体积表、汇总与7/14/28日区间已保留。

{high_table}

高体积正点估计未给主要结论带来稳定支持；该阈值不是容量、许可或溢流线。总SiteID-日期数不是独立样本数。raw预测共{negative_prediction_count}条负值，统一max(0,prediction)的次要结果全部保留；主要候选各预算技能最大变化为{primary_clip_change:.3g}，没有通过选择性裁零改善主成绩。

仅10个非随机开发SiteID、3来源、未完成物理分组、可能共同天气和重复使用四开发窗口限制外推。本站点同步块和整SiteID重采样考虑日期相关与站点聚类，但无法制造设施独立性或证明总体覆盖保证。种子、预算、时距、重复窗口、预测日均不增加独立水厂数。

## 追加窗口是否合格、paper idea应保留或修改什么

历史审查扫描{history['prior_date_bearing_csv_files']}个日期CSV、{history['prior_temporal_json_files']}个训练/验证时间JSON，最晚旧预测标签{history['prior_prediction_target_maximum']}，未检出2023-10-02至12-02参与先前训练、验证、性能或选型。模型、窗口、参数与统计规则在评分前最终冻结，所以执行了唯一候选2023-10-01连续60起点。此前全2023描述性QA读取已发生，工作区审查不能排除未记录的人工或外部查看；只能称同一开发SiteID追加时间验证，不能称从未接触原始数据、新厂外部验证。**现在该追加窗口已被评价并解释，下一轮必须记为已使用开发历史**，不得再拿它当未使用验证集。

paper idea真实存在且已读取；可以保留既有设施有限初始建模历史、处理后每日体积、跨站信息与负迁移的研究问题，以及固定预算与真实负面结果的可复核设计。原假设“共享历史可能提供收益”仍可作为待验问题；不应写成已经普遍建立有用预测、节省本地历史或识别不可靠部署。局部收益与条件适用范围可谨慎描述，需要同时给出Persistence与强本地参照。

必须修改或不提出：独立物理厂泛化、实时上线、世界首次/新算法、跨国泛化、污染物削减/节能/溢流控制/经济收益、可靠预测区间和软件应用成效。区间可靠性与“不可靠时提示”仍是paper idea的未执行研究目标，而非本轮点预测区间或软件功能。目标期刊尚未确定，候选仍为Journal of Hydroinformatics和Water Science & Technology；当前范围/作者指南未在本轮完成核实，不自行选刊或换模板。

## 下一阶段最值得做的一项实验与停止点

建议先补TDV物理设施/仪表/正常排口映射与体积/QA时间戳证据，再考虑**预测起点真实可得降雨信息的受控特征消融**：保留Persistence、紧凑本地残差与同骨干共享残差，比较只用体积历史和增加合法已知降雨/当时发布预报两种输入。必须有历史发布时间及可用性证据，不用未来实测降雨；源池与目标/日期划分先冻结，不按新部署误差择厂或拟合选择器。若工程输入和物理分组无法取得，收缩为SiteID历史回顾的适用边界研究，暂不推进复杂模型。

这只是一项待审查建议，本轮没有执行。当前两核CPU完整Ridge条件拟合/预测实际{first_run['seconds_this_call']:.2f}秒，指标和所有块区间{eval_run['wall_seconds']:.2f}秒；源码/数据/来源准备及独立审计另计，不能相加冒充全过程CPU时间。本轮未独立测进程峰值内存；不需要GPU或付费计算。若合法降雨数据齐备，仍用两核CPU和小Ridge、预计几分钟级计算应够，数据连接/缺失核验时间另估；这是根据当前计时的预估，不是新实验实测。点预测与独立验证证据不足，预测区间、组合模型和正式软件暂缓。

新运行版本{args.version}，执行签名`{manifest['signature']}`；配置SHA`{sha256(cfg_path)}`。原始数据SHA`{quality['hashes']['wastewater_data/raw/wessex_all_2016_2025.csv']}`；QA-v3 SHA`{manifest['provenance']['canonical_sha256']}`；逐条预测SHA`{independent['predictions_sha256']}`；逐日损失SHA`{independent['daily_losses_sha256']}`。具体证据—结论—图件—拟议正文位置见同目录CLAIM_EVIDENCE.csv；图件有9个实际文件组、7项研究问题，含可编辑.drawio及真实结果PDF/SVG/PNG，未画未执行模块。

复核与续跑命令见[REPRODUCE.md](REPRODUCE.md)。不要在原工作区用重训入口覆写审查表；完整缓存续跑在新审查目录核验，新实验必须新版本：

```bash
export PYTHONPATH=src
.venv-stage2/bin/python scripts/recalculate_stage3a_delivery.py --output outputs/recomputed_stage3a
.venv-stage2/bin/python scripts/summarize_stage3b.py --config configs/stage3b_20261011_v1/full.json --predictions reports/stage3b_20261011_v1/results/predictions_all.csv.gz --output outputs/recomputed_stage3b
.venv-stage2/bin/python -m wastewater.stage3b_experiment --config configs/stage3b_20261011_v1/full.json --workers 2
```

Stage3B已按冻结边界完成并停止，等待审查；未因主要结果不显著扩大搜索、源设施、窗口或深度模型。
'''
    (out / 'ANALYSIS_ZH.md').write_text(prose)

    claims = []
    def claim(identifier, statement, status, file, filters, value, uncertainty='', counterexample='', limitation='', next_experiment='', figure='', location='Results (proposed; manuscript not rewritten)'):
        path = root / file
        claims.append(dict(claim_id=identifier, proposed_statement_en=statement, evidence_status=status,
                           run_version=args.version, execution_signature=manifest['signature'],
                           data_version='wessex_qa_v3_20261009', data_sha256=manifest['provenance']['canonical_sha256'],
                           cleaning_rules='Good finite nonnegative/nonconflicting; Missing/Suspect/Good-negative masked; no target interpolation',
                           configuration='configs/' + args.version + '/full.json', configuration_sha256=sha256(cfg_path),
                           evidence_file=file, evidence_file_sha256=sha256(path), result_filter=filters,
                           value=value, uncertainty=uncertainty, figure_source=figure, counterexamples=counterexample,
                           limitations=limitation, required_next_experiment=next_experiment, proposed_manuscript_location=location))
    resultbase = 'reports/' + args.version + '/results/'
    claim('C01', 'The accepted Stage 3A archive supports independently recomputed saved-prediction metrics, Ridge refits and selected-GRU forward reproduction.',
          'verified_with_scope', 'STAGE3A_EVIDENCE_AUDIT.md', 'stage3a_20261010_v3',
          '388800 predictions; 1800 station metrics; 960 Ridge fits; 2160 selected GRU forward reconstructions',
          counterexample='Full GRU optimizer training was not repeated; endpoint agreement with Stage2 is tolerance-based.',
          limitation='This is not a claim that every training trajectory was independently rerun.', location='Methods/Reproducibility (proposed)')
    claim('C02', 'The selected retrospective cohort preserves genuine Good zeros and excludes Missing-coded zeros from both inputs and labels.',
          'verified', 'data/provenance/' + args.version + '/data_provenance_audit.json', 'quality_counts',
          f'{qcounts["valid_good_targets"]} valid Good targets; {qcounts["Good_zero_retained"]} Good zeros; {qcounts["Missing_zero"]} Missing zeros masked',
          limitation='Released quality annotations may differ from those available at forecast time.', location='Methods/Data (proposed)')
    claim('C03', 'The forecasts simulate existing-facility initial modeling histories followed by frozen-parameter deployment.',
          'verified', resultbase + 'training_diagnostics.csv', 'models_frozen_during_deployment=True; deployment_label_updates=False',
          'B=30/90/180 calendar days; 60 origins; h=1/3 single-day targets',
          limitation='New observations update lag inputs; B is not the total observations accessed over deployment.', location='Methods/Protocol (proposed)')
    claim('C04', 'The development SiteIDs constitute independently verified physical-plant external validation.',
          'unsupported', 'data/provenance/' + args.version + '/FACILITY_REVIEW_STATUS.json', 'physical_facility_independence_verified',
          'False', counterexample='TDV physical facility and normal treated-outfall identities remain unknown.',
          limitation='Ten SiteIDs are not ten confirmed independent facilities.', next_experiment='Obtain official TDV instrument/facility/normal-outfall crosswalk before facility-external validation.', location='Limitations (proposed)')
    claim('C05', 'Real-time availability of daily volume and final public quality flags has been demonstrated.',
          'unsupported', 'data/provenance/' + args.version + '/DATA_PROVENANCE.md', 'QA publication/revision section',
          'Retrospective published-QA scenario only', counterexample='First-arrival timestamps and revisions were not provided.',
          next_experiment='Acquire volume and quality-flag publication/revision timestamps.', location='Limitations (proposed)')
    for window in WINDOWS:
        for horizon in cfg['horizons']:
            c = ci_row(window, horizon=horizon)
            claim('C06_' + window + '_h' + str(horizon),
                  'The predeclared B30 shared residual Ridge with bias and selected lambda improves Persistence in this evaluation set.',
                  'not_demonstrated', resultbase + 'paired_block_intervals.csv',
                  f'evaluation_set={window}; model={PRIMARY}; budget=30; horizon={horizon}; reference=persistence; constraint=raw; block_days=14',
                  percent(c.mean_station_skill), 'Bonferroni two-horizon individual97.5% ' + interval(c),
                  counterexample='All h1 policies return Persistence exactly at lambda0.' if horizon == 1 else 'The adjusted interval contains zero; original and additional h3 point estimates have opposite signs.',
                  limitation='Same ten incompletely mapped development SiteIDs; original windows reused; no operational minimum gain established.',
                  figure='figures/' + args.version + '/primary_b30_persistence_intervals.pdf')
    claim('C07', 'Validation-selected corrections can fall back exactly to Persistence without ensuring benefit over a matched local model.',
          'verified', resultbase + 'parameter_selections.csv', f'model={PRIMARY}; budget=30; horizon=1',
          f'lambda0 in {len(b30_h1)}/{len(b30_h1)} B30/h1 conditions',
          counterexample='B30 local residual selected has positive mean Persistence skill at h1 in both evaluation sets.',
          limitation='Fallback removes the shared correction; zero skill is not evidence of shared-information usefulness.',
          figure='figures/' + args.version + '/lambda_selection_original_development.pdf')
    for window in WINDOWS:
        for horizon in cfg['horizons']:
            c = ci_row(window, horizon=horizon, reference=LOCAL_RESIDUAL)
            ids = sorted(negative_groups[(window, horizon, LOCAL_RESIDUAL)])
            claim('C08_' + window + '_h' + str(horizon), 'Negative transfer remains against the matched validation-selected local residual baseline.',
                  'verified_for_observed_cohort', resultbase + 'paired_comparisons_by_station.csv',
                  f'evaluation_set={window}; model={PRIMARY}; budget=30; horizon={horizon}; reference={LOCAL_RESIDUAL}; reference_budget=30; constraint=raw',
                  f'mean skill {percent(c.mean_station_skill)}; negative SiteIDs {", ".join(ids)}',
                  uncertainty='Exploratory95% ' + interval(c), limitation='Station-window pooled losses; no causal facility mechanism established.',
                  figure='figures/' + args.version + '/primary_site_skill_and_negative_transfer.pdf')
    for horizon in cfg['horizons']:
        c = ci_row('original_development', horizon=horizon, reference=LOCAL_DIRECT, reference_budget=90)
        claim('C09_h' + str(horizon), 'Shared B30 has relative history efficiency against the compact direct local B90 comparator in reused development windows.',
              'verified_reference_specific', resultbase + 'paired_block_intervals.csv',
              f'evaluation_set=original_development; model={PRIMARY}; budget=30; horizon={horizon}; reference={LOCAL_DIRECT}; reference_budget=90; constraint=raw; block_days=14',
              percent(c.mean_station_skill), 'Exploratory95% ' + interval(c),
              counterexample='The same candidate does not improve Persistence at both horizons and does not consistently beat local residual B90.',
              limitation='History efficiency is comparator-dependent; h1 is exact baseline fallback.',
              figure='figures/' + args.version + '/history_budget_comparison_intervals.pdf')
    claim('C10', 'Cross-site learning generally reduces the history required to achieve useful prediction beyond Persistence.',
          'unsupported', resultbase + 'paired_block_intervals.csv',
          f'model={PRIMARY}; kind=history_budget_comparison; references local residual selected and local direct tuned; budgets30→90/30→180/90→180',
          'Mixed, reference-dependent and window-dependent outcomes',
          counterexample='Original B30 versus local residual B90 mean skills are negative at both horizons; h1 primary is Persistence.',
          limitation='No validated operational accuracy threshold; two co-primary gains not established.',
          next_experiment='Frozen controlled ablation of genuinely origin-available engineering rainfall inputs after mapping and arrival-time prerequisites.')
    claim('C11', 'The additional October 2023 episode is temporal validation on the same development SiteIDs, with prior descriptive contact disclosed.',
          'verified_with_archival_limit', 'reports/' + args.version + '/audit/historical_window_eligibility.json',
          'candidate_first_origin=2023-10-01; candidate_label_start=2023-10-02; candidate_label_end=2023-12-02',
          f'{history["prior_date_bearing_csv_files"]} CSVs and {history["prior_temporal_json_files"]} temporal JSONs; prior target maximum {history["prior_prediction_target_maximum"]}; no archived overlap',
          counterexample='Canonical/descriptive processing already read2023; undocumented historical viewing cannot be ruled out.',
          limitation='This episode is now used and must not be called unused validation again.', location='Methods/Validation and limitations (proposed)')
    claim('C12', 'The B30 shared residual policy without bias shows a positive exploratory h3 signal in the additional episode.',
          'exploratory', resultbase + 'paired_block_intervals.csv',
          'evaluation_set=additional_time_validation; model=shared_residual_ridge_selected; budget=30; horizon=3; reference=persistence; constraint=raw; block_days=14',
          percent(no_bias_extra.mean_station_skill), 'Pointwise95% ' + interval(no_bias_extra, '95'),
          counterexample='Original-window pointwise95% ' + interval(no_bias_original, '95') + '; this was not the primary candidate.',
          limitation='Multiple exploratory comparisons; cannot switch primary method after scores.')
    claim('C13', 'The residual parameterization is a novel forecasting algorithm.',
          'unsupported', 'STAGE3B_PROTOCOL.md', 'Model families and finite selection',
          'Established residual Ridge and correction shrinkage',
          counterexample='When observed lag0 equals Persistence, residual learning shifts the coefficient penalty center; it is often a linear reparameterization.',
          limitation='Different selected alpha between selected and unshrunk policies prevents pure shrinkage attribution.', location='Methods/Model positioning (proposed)')
    claim('C14', 'Exploratory high-volume subgroup improvement establishes capacity, permit or overflow-control value.',
          'unsupported', resultbase + 'high_volume_block_intervals.csv',
          f'model={PRIMARY}; budget=30; reference=persistence; constraint=raw; block_days=14',
          'Q90 based on initial30-day historical valid observations; primary h3 intervals include zero',
          counterexample='Realized targets select a retrospective reporting subgroup only; no facility capacity or overflow outcome is modeled.',
          limitation='Conditional subgroup and multiple exploration; not deployment selection or prediction intervals.',
          figure='figures/' + args.version + '/high_volume_exploratory.pdf')
    claim('C15', 'Uniform nonnegative sensitivity does not change primary-candidate station-average skill in this round.',
          'verified', resultbase + 'summary.csv', f'model={PRIMARY}; paired raw versus all_models_nonnegative; all B/h/evaluation sets',
          f'maximum absolute mean-skill difference {primary_clip_change:g}; total raw negative predictions {negative_prediction_count}',
          limitation='The primary analysis remains raw for every method; negative outcomes were retained.')
    claim('C16', 'Prediction-interval reliability, operational warning software and control benefits have been demonstrated.',
          'unsupported', 'STAGE3B_PROTOCOL.md', 'Execution, verification and stop',
          'Not executed', counterexample='Only point forecasts and uncertainty in paired mean error comparisons were evaluated.',
          limitation='No predictive coverage claim, real-time deployment, pollutant/energy/overflow or economic benefit.',
          next_experiment='Defer interval/software work until point forecasts and validation prerequisites are supported.', location='Discussion/Scope (proposed)')
    claim('C17', 'The completed deterministic Ridge round is reproducible with matched inputs and verified immutable task caches.',
          'verified_for_local_checks', 'reports/' + args.version + '/audit/STAGE3B_INDEPENDENT_CHECK.json', 'status=passed; arithmetic_only=False',
          f'{independent["station_metric_checks"]} station metrics; {independent["linear_prediction_reconstruction_checks"]} linear predictions; {independent["independent_source_normal_equation_checks"]} source equations; {independent["lambda_zero_exact_prediction_checks"]} exact fallback rows',
          uncertainty='Arithmeticatol1e-8/rtol1e-12; normalizedRidgeatol/rtol1e-10; lambda0 exact.',
          limitation='This does not certify untested Colab login/Drive or complete historical GRU training replay.', location='Methods/Reproducibility (proposed)')
    pd.DataFrame(claims).to_csv(out / 'CLAIM_EVIDENCE.csv', index=False)
    print(f'Wrote {out / "ANALYSIS_ZH.md"}: {len(prose)} characters; {len(claims)} traced claims.')


if __name__ == '__main__':
    main()
