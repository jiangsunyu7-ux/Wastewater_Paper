"""Independent primary interval recomputation from individual forecasts."""
import json
from pathlib import Path
import warnings
import numpy as np
import pandas as pd
from wastewater.common import sha256,write_json

ROOT=Path(__file__).resolve().parents[1]


def main():
    cfg=json.loads((ROOT/'configs/stage3b_20261011_v1/full.json').read_text());r=ROOT/cfg['report_output']
    p=pd.read_csv(r/'predictions_all.csv.gz',dtype={'site_id':str},low_memory=False)
    ci=pd.read_csv(r/'paired_block_intervals.csv');candidate=cfg['primary_model'];checks=[]
    with warnings.catch_warnings():
        warnings.simplefilter('ignore',RuntimeWarning)
        for evaluation_set,episodes in [('original_development',cfg['origins']),('additional_time_validation',[cfg['additional_origin']])]:
            for horizon in cfg['horizons']:
                q=p[p.common_evaluation&p.budget.eq(30)&p.horizon.eq(horizon)&p.episode.isin(episodes)&p.model.isin(['persistence',candidate])]
                arrays=np.full((10,60*len(episodes),2),np.nan)
                for row in q.itertuples(index=False):
                    index=60*episodes.index(row.episode)+(pd.Timestamp(row.origin)-pd.Timestamp(row.episode)).days
                    arrays[cfg['development_ids'].index(row.site_id),index,0 if row.model=='persistence' else 1]=abs(row.prediction_m3-row.truth_m3)
                for block in cfg['bootstrap']['blocks']:
                    rng=np.random.default_rng(cfg['bootstrap']['seed']+100*horizon+block);values=[]
                    for _ in range(cfg['bootstrap']['replicates']):
                        selected=[]
                        for j in range(len(episodes)):
                            starts=rng.integers(0,61-block,int(np.ceil(60/block)))
                            selected.extend((starts[:,None]+np.arange(block)).reshape(-1)[:60]+60*j)
                        stations=rng.integers(0,10,10);means=np.nanmean(arrays[stations][:,selected],axis=1)
                        values.append(np.nanmean(np.where(means[:,0]>0,1-means[:,1]/means[:,0],np.nan)))
                    expected=np.nanquantile(values,[.025,.975,.0125,.9875,.00625,.99375])
                    row=ci[(ci.evaluation_set==evaluation_set)&ci.co_primary&(ci.horizon==horizon)&(ci.block_days==block)].iloc[0]
                    actual=row[['lower_95','upper_95','lower_bonferroni_2','upper_bonferroni_2','lower_bonferroni_4','upper_bonferroni_4']].to_numpy(float)
                    np.testing.assert_allclose(expected,actual,atol=1e-12,rtol=1e-12)
                    checks.append(dict(evaluation_set=evaluation_set,horizon=horizon,block_days=block,max_absolute_difference=float(np.max(np.abs(expected-actual)))))
        common=p[p.common_evaluation].copy();common['high']=common.truth_m3.ge(common.high_threshold_m3)
        mismatch=int(common.groupby(['site_id','episode','horizon','origin','target_date']).high.nunique().gt(1).sum())
        assert mismatch==0
    result=dict(status='passed',primary_interval_rows_independently_recomputed=len(checks),high_volume_classification_mismatch_groups=mismatch,checks=checks,skill_tolerance={'atol':1e-12,'rtol':1e-12},predictions_sha256=sha256(r/'predictions_all.csv.gz'),checker_sha256=sha256(Path(__file__)),no_model_training=True)
    write_json(ROOT/'reports'/cfg['version']/'audit'/'PRIMARY_INTERVAL_INDEPENDENT_CHECK.json',result);print(json.dumps(result,indent=2))


if __name__=='__main__':main()
