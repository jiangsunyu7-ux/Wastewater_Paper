"""Record content-based code version and an honest diff from preserved Stage3A."""
from __future__ import annotations
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
VERSION = 'stage3b_20261011_v1'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    out = ROOT/'reports'/VERSION
    preserved = ROOT/'preservation/stage3a_before_stage3b_20261011'
    old = json.loads((preserved/'manifest.json').read_text())['files']
    files = sorted(p for folder in ('src', 'scripts', 'tests', 'configs', 'notebooks')
                   for p in (ROOT/folder).rglob('*') if p.is_file()
                   and '__pycache__' not in p.parts and p.suffix not in ('.pyc', '.pyo'))
    hashes = {str(p.relative_to(ROOT)): sha(p) for p in files}
    added = {k:v for k,v in hashes.items() if k not in old}
    changed = {k:{'before':old[k]['sha256'], 'after':v}
               for k,v in hashes.items() if k in old and v != old[k]['sha256']}
    if changed:
        raise RuntimeError(f'Preserved scientific source changed: {list(changed)}')
    docs = ['AGENTS.md', 'EXPERIMENT_PROTOCOL.md', 'RESEARCH_PLAN.md', 'STATUS.md', 'WORKFLOW.md']
    chunks = []
    for name in docs:
        chunks.extend(difflib.unified_diff((preserved/name).read_text().splitlines(True),
                      (ROOT/name).read_text().splitlines(True), fromfile='preserved/'+name, tofile=name))
    for name in sorted(added):
        if Path(name).suffix == '.py':
            chunks.extend(difflib.unified_diff([], (ROOT/name).read_text().splitlines(True),
                          fromfile='/dev/null', tofile=name))
    diff = out/'code_changes.diff'
    diff.write_text(''.join(chunks))
    freeze = json.loads((ROOT/'configs'/VERSION/'FREEZE.json').read_text())
    record = {
        'version': VERSION,
        'git_base_head': subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT, text=True).strip(),
        'git_source_commit_status': 'Application sources are untracked in this checkout; content hashes and delivered source are the scientific code version. A later dedicated delivery commit contains the ZIPs, not a claim that base HEAD contains this source.',
        'scientific_signature': json.loads((out/'RUN_STATUS.json').read_text())['scientific_signature'],
        'freeze': freeze,
        'all_code_config_notebook_sha256': hashes,
        'new_files_since_preserved_stage3a': added,
        'changed_preserved_scientific_source_files': changed,
        'merged_global_doc_sha256': {k:sha(ROOT/k) for k in docs},
        'diff_sha256': sha(diff),
        'diff_basis': 'Preservation snapshot; old source/config/scripts/tests unchanged. Added text source files shown against /dev/null; notebook and configs included in full with hashes.',
        'preservation_manifest_sha256': sha(preserved/'manifest.json'),
        'post_fit_model_core_edits': False,
        'not_bitwise_gru_retraining_claim': True,
    }
    (out/'CODE_VERSION.json').write_text(json.dumps(record, indent=2, ensure_ascii=False)+'\n')
    (out/'CODE_CHANGES.md').write_text(
        '# Code version and preserved-source changes\n\n'
        'Stage3B is identified by the frozen execution signature, configuration and actual source hashes in CODE_VERSION.json. '
        'The base Git HEAD contains only the original README; it must not be presented as containing the scientific implementation. '
        'The dedicated delivery commit will contain the checked packages and full source archive.\n\n'
        'Existing Stage2/Stage3A source, tests, scripts, configurations and results remain unchanged. '
        'New modules implement compact residual Ridge, legal alpha/lambda selection, frozen initial-history deployment, recursive cache checking, '
        'paired evaluation and independent arithmetic checks. New tests cover time boundaries, legal validation, exact Persistence fallback, '
        'future-record perturbations and safe package imports. New figure, notebook and packaging helpers do not alter model fitting. '
        'Global instructions were merged with preserved before-copies; no old scientific protocol was overwritten.\n\n'
        'code_changes.diff uses the preservation snapshot as its basis, not a misleading tracked-only Git diff. '
        'Added Python source is shown against /dev/null; full configurations and notebook are delivered with their content hashes. '
        'IMPLEMENTATION.md retains failed preflights and corrections. Scientific model core was not edited after accepted fitting. '
        'Metadata, reporting, independent checks and delivery helpers added after fitting are separate from execution hashes.\n')
    print(json.dumps({'status':'passed', 'code_files':len(hashes), 'new_files':len(added), 'preserved_source_edits':len(changed)}))

if __name__ == '__main__':
    main()
