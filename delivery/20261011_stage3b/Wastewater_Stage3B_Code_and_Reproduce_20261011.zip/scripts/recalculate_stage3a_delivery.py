"""Independently recalculate archived Stage3A losses without training checkpoints."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
KEYS = ['site_id', 'episode', 'horizon', 'origin', 'target_date']
DAY = KEYS + ['budget', 'model', 'constraint']
STATION = ['constraint', 'site_id', 'budget', 'horizon', 'model']
ATOL, RTOL = 1e-8, 1e-12


def compare(actual, saved, keys, columns):
    left, right = actual.set_index(keys).sort_index(), saved.set_index(keys).sort_index()
    if not left.index.equals(right.index):
        raise AssertionError('Recalculated key sets differ from the archive')
    maxima = {}
    for column in columns:
        a, b = left[column].to_numpy(float), right[column].to_numpy(float)
        np.testing.assert_allclose(a, b, atol=ATOL, rtol=RTOL, equal_nan=True)
        finite = np.isfinite(a) & np.isfinite(b)
        maxima[column] = float(np.max(np.abs(a[finite] - b[finite]))) if finite.any() else None
    return maxima


def recalculate(root, output):
    folder = root / 'reports/stage3a_20261010/results'
    p = pd.read_csv(folder / 'predictions_all.csv', dtype={'site_id': str}, low_memory=False)
    cfg = json.loads((root / 'configs/stage3a_20261010/full.json').read_text())
    if cfg['version'] != 'stage3a_20261010_v3':
        raise ValueError('Unexpected archived Stage3A version')
    if p.duplicated(KEYS + ['budget', 'model', 'seed']).any():
        raise ValueError('Duplicate individual forecasts')
    counts = p.groupby(KEYS).size()
    if len(p) != 388800 or len(counts) != 4800 or not counts.eq(81).all():
        raise AssertionError('Stage3A completed forecast grid differs from the accepted archive')
    if not (pd.to_datetime(p.target_date)-pd.to_datetime(p.origin)).dt.days.eq(p.horizon).all():
        raise AssertionError('Incorrect horizon alignment')
    clipped = np.maximum(0., p.prediction_m3.to_numpy(float))
    np.testing.assert_allclose(clipped, p.prediction_nonnegative_m3, atol=0., rtol=0., equal_nan=True)
    valid = (np.isfinite(p.truth_m3) & np.isfinite(p.prediction_m3)).groupby([p[k] for k in KEYS]).all()
    derived_mask = p.set_index(KEYS).index.map(valid).astype(bool)
    if not np.array_equal(derived_mask, p.common_evaluation.eq(True).to_numpy()):
        raise AssertionError('Archived common-date flag differs from independently derived mask')
    selected = p[derived_mask].copy()
    losses = []
    for constraint, prediction in [('raw', 'prediction_m3'), ('all_models_nonnegative', 'prediction_nonnegative_m3')]:
        q = selected.copy()
        error = q[prediction] - q.truth_m3
        q['absolute_error'], q['squared_error'] = error.abs(), error**2
        q['constraint'] = constraint
        d = q.groupby(DAY).agg(absolute_error=('absolute_error', 'mean'), squared_error=('squared_error', 'mean'),
                              truth_m3=('truth_m3', 'first'), high_threshold_m3=('high_threshold_m3', 'first'),
                              seed_count=('seed', 'nunique')).reset_index()
        losses.append(d)
    daily = pd.concat(losses, ignore_index=True)
    m = daily.groupby(STATION).agg(n_dates=('absolute_error', 'size'), mae_m3=('absolute_error', 'mean'),
                                  mse=('squared_error', 'mean')).reset_index()
    m['rmse_m3'] = np.sqrt(m.pop('mse'))
    baseline_keys = [k for k in STATION if k != 'model']
    baseline = m[m.model.eq('persistence')][baseline_keys + ['mae_m3']].rename(columns={'mae_m3': 'persistence_mae'})
    m = m.merge(baseline, on=baseline_keys, validate='many_to_one')
    m['skill_vs_persistence'] = 1-m.mae_m3/m.persistence_mae.where(m.persistence_mae.gt(0))
    checks = dict(daily=compare(daily, pd.read_csv(folder/'daily_losses.csv', dtype={'site_id': str}), DAY,
                               ['absolute_error', 'squared_error', 'truth_m3', 'high_threshold_m3', 'seed_count']),
                  station_metrics=compare(m, pd.read_csv(folder/'metrics_by_station.csv', dtype={'site_id': str}), STATION,
                                          ['n_dates', 'mae_m3', 'rmse_m3', 'skill_vs_persistence']))
    output.mkdir(parents=True, exist_ok=True)
    daily.to_csv(output/'daily_losses_recomputed.csv.gz', index=False, compression={'method': 'gzip', 'mtime': 0})
    m.to_csv(output/'metrics_by_station_recomputed.csv', index=False)
    result = dict(status='passed', prediction_rows=len(p), common_origin_conditions=int(valid.sum()),
                  station_metrics=len(m), seed_aggregation='Mean per-date absolute and squared losses, not a prediction ensemble',
                  atol=ATOL, rtol=RTOL, checks=checks,
                  scope='Independent arithmetic and date/mask checks only; no training or full trajectory replay claimed')
    (output/'RECALCULATION_STATUS.json').write_text(json.dumps(result, indent=2)+'\n')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--output', type=Path, default=Path('outputs/recomputed_stage3a'))
    args = parser.parse_args()
    output = args.output if args.output.is_absolute() else args.root / args.output
    print(json.dumps(recalculate(args.root, output), indent=2))
