"""Collect completed Stage3B records and independently check archived controls.

No model is fitted and no archived experiment is modified. Example:
PYTHONPATH=src python scripts/collect_stage3b_diagnostics.py --config configs/stage3b_20261011_v1/full.json
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from wastewater.common import sha256, utc_now, write_json
from wastewater.shared_data import build_samples, load_series, scale_from_history
from wastewater.stage3a_data import eligible
from wastewater.stage3b_models import MODELS

ROOT = Path(__file__).resolve().parents[1]
KEYS = ["site_id", "episode", "budget", "horizon", "origin", "target_date", "model"]


def load_json(path):
    return json.loads(Path(path).read_text())


def verify_outputs(folder):
    status = load_json(folder / "status.json")
    if status["status"] == "completed":
        for name, digest in status["outputs_sha256"].items():
            if sha256(folder / name) != digest:
                raise ValueError(f"Completed artifact changed: {folder / name}")
    return status


def archived_control_check(cfg, predictions, output):
    names = list(MODELS[:5])
    actual = predictions[predictions.episode.isin(cfg["origins"]) & predictions.model.isin(names)].copy()
    assert len(actual) == 72000 and not actual.duplicated(KEYS).any()
    archive = ROOT / "reports/stage3a_20261010/results/predictions_all.csv"
    if not archive.exists():
        archive = archive.with_suffix(".csv.gz")
    if not archive.exists():
        raise FileNotFoundError("Full accepted Stage3A predictions_all.csv(.gz) is required for archived control verification")
    columns = KEYS + ["prediction_m3", "prediction_nonnegative_m3", "truth_m3", "common_evaluation"]
    chunks = []
    for chunk in pd.read_csv(archive, dtype={"site_id": str}, usecols=columns, chunksize=50000, low_memory=False):
        chunks.append(chunk[chunk.model.isin(names)])
    old = pd.concat(chunks, ignore_index=True).rename(columns={"common_evaluation": "common_all_models"})
    compared = actual.merge(old, on=KEYS, how="outer", suffixes=("", "_archive"), validate="one_to_one", indicator=True)
    assert compared._merge.eq("both").all() and len(compared) == 72000
    records = []
    for column in ["prediction_m3", "prediction_nonnegative_m3", "truth_m3"]:
        new = compared[column].to_numpy(float)
        saved = compared[column + "_archive"].to_numpy(float)
        denominator = compared.scale_m3.to_numpy(float)
        normalized_delta = np.abs((new - saved) / denominator)
        matched = np.allclose(new / denominator, saved / denominator, atol=1e-10, rtol=1e-10, equal_nan=True)
        if not matched:
            raise AssertionError(f"Archived direct comparator differs beyond normalized tolerance: {column}")
        records.append(dict(column=column, compared_rows=len(compared),
            finite_rows=int((np.isfinite(new) & np.isfinite(saved)).sum()),
            maximum_absolute_difference_m3=float(np.nanmax(np.abs(new-saved))),
            maximum_normalized_difference=float(np.nanmax(normalized_delta)),
            normalized_atol=1e-10, rtol=1e-10, tolerance_passed=True,
            bitwise_csv_values=bool(np.array_equal(new, saved, equal_nan=True))))
    index = ["site_id", "episode", "horizon", "origin", "target_date"]
    archived_mask = old.groupby(index).common_all_models.first()
    all_new = predictions[predictions.episode.isin(cfg["origins"])].copy()
    all_new["row_valid"] = np.isfinite(all_new.truth_m3) & np.isfinite(all_new.prediction_m3)
    new_mask = all_new.groupby(index).row_valid.all()
    mask = pd.concat([archived_mask.rename("archived_common"), new_mask.rename("new_common")], axis=1)
    if mask.isna().any().any() or not mask.archived_common.eq(mask.new_common).all():
        raise AssertionError("Stage3B original common-date mask differs from Stage3A archive")
    pd.DataFrame(records).to_csv(output / "archived_direct_control_comparisons.csv", index=False)
    mask.reset_index().to_csv(output / "archived_common_date_mask_check.csv", index=False)
    return dict(archive_sha256=sha256(archive), control_rows=len(compared),
        compared_columns=records, paired_calendar_positions=len(mask), common_positions=int(mask.new_common.sum()),
        common_date_mask_identical=True, preservation="read-only archived predictions")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/stage3b_20261011_v1/full.json")
    args = parser.parse_args()
    cfg = load_json(ROOT / args.config)
    result_dir = ROOT / cfg.get("report_output", f"reports/{cfg['version']}/results")
    result_dir.mkdir(parents=True, exist_ok=True)
    source_dir = ROOT / cfg["source_output"]
    verify_outputs(source_dir)
    source_selection = load_json(source_dir / "selection.json")
    source_diagnostics = load_json(source_dir / "source_diagnostics.json")
    pseudo_folds = pd.DataFrame(load_json(source_dir / "pseudo_validation_folds.json"))
    final_source = {row["horizon"]: row for row in source_diagnostics if row["group"] == "final"}
    proxy_source = {row["horizon"]: row for row in source_diagnostics if row["group"] == "proxy"}
    loso_source = {(row["group"].replace("loso_", ""), row["horizon"]): row for row in source_diagnostics if row["group"].startswith("loso_")}
    archived = load_json(ROOT / cfg.get("stage3a_selection", "runs/stage3a_20261010_v3/source/selection.json"))
    source_series = load_series(ROOT / cfg["canonical_csv"], cfg["source_ids"])
    direct_source_validation_counts = {}
    for horizon in cfg["horizons"]:
        count = 0
        for site in cfg["source_ids"]:
            scale = scale_from_history(source_series[site], "2016-01-01", "2020-12-31")
            samples = build_samples(source_series[site], pd.date_range("2021-01-01", pd.Timestamp("2021-12-31")-pd.Timedelta(days=horizon)),
                                    horizon, "2016-01-01", scale)
            _, mask = eligible(samples)
            count += int(mask.sum())
        direct_source_validation_counts[horizon] = count
    records, diagnostics_rows, grids, completion = [], [], [], []
    for folder in sorted((ROOT / cfg["output"] / "jobs").iterdir()):
        if not folder.is_dir():
            continue
        status = verify_outputs(folder)
        completion.append(dict(task=folder.name, status=status["status"], attempt=status.get("attempt"),
            seconds=status.get("seconds"), started_utc=status.get("started_utc"), finished_utc=status.get("finished_utc"),
            failure_reason=status.get("error"), status_sha256=sha256(folder / "status.json")))
        if status["status"] != "completed":
            continue
        diag = load_json(folder / "diagnostics.json")
        selection = load_json(folder / "selection.json")
        params = load_json(folder / "parameters.json")
        fold = selection["fold"]
        budget, horizon = diag["budget"], diag["horizon"]
        shared_training = final_source[horizon]
        fallback = bool(fold["source_assisted"])
        relevant = pseudo_folds[pseudo_folds.budget.eq(budget) & pseudo_folds.horizon.eq(horizon)] if fallback else None
        selection_valid_count = int(relevant.validation_labels.sum()) if fallback else fold["validation_labels"]
        local_selection_fit_count = int(relevant.fitting_labels.sum()) if fallback else fold["fitting_labels"]
        selection_folds = 6 if fallback else 1
        source_fit_counts = [loso_source[(row.held_out_source, horizon)]["total_training_labels"] for row in relevant.itertuples()] if fallback else [proxy_source[horizon]["total_training_labels"]]
        info = dict(site_id=diag["site_id"], episode=diag["episode"], budget=budget, horizon=horizon,
            window_class="additional_time_validation" if diag["episode"] == "2023-10-01" else "reused_development",
            initial_calendar_days=diag["initial_calendar_days"], initial_valid_inputs=diag["valid_initial_inputs"],
            initial_valid_targets=diag["valid_initial_targets"], initial_training_labels=diag["training_labels"],
            legacy_training_labels=diag["direct_legacy_training_labels"],
            residual_required_persistence_exclusions=diag["residual_required_persistence_exclusions"],
            initial_fit_start=diag["budget_start"], initial_fit_end=diag["fit_end"],
            first_train_origin=diag["first_train_origin"], last_train_origin=diag["last_train_origin"],
            first_train_target=diag["first_train_target"], last_train_target=diag["last_train_target"],
            scale_m3=diag["scale_m3"], normalization_fit_start=diag["normalization_fit_start"],
            normalization_fit_end=diag["normalization_fit_end"],
            attempted_target_cv_fitting_labels=fold["fitting_labels"], attempted_target_cv_validation_labels=fold["validation_labels"],
            target_internal_fold_valid=fold["valid"], target_cv_fit_end=fold["fit_end"],
            target_cv_validation_start=fold["validation_start"],
            high_threshold_m3=diag["high_threshold_m3"], threshold_start=diag["threshold_start"],
            threshold_end=diag["threshold_end"], threshold_observations=diag["threshold_observations"],
            models_frozen_during_deployment=True, deployment_label_updates=False,
            retrospective_quality=True, nominal_parameters=7, features=6, intercept_penalized=False,
            training_objective="weighted MSE + alpha * squared coefficients; weights sum one",
            source_training_site_ids="|".join(cfg["source_ids"]), source_final_fit_start="2016-01-01", source_final_fit_end="2021-12-31",
            source_model_scales_json=json.dumps({s["site_id"]: s["scale_m3"] for s in shared_training["sites"]}, sort_keys=True),
            source_facility_weight_sums_json=json.dumps({s["site_id"]: s["weight_sum"] for s in shared_training["sites"]}, sort_keys=True),
            source_sample_weights_json=json.dumps({s["site_id"]: s["individual_sample_weight"] for s in shared_training["sites"]}, sort_keys=True),
            model_file=str((folder / "ridge_parameters.npz").relative_to(ROOT)), model_file_sha256=sha256(folder / "ridge_parameters.npz"),
            diagnostic_sha256=sha256(folder / "diagnostics.json"))
        for model, choice in params.items():
            shared = model.startswith("shared_")
            residual = "residual" in model
            bias = model.endswith("_bias") or "_bias_" in model
            selection_source = fold["choice_source"]
            actual_valid_count, actual_fit_count, folds = selection_valid_count, local_selection_fit_count, selection_folds
            if shared and not residual:
                selection_source = "frozen_accepted_Stage3A_source_2021_normalized_MAE"
                actual_valid_count, actual_fit_count, folds = direct_source_validation_counts[horizon], proxy_source[horizon]["total_training_labels"], 3
                selected_mae = next(row["validation_mae"] for row in archived["settings"][str(horizon)]["shared_ridge_scores"] if row["alpha"] == choice["alpha"])
            elif residual:
                selected_mae = choice["validation_mae"]
            else:
                selected_mae = selection["direct_validation_mae"]
            row = dict(info, model=model, alpha=choice["alpha"], shrinkage=choice.get("shrinkage"),
                bias_normalized=choice.get("bias_normalized", choice["bias_m3"] / diag["scale_m3"]),
                bias_m3=choice["bias_m3"], selection_validation_mae_normalized=selected_mae,
                validation_mae_scope="alpha only, before local bias" if shared and not residual else "complete prediction policy",
                selection_source=selection_source, source_assisted_hyperparameters=bool(fallback or (shared and not residual)),
                actual_selection_validation_labels=actual_valid_count, selection_fold_count=folds,
                actual_selection_local_fitting_labels_sum=local_selection_fit_count if not (shared and not residual) else 0,
                actual_selection_model_fitting_labels=actual_fit_count if not shared else (proxy_source[horizon]["total_training_labels"] if not residual else None),
                selection_shared_fit_labels_by_fold_json=json.dumps(source_fit_counts if residual and shared else []),
                final_model_training_labels=shared_training["total_training_labels"] if shared else diag["training_labels"],
                local_target_model_fitting_labels=0 if shared else diag["training_labels"],
                local_bias_calibration_labels=diag["training_labels"] if bias else 0,
                local_individual_sample_weight=1/diag["training_labels"] if not shared or bias else None,
                source_assisted_validation_fold_ids="|".join(relevant.fold_id) if fallback and not (shared and not residual) else "",
                selection_fit_start=str(relevant.fit_start.min()) if fallback else fold["fit_start"],
                selection_fit_end=str(relevant.fit_end.max()) if fallback else fold["fit_end"],
                selection_validation_start=str(relevant.first_validation_origin.min()) if fallback else fold["first_validation_origin"],
                selection_validation_end=str(relevant.last_validation_target.max()) if fallback else fold["last_validation_target"],
                selection_shared_proxy_fit_end="2020-12-31" if shared else None,
                lambda_zero_fallback=bool(choice.get("shrinkage") == 0), device="cpu", deterministic=True)
            if shared and not residual:
                row.update(selection_fit_start="2016-01-01", selection_fit_end="2020-12-31",
                           selection_validation_start="2021-01-01", selection_validation_end="2021-12-31")
            records.append(row)
            diagnostics_rows.append(dict(row, fitting_method="analytic sklearn Ridge solve",
                optimizer_updates=None, epochs=None, job_seconds=status["seconds"],
                fitting_labels_semantics="source labels for shared coefficient fit; target budget labels for local coefficients/bias"))
        for score in selection["residual_validation"]:
            grids.append(dict(score, stage="target_internal_validation", site_id=diag["site_id"], episode=diag["episode"],
                budget=budget, horizon=horizon, fold_id=folder.name, source_assisted=False,
                fit_start=fold["fit_start"], fit_end=fold["fit_end"], validation_start=fold["first_validation_origin"],
                validation_end=fold["last_validation_target"], source_proxy_fit_end="2020-12-31"))
        for score in selection["direct_validation"]:
            grids.append(dict(score, family="local_ridge_lags_tuned", stage="target_internal_validation", site_id=diag["site_id"],
                episode=diag["episode"], budget=budget, horizon=horizon, fold_id=folder.name, source_assisted=False,
                fitting_labels=fold["fitting_labels"], validation_labels=fold["validation_labels"],
                fit_start=fold["fit_start"], fit_end=fold["fit_end"], validation_start=fold["first_validation_origin"],
                validation_end=fold["last_validation_target"]))
    if len(completion) != 300 or any(row["status"] != "completed" for row in completion):
        raise AssertionError("Diagnostic collection requires all frozen 300 conditions completed")
    for name, family in [("residual_fallback_grid.csv", None), ("direct_fallback_grid.csv", "local_ridge_lags_tuned")]:
        source_grid = pd.read_csv(source_dir / name, dtype={"held_out_source": str})
        source_grid = source_grid.merge(pseudo_folds[["fold_id", "fit_start", "fit_end", "first_validation_origin", "last_validation_target"]], on="fold_id", validate="many_to_one")
        source_grid = source_grid.rename(columns={"first_validation_origin": "validation_start", "last_validation_target": "validation_end"})
        source_grid["stage"] = "source_pseudo_budget_LOSO_validation"
        source_grid["source_assisted"] = True
        source_grid["source_proxy_fit_end"] = "2020-12-31"
        if family:
            source_grid["family"] = family
        grids.extend(source_grid.to_dict("records"))
    parameter_frame = pd.DataFrame(records)
    parameter_frame.to_csv(result_dir / "parameter_selections.csv", index=False)
    pd.DataFrame(diagnostics_rows).to_csv(result_dir / "training_diagnostics.csv", index=False)
    pd.DataFrame(grids).to_csv(result_dir / "validation_grids.csv.gz", index=False, compression={"method": "gzip", "mtime": 0})
    pd.DataFrame(completion).to_csv(result_dir / "run_completion.csv", index=False)
    prediction_path = result_dir / "predictions_all.csv.gz"
    predictions = pd.read_csv(prediction_path, dtype={"site_id": str}, low_memory=False)
    archive_check = archived_control_check(cfg, predictions, result_dir)
    selected = parameter_frame[parameter_frame.model.str.endswith("_selected")]
    fallbacks = selected.groupby(["window_class", "model", "budget", "horizon"], as_index=False).agg(
        configurations=("lambda_zero_fallback", "size"), lambda_zero_configurations=("lambda_zero_fallback", "sum"))
    fallbacks["lambda_zero_fraction"] = fallbacks.lambda_zero_configurations / fallbacks.configurations
    fallbacks.to_csv(result_dir / "lambda_fallback_by_condition.csv", index=False)
    first_manifest = ROOT / f"reports/{cfg['version']}/software/full_first_run_manifest.json"
    first_run = load_json(first_manifest if first_manifest.exists() else ROOT / cfg["output"] / "manifest.json")
    report = dict(checked_utc=utc_now(), status="completed", conditions=len(completion), learned_policy_rows=len(parameter_frame),
        residual_eligibility_exclusions=int(parameter_frame.drop_duplicates(["site_id", "episode", "budget", "horizon"]).residual_required_persistence_exclusions.sum()),
        validation_grid_rows=len(grids), all_outputs_hash_verified=True, archived_controls=archive_check,
        actual_first_full_seconds=first_run["seconds_this_call"], device="cpu", workers=cfg.get("workers", 2),
        code_sha256=sha256(Path(__file__)), config_sha256=sha256(ROOT / args.config),
        source_selection_sha256=sha256(source_dir / "selection.json"),
        notes=["Nominal coefficient/intercept count is seven; this is not effective degrees of freedom.",
            "B30 attempted target CV counts are distinct from six source-assisted pseudo-validation counts.",
            "Shared direct validation loss belongs to frozen alpha selection before local bias, not a target policy validation.",
            "Source pseudo folds for B90/B180 were executed as precomputed fallback candidates, even where target internal folds suffice.",
            "No GRU was retrained; no GPU or paid resource was requested.",
            "GNU time was unavailable; no independently measured peak memory is claimed."])
    write_json(result_dir / "DIAGNOSTIC_COLLECTION_CHECK.json", report)
    print(json.dumps({k:report[k] for k in ["status", "conditions", "learned_policy_rows", "validation_grid_rows", "residual_eligibility_exclusions", "actual_first_full_seconds"]}, indent=2))


if __name__ == "__main__":
    main()
