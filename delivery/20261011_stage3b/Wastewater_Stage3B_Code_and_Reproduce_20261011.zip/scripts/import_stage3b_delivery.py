"""Safely verify and merge independently extractable Stage3B delivery ZIPs.

Existing different files, traversal, symlinks, unmanifested members, duplicates,
oversize ZIPs and incomplete SHA verification are rejected before import.
"""
from __future__ import annotations
import argparse
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import tempfile
import zipfile

LIMIT = 24*1024**2


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for data in iter(lambda: f.read(1024**2), b''):
            h.update(data)
    return h.hexdigest()


def safe_path(name):
    p = PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or '\\' in name or ':' in name or name.endswith('/'):
        raise ValueError(f'Unsafe member: {name}')
    return p


def import_archives(archives, destination, outer_checks=None):
    destination = Path(destination).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    outer = {}
    if outer_checks is not None:
        for line in Path(outer_checks).read_text().splitlines():
            h, name = line.split('  ', 1)
            outer[name] = h
    merged, manifests = {}, []
    with tempfile.TemporaryDirectory(prefix='stage3b_import_', dir=destination.parent) as temporary:
        staging = Path(temporary)
        for filename in map(Path, archives):
            if filename.stat().st_size >= LIMIT:
                raise ValueError('A ZIP reaches/exceeds the 24 MiB limit')
            if outer_checks is not None and outer.get(filename.name) != digest(filename):
                raise ValueError(f'Outer checksum mismatch: {filename.name}')
            with zipfile.ZipFile(filename) as z:
                names = z.namelist()
                if len(names) != len(set(names)) or z.testzip() is not None:
                    raise ValueError('Duplicate names or CRC failure')
                for info in z.infolist():
                    safe_path(info.filename)
                    if (info.external_attr >> 16) & 0o170000 == 0o120000:
                        raise ValueError('Symlinks are forbidden')
                manifest_names = [n for n in names if n.startswith('.stage3b_package_manifests/') and n.endswith('/MANIFEST.json')]
                if len(manifest_names) != 1:
                    raise ValueError('Exactly one package manifest is required')
                manifest = json.loads(z.read(manifest_names[0]))
                required = set(manifest['files_sha256']) | {manifest_names[0], manifest_names[0].replace('MANIFEST.json', 'SHA256SUMS')}
                if required != set(names):
                    raise ValueError('Unmanifested or missing ZIP members')
                internal = {}
                for line in z.read(manifest_names[0].replace('MANIFEST.json', 'SHA256SUMS')).decode().splitlines():
                    expected, name = line.split('  ', 1)
                    internal[name] = expected
                if set(internal) != set(manifest['files_sha256']) | {manifest_names[0]}:
                    raise ValueError('Internal checksum list is incomplete')
                if internal[manifest_names[0]] != hashlib.sha256(z.read(manifest_names[0])).hexdigest():
                    raise ValueError('Internal manifest SHA mismatch')
                if any(internal[name] != expected for name, expected in manifest['files_sha256'].items()):
                    raise ValueError('Internal checksum manifest disagrees with MANIFEST.json')
                for name, expected in manifest['files_sha256'].items():
                    source = staging / safe_path(name)
                    source.parent.mkdir(parents=True, exist_ok=True)
                    with z.open(name) as f, source.open('wb') as target:
                        shutil.copyfileobj(f, target)
                    if digest(source) != expected:
                        raise ValueError(f'Member SHA mismatch: {name}')
                    if name in merged and merged[name] != expected:
                        raise ValueError(f'Conflicting bundle contents: {name}')
                    merged[name] = expected
                for name in required-set(manifest['files_sha256']):
                    source = staging/safe_path(name)
                    source.parent.mkdir(parents=True, exist_ok=True)
                    source.write_bytes(z.read(name))
                    merged[name] = digest(source)
                manifests.append(manifest)
        # Materialize large CSVs into their original paths after gzip hash verification.
        for manifest in manifests:
            for name, record in manifest.get('gzip_originals', {}).items():
                if not 0 <= record['original_bytes'] <= 512*1024**2:
                    raise ValueError('Unexpected decompressed artifact size')
                original = record['original_path']
                source = staging/safe_path(name)
                target = staging/safe_path(original)
                target.parent.mkdir(parents=True, exist_ok=True)
                with gzip.open(source, 'rb') as f, target.open('wb') as output:
                    written = 0
                    for chunk in iter(lambda: f.read(1024**2), b''):
                        written += len(chunk)
                        if written > record['original_bytes']:
                            raise ValueError('Compressed payload exceeds declared size')
                        output.write(chunk)
                if target.stat().st_size != record['original_bytes'] or digest(target) != record['original_sha256']:
                    raise ValueError(f'Gzip original SHA mismatch: {original}')
                if original in merged and merged[original] != record['original_sha256']:
                    raise ValueError('Conflicting compressed/uncompressed originals')
                merged[original] = record['original_sha256']
        # Verify all conflicts first; only then install verified payloads.
        for name, expected in merged.items():
            target = destination/safe_path(name)
            if target.is_symlink() or not target.resolve().is_relative_to(destination):
                raise ValueError('Destination escapes the import directory')
            if target.exists() and (not target.is_file() or digest(target) != expected):
                raise FileExistsError(f'Refusing to overwrite different file: {target}')
        for name in merged:
            target = destination/safe_path(name)
            if not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(staging/safe_path(name), target)
    return dict(status='passed', archives=len(archives), verified_files=len(merged),
                crc_and_all_member_sha256_verified=True, destination=str(destination))


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--destination', type=Path, required=True)
    p.add_argument('--sha256sums', type=Path)
    p.add_argument('archives', nargs='+', type=Path)
    a = p.parse_args()
    print(json.dumps(import_archives(a.archives, a.destination, a.sha256sums), indent=2))
