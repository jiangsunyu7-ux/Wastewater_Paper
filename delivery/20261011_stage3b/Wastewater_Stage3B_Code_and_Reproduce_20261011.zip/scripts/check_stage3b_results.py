"""Independent saved-forecast arithmetic and model reconstruction, no fitting decisions.

This checker does not import Stage3B evaluation or fitting functions. It uses
the frozen calendar builder and stored linear coefficients, independently
recomputes weighted normal equations, and compares only within stated
tolerances. Run after the complete source/target experiment and reporting.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

from wastewater.common import sha256, write_json
from wastewater.shared_data import build_samples, load_series, scale_from_history, train_samples

ROOT = Path(__file__).resolve().parents[1]
KEYS = ['site_id','episode','horizon','origin','target_date']


def features(X):
    return np.concatenate((X[:,[6,5,0],0],X[:,[6,5,0],1]),axis=1).astype(float)


def normal_equations(X,y,alpha,w):
    assert np.isclose(w.sum(),1.)
    xm=w@X;ym=w@y;xc=X-xm
    beta=np.linalg.solve(xc.T@(w[:,None]*xc)+alpha*np.eye(X.shape[1]),xc.T@(w*(y-ym)))
    return beta,ym-xm@beta


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--config',default='configs/stage3b_20261011_v1/full.json')
    ap.add_argument('--output',default='reports/stage3b_20261011_v1/audit/STAGE3B_INDEPENDENT_CHECK.json')
    ap.add_argument('--arithmetic-only',action='store_true');args=ap.parse_args()
    cfg=json.loads((ROOT/args.config).read_text());folder=ROOT/cfg['report_output']
    p=pd.read_csv(folder/'predictions_all.csv.gz',dtype={'site_id':str})
    metric=pd.read_csv(folder/'metrics_by_station.csv',dtype={'site_id':str})
    assert not p.duplicated(KEYS+['budget','model']).any()
    assert (pd.to_datetime(p.target_date)-pd.to_datetime(p.origin)).dt.days.eq(p.horizon).all()
    assert pd.to_datetime(p.target_date).max()<=pd.Timestamp('2023-12-31')
    assert pd.to_datetime(p.last_train_target).le(pd.to_datetime(p.fit_end)).all()
    assert pd.to_datetime(p.latest_input_date).le(pd.to_datetime(p.origin)).all()
    finite=np.isfinite(p.prediction_m3)&np.isfinite(p.truth_m3)
    mask=finite.groupby([p[k] for k in KEYS]).all()
    assert np.array_equal(p.common_evaluation,p.set_index(KEYS).index.map(mask))
    assert p.groupby(KEYS).size().eq(len(cfg['models'])*len(cfg['budgets'])).all()
    np.testing.assert_allclose(p.prediction_nonnegative_m3,np.maximum(0,p.prediction_m3),atol=0,rtol=0,equal_nan=True)
    common=p[p.common_evaluation];daily=[]
    for constraint,column in [('raw','prediction_m3'),('all_models_nonnegative','prediction_nonnegative_m3')]:
        q=common.copy();error=q[column]-q.truth_m3;q['absolute_error']=error.abs();q['squared_error']=error**2;q['constraint']=constraint
        daily.append(q)
    d=pd.concat(daily,ignore_index=True);sk=['evaluation_set','constraint','site_id','budget','horizon','model']
    calculated=d.groupby(sk).agg(n_dates=('origin','size'),mae_m3=('absolute_error','mean'),mse=('squared_error','mean')).reset_index()
    calculated['rmse_m3']=np.sqrt(calculated.pop('mse'))
    a=calculated.set_index(sk).sort_index();b=metric[metric.n_dates.gt(0)].set_index(sk).sort_index()
    assert a.index.equals(b.index)
    np.testing.assert_allclose(a[['n_dates','mae_m3','rmse_m3']],b[['n_dates','mae_m3','rmse_m3']],atol=1e-8,rtol=1e-12)
    dk=['evaluation_set','constraint']+KEYS+['budget','model']
    saved=pd.read_csv(folder/'daily_losses.csv.gz',dtype={'site_id':str})
    da=d.set_index(dk).sort_index();db=saved.set_index(dk).sort_index();assert da.index.equals(db.index)
    np.testing.assert_allclose(da[['absolute_error','squared_error']],db[['absolute_error','squared_error']],atol=1e-8,rtol=1e-12)
    baseline=metric[metric.model.eq('persistence')].set_index(sk[:-1]).mae_m3
    for row in metric.itertuples(index=False):
        ref=baseline.loc[tuple(getattr(row,k) for k in sk[:-1])]
        skill=1-row.mae_m3/ref if ref>0 else np.nan
        np.testing.assert_allclose(skill,row.skill_vs_persistence,atol=1e-12,rtol=1e-12,equal_nan=True)
    summary=pd.read_csv(folder/'summary.csv')
    summaries=metric.groupby(['evaluation_set','constraint','budget','horizon','model']).skill_vs_persistence.agg(['mean','median'])
    ss=summary.set_index(['evaluation_set','constraint','budget','horizon','model']).sort_index()
    np.testing.assert_allclose(summaries.sort_index()['mean'],ss.mean_skill,atol=1e-12,rtol=1e-12,equal_nan=True)
    np.testing.assert_allclose(summaries.sort_index()['median'],ss.median_skill,atol=1e-12,rtol=1e-12,equal_nan=True)
    zero=p[p.shrinkage.eq(0)].copy();base=p[p.model.eq('persistence')].set_index(KEYS+['budget']).prediction_m3
    zz=base.reindex(zero.set_index(KEYS+['budget']).index).to_numpy()
    np.testing.assert_allclose(zero.prediction_m3,zz,atol=0,rtol=0,equal_nan=True)
    model_checks=0;source_checks=0;cache_files=0;diag_rows=[]
    if not args.arithmetic_only:
        series=load_series(ROOT/cfg['canonical_csv'],cfg['source_ids']+cfg['development_ids'])
        source=ROOT/cfg['source_output'];srcdiag=json.loads((source/'source_diagnostics.json').read_text())
        for group in srcdiag:
            xs=[];ys=[];rs=[];ws=[]
            for site in group['source_ids']:
                s=series[site];end=group['fit_end'];scale=scale_from_history(s,cfg['source_training_start'],end)
                tr=train_samples(s,cfg['source_training_start'],end,group['horizon'],scale)
                keep=np.isfinite(tr.persistence);x=features(tr.X[keep]);y=tr.y[keep];r=y-tr.persistence[keep]/scale
                xs.append(x);ys.append(y);rs.append(r);ws.append(np.ones(len(y))/(len(group['source_ids'])*len(y)))
                assert tr.targets.max()<=pd.Timestamp(end)
            x=np.concatenate(xs);w=np.concatenate(ws)
            with np.load(source/f"{group['group']}_H{group['horizon']}.npz") as models:
                for j,alpha in enumerate(models['alphas']):
                    for family,y in [('direct',np.concatenate(ys)),('residual',np.concatenate(rs))]:
                        coef,intercept=normal_equations(x,y,alpha,w)
                        np.testing.assert_allclose(coef,models[f'{family}_coefs'][j],atol=1e-10,rtol=1e-10)
                        np.testing.assert_allclose(intercept,models[f'{family}_intercepts'][j],atol=1e-10,rtol=1e-10);source_checks+=1
        for job in sorted((ROOT/cfg['output']/'jobs').iterdir()):
            status=json.loads((job/'status.json').read_text());assert status['status']=='completed'
            for name,h in status['outputs_sha256'].items():assert sha256(job/name)==h;cache_files+=1
            diag=json.loads((job/'diagnostics.json').read_text());params=json.loads((job/'parameters.json').read_text())
            s=series[str(diag['site_id'])];start=pd.Timestamp(diag['episode']);left=start-pd.Timedelta(days=diag['budget']);end=start-pd.Timedelta(days=1)
            scale=scale_from_history(s,left,end);tr=train_samples(s,left,end,diag['horizon'],scale)
            keep=np.isfinite(tr.persistence);x=features(tr.X[keep]);yn=tr.y[keep];rn=yn-tr.persistence[keep]/scale
            te=build_samples(s,pd.date_range(start,periods=60),diag['horizon'],left,scale);xt=features(te.X)
            assert len(x)==diag['training_labels'] and tr.targets.max()<=end
            fold=diag['validation'];assert pd.Timestamp(fold['normalization_fit_end'])<=end
            if not fold['source_assisted']:
                assert pd.Timestamp(fold['last_fit_target'])<pd.Timestamp(fold['validation_start'])
                assert pd.Timestamp(fold['last_validation_target'])<=end
            jp=pd.read_csv(job/'predictions.csv');weights=np.ones(len(yn))/len(yn)
            with np.load(job/'ridge_parameters.npz') as stored:
                for name,param in params.items():
                    if name=='local_ridge_lags_tuned':
                        coef,intercept=normal_equations(x,yn,param['alpha'],weights)
                        np.testing.assert_allclose(coef,stored['local_direct_coef'],atol=1e-10,rtol=1e-10)
                        expected=(xt@coef+intercept)*scale
                    elif name in ['shared_ridge_lags','shared_ridge_lags_bias']:
                        expected=(xt@stored['shared_direct_coef']+stored['shared_direct_intercept']+(stored['direct_bias_normalized'] if name.endswith('bias') else 0))*scale
                    else:
                        coef=stored[name+'_coef'];intercept=stored[name+'_intercept'];bias=stored[name+'_bias']
                        if name.startswith('local_'):
                            expected_coef,expected_intercept=normal_equations(x,rn,param['alpha'],weights)
                            np.testing.assert_allclose(coef,expected_coef,atol=1e-10,rtol=1e-10)
                            np.testing.assert_allclose(intercept,expected_intercept,atol=1e-10,rtol=1e-10)
                        if name.startswith('shared_residual_ridge_bias_'):
                            np.testing.assert_allclose(bias,np.mean(rn-(x@coef+intercept)),atol=1e-12,rtol=1e-12)
                        expected=te.persistence.copy() if param['shrinkage']==0 else te.persistence+param['shrinkage']*(xt@coef+intercept+bias)*scale
                    if param.get('shrinkage')!=0:expected[te.X[:,:,1].sum(axis=1)==0]=np.nan
                    actual=jp[jp.model.eq(name)].prediction_m3.to_numpy(float)
                    np.testing.assert_allclose(expected/scale,actual/scale,atol=1e-10,rtol=1e-10,equal_nan=True);model_checks+=1
            diag_rows.append({'task':job.name,'training_labels':len(x),'source_assisted':fold['source_assisted'],'validation_labels':fold['validation_labels'],'normalization_fit_start':diag['normalization_fit_start'],'normalization_fit_end':diag['normalization_fit_end'],'residual_required_persistence_exclusions':diag['residual_required_persistence_exclusions']})
        pd.DataFrame(diag_rows).to_csv(ROOT/'reports'/cfg['version']/'audit'/'stage3b_budget_checks.csv',index=False)
    out=ROOT/args.output;out.parent.mkdir(parents=True,exist_ok=True)
    result=dict(status='passed',prediction_rows=len(p),daily_losses=len(saved),station_metric_checks=len(calculated),lambda_zero_exact_prediction_checks=len(zero),linear_prediction_reconstruction_checks=model_checks,independent_source_normal_equation_checks=source_checks,completed_output_hash_checks=cache_files,arithmetic_only=args.arithmetic_only,arithmetic_tolerances={'atol_m3':1e-8,'rtol':1e-12},ridge_normalized_tolerances=cfg['prediction_tolerance'],predictions_sha256=sha256(folder/'predictions_all.csv.gz'),daily_losses_sha256=sha256(folder/'daily_losses.csv.gz'),checker_sha256=sha256(Path(__file__)),final_period_used=False)
    write_json(out,result);print(json.dumps(result,indent=2))


if __name__=='__main__':main()
