"""Create immutable, checked Stage3B review/code/prediction packages <24 MiB."""
from __future__ import annotations
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import zipfile
import zlib
from wastewater.common import sha256

ROOT = Path(__file__).resolve().parents[1]
VERSION = 'stage3b_20261011_v1'
LIMIT, TARGET = 24*1024**2, 22*1024**2
SKIP = {'__pycache__', '.git', '.cache', '.ipynb_checkpoints'}


def collect(paths, required=True):
    files = {}
    for name in paths:
        p = ROOT/name
        if not p.exists():
            if required:
                raise FileNotFoundError(p)
            continue
        for f in ([p] if p.is_file() else sorted(p.rglob('*'))):
            rel = f.relative_to(ROOT)
            if f.is_file() and not any(part in SKIP for part in rel.parts) and f.suffix not in {'.pyc', '.pyo'}:
                if f.is_symlink() or not f.resolve().is_relative_to(ROOT):
                    raise ValueError('Unsafe source payload')
                files[str(rel)] = f
    return files


def split(files):
    groups, current, size = [], {}, 0
    for name, source in sorted(files.items()):
        compressor, amount = zlib.compressobj(6, zlib.DEFLATED, -15), 0
        with source.open('rb') as f:
            for data in iter(lambda: f.read(1024**2), b''):
                amount += len(compressor.compress(data))
        amount += len(compressor.flush()) + len(name.encode())*3 + 1000
        if amount >= TARGET:
            raise ValueError(f'One artifact exceeds the package target: {name}; split the artifact without dropping rows')
        if current and size+amount > TARGET:
            groups.append(current)
            current, size = {}, 0
        current[name], size = source, size+amount
    if current:
        groups.append(current)
    return groups


def archived_dependencies(derived_omissions=None):
    records = []
    old = [
        ('deliverables/stage2_20261010/package_checks.json', '72c3f6472c37a5cb8b8a9604fff2527ac3722929', 'delivery/20261010'),
        ('deliverables/stage3a_20261010/package_checks.json', '4e650eeea186f22c3633e4456c114571d2de479b', 'delivery/20261010_stage3a'),
    ]
    for filename, commit, folder in old:
        receipt = json.loads((ROOT/filename).read_text())
        for record in receipt['packages']:
            if 'Quick_Review' in record['filename']:
                continue
            records.append(dict(record, historical_delivery_commit=commit,
                                url=f"https://github.com/jiangsunyu7-ux/Wastewater_Paper/blob/{commit}/{folder}/{record['filename']}?raw=true"))
    return dict(new_stage3b_execution_requires_omitted_weights=False,
                stage3a_arithmetic_requires_omitted_weights=False,
                historical_full_training_replay='Use a separate clean directory and the complete original Stage3A/Stage2 delivery instructions; do not overlay old historical code/documents on this new project.',
                omitted_original_raw_csv=dict(path='wastewater_data/raw/wessex_all_2016_2025.csv',
                                              sha256='22f494e2b96fe6fa9550c68971d50c752ddd291793fdc60334d64b2ef089f518',
                                              retrieval='Original uploaded Wastewater_Part1_Plan_and_Raw.zip; not required for the included QA-v3 model replay. Included selected_raw_records.csv.gz permits selected-cohort QA checks.'),
                omitted_stage3a_checkpoints='All target/source optimizer and most epoch weight files; selected diagnostics and complete key curves are included. Archived endpoint/full trajectory replay needs the historical Runs packages listed below.',
                omitted_regenerated_arithmetic_duplicates=derived_omissions or [],
                duplicate_omission_scope='Only regenerated daily-loss copies are omitted from these ZIPs; original complete Stage3A daily_losses and all individual predictions are included. Workspace copies remain unchanged, and their JSON receipts, metrics and recalculation code are supplied. No negative experimental outcomes are removed.',
                verified_historical_packages=records,
                visibility='Repository visibility unchanged; private repository download needs an authorized GitHub session.')


def archive(folder, label, index, total, files, gzip_originals):
    stem = f'Wastewater_Stage3B_{label}_20261011' + (f'_Part{index:02d}' if total > 1 else '')
    destination = folder/(stem+'.zip')
    prefix = f'.stage3b_package_manifests/{stem}'
    start = f'{prefix}/START_HERE.md'
    text = ('# Stage3B evidence delivery\n\nEvery part is independently extractable. '
            'Quick_Review alone is not full evidence. Merge all categories into a NEW directory using '
            'scripts/import_stage3b_delivery.py and the outer SHA256SUMS. Read '
            'reports/stage3b_20261011_v1/REPRODUCE.md. Preserve original results. '
            'STOP after the fixed Stage3B round. No final2024–2025 performance is included.\n').encode()
    checks = {name: sha256(source) for name, source in sorted(files.items())}
    checks[start] = hashlib.sha256(text).hexdigest()
    manifest = dict(version=VERSION, category=label, part=index, parts=total,
                    files_sha256=checks, gzip_originals={k: v for k, v in gzip_originals.items() if k in files},
                    raw_final_period_performance_packaged=False)
    manifest_bytes = (json.dumps(manifest, indent=2, ensure_ascii=False)+'\n').encode()
    manifest_name = prefix+'/MANIFEST.json'
    manifest_hash = hashlib.sha256(manifest_bytes).hexdigest()
    internal_checks = dict(checks, **{manifest_name: manifest_hash})
    with zipfile.ZipFile(destination, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, source in sorted(files.items()):
            z.write(source, name)
        z.writestr(start, text)
        z.writestr(manifest_name, manifest_bytes)
        z.writestr(prefix+'/SHA256SUMS', ''.join(f'{h}  {n}\n' for n, h in sorted(internal_checks.items())))
    if destination.stat().st_size >= LIMIT:
        raise AssertionError('Package reaches/exceeds 24 MiB')
    with zipfile.ZipFile(destination) as z:
        assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
        for name, h in internal_checks.items():
            assert hashlib.sha256(z.read(name)).hexdigest() == h
    return dict(filename=destination.name, bytes=destination.stat().st_size, sha256=sha256(destination),
                category=label, part=index, parts=total, payload_files=len(files),
                crc_and_all_member_sha256_passed=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', default=f'deliverables/{VERSION}')
    args = parser.parse_args()
    output = ROOT/args.output
    if output.exists():
        raise FileExistsError('Delivery is immutable; use a new output directory')
    cfg = json.loads((ROOT/f'configs/{VERSION}/full.json').read_text())
    run = json.loads((ROOT/cfg['output']/'manifest.json').read_text())
    if run.get('status') != 'completed' or run.get('failed_conditions'):
        raise ValueError('Scientific run is not complete')
    for required in ['STAGE3A_EVIDENCE_AUDIT.md', 'STAGE3B_PROTOCOL.md',
                     f'reports/{VERSION}/ANALYSIS_ZH.md', f'reports/{VERSION}/CLAIM_EVIDENCE.csv',
                     f'reports/{VERSION}/RUN_STATUS.json', f'reports/{VERSION}/REPRODUCE.md',
                     f'reports/{VERSION}/CODE_VERSION.json', f'reports/{VERSION}/CODE_CHANGES.md',
                     f'reports/{VERSION}/code_changes.diff',
                     'notebooks/Wessex_Stage3B_CPU.ipynb']:
        if not (ROOT/required).is_file():
            raise FileNotFoundError(required)
    code = collect(['src', 'tests', 'scripts', 'requirements.txt', 'requirements-stage2.txt',
                    'notebooks/Wessex_Stage3B_CPU.ipynb', 'AGENTS.md', 'README.md', 'WORKFLOW.md',
                    'STAGE3B_PROTOCOL.md', 'STAGE3A_PROTOCOL.md', 'STAGE3A_IMPLEMENTATION.md',
                    f'reports/{VERSION}/REPRODUCE.md',
                    f'reports/{VERSION}/CODE_VERSION.json', f'reports/{VERSION}/CODE_CHANGES.md',
                    f'reports/{VERSION}/code_changes.diff', f'reports/{VERSION}/ENVIRONMENT.json',
                    f'reports/{VERSION}/audit/historical_window_eligibility.json',
                    'configs/shared_v3_20261009', 'configs/stage3a_20261010', f'configs/{VERSION}',
                    'data/derived/wessex_qa_v3_20261009', 'data/provenance/DEVELOPMENT_SELECTION_20261009.json',
                    'data/provenance/DEVELOPMENT_STATIONS_20261009.csv', 'data/provenance/SMOKE_STATIONS_20261009.csv',
                    'data/provenance/FACILITY_MAPPING_V3_20261009.csv', 'data/provenance/SOURCE_REGISTRY.csv',
                    'data/provenance/SEMANTICS_AND_TIMING_20261009.md',
                    'data/provenance/reconciliation_20261009/coverage_2016_2021.csv',
                    'data/provenance/stage2_facility_access_20261009', f'data/provenance/{VERSION}',
                    'runs/stage3a_20261010_v3/source/selection.json'])
    code.update(collect(['data/derived/wessex_audit_20261009/manifest.json',
                         'data/derived/wessex_audit_20261009/rules.json',
                         'data/derived/wessex_audit_20261009/summary.json',
                         'materials/received_stage2_20261009/paper idea.docx',
                         'data/provenance/paper_idea_20261009_extracted.txt'], required=False))
    quick = collect(['STAGE3A_EVIDENCE_AUDIT.md', 'STAGE3A_PROTOCOL.md', 'STAGE3A_IMPLEMENTATION.md',
                     'STAGE3B_PROTOCOL.md', 'RESEARCH_PLAN.md', 'EXPERIMENT_PROTOCOL.md', 'STATUS.md',
                     f'figures/{VERSION}', f'reports/{VERSION}'])
    diagnostics = collect([f'runs/{VERSION}'])
    # Large predictions, losses and traces belong to the evidence category, not Quick_Review.
    heavy_names = {'predictions_all.csv.gz', 'daily_losses.csv.gz', 'paired_index.csv.gz', 'paired_index.csv',
                   'daily_losses.csv', 'predictions_all.csv', 'validation_grid.csv', 'source_validation_grid.csv'}
    for name in list(quick):
        if Path(name).name in heavy_names or quick[name].stat().st_size > 2*1024**2:
            diagnostics[name] = quick.pop(name)
    archived = collect(['reports/stage3a_20261010/results',
                        'reports/stage3a_20261010/source_training_and_validation_curves.csv',
                        'reports/stage3a_20261010/trajectory_index.csv',
                        'reports/stage3a_20261010/ANALYSIS_ZH.md',
                        'runs/stage3a_20261010_v3/full/manifest.json',
                        'runs/stage3a_20261010_v3/full/completion.json'])
    # Include old per-condition selection, fit diagnostics and statuses, not all weight files.
    for f in (ROOT/'runs/stage3a_20261010_v3').rglob('*'):
        if f.is_file() and f.name in {'selection.json', 'selection_scores.json', 'diagnostics.json', 'data_diagnostics.json', 'status.json', 'curve.csv'}:
            name = str(f.relative_to(ROOT))
            if name not in code:
                archived[name] = f
    for f in (ROOT/'validation').glob('stage3a*'):
        if f.is_file() and f.suffix in {'.json', '.log'}:
            archived[str(f.relative_to(ROOT))] = f
    diagnostics.update(archived)
    derived_omissions = []
    for name, command in [
        (f'reports/{VERSION}/audit/stage3a_daily_losses_recomputed.csv.gz',
         'PYTHONPATH=src python scripts/check_stage3a_evidence_stage3b.py --arithmetic-only --skip-history --output outputs/recomputed_stage3a_full'),
        (f'reports/{VERSION}/arithmetic_external_recheck/stage3a_daily_losses_recomputed.csv.gz',
         'PYTHONPATH=src python scripts/check_stage3a_evidence_stage3b.py --arithmetic-only --skip-history --output outputs/recomputed_stage3a_full'),
        (f'reports/{VERSION}/software/portable_stage3a_arithmetic/daily_losses_recomputed.csv.gz',
         'python scripts/recalculate_stage3a_delivery.py --output outputs/recomputed_stage3a'),
    ]:
        for category in (quick, diagnostics):
            if name in category:
                source = category.pop(name)
                derived_omissions.append(dict(path=name, bytes=source.stat().st_size, sha256=sha256(source),
                                               reason='Regenerated arithmetic daily-loss duplicate; original scientific daily-loss file is fully included',
                                               recalculate_command=command, workspace_file_preserved=True))
    overlap = set(code)&set(quick) | set(code)&set(diagnostics) | set(quick)&set(diagnostics)
    for name in overlap:
        copies = [category[name] for category in (code, quick, diagnostics) if name in category]
        if len({sha256(f) for f in copies}) != 1:
            raise ValueError(f'Conflicting category overlap: {name}')
    output.parent.mkdir(parents=True, exist_ok=True)
    from import_stage3b_delivery import import_archives
    with tempfile.TemporaryDirectory(prefix='stage3b_package_', dir=output.parent) as temporary:
        temporary = Path(temporary)
        build, cache = temporary/'delivery', temporary/'gzip_cache'
        build.mkdir(); cache.mkdir()
        dependency_file = cache/'OMITTED_DEPENDENCIES.json'
        dependency_file.write_text(json.dumps(archived_dependencies(derived_omissions), indent=2, ensure_ascii=False)+'\n')
        code[f'reports/{VERSION}/OMITTED_DEPENDENCIES.json'] = dependency_file
        gzip_originals = {}
        for name in list(diagnostics):
            source = diagnostics[name]
            if source.suffix == '.csv' and source.stat().st_size > 2*1024**2:
                compressed = cache/(hashlib.sha256(name.encode()).hexdigest()+'.gz')
                with source.open('rb') as original, compressed.open('wb') as stream:
                    with gzip.GzipFile(filename='', mode='wb', fileobj=stream, compresslevel=6, mtime=0) as zipped:
                        shutil.copyfileobj(original, zipped)
                del diagnostics[name]
                diagnostics[name+'.gz'] = compressed
                gzip_originals[name+'.gz'] = dict(original_path=name, original_sha256=sha256(source), original_bytes=source.stat().st_size)
        records = []
        for label, files in [('Quick_Review', quick), ('Code_and_Reproduce', code), ('Predictions_and_Diagnostics', diagnostics)]:
            chunks = split(files)
            for index, chunk in enumerate(chunks, 1):
                records.append(archive(build, label, index, len(chunks), chunk, gzip_originals))
        outer = build/'SHA256SUMS'
        outer.write_text(''.join(f"{r['sha256']}  {r['filename']}\n" for r in records))
        extracted = temporary/'clean_extraction'
        receipt = import_archives([build/r['filename'] for r in records], extracted, outer)
        receipt.update(version=VERSION, packages=records, all_zip_sizes_below_24_MiB=True,
                       extraction_crc_and_all_member_hashes_passed=True,
                       scientific_manifest_sha256=sha256(ROOT/cfg['output']/'manifest.json'),
                       protocol_sha256=sha256(ROOT/'STAGE3B_PROTOCOL.md'),
                       packaging_did_not_train_models=True, live_colab_drive_verified=False,
                       full_stage3a_training_replay_not_claimed=True)
        receipt.pop('destination', None)
        (build/'package_checks.json').write_text(json.dumps(receipt, indent=2)+'\n')
        shutil.copy2(ROOT/f'reports/{VERSION}/REPRODUCE.md', build/'README.md')
        os.rename(build, output)
        print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
