"""Recompute Stage 3B point metrics and synchronized paired calendar intervals."""
import argparse
import json
from pathlib import Path

import pandas as pd

from wastewater.stage3b_evaluation import summarize_predictions


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', default='configs/stage3b_20261011_v1/full.json')
    parser.add_argument('--predictions', default='reports/stage3b_20261011_v1/results/predictions_all.csv.gz')
    parser.add_argument('--output', default='reports/stage3b_20261011_v1/results')
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    config = json.loads((root / args.config).read_text())
    predictions = pd.read_csv(root / args.predictions, dtype={'site_id': str})
    _, _, metric, _ = summarize_predictions(predictions, config, root / args.output)
    print(metric[metric.model.eq('shared_residual_ridge_bias_selected') & metric.budget.eq(30) & metric.constraint.eq('raw')].to_string(index=False))


if __name__ == '__main__':
    main()
