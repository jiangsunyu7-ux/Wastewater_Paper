"""Recheck QA-v3 from the delivered genuine raw excerpt without the full raw CSV.

The excerpt's audit_rule column is ignored: all quality decisions are rebuilt
from the provider's original fields. No experiment predictions are read.
"""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--raw-excerpt", type=Path, default=Path(__file__).resolve().parent / "selected_raw_records.csv.gz")
    ap.add_argument("--canonical", type=Path, default=Path(__file__).resolve().parents[2] / "derived/wessex_qa_v3_20261009/daily_candidates.csv")
    ap.add_argument("--output", type=Path)
    args = ap.parse_args()
    raw = pd.read_csv(args.raw_excerpt, dtype={"SiteID": str})
    canonical = pd.read_csv(args.canonical, dtype={"site_id": str})
    raw["value"] = pd.to_numeric(raw.TotalVolume, errors="coerce").astype(float)
    raw["quality"] = raw.QualityFlag.str.strip().str.casefold()
    key = ["SiteID", "Date"]
    variants = raw.drop_duplicates(key + ["value", "quality", "Units"])
    conflicts = pd.MultiIndex.from_frame(variants.loc[variants.duplicated(key, keep=False), key]).unique()
    raw["conflict"] = pd.MultiIndex.from_frame(raw[key]).isin(conflicts)
    raw["valid"] = raw.quality.eq("good") & np.isfinite(raw.value) & raw.value.ge(0) & raw.Units.eq("m3") & ~raw.conflict
    first = raw.drop_duplicates(key)
    rebuilt = first[["SiteID", "Date"]].rename(columns={"SiteID": "site_id", "Date": "date"}).copy()
    rebuilt["value"] = first.value.where(first.valid)
    both = canonical.merge(rebuilt, on=["site_id", "date"], how="outer", indicator=True, validate="one_to_one")
    assert both._merge.eq("both").all()
    assert np.array_equal(both.candidate_value_m3.isna(), both.value.isna())
    keep = both.value.notna()
    assert np.array_equal(both.loc[keep, "candidate_value_m3"].to_numpy(), both.loc[keep, "value"].to_numpy())
    assert np.array_equal(both.observed_input_m3.isna(), both.value.isna())
    assert np.array_equal(both.loc[keep, "observed_input_m3"].to_numpy(), both.loc[keep, "value"].to_numpy())
    assert np.array_equal(both.target_quality_valid.to_numpy(), both.value.notna().to_numpy(int))
    result = {"status": "passed", "raw_excerpt_sha256": hashlib.sha256(args.raw_excerpt.read_bytes()).hexdigest(), "canonical_sha256": hashlib.sha256(args.canonical.read_bytes()).hexdigest(), "rows": len(raw), "valid_good_nonnegative": int(raw.valid.sum()), "Good_zero_retained": int((raw.valid & raw.value.eq(0)).sum()), "Missing_zero_excluded": int((raw.quality.eq("missing") & raw.value.eq(0)).sum()), "missing_or_excluded_targets_interpolated": False, "value_comparison": "exact for all delivered float64 values and missing positions"}
    text = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text)
    print(text)


if __name__ == "__main__":
    main()
