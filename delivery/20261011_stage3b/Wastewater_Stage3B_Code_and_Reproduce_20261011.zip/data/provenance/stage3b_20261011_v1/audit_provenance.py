"""Independent, read-only QA/metadata audit for the fixed Stage 3B SiteID cohort.

Run from repository root with .venv-stage2/bin/python. All outputs are written
beside this script. Forecast performances and 2024--2025 values are not used.
"""
from __future__ import annotations

import concurrent.futures
import datetime as dt
import hashlib
import html
import json
import math
import re
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
SOURCES = ["13006", "13008", "13012"]
TARGETS = ["13013", "13015", "13016", "13017", "13022", "13024", "13025", "13028", "13029", "13031"]
ITEM = "https://www.arcgis.com/sharing/rest/content/items/10b910ef3524448e9a5c8691f802dcd2?f=json"
SERVICE = "https://services.arcgis.com/3SZ6e0uCvPROr4mS/arcgis/rest/services/Wessex_Water_Total_Daily_Volume_20162025/FeatureServer"


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(name: str, value) -> None:
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def request_metadata(pair):
    name, url = pair
    record = {"query_name": name, "url": url, "queried_utc": now(), "query_date": "2026-10-11", "verification": "live_request_attempt"}
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "Wastewater-research-evidence-audit/1.0"})
        with urllib.request.urlopen(request, timeout=12) as response:
            body = response.read(2 * 1024 * 1024)
            record.update(status=response.status, final_url=response.url, response_sha256=hashlib.sha256(body).hexdigest(), response_bytes=len(body))
            (OUT / f"official_{name}_response.bin").write_bytes(body)
            record["excerpt"] = body[:600].decode("utf-8", errors="replace")
            record["success"] = True
            try:
                parsed = json.loads(body)
                if isinstance(parsed, dict) and "error" in parsed:
                    record.update(success=False, arcgis_error=parsed["error"])
            except (ValueError, UnicodeDecodeError):
                record.update(success=False, error="Response is not valid JSON metadata")
    except Exception as exc:
        record.update(success=False, exception_type=type(exc).__name__, error=str(exc), status=getattr(exc, "code", None))
        if isinstance(exc, urllib.error.HTTPError):
            body = exc.read(4096)
            record["response_excerpt"] = body.decode("utf-8", errors="replace")
            record["response_excerpt_sha256"] = hashlib.sha256(body).hexdigest()
    return record


def main() -> None:
    raw_path = ROOT / "wastewater_data/raw/wessex_all_2016_2025.csv"
    canonical_path = ROOT / "data/derived/wessex_qa_v3_20261009/daily_candidates.csv"
    mapping_path = ROOT / "data/provenance/FACILITY_MAPPING_V3_20261009.csv"
    coverage_path = ROOT / "data/provenance/reconciliation_20261009/coverage_2016_2021.csv"
    selection_path = ROOT / "data/provenance/DEVELOPMENT_SELECTION_20261009.json"
    paper_path = ROOT / "materials/received_stage2_20261009/paper idea.docx"
    selection = json.loads(selection_path.read_text())
    assert selection["reserved_source_candidate_ids"] == SOURCES
    assert selection["development_ids"] == TARGETS
    hashes = {str(p.relative_to(ROOT)): digest(p) for p in [raw_path, canonical_path, mapping_path, coverage_path, selection_path]}
    assert hashes[str(raw_path.relative_to(ROOT))] == "22f494e2b96fe6fa9550c68971d50c752ddd291793fdc60334d64b2ef089f518"
    assert hashes[str(canonical_path.relative_to(ROOT))] == "40f6e6fdb1d09d0afa9c19ba31729b156811ca1cdbb0b317484fdf5fea1d854f"
    assert hashes[str(mapping_path.relative_to(ROOT))] == "34a40ca92b25d081636c88dd752f007366bde73cff1b5ee3962ee3a300e77eab"

    paper = {"exists": paper_path.exists(), "path": str(paper_path.relative_to(ROOT)), "attachment_role": "research material, not execution authorization"}
    if paper_path.exists():
        with zipfile.ZipFile(paper_path) as archive:
            document = ET.fromstring(archive.read("word/document.xml"))
        ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
        paragraphs = ["".join(p.itertext()).strip() for p in document.findall(".//w:p", ns)]
        text = "\n\n".join(p for p in paragraphs if p)
        (OUT / "paper_idea_from_docx.txt").write_text(text + "\n")
        paper.update(sha256=digest(paper_path), extracted_sha256=digest(OUT / "paper_idea_from_docx.txt"), paragraphs=len(paragraphs), text_characters=len(text))
        assert paper["sha256"] == "e698f0c07c3e73baf16c2b88d873675405443b2186dfe6746f55a50e33c818b1"
    write_json("paper_idea_evidence.json", paper)

    frames, name_frames = [], []
    for chunk in pd.read_csv(raw_path, dtype={"SiteID": str}, chunksize=100000):
        early = chunk.loc[chunk.Date.le("2021-12-31") & chunk.SiteName.str.contains("WATER RECYCLING CENTRE", na=False), ["SiteID", "SiteName"]]
        name_frames.append(early.drop_duplicates())
        keep = chunk.SiteID.isin(SOURCES + TARGETS) & chunk.Date.ge("2016-01-01") & chunk.Date.le("2023-12-31")
        keep &= ~chunk.SiteID.isin(SOURCES) | chunk.Date.le("2021-12-31")
        frames.append(chunk.loc[keep].copy())
    raw = pd.concat(frames, ignore_index=True)
    names = pd.concat(name_frames, ignore_index=True).drop_duplicates()
    # Downstream calculations are restricted to source <=2021 and target <=2023.
    assert set(raw.Units) == {"m3"}
    raw["value"] = pd.to_numeric(raw.TotalVolume, errors="coerce").astype(float)
    raw["quality"] = raw.QualityFlag.str.strip().str.casefold()
    key = ["SiteID", "Date"]
    variants = raw.drop_duplicates(key + ["value", "quality", "Units"])
    conflict_keys = pd.MultiIndex.from_frame(variants.loc[variants.duplicated(key, keep=False), key]).unique()
    raw["conflict"] = pd.MultiIndex.from_frame(raw[key]).isin(conflict_keys)
    raw["exact_duplicate"] = raw.duplicated(key + ["value", "quality", "Units"], keep=False) & ~raw.conflict
    raw["valid"] = raw.quality.eq("good") & np.isfinite(raw.value) & raw.value.ge(0) & ~raw.conflict & raw.Units.eq("m3")
    def reason(row):
        if row["conflict"]:
            return "conflicting_site_day"
        if not np.isfinite(row["value"]):
            return "nonfinite_numeric_value"
        if row["quality"] == "missing":
            return "Missing_zero_code" if row["value"] == 0 else "Missing_nonzero"
        if row["quality"] == "suspect":
            return "Suspect_published_flag"
        if row["quality"] != "good":
            return "unrecognized_or_missing_quality"
        if row["value"] < 0:
            return "Good_negative"
        return "accepted_Good_zero" if row["value"] == 0 else "accepted_Good_positive"
    raw["audit_rule"] = raw.apply(reason, axis=1)
    raw.drop(columns=["value", "quality", "valid", "conflict", "exact_duplicate"]).to_csv(OUT / "selected_raw_records.csv.gz", index=False, compression={"method": "gzip", "mtime": 0})
    raw.loc[~raw.valid, ["OBJECTID", "SiteID", "SiteName", "Date", "TotalVolume", "Units", "QualityFlag", "audit_rule"]].to_csv(OUT / "excluded_selected_records.csv", index=False)
    first = raw.drop_duplicates(key).copy()
    reconstructed = first[["SiteID", "Date"]].rename(columns={"SiteID": "site_id", "Date": "date"})
    reconstructed["candidate_value_m3"] = first.value.where(first.valid)
    canonical = pd.read_csv(canonical_path, dtype={"site_id": str})
    joined = canonical.merge(reconstructed, on=["site_id", "date"], how="outer", suffixes=("_saved", "_recomputed"), indicator=True, validate="one_to_one")
    saved = joined.candidate_value_m3_saved.to_numpy(float)
    rebuilt = joined.candidate_value_m3_recomputed.to_numpy(float)
    assert joined._merge.eq("both").all()
    assert np.array_equal(np.isnan(saved), np.isnan(rebuilt))
    assert np.array_equal(saved[np.isfinite(saved)], rebuilt[np.isfinite(rebuilt)])
    assert np.array_equal(canonical.candidate_value_m3.isna(), canonical.observed_input_m3.isna())
    assert np.array_equal(canonical.loc[canonical.candidate_value_m3.notna(), "candidate_value_m3"], canonical.loc[canonical.observed_input_m3.notna(), "observed_input_m3"])
    assert np.array_equal(canonical.target_quality_valid.to_numpy(int), canonical.candidate_value_m3.notna().to_numpy(int))
    assert not canonical.duplicated(["site_id", "date"]).any()
    assert not canonical.candidate_value_m3.lt(0).any()

    count_rows = []
    for site, rows in [("ALL", raw)] + list(raw.groupby("SiteID", sort=True)):
        role = "fixed_source_and_development" if site == "ALL" else "source" if site in SOURCES else "development"
        counts = rows.audit_rule.value_counts()
        row = {"site_id": site, "partition": role, "raw_rows": len(rows), "unique_calendar_dates": rows.Date.nunique(), "first_date": rows.Date.min(), "last_date": rows.Date.max(), "valid_good_nonnegative_rows": int(rows.valid.sum()), "duplicate_rows": int(rows.duplicated(key, keep=False).sum()), "conflict_rows": int(rows.conflict.sum()), "identical_duplicate_rows": int(rows.exact_duplicate.sum())}
        for rule in sorted(raw.audit_rule.unique()):
            row[rule] = int(counts.get(rule, 0))
        count_rows.append(row)
    counts_frame = pd.DataFrame(count_rows).fillna(0)
    counts_frame.to_csv(OUT / "data_quality_counts.csv", index=False)
    selected_counts = {"raw_rows": len(raw), "canonical_rows": len(canonical), "valid_good_targets": int(raw.valid.sum()), "Missing_zero": int((raw.quality.eq("missing") & raw.value.eq(0)).sum()), "Missing_nonzero": int((raw.quality.eq("missing") & raw.value.ne(0)).sum()), "Good_negative": int((raw.quality.eq("good") & raw.value.lt(0)).sum()), "Good_zero_retained": int((raw.quality.eq("good") & raw.value.eq(0) & raw.valid).sum()), "Suspect": int(raw.quality.eq("suspect").sum()), "conflicting_days": len(conflict_keys), "duplicate_rows": int(raw.duplicated(key, keep=False).sum())}
    assert selected_counts["raw_rows"] == 35796 and selected_counts["valid_good_targets"] == 35518

    coverage = pd.read_csv(coverage_path, dtype={"site_id": str})
    source_coverage = coverage[coverage.site_id.isin(SOURCES)].copy()
    assert len(source_coverage) == 18
    assert source_coverage.year.between(2016, 2021).all()
    assert source_coverage.coverage.ge(.95).all()
    # Recount each source-year directly under the current nonnegative QA rule.
    for row in source_coverage.itertuples():
        rows = raw.loc[raw.SiteID.eq(row.site_id) & raw.Date.str[:4].eq(str(row.year))]
        valid_days = rows.loc[rows.valid, "Date"].nunique()
        assert valid_days == row.valid_nonnegative_dates
        assert math.isclose(valid_days / row.calendar_days, row.coverage, abs_tol=1e-12)
    source_coverage.to_csv(OUT / "source_coverage_rechecked.csv", index=False)
    names["name_group"] = names.SiteName.str.casefold().str.replace(r"\s+(outfall|outlet).*$", "", regex=True).str.replace(r"\s+", " ", regex=True).str.strip()
    groups = names.groupby("name_group").SiteID.apply(lambda x: sorted(set(x)))
    mapping = pd.read_csv(mapping_path, dtype={"site_id": str})
    for row in mapping.itertuples():
        name_rows = names[names.SiteID.eq(row.site_id)]
        assert len(name_rows) == 1
        assert name_rows.SiteName.iloc[0] == row.provider_site_name
        linked = groups[name_rows.name_group.iloc[0]]
        assert not any(other in SOURCES + TARGETS and (other in SOURCES) != (row.site_id in SOURCES) for other in linked)
        assert row.physical_facility_id == "unknown" and row.outfall_id == "unknown" and not row.mapping_verified
    mapping["upstream_mapping_sha256"] = digest(mapping_path)
    mapping["official_evidence_url"] = ITEM
    mapping["official_service_url"] = SERVICE + "/0?f=pjson"
    mapping["query_date"] = "2026-10-11"
    mapping["verification_status"] = "SiteID/name linkage verified in released raw records; physical facility and outfall identity unresolved"
    mapping["cross_partition_same_name_conflict_found"] = False
    mapping.to_csv(OUT / "FACILITY_MAPPING.csv", index=False)

    eligible = coverage.groupby("site_id").agg(years=("year", "nunique"), minimum_year_coverage=("coverage", "min"), site_name=("site_name", "first"))
    eligible = eligible[(eligible.years == 6) & (eligible.minimum_year_coverage >= .95)].copy()
    name_counts = names.groupby("SiteID").SiteName.nunique()
    eligible = eligible.loc[eligible.index.map(lambda site: name_counts.get(site, 0) == 1)]
    assert len(eligible) == selection["eligible_count"] == 199
    candidates = eligible.loc[~eligible.index.isin(SOURCES + TARGETS)].copy().reset_index()
    candidates["selection_rule"] = "2016-2021 every year Good/nonnegative/nonconflict calendar coverage >=95%; one released name"
    candidates["performance_used_for_selection"] = False
    candidates["physical_identity_verified"] = False
    candidates["used_in_stage3b_main_source_pool"] = False
    candidates["partition_status"] = "not assigned; resolve physical links and future held-out target reservations before any expansion"
    candidates.to_csv(OUT / "future_source_expansion_candidates_pre2022.csv", index=False)

    queries = [("item", ITEM), ("tdv_table", SERVICE + "/0?f=pjson"), ("provider_catalog", "https://www.arcgis.com/sharing/rest/search?q=owner%3AWessexWaterData&num=100&f=json")]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        query_records = list(pool.map(request_metadata, queries))
    write_json("official_metadata_queries.json", query_records)
    saved_item_path = ROOT / "wastewater_data/metadata/wessex_item.json"
    saved_layer_path = ROOT / "wastewater_data/metadata/wessex_layer.json"
    item = json.loads(saved_item_path.read_text())
    layer = json.loads(saved_layer_path.read_text())
    description = html.unescape(re.sub("<[^>]*>", " ", item["description"]))
    description = re.sub(r"\s+", " ", description).strip()
    excerpts = {
        "tdv_definition": "Total Daily Volume (TDV) is the volume of effluent discharged to the environment from the permitted outfall at a Water Recycling Centre (WRC) or Wastewater Treatment Centre (WTC).",
        "missing_zero_code": "For whole days with missing data, the TDV value is set to zero and the missing flag applied, even though flow is likely to have passed through the asset.",
        "manual_quality_revision": "Data may also be manually flagged as ‘Suspect’ where there is a known issue with the flow meter that is not identified by the automatic quality assessment system.",
        "suspect_threshold": "If fewer than 90% of a calendar day’s readings are flagged as ‘Good’, the TDV for that day is assigned a ‘Suspect’ flag.",
        "public_update": "This dataset will be updated by 1 April annually."
    }
    for key_name, excerpt in excerpts.items():
        # The published HTML uses extra whitespace/inline formatting; whitespace is normalized only for comparison.
        assert excerpt in description, key_name
    official_snapshot = {"evidence_status": "actual supplied official snapshot read and hashed; fresh metadata request status recorded separately", "source_url": ITEM, "reported_download_date": "2026-10-08", "received_date": "2026-10-09", "review_date": "2026-10-11", "title": item["title"], "owner": item["owner"], "item_id": item["id"], "item_modified_epoch_ms": item["modified"], "service_url": item["url"], "license": "CC BY 4.0", "license_evidence": "https://creativecommons.org/licenses/by/4.0/ appears in saved provider licenseInfo", "layer_type": layer["type"], "relationships": layer["relationships"], "field_names": [field["name"] for field in layer["fields"]], "excerpts": excerpts, "physical_mapping_claim": "not established by a nonspatial table with no relationships; distinct names do not prove independence", "unit_observed": "m3 in all selected raw records"}
    assert "creativecommons.org/licenses/by/4.0/" in item["licenseInfo"]
    write_json("official_snapshot_evidence.json", official_snapshot)
    hashes[str(saved_item_path.relative_to(ROOT))] = digest(saved_item_path)
    hashes[str(saved_layer_path.relative_to(ROOT))] = digest(saved_layer_path)
    if paper_path.exists():
        hashes[str(paper_path.relative_to(ROOT))] = digest(paper_path)
    write_json("data_provenance_audit.json", {"status": "completed", "audited_utc": now(), "version": "stage3b_20261011_v1", "sources": SOURCES, "development": TARGETS, "quality_counts": selected_counts, "checks": {"fixed_cohort_matches_saved_selection": True, "raw_hash_matches_qa_v3_manifest": True, "qa_v3_hash_matches_accepted_version": True, "independent_raw_reconstruction_exactly_matches_all_qa_v3_input_and_target_values": True, "all_source_years_coverage_ge_95pct": True, "no_same_normalized_name_group_crosses_source_target_partition": True, "physical_facility_independence_verified": False}, "hashes": hashes, "source_expansion_candidates": len(candidates), "fresh_official_metadata_successes": sum(record["success"] for record in query_records), "scope": "No 2024-2025 forecast performance evaluated or used; raw CSV scanned only to filter and reconstruct source <=2021/development <=2023; existing all-period descriptive audit remains disclosed"})
    print(json.dumps({"status": "completed", "quality_counts": selected_counts, "future_candidates": len(candidates), "live_metadata_successes": sum(record["success"] for record in query_records), "raw_reconstruction_matches": True}, ensure_ascii=False))


if __name__ == "__main__":
    main()
