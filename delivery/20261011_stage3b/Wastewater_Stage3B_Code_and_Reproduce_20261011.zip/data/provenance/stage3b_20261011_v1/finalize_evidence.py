"""Index saved official requests and conservatively annotate unresolved identities."""
from pathlib import Path
import json
import hashlib
import pandas as pd

OUT = Path(__file__).resolve().parent


def main():
    queries = []
    sources = sorted(OUT.glob("facility_lookup*queries.json")) + [OUT / "official_metadata_queries.json"]
    for source in sources:
        records = json.loads(source.read_text())
        for record in records:
            body = OUT / f"official_{record['query_name']}_response.bin"
            if body.exists():
                parsed = json.loads(body.read_bytes())
                if isinstance(parsed, dict) and "error" in parsed:
                    record.update(success=False, arcgis_error=parsed["error"])
                record["saved_response_file"] = body.name
                record["saved_response_sha256"] = hashlib.sha256(body.read_bytes()).hexdigest()
                record["returned_attribute_records"] = len(parsed["features"]) if "features" in parsed else None
            record["contains_forecast_performance"] = False
            record["response_class"] = "official_static_metadata_or_static_location_attributes"
            queries.append(record)
        source.write_text(json.dumps(records, ensure_ascii=False, indent=2) + "\n")
    (OUT / "OFFICIAL_QUERY_INDEX.json").write_text(json.dumps(queries, ensure_ascii=False, indent=2) + "\n")
    pd.DataFrame([{key: record.get(key) for key in ["query_name", "url", "queried_utc", "query_date", "success", "status", "saved_response_file", "saved_response_sha256", "returned_attribute_records", "contains_forecast_performance"]} | {"failure_reason": str(record.get("arcgis_error", record.get("error", "")))} for record in queries]).to_csv(OUT / "OFFICIAL_QUERY_INDEX.csv", index=False)

    def attributes(name):
        payload = json.loads((OUT / f"official_{name}_response.bin").read_bytes())
        assert "error" not in payload
        return pd.DataFrame([feature["attributes"] for feature in payload["features"]])

    links = attributes("selected_overflow_link_attributes")
    links.to_csv(OUT / "related_storm_overflow_links.csv", index=False)
    catchments = pd.concat([attributes("selected_catchment_name_candidates"), attributes("box_catchment_name_candidate")], ignore_index=True).drop_duplicates()
    catchments["status"] = "name-match candidate; no documented crosswalk to TDV SiteID or physical facility"
    catchments.to_csv(OUT / "catchment_name_candidates.csv", index=False)
    locdata = json.loads((OUT / "official_related_storm_outfall_location_candidates_response.bin").read_bytes())
    locations = pd.DataFrame([{**feature["attributes"], "longitude": feature.get("geometry", {}).get("x"), "latitude": feature.get("geometry", {}).get("y"), "status": "storm-overflow outfall; not the treated-TDV outfall identity"} for feature in locdata["features"]])
    locations.to_csv(OUT / "related_storm_outfall_locations.csv", index=False)

    mapping = pd.read_csv(OUT / "FACILITY_MAPPING.csv", dtype={"site_id": str})
    related = links.groupby("SiteID").OverflowID.apply(lambda values: "|".join(sorted(set(values))))
    mapping["related_storm_overflow_ids"] = mapping.site_id.astype(int).map(related).fillna("none returned")
    mapping["storm_link_evidence_file"] = "official_selected_overflow_link_attributes_response.bin"
    mapping["storm_link_caveat"] = "Storm overflow namespace; not a verified treated-effluent TDV outfall link"
    # These are manually reviewed name candidates, never inferred numerical IDs.
    name_candidates = {"13006": "ALMONDSBURY", "13008": "AMESBURY", "13012": "AUST", "13013": "AVONMOUTH", "13015": "BARFORD ST MARTIN", "13016": "SALTFORD", "13017": "BECKINGTON", "13022": "BISHOPS LYDEARD", "13024": "BLACKHEATH", "13025": "BLAGDON", "13028": "BOWERHILL", "13029": "BOX", "13031": "BRADFORD ON AVON"}
    mapping["catchment_name_candidate"] = mapping.site_id.map(name_candidates)
    names_to_id = catchments.set_index("BoundryNme").BoundaryId
    mapping["catchment_boundary_id_candidate"] = mapping.catchment_name_candidate.map(names_to_id)
    assert mapping.catchment_boundary_id_candidate.notna().all()
    mapping["catchment_caveat"] = "Official name match, no documented SiteID crosswalk; not a physical_facility_id"
    mapping["unresolved"] = "TDV meter/physical-facility/normal treated-effluent outfall crosswalk unavailable; sewer-catchment and storm-overflow metadata only provide candidate context"
    assert not mapping.mapping_verified.any()
    assert mapping.physical_facility_id.eq("unknown").all() and mapping.outfall_id.eq("unknown").all()
    mapping.to_csv(OUT / "FACILITY_MAPPING.csv", index=False)
    cross_partition = []
    expanded = links.assign(site_id=links.SiteID.astype(str)).merge(mapping[["site_id", "partition"]], on="site_id", validate="many_to_one")
    for overflow_id, rows in expanded.groupby("OverflowID"):
        if rows.partition.nunique() > 1:
            cross_partition.append({"overflow_id": overflow_id, "site_ids": sorted(rows.site_id.unique().tolist())})
    assert not cross_partition, "Potential official storm linkage crosses fixed partitions; investigate before running"
    (OUT / "FACILITY_REVIEW_STATUS.json").write_text(json.dumps({"review_date": "2026-10-11", "official_requests": len(queries), "valid_json_successes": sum(record["success"] for record in queries), "failed_requests": [{"query_name": record["query_name"], "reason": record.get("arcgis_error", record.get("error"))} for record in queries if not record["success"]], "storm_link_records": len(links), "site_ids_with_storm_links": int(links.SiteID.nunique()), "storm_link_cross_partition_conflicts": cross_partition, "catchment_name_candidates": 13, "physical_facility_independence_verified": False, "treated_TDV_outfall_identity_verified": False, "final_performance_used": False}, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"indexed_official_queries": len(queries), "semantic_successes": sum(record["success"] for record in queries), "physical_mapping_verified": False, "cross_partition_conflicts": cross_partition}))


if __name__ == "__main__":
    main()
