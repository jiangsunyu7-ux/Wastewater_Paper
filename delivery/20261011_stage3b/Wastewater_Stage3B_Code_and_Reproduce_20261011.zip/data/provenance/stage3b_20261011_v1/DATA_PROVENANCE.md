# Stage 3B 数据、附件与设施证据核验

核验日期：2026-10-11。此目录只保存新增审查材料；Stage 2、Stage 3A、原始文件和 QA-v3 派生文件保持原样。本次核验没有计算或查看 2024—2025 年预测性能。

## 原始数据版本与语义

Wessex Water 官方条目为 `10b910ef3524448e9a5c8691f802dcd2`，标题为 *Wessex Water Wastewater Total Daily Volume Data 2016-2025*，官方所有者 `WessexWaterData`。来源链接：

- https://www.arcgis.com/sharing/rest/content/items/10b910ef3524448e9a5c8691f802dcd2?f=json
- https://services.arcgis.com/3SZ6e0uCvPROr4mS/arcgis/rest/services/Wessex_Water_Total_Daily_Volume_20162025/FeatureServer/0?f=pjson

原始 CSV 的 SHA256 为 `22f494e2b96fe6fa9550c68971d50c752ddd291793fdc60334d64b2ef089f518`。已有下载记录报告下载日期为 2026-10-08，项目接收日期为 2026-10-09；这是收到的冻结文件，本轮没有重新下载或替换体积数据。保存的官方 `licenseInfo` 明示 **CC BY 4.0**，应归属 Wessex Water；这项许可依据与原始文件校验值见 `official_snapshot_evidence.json`、`data_provenance_audit.json` 和原 `SOURCE_REGISTRY.csv`。

提供方定义：“Total Daily Volume (TDV) is the volume of effluent discharged to the environment from the permitted outfall at a Water Recycling Centre (WRC) or Wastewater Treatment Centre (WTC).” 本轮固定队列全为 WRC，原始 `Units` 全部是 `m3`。对象为 **daily treated effluent discharge volume / treated effluent volume forecasting**，不是瞬时流量、进水、污染物浓度、许可阈值或处理能力。

元数据说明日体积来自 15 分钟测量，多数仪表取得 MCERTS 认证，也明确存在未认证或中途认证的站点。不能统一宣称各站测量真值具有 ±8% 精度。元数据中的 `86,000` 秒计算公式存在疑点，本研究保留发布的日体积，未擅自重算。当前评价真值是发布后合格记录，不能分离仪表误差与模型误差。

本轮官方条目、TDV 字段结构和提供方目录请求均实际成功，保存完整响应、URL、查询时间、SHA256 于 `official_*_response.bin` 和 `official_metadata_queries.json`。新条目的 `modified` 值与原保存快照一致（1783081759000）；HTTP 返回字节不必与旧 JSON 排版一致。网络恢复不构成数据版本更新。

## QA-v3 独立重建

沿用 `data/derived/wessex_qa_v3_20261009/daily_candidates.csv`，SHA256 为 `40f6e6fdb1d09d0afa9c19ba31729b156811ca1cdbb0b317484fdf5fea1d854f`。`audit_provenance.py` 从原始 CSV 独立筛选固定 13 个 SiteID，源站只取 2016—2021，开发站只取 2016—2023，重新核验单位、数值、公开质量标记和同站同日冲突，再与全部保存的 QA-v3 输入、目标值、有效标记及日历键逐条比较；合法值和缺失位置均精确一致。未发现需要改写 QA-v3 的问题。

| 项目 | 固定队列记录数 |
|---|---:|
| 原始记录 / QA-v3 日记录 | 35,796 / 35,796 |
| 有效 Good 非负目标 | 35,518 |
| 保留的 Good 零值 | 14 |
| Missing 编码零值 | 37 |
| Missing 非零值 | 2 |
| Good 负值 | 19 |
| Suspect | 220 |
| 同站同日重复 / 冲突日 | 0 / 0 |
| 总屏蔽记录 | 278 |

规则同时用于输入、训练标签和评价真值：只保留 Good、有限非负、单位 m3、无冲突记录；Missing（包括编码零）、Suspect、Good 负值或非有限值屏蔽。提供方原文：“For whole days with missing data, the TDV value is set to zero and the missing flag applied, even though flow is likely to have passed through the asset.” 因而 Missing 零不能用作真实观测；Good 零按既定规则保留，也不构成独立仪表真值核验。

固定 13 站当前没有重复记录不意味着全库无冲突。此前全量描述性审计发现的冲突仍保留在旧审计；若后续扩源，必须继续按同一规则隔离冲突整日，不自动平均或挑值。日历缺失位置不能压缩，不插值目标，不从未来填补输入。

`data_quality_counts.csv` 给出逐 SiteID 计数，`excluded_selected_records.csv` 给出本队列全部 278 条排除记录，`selected_raw_records.csv.gz` 保存 35,796 条允许时期的原始记录摘录（含原 OBJECTID 与排除规则），支持不携带全库时的清理核验。它不含 2024—2025 年原始记录。

这是**使用发布后质量标记的历史回顾实验**。提供方说质量标记入库时可自动生成，也可能手工修改，公开日数据每年更新；没有历史首次到达、修订日志或日终可用时刻证据。当前不能证明预测起点可读取最终 QA 或体积，更不能声称真实部署已验证。

## 固定分区与设施关系

源 SiteID：13006、13008、13012。开发 SiteID：13013、13015、13016、13017、13022、13024、13025、13028、13029、13031。原来的两站流程检查仍为 13013、13015。

`FACILITY_MAPPING.csv` 保留原名字、角色、同名组以及未验证状态。原映射 SHA256 为 `34a40ca92b25d081636c88dd752f007366bde73cff1b5ee3962ee3a300e77eab`。2016—2021 原始名字核验中，各固定 ID 只有一个提供方名称，规范化同名组没有跨源/目标分区冲突。不同名字只能排除这个有限的文字冲突，不能证明不同物理设施。

新查询继续查官方污水集水区、`overflow_to_outfall` 与 `outfall_location` 静态属性。原 TDV 服务仍是非空间 Table，只有 SiteID、SiteName、Date、TotalVolume、Units、QualityFlag 等字段，`relationships=[]`，没有厂址、许可号或 TDV 排口关系。集水区名称能匹配若干候选边界，但其 `BoundaryId` 属另一命名空间，不能通过数字规律自行补成物理设施 ID。原 13 个 SiteID 直接查询集水区 BoundaryId 和 EDM SiteId 均返回零条。

`overflow_to_outfall` 按原 SiteID 查询返回 13 条暴雨溢流结构关联，涉及 12 个 SiteID；13028 有 `13028B` / `13028S`，13012 未返回。没有发现源/目标共享同一 OverflowID 的证据。这些是**暴雨溢流**关联，不是本研究处理后正常 TDV 排口的许可或仪表身份，不能用来补全 `outfall_id`，不能把溢流数据加入本轮特征或结论。有关候选关联和查询失败均保留，`physical_facility_id`、处理后 `outfall_id`、`mapping_verified` 仍分别为 `unknown`、`unknown`、`False`。

本轮共保存 19 次官方查询，17 次取得有效元数据或属性响应；最初按 layer 0 查询 outfall/overflow 两服务返回 ArcGIS 400（HTTP 200 中的错误对象），后从服务结构核实实际层号分别为 1、2 并成功重查。失败响应同样保存，不能把所有 HTTP 200 都统计为成功。`OFFICIAL_QUERY_INDEX.csv/json` 是完整查询索引，`FACILITY_REVIEW_STATUS.json` 记录未解决项。

因此主实验只能称 **SiteID 分组的探索性开发实验**，不能称独立水厂外部验证。下一阶段仍需官方 TDV 仪表/处理设施/排口交叉表、厂址或坐标、许可号、名称变更及同厂多出口信息；所有实际关联测点须统一分区。

## 源选择与后续候选

原入选规则登记在 2026-10-09，依据 2016—2021 每年 Good、非负、无冲突日历覆盖率 ≥95%、单一提供方名称和数字 ID 排序，不参考目标模型误差。三源 18 个站年从原始记录独立重算，与原覆盖表完全一致；最低年度覆盖率分别为 13006：96.9945%，13008：98.6339%，13012：97.8082%。源共享拟合截止仍为 2021-12-31。

`future_source_expansion_candidates_pre2022.csv` 从原覆盖表按相同规则列出当前 13 站以外的 186 个候选 SiteID，不看模型误差，不加入本轮源训练。它是未分配的质量候选清单，不是已核实设施清单；正式扩源前需先解决物理分组、预留独立目标设施，再制定分区，不能直接把所有候选都加入来源。

## paper idea 和目标期刊

已实际读取 `materials/received_stage2_20261009/paper idea.docx` 中的 Word XML；SHA256 为 `e698f0c07c3e73baf16c2b88d873675405443b2186dfe6746f55a50e33c818b1`，新提取文本为 `paper_idea_from_docx.txt`。该附件强调既有水厂有限建模历史、日处理后体积、共享历史是否节省预算和负迁移，不支持新建厂启动、污染削减、节能、溢流控制、真实上线效果或“世界首次”的结论；可靠性与预测区间是后续研究目标，本轮不实施。

现有研究计划仍记载候选 Journal of Hydroinformatics / Water Science & Technology，未记录已确定的目标期刊，官方范围和作者指南也未完成当前核实。本轮不自行选择期刊、不修改期刊模板、不把项目附件当成执行授权。

## 核验命令与边界

从项目根目录运行：

```bash
.venv-stage2/bin/python data/provenance/stage3b_20261011_v1/audit_provenance.py
```

若复核包只有固定队列原始摘录，使用以下命令，不需要全量原始 CSV：

```bash
.venv-stage2/bin/python data/provenance/stage3b_20261011_v1/recompute_selected_qa.py
```

该脚本忽略摘录中的派生 `audit_rule`，从提供方原始字段重算规则，实际本地执行通过；原始摘录 SHA256 为 `6ea2f404041d7c398d74e12f64a89a416b08a44ec48725cceb9c26d2f7468fbc`。这支持固定队列的清理复核，不把摘录等同于全库原文件。官方接口当前返回的元数据可能改变，独立核验应以本轮保存响应及校验值为准。

独立清理只扫描原 CSV 来过滤允许时期；没有计算最终期预测或依据其选择站点。此前全库描述性审计已覆盖 2024—2025，应继续披露，不能声称从未接触最终数据。本轮给定历史阈值、初始预算和模型选择规则由协议定义，设施证据不补足实时数据可用性或工程效果证据。
