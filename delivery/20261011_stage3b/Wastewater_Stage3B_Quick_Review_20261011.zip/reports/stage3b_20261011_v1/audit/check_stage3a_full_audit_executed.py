"""Read-only Stage 3A evidence audit; new outputs only, no model training.

The metric and bootstrap calculations below deliberately do not import the
historical reporting functions. Archive equivalence is numerical, not bitwise.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import re
import sys
import time

import numpy as np
import pandas as pd
import torch


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from wastewater.shared_data import load_series
from wastewater.shared_experiment import target_data, source_pool
from wastewater.stage3a_data import internal_fold, compact
from wastewater.shared_models import CompactGRU

KEYS = ["site_id", "episode", "horizon", "origin", "target_date"]
DAY_KEYS = KEYS + ["budget", "model", "constraint"]
STATION_KEYS = ["constraint", "site_id", "budget", "horizon", "model"]
RTOL, ATOL = 1e-12, 1e-8


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def save_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def compare_frames(actual, saved, keys, columns, name):
    a = actual.set_index(keys).sort_index()
    b = saved.set_index(keys).sort_index()
    if not a.index.equals(b.index):
        raise AssertionError(f"{name}: unequal key sets")
    rows = []
    for col in columns:
        aa, bb = a[col].to_numpy(float), b[col].to_numpy(float)
        np.testing.assert_allclose(aa, bb, rtol=RTOL, atol=ATOL, equal_nan=True,
                                   err_msg=f"{name}/{col}")
        finite = np.isfinite(aa) & np.isfinite(bb)
        rows.append(dict(table=name, column=col, rows=len(aa),
                         max_absolute_difference=float(np.max(np.abs(aa[finite]-bb[finite]))) if finite.any() else None,
                         atol=ATOL, rtol=RTOL))
    return rows


def metrics_from_daily(d):
    m = d.groupby(STATION_KEYS).agg(n_dates=("absolute_error", "size"),
                                   mae_m3=("absolute_error", "mean"),
                                   mse=("squared_error", "mean")).reset_index()
    m["rmse_m3"] = np.sqrt(m.pop("mse"))
    bk = [k for k in STATION_KEYS if k != "model"]
    p = m[m.model.eq("persistence")][bk+["mae_m3"]].rename(columns={"mae_m3":"persistence_mae"})
    m = m.merge(p, on=bk, validate="many_to_one")
    m["skill_vs_persistence"] = 1 - m.mae_m3 / m.persistence_mae.where(m.persistence_mae.gt(0))
    return m


def aggregate(m):
    rows=[]
    for keys,g in m.groupby(["constraint","budget","horizon","model"]):
        skill=g.skill_vs_persistence.dropna()
        rows.append(dict(zip(["constraint","budget","horizon","model"],keys),
             stations=len(g),equal_station_mae_m3=float(g.mae_m3.mean()),
             equal_station_rmse_m3=float(g.rmse_m3.mean()),mean_skill=float(skill.mean()),
             median_skill=float(skill.median()),winning_stations=int(skill.gt(0).sum()),
             worse_stations=int(skill.lt(0).sum()),win_fraction=float(skill.gt(0).mean()),
             defined_skill_stations=len(skill),min_dates=int(g.n_dates.min()),max_dates=int(g.n_dates.max())))
    return pd.DataFrame(rows)


def independent_ridge(X, y, alpha, weights=None):
    """Weighted normal equations; unpenalized intercept, weights sum to one."""
    x=np.asarray(X,dtype=float).reshape(len(y),-1); y=np.asarray(y,dtype=float)
    w=np.ones(len(y))/len(y) if weights is None else np.asarray(weights,dtype=float)
    assert np.isclose(w.sum(),1)
    mx=np.sum(w[:,None]*x,axis=0);my=np.sum(w*y)
    xc=x-mx;yc=y-my
    beta=np.linalg.solve(xc.T@(w[:,None]*xc)+float(alpha)*np.eye(x.shape[1]),xc.T@(w*yc))
    intercept=my-mx@beta
    return beta,intercept


def independent_intervals(d, cfg, saved_ci, paired):
    """Exact old sampling design, independently implemented from raw losses."""
    sites, episodes, budgets = cfg["development_ids"], cfg["origins"], cfg["budgets"]
    models = sorted(d.model.unique())
    length = cfg["evaluation_days"]
    rows, site_rows = [], []
    contrasts = paired.drop_duplicates("id")[["id","model","budget","reference","reference_budget","horizon","kind"]]
    for h in cfg["horizons"]:
        a = np.full((len(sites), len(episodes)*length, len(budgets), len(models)), np.nan)
        for row in d[d.horizon.eq(h)].itertuples(index=False):
            offset = (pd.Timestamp(row.origin)-pd.Timestamp(row.episode)).days
            a[sites.index(row.site_id),episodes.index(row.episode)*length+offset,
              budgets.index(row.budget),models.index(row.model)] = row.absolute_error
        means = np.nanmean(a, axis=1)
        hc = contrasts[contrasts.horizon.eq(h)]
        for c in hc.itertuples(index=False):
            left = means[:,budgets.index(c.budget),models.index(c.model)]
            right = means[:,budgets.index(c.reference_budget),models.index(c.reference)]
            for i, site in enumerate(sites):
                site_rows.append(dict(id=c.id,site_id=site,mae_m3=left[i],reference_mae_m3=right[i],
                                      skill=1-left[i]/right[i] if right[i]>0 else np.nan))
        for block in cfg["bootstrap"]["blocks"]:
            rng = np.random.default_rng(cfg["bootstrap"]["seed"]+h*100+block)
            samples = np.empty((cfg["bootstrap"]["replicates"],len(sites),len(budgets),len(models)))
            for r in range(len(samples)):
                sampled_days=[]
                for e in range(len(episodes)):
                    starts=rng.integers(0,length-block+1,size=int(np.ceil(length/block)))
                    offsets=(starts[:,None]+np.arange(block)[None,:]).ravel()[:length]
                    sampled_days.extend((offsets+e*length).tolist())
                clusters=rng.integers(0,len(sites),size=len(sites))
                samples[r]=np.nanmean(a[clusters][:,sampled_days],axis=1)
            for c in hc.itertuples(index=False):
                left=samples[:,:,budgets.index(c.budget),models.index(c.model)]
                right=samples[:,:,budgets.index(c.reference_budget),models.index(c.reference)]
                with np.errstate(divide="ignore",invalid="ignore"):
                    skill=np.nanmean(np.where(right>0,1-left/right,np.nan),axis=1)
                lower,upper=np.nanquantile(skill,[.025,.975])
                base=means[:,budgets.index(c.budget),models.index(c.model)]
                ref=means[:,budgets.index(c.reference_budget),models.index(c.reference)]
                rows.append(dict(id=c.id,block_days=block,mean_station_skill=float(np.nanmean(np.where(ref>0,1-base/ref,np.nan))),
                                 lower_95=float(lower),upper_95=float(upper)))
    return pd.DataFrame(rows),pd.DataFrame(site_rows)


def historical_inventory(root, out):
    """Inventory archived project records; no claim about absent external logs."""
    lower,upper = pd.Timestamp("2023-10-02"),pd.Timestamp("2023-12-02")
    csv_rows=[]; json_rows=[]; hits=[]
    prior_roots=[root/x for x in ["configs","runs","reports","validation"]]
    files=[p for directory in prior_roots for p in directory.rglob("*")
           if p.is_file() and "stage3b" not in p.as_posix().lower()]
    for path in files:
        if path.suffix != ".csv":
            continue
        with path.open(newline="") as f:
            header=next(csv.reader(f),[])
        datecols=[c for c in header if c in ["origin","target_date","latest_input_date","budget_start","history_left","fit_end","last_train_target","last_fit_target","calibration_end","episode","validation_start","first_validation_origin","last_validation_target","budget_end"]]
        if not datecols:
            continue
        frame=pd.read_csv(path,usecols=datecols)
        row=dict(path=str(path.relative_to(root)),sha256=digest(path),rows=len(frame))
        for col in datecols:
            dates=pd.to_datetime(frame[col],errors="coerce",format="mixed")
            row[col+"_minimum"]=str(dates.min().date()) if dates.notna().any() else None
            row[col+"_maximum"]=str(dates.max().date()) if dates.notna().any() else None
            overlapping=int(dates.between(lower,upper).sum())
            row[col+"_candidate_label_overlap_rows"]=overlapping
            if overlapping:
                hits.append(dict(path=row["path"],column=col,overlap_rows=overlapping))
        csv_rows.append(row)
    date_pattern=re.compile(r"^20\d\d-\d\d-\d\d$")
    date_key_pattern=re.compile(r"origin|target|fit|train|validation|calibration|budget_end|episode|^date$",re.I)
    def visit(value,key=""):
        if isinstance(value,dict):
            for k,v in value.items():
                yield from visit(v,k)
        elif isinstance(value,list):
            for v in value:
                yield from visit(v,key)
        elif isinstance(value,str) and date_pattern.match(value) and date_key_pattern.search(key):
            yield key,value
    for path in files:
        if path.suffix!=".json":
            continue
        try:
            value=json.loads(path.read_text())
        except (ValueError,UnicodeDecodeError):
            continue
        dates=list(visit(value))
        if not dates:
            continue
        fitdates=[date for key,date in dates if re.search(r"fit|train|calibration|budget_end",key,re.I)]
        selectiondates=[date for key,date in dates if re.search(r"validation|target|origin|episode",key,re.I)]
        row=dict(path=str(path.relative_to(root)),sha256=digest(path),date_fields=len(dates),
                 fit_calibration_maximum=max(fitdates) if fitdates else None,
                 origin_target_validation_maximum=max(selectiondates) if selectiondates else None,
                 candidate_label_overlap_fields=sum(lower<=pd.Timestamp(date)<=upper for _,date in dates))
        if row["candidate_label_overlap_fields"]:
            hits.append(dict(path=row["path"],column="JSON historical temporal fields",overlap_rows=row["candidate_label_overlap_fields"]))
        json_rows.append(row)
    pd.DataFrame(csv_rows).to_csv(out/"historical_prediction_dates_inventory.csv",index=False)
    pd.DataFrame(json_rows).to_csv(out/"historical_training_validation_inventory.csv",index=False)
    pmax=max(r["target_date_maximum"] for r in csv_rows if r.get("target_date_maximum"))
    summary=dict(candidate_first_origin="2023-10-01",candidate_origins=60,
                 candidate_label_start=str(lower.date()),candidate_label_end=str(upper.date()),
                 prior_date_bearing_csv_files=len(csv_rows),prior_temporal_json_files=len(json_rows),
                 prior_prediction_target_maximum=pmax,overlapping_archived_records=hits,
                 eligible_from_archived_project_records=not hits,
                 descriptive_contact=True,
                 qualification="No archived training, validation or performance record overlaps these labels. Canonical QA and descriptive audits already read full 2023; this is additional time validation on the same development SiteIDs, not untouched raw data or external-facility validation.",
                 limitation="Artifact audit cannot certify undocumented off-workspace or human-only historical viewing. No absent-file inference is treated as proof of universal blindness.")
    save_json(out/"historical_window_eligibility.json",summary)
    return summary


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",type=Path,default=ROOT)
    ap.add_argument("--output",default="reports/stage3b_20261011_v1/audit")
    ap.add_argument("--skip-history",action="store_true")
    args=ap.parse_args(); root=args.root.resolve(); out=root/args.output
    out.mkdir(parents=True,exist_ok=True); started=time.perf_counter()
    cfg=json.loads((root/"configs/stage3a_20261010/full.json").read_text())
    assert cfg["version"]=="stage3a_20261010_v3"
    manifest=json.loads((root/cfg["output"]/"manifest.json").read_text())
    assert manifest["config"]==cfg and manifest["status"]=="completed" and manifest["failed_conditions"]==0
    preserved={}
    for name,expected in manifest["provenance"]["core_sha256"].items():
        file=root/"src/wastewater"/name
        assert digest(file)==expected
        preserved[str(file.relative_to(root))]=expected
    for key,pathkey in [("data_sha256","canonical_csv"),("mapping_sha256","mapping_csv")]:
        assert digest(root/cfg[pathkey])==manifest["provenance"][key]
        preserved[cfg[pathkey]]=digest(root/cfg[pathkey])
    report=root/"reports/stage3a_20261010/results"
    p=pd.read_csv(report/"predictions_all.csv",dtype={"site_id":str},low_memory=False)
    assert len(p)==388800 and set(p.site_id)==set(cfg["development_ids"])
    assert (pd.to_datetime(p.target_date)-pd.to_datetime(p.origin)).dt.days.eq(p.horizon).all()
    assert pd.to_datetime(p.target_date).max()<pd.Timestamp("2024-01-01")
    assert (pd.to_datetime(p.last_train_target)<=pd.to_datetime(p.fit_end)).all()
    assert (pd.to_datetime(p.fit_end)==pd.to_datetime(p.episode)-pd.Timedelta(days=1)).all()
    assert (pd.to_datetime(p.episode)-pd.to_datetime(p.budget_start)).dt.days.eq(p.budget).all()
    assert not p.duplicated(KEYS+["budget","model","seed"]).any()
    finite=np.isfinite(p.prediction_m3)&np.isfinite(p.truth_m3)
    finite_groups=finite.groupby([p[k] for k in KEYS]).all()
    assert len(finite_groups)==4800 and int(finite_groups.sum())==4713
    independently_matched=p.set_index(KEYS).index.map(finite_groups).to_numpy(bool)
    assert np.array_equal(independently_matched,p.common_evaluation.to_numpy(bool))
    assert p.groupby(KEYS).size().eq(81).all()
    np.testing.assert_allclose(p.prediction_nonnegative_m3,np.maximum(0,p.prediction_m3),equal_nan=True,rtol=RTOL,atol=ATOL)
    common=p[independently_matched].copy(); daily_parts=[]
    for constraint,col in [("raw","prediction_m3"),("all_models_nonnegative","prediction_nonnegative_m3")]:
        frame=common.copy(); error=frame[col]-frame.truth_m3
        frame["absolute_error"],frame["squared_error"]=error.abs(),error**2
        d=frame.groupby(KEYS+["budget","model"]).agg(absolute_error=("absolute_error","mean"),
             squared_error=("squared_error","mean"),truth_m3=("truth_m3","first"),
             high_threshold_m3=("high_threshold_m3","first"),seed_count=("seed","nunique")).reset_index()
        d["constraint"]=constraint;daily_parts.append(d)
    daily=pd.concat(daily_parts,ignore_index=True)
    daily.to_csv(out/"stage3a_daily_losses_recomputed.csv.gz",index=False)
    checks=compare_frames(daily,pd.read_csv(report/"daily_losses.csv",dtype={"site_id":str}),DAY_KEYS,
                           ["absolute_error","squared_error","truth_m3","high_threshold_m3","seed_count"],"daily_losses")
    m=metrics_from_daily(daily);m.to_csv(out/"stage3a_station_metrics_recomputed.csv",index=False)
    checks+=compare_frames(m,pd.read_csv(report/"metrics_by_station.csv",dtype={"site_id":str}),STATION_KEYS,
                           ["n_dates","mae_m3","rmse_m3","persistence_mae","skill_vs_persistence"],"station_metrics")
    summary=aggregate(m);summary.to_csv(out/"stage3a_summary_recomputed.csv",index=False)
    checks+=compare_frames(summary,pd.read_csv(report/"summary.csv"),["constraint","budget","horizon","model"],
             ["stations","equal_station_mae_m3","equal_station_rmse_m3","mean_skill","median_skill", "winning_stations","worse_stations","win_fraction","defined_skill_stations","min_dates","max_dates"],"summary")
    high=daily[daily.truth_m3.ge(daily.high_threshold_m3)].copy();hm=metrics_from_daily(high)
    hm.to_csv(out/"stage3a_high_volume_metrics_recomputed.csv",index=False)
    checks+=compare_frames(hm,pd.read_csv(report/"high_volume_metrics_by_station.csv",dtype={"site_id":str}),STATION_KEYS,
                           ["n_dates","mae_m3","rmse_m3","skill_vs_persistence"],"high_volume_metrics")
    hs=aggregate(hm);hs.to_csv(out/"stage3a_high_volume_summary_recomputed.csv",index=False)
    checks+=compare_frames(hs,pd.read_csv(report/"high_volume_summary.csv"),["constraint","budget","horizon","model"],
             ["equal_station_mae_m3","equal_station_rmse_m3","mean_skill","median_skill","winning_stations","worse_stations"],"high_volume_summary")
    seed_counts=common.groupby(KEYS+["budget","model"]).seed.nunique()
    assert seed_counts[seed_counts.index.get_level_values("model").str.contains("gru")].eq(3).all()
    # Demonstrate that actual GRU loss averages differ from ensemble losses.
    g=common[common.model.str.contains("gru")].copy()
    ensemble=g.groupby(KEYS+["budget","model"]).agg(pred=("prediction_m3","mean"),truth=("truth_m3","first")).reset_index()
    ensemble["ensemble_absolute_error"]=(ensemble.pred-ensemble.truth).abs()
    rawdaily=daily[daily.constraint.eq("raw")]
    ev=ensemble.merge(rawdaily[KEYS+["budget","model","absolute_error"]],on=KEYS+["budget","model"],validate="one_to_one")
    ensemble_different=int(np.sum(np.abs(ev.absolute_error-ev.ensemble_absolute_error)>1e-8))
    assert ensemble_different>0
    paired=pd.read_csv(report/"paired_comparisons_by_station.csv",dtype={"site_id":str})
    ci=pd.read_csv(report/"paired_block_intervals.csv")
    independent_ci,independent_pairs=independent_intervals(rawdaily,cfg,ci,paired)
    independent_ci.to_csv(out/"stage3a_block_intervals_recomputed.csv",index=False)
    independent_pairs.to_csv(out/"stage3a_paired_skills_recomputed.csv",index=False)
    checks+=compare_frames(independent_ci,ci,["id","block_days"],["mean_station_skill","lower_95","upper_95"],"block_intervals")
    checks+=compare_frames(independent_pairs,paired,["id","site_id"],["mae_m3","reference_mae_m3","skill"],"paired_skills")
    hci=pd.read_csv(report/"high_volume_block_intervals.csv")
    hpair=pd.read_csv(report/"high_volume_paired_by_station.csv",dtype={"site_id":str})
    independent_hci,independent_hpair=independent_intervals(high[high.constraint.eq("raw")],cfg,hci,hpair)
    independent_hci.to_csv(out/"stage3a_high_volume_intervals_recomputed.csv",index=False)
    checks+=compare_frames(independent_hci,hci,["id","block_days"],["mean_station_skill","lower_95","upper_95"],"high_volume_intervals")
    pd.DataFrame(checks).to_csv(out/"stage3a_numeric_comparisons.csv",index=False)
    series=load_series(root/cfg["canonical_csv"],cfg["development_ids"])
    completion=json.loads((root/cfg["output"]/"completion.json").read_text()); assert len(completion)==240
    fitting=[]; statuses=[]; hash_checks=0; encoder_checks=0; forecast_checks=[]; ridge_checks=[]; parameter_choices=0
    torch.set_num_threads(1)
    source_states={}
    source_selection=json.loads((root/cfg["source_output"]/"selection.json").read_text())
    source_series=load_series(root/cfg["canonical_csv"],cfg["source_ids"])
    independent_shared_ridge={}
    for h in cfg["horizons"]:
        x,y,w,_=source_pool(source_series,cfg,h,"2021-12-31")
        independent_shared_ridge[h]=independent_ridge(compact(x),y,source_selection["settings"][str(h)]["shared_lags_alpha"],w)
    prediction_groups={key:g for key,g in p.groupby(["site_id","episode","budget","horizon","model","seed"])}
    def torch_prediction(state,X):
        model=CompactGRU(8);model.load_state_dict(state);model.eval()
        with torch.no_grad():
            return model(torch.as_tensor(X,dtype=torch.float32)).cpu().numpy().astype(float)
    for c in completion:
        folder=root/c["folder"];status=json.loads((folder/"status.json").read_text());assert status["status"]=="completed"
        for name,expected in status["outputs_sha256"].items():
            assert digest(folder/name)==expected;hash_checks+=1
        d=json.loads((folder/"diagnostics.json").read_text())
        tr,te,td=target_data(series,cfg,d["site_id"],d["episode"],d["budget"],d["horizon"])
        assert td["training_X_sha256"]==d["training_X_sha256"] and td["evaluation_X_sha256"]==d["evaluation_X_sha256"]
        assert tr.targets.max()<=pd.Timestamp(d["fit_end"]) and te.origins.max()<pd.Timestamp("2024-01-01")
        prior=series[d["site_id"]].loc[pd.Timestamp(d["episode"])-pd.Timedelta(days=30):pd.Timestamp(d["episode"])-pd.Timedelta(days=1)].dropna()
        threshold=float(prior.quantile(.9)) if len(prior)>=14 else np.nan
        np.testing.assert_allclose(td["high_threshold_m3"],threshold,rtol=RTOL,atol=ATOL,equal_nan=True)
        fold=d["selection"]["fold"]
        _,_,indfold=internal_fold(series[d["site_id"]],d["episode"],d["budget"],d["horizon"],cfg)
        assert indfold["fitting_labels"]==fold["fitting_labels"] and indfold["validation_labels"]==fold["validation_labels"]
        if not fold["source_assisted"]:
            assert pd.Timestamp(fold["last_fit_target"])<pd.Timestamp(fold["validation_start"])
            assert pd.Timestamp(fold["last_validation_target"])<=pd.Timestamp(d["fit_end"])
            assert fold["scale_m3"]==indfold["scale_m3"]
        else:
            assert d["budget"]==30 and fold["fallback_key"]==f'B30_H{d["horizon"]}'
        sel=d["selection"]
        beta42,intercept42=independent_ridge(tr.X,tr.y,sel["ridge_alphas"]["42"])
        betalags,interceptlags=independent_ridge(compact(tr.X),tr.y,sel["ridge_alphas"]["lags"])
        sharedbeta,sharedintercept=independent_shared_ridge[d["horizon"]]
        residual_bias=float(np.mean(tr.y-(compact(tr.X).astype(float)@sharedbeta+sharedintercept)))
        ridge_outputs={"local_ridge42_tuned":(te.X.reshape(len(te.y),-1).astype(float)@beta42+intercept42)*te.scale,
                       "local_ridge_lags_tuned":(compact(te.X).astype(float)@betalags+interceptlags)*te.scale,
                       "shared_ridge_lags":(compact(te.X).astype(float)@sharedbeta+sharedintercept)*te.scale,
                       "shared_ridge_lags_bias":(compact(te.X).astype(float)@sharedbeta+sharedintercept+residual_bias)*te.scale}
        for model,prediction in ridge_outputs.items():
            prediction[te.X[:,:,1].sum(axis=1)==0]=np.nan
            old=prediction_groups[(d["site_id"],d["episode"],d["budget"],d["horizon"],model,0)].sort_values("origin")
            np.testing.assert_allclose(prediction,old.prediction_m3.to_numpy(float),equal_nan=True,rtol=RTOL,atol=ATOL)
            ridge_checks.append(dict(task=c["task"],model=model,origins=len(prediction),
                max_absolute_prediction_difference=float(np.nanmax(np.abs(prediction-old.prediction_m3.to_numpy(float))))))
        if not fold["source_assisted"]:
            for feature in ["42","lags"]:
                rows=[r for r in sel["ridge_validation"] if r["features"]==feature]
                best=min(rows,key=lambda r:(r["validation_mae"],r["alpha"]))
                assert best["alpha"]==sel["ridge_alphas"][feature];parameter_choices+=1
            for family,outkey in [("local_gru_validation","local_epoch"),("head_gru_validation","head_epoch")]:
                cv=pd.DataFrame(sel[family]);score=cv.groupby("epoch").validation_mae.mean()
                epoch=min(score.index,key=lambda e:(score.loc[e],e))
                assert int(epoch)==sel[outkey];parameter_choices+=1
        for seed in cfg["seeds"]:
            sk=(d["horizon"],seed)
            if sk not in source_states:
                source_states[sk]=torch.load(root/f'runs/shared_v3_20261009/source/final_h{d["horizon"]}_seed{seed}.pt',map_location="cpu",weights_only=False)["model"]
            for epoch in [10,40,120]:
                state=torch.load(folder/f"head_seed{seed}/epoch{epoch}.pt",map_location="cpu",weights_only=False)["model"]
                assert all(torch.equal(v,state[k]) for k,v in source_states[sk].items() if k.startswith("gru."));encoder_checks+=1
            policies=[("local_gru_selected",folder/f'local_seed{seed}/epoch{sel["local_epoch"]}.pt'),
                      ("shared_gru_head_selected",folder/f'head_seed{seed}/epoch{sel["head_epoch"]}.pt'),
                      ("shared_gru_selected",root/cfg["source_output"]/f'full_h{d["horizon"]}_seed{seed}/epoch{d["source_shared_epoch"]}.pt')]
            for model,file in policies:
                state=torch.load(file,map_location="cpu",weights_only=False)["model"]
                prediction=torch_prediction(state,te.X)*te.scale
                prediction[te.X[:,:,1].sum(axis=1)==0]=np.nan
                old=prediction_groups[(d["site_id"],d["episode"],d["budget"],d["horizon"],model,seed)].sort_values("origin")
                np.testing.assert_allclose(prediction,old.prediction_m3.to_numpy(float),equal_nan=True,rtol=RTOL,atol=ATOL)
                delta=np.abs(prediction-old.prediction_m3.to_numpy(float))
                forecast_checks.append(dict(task=c["task"],model=model,seed=seed,origins=len(prediction),
                    selected_weight_file=str(file.relative_to(root)),weight_file_sha256=digest(file),
                    max_absolute_prediction_difference=float(np.nanmax(delta))))
        fitting.append(dict(fold,site_id=d["site_id"],episode=d["episode"],budget=d["budget"],horizon=d["horizon"],
                            full_fit_labels=len(tr.y),nonfinite_training_persistence=int((~np.isfinite(tr.persistence)).sum()),
                            historical_Q90=threshold,threshold_valid_observations=len(prior)))
        statuses.append(dict(task=c["task"],status=status["status"],folder=c["folder"],checked_outputs=len(status["outputs_sha256"])))
    pd.DataFrame(fitting).to_csv(out/"stage3a_training_budget_verification.csv",index=False)
    pd.DataFrame(statuses).to_csv(out/"stage3a_condition_status_verification.csv",index=False)
    pd.DataFrame(forecast_checks).to_csv(out/"stage3a_selected_gru_forward_reproduction.csv",index=False)
    pd.DataFrame(ridge_checks).to_csv(out/"stage3a_ridge_fit_reproduction.csv",index=False)
    source=json.loads((root/cfg["source_output"]/"selection.json").read_text())
    assert source["signature"]==manifest["signature"]
    source_counts={}
    for row in source["source_trajectories"]:
        diag=json.loads((root/row["folder"]/"data_diagnostics.json").read_text())
        assert diag["fit_end"]==("2021-12-31" if row["kind"]=="full" else "2020-12-31")
        assert diag["held_out_source"]==row["held"]
        if row["held"] is not None:
            assert row["held"] not in {s["site_id"] for s in diag["sites"]}
        source_counts[row["kind"]]=source_counts.get(row["kind"],0)+1
    assert source_counts=={"select":6,"full":6,"loso":18}
    for row in source["source_budget_folds"]:
        f=row["fold"]
        assert f["budget"]==30 and pd.Timestamp(f["last_fit_target"])<pd.Timestamp(f["first_validation_origin"])
        assert pd.Timestamp(f["last_validation_target"])<=pd.Timestamp("2021-12-31")
    for folder in ["runs/stage3a_20261010","runs/stage3a_20261010_v2"]:
        assert (root/folder).exists()
    checks_df=pd.DataFrame(checks)
    raw_learning=m[m.constraint.eq("raw")&~m.model.isin(["persistence","weekly_persistence"])]
    means=raw_learning.groupby(["model","budget","horizon"]).skill_vs_persistence.mean()
    # Summary claims are tested independently, not inherited from pass flags.
    assert len(means)==78 and means.lt(0).all()
    artifacts=["configs/stage3a_20261010/full.json","STAGE3A_PROTOCOL.md","STAGE3A_IMPLEMENTATION.md",
               "runs/stage3a_20261010_v3/full/manifest.json","runs/stage3a_20261010_v3/source/selection.json",
               "reports/stage3a_20261010/results/predictions_all.csv","reports/stage3a_20261010/results/daily_losses.csv",
               "reports/stage3a_20261010/results/metrics_by_station.csv","reports/stage3a_20261010/results/target_training_curves.csv",
               "reports/stage3a_20261010/source_training_and_validation_curves.csv",
               "wastewater_data/raw/wessex_all_2016_2025.csv","materials/received_stage2_20261009/paper idea.docx"]
    hashes=dict(preserved,**{f:digest(root/f) for f in artifacts if (root/f).exists()})
    save_json(out/"stage3a_input_artifact_hashes.json",hashes)
    history=None if args.skip_history else historical_inventory(root,out)
    result=dict(status="passed",accepted_version=cfg["version"],prediction_rows=len(p),
                common_groups=int(finite_groups.sum()),candidate_groups=len(finite_groups),
                independently_recomputed_daily_rows=len(daily),independently_recomputed_station_metrics=len(m),
                high_volume_station_metrics=len(hm),independently_recomputed_interval_rows=len(independent_ci),
                independently_recomputed_high_volume_interval_rows=len(independent_hci),
                completed_conditions=len(completion),status_output_sha256_checks=hash_checks,
                independently_reproduced_selected_gru_forecast_conditions=len(forecast_checks),
                independently_recomputed_ridge_fit_and_forecast_conditions=len(ridge_checks),
                frozen_encoder_checkpoint_checks=encoder_checks,internal_hyperparameter_choice_checks=parameter_choices,
                source_trajectory_counts=source_counts,source_budget_validation_folds=len(source["source_budget_folds"]),
                seed_rule="Arithmetic mean of per-origin absolute/squared losses; never average predictions for model scores",
                actual_seed_mean_vs_ensemble_differing_rows=ensemble_different,
                raw_negative_prediction_rows=int(p.prediction_m3.lt(0).sum()),
                all_78_learning_mean_skills_negative=True,zero_persistence_mae_station_metrics=int(m.persistence_mae.eq(0).sum()),
                numerical_comparison_atol=ATOL,numerical_comparison_rtol=RTOL,
                training_archive_equivalence="Old/new endpoints use atol=1e-4,rtol=1e-5 normalized prediction tolerance introduced in source-only preflight; not bitwise archive reproduction.",
                not_repeated="No GRU retraining, every optimizer-state trajectory, physical mapping verification, real-time QA verification, or original raw QA reconstruction is claimed here. Selected GRU forward forecasts and all frozen-head encoder candidates are checked from actual saved weights.",
                historic_window=history,wall_seconds=time.perf_counter()-started,
                checker_sha256=digest(Path(__file__)),outputs_sha256={f.name:digest(f) for f in out.iterdir() if f.is_file()})
    save_json(out/"STAGE3A_INDEPENDENT_EVIDENCE_CHECK.json",result)
    print(json.dumps({k:result[k] for k in ["status","accepted_version","prediction_rows","completed_conditions","independently_recomputed_station_metrics","independently_recomputed_interval_rows","wall_seconds"]},indent=2))
    if history:
        print(json.dumps(history,indent=2))


if __name__=="__main__":
    main()
