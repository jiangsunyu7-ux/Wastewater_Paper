# Stage3B implementation and preflight history

The accepted scientific version is `stage3b_20261011_v1`. STAGE3B_PROTOCOL.md and full.json were written before any new deployment scores. The new modules preserve all existing Stage2/Stage3A code and results.

The initial 02:30:52 UTC freeze referenced a historical-use inventory of2059 date CSVs. The auditor's already running expanded check added25 fitting/validation CSVs (2084 total) before new model fitting. The runner correctly rejected the changed historical-evidence hash. FREEZE_preflight1.json preserves that initial record; the final FREEZE.json was saved at02:33:46 UTC, after the audit process stopped. The candidate window, models, alpha/lambda grids and comparisons did not change. No source fit or target prediction preceded the final freeze.

Source/target model code is immutable after the first accepted source fit. The runner hashes the actual accepted Stage3A source-selection file used for direct-control settings, as well as code, data, mapping, configuration and protocol. Completed source/job caches recursively verify member hashes; incomplete tasks retry deterministically, preserving failure logs. Explicit lambda0 handling preserves Persistence even when all model input lags are missing.

Before first evaluation scores, the reporting module added the already specified comparison of the primary candidate with same-budget tuned local direct Ridge. This corrected an implementation omission; no new hypothesis, model, parameter candidate or window was introduced. New reporting code is hashed separately from model execution.

A comment in target_worker says selections are saved before reading deployment truth. More precisely, initial_data has already loaded deployment target arrays, but these arrays never enter training, scaling, bias or selection. Selections are persisted before any deployment-error calculation. Real-history future-perturbation tests check that changing forbidden future targets does not change fitting or permitted earlier predictions. This is a wording clarification, not a discovered information leak; the scientific code was not changed after fitting to edit that comment.

An optional `/usr/bin/time` wrapper was absent; its shell-only exit127 is retained in the software log. The experiment then used its own elapsed timers, with no scientific task failure or paid resource. Do not claim process peak memory was measured by that unavailable wrapper.

Ridge coefficients and intercepts have7 nominal parameters. Effective degrees of freedom depend on data, alpha and collinearity and are not claimed to equal7. Existing three-seed GRU is archived and audited by saved-weight forward prediction, not retrained. Original archive numeric agreement remains tolerance-based, not bitwise training reproduction.

Arithmetic checks use absolute tolerance1e-8m³ and relative1e-12; deterministic Ridge prediction/replay checks use the frozen normalized absolute/relative1e-10 tolerance. Exact lambda0 checks use zero tolerance. These verification tolerances do not turn near-zero scientific effects into equivalence.

Colab notebook instructions support Drive persistence and safe imports, but actual Colab login/mount is not verified. Local software, clean extraction, metric recomputation and small CPU replay are recorded separately. No2024–2025 performance, new source-pool experiment, interval model, ensemble, App, or manuscript rewrite is executed.
