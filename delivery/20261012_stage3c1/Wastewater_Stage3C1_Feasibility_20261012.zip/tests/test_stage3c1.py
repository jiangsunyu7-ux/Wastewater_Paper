"""Software fixtures for rainfall completeness and information-time boundaries."""
import importlib.util
from pathlib import Path
import unittest
import pandas as pd

spec=importlib.util.spec_from_file_location('rain_check',Path(__file__).resolve().parents[1]/'scripts/stage3c1_rainfall_check.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def fixture(day='2023-09-29'):
    return [{'dateTime':str(t),'value':0.,'quality':'Good','completeness':'Complete'}
            for t in pd.date_range(day,periods=96,freq='15min')]

class RainfallAlignmentTests(unittest.TestCase):
    def test_true_zero_is_complete_and_not_missing(self):
        d=m.day_summary(fixture(),'2023-09-29')
        self.assertTrue(d['complete_good_day']);self.assertEqual(d['qualified_total_mm'],0.)
        self.assertFalse(d['daily_statistical_day_verified'])

    def test_missing_and_suspect_are_not_zero_filled(self):
        for mode in ['missing','suspect','incomplete']:
            rows=fixture()
            if mode=='missing':rows[0].pop('value')
            if mode=='suspect':rows[0]['quality']='Suspect'
            if mode=='incomplete':rows[0]['completeness']='Incomplete'
            d=m.day_summary(rows,'2023-09-29')
            self.assertFalse(d['complete_good_day']);self.assertTrue(pd.isna(d['qualified_total_mm']))
            self.assertEqual(d['valid_intervals'],95)

    def test_duplicate_or_missing_interval_rejects_daily_total(self):
        for rows in [fixture()[:-1],fixture()+[dict(fixture()[0],value=12.)]]:
            self.assertFalse(m.day_summary(rows,'2023-09-29')['complete_good_day'])

    def test_conservative_end_and_bst_cutoff(self):
        end,cutoff,passed=m.time_bounds('2023-09-29T23:45:00','2023-10-01')
        self.assertEqual(str(end),'2023-09-30 00:00:00+00:00')
        self.assertEqual(str(cutoff),'2023-10-01 22:59:59+00:00')
        self.assertTrue(passed)
        self.assertFalse(m.time_bounds('2023-10-03T12:00:00','2023-10-01')[2])
        self.assertFalse(m.time_bounds('2023-01-01T23:44:59','2023-01-01')[2])

    def test_future_values_do_not_change_lag2_day(self):
        rows=fixture();before=m.day_summary(rows,'2023-09-29')
        rows += [dict(r,value=1000.) for r in fixture('2023-10-03')]
        self.assertEqual(before,m.day_summary(rows,'2023-09-29'))

    def test_ambiguous_dst_clock_is_not_silently_guessed(self):
        with self.assertRaises(Exception):m.time_bounds('2023-10-29T01:15:00','2023-10-30')

if __name__=='__main__':unittest.main()
