"""Finalize evidence receipts and verify preservation; no forecasting or fitting."""
from __future__ import annotations
import csv
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess

ROOT = Path(__file__).resolve().parents[1]
VERSION = 'stage3c1_20261011_v1'
REPORT = ROOT / 'reports' / VERSION
DATA = ROOT / 'data/provenance' / VERSION


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def save(name, obj):
    (REPORT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n')


def main():
    before = json.loads((REPORT/'STAGE3B_PRESERVATION_BEFORE.json').read_text())
    problems = []
    for name, receipt in before['files'].items():
        path = ROOT/name
        if not path.is_file():
            problems.append({'path': name, 'problem': 'missing'})
        elif path.stat().st_size != receipt['bytes'] or sha(path) != receipt['sha256']:
            problems.append({'path': name, 'problem': 'changed'})
    preservation = {'status': 'passed' if not problems else 'failed',
                    'checked_utc': datetime.now(timezone.utc).isoformat(),
                    'files_checked': len(before['files']),
                    'bytes_checked': sum(r['bytes'] for r in before['files'].values()),
                    'missing_or_changed': problems,
                    'comparison': 'SHA256 and exact byte count, no numerical tolerance',
                    'scope': 'all files in the pre-task Stage3B snapshot; global long-term documents are separately merged'}
    save('STAGE3B_PRESERVATION_AFTER.json', preservation)
    if problems:
        raise RuntimeError('Stage3B preservation mismatch; see report')

    evidence = []
    def add(kind, name, url, queried, status, path, expected=None):
        p = ROOT/path if path else None
        digest = sha(p) if p and p.is_file() else ''
        if expected and digest != expected:
            raise RuntimeError(f'evidence SHA mismatch: {name}')
        evidence.append({'class': kind, 'name': name, 'url': url,
                         'retrieved_utc': queried, 'http_or_api_status': status,
                         'saved_response': path, 'bytes': p.stat().st_size if p and p.is_file() else 0,
                         'sha256': digest, 'historical_first_publication_proved': False})

    fac = DATA/'facilities'
    with (fac/'REUSED_OFFICIAL_QUERY_INDEX.csv').open(newline='') as f:
        for r in csv.DictReader(f):
            add('reused_official', r['query_name'], r['url'], r['queried_utc'],
                'success' if r['success']=='True' else 'archived_api_error',
                r['delivery_evidence_copy_path'], r['sha256'])
    q = json.loads((fac/'bounded_new_query_receipt.json').read_text())
    add('new_facility_metadata', q['query_name'], q['url'], q['queried_utc'],
        q['http_status'], str((fac/q['saved_response_file']).relative_to(ROOT)), q['response_sha256'])
    cat = DATA/'rainfall_catalog'
    for q in json.loads((cat/'query_log.json').read_text()):
        p = str((cat/q['file']).relative_to(ROOT)) if q.get('file') else ''
        add('new_rain_metadata', q['id'], q['requested_url'], q['queried_at_utc'], q['status'], p, q.get('sha256'))
    for path in sorted((DATA/'rainfall_samples').glob('*.metadata.json')):
        q = json.loads(path.read_text())
        response = Path(str(path).removesuffix('.metadata.json'))
        add('new_hydrology_sample_or_metadata', response.name, q['url'], q['retrieved_utc'],
            q.get('http_status', q.get('status')), str(response.relative_to(ROOT)) if response.exists() else '', q.get('sha256'))
    with (REPORT/'EVIDENCE_LINKS.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(evidence[0]))
        writer.writeheader();writer.writerows(evidence)
    new = [r for r in evidence if r['class']!='reused_official']
    successes = sum(str(r['http_or_api_status'])=='200' for r in new)
    save('EVIDENCE_LEDGER_CHECK.json', {'reused_official_queries':len(evidence)-len(new),
         'new_bounded_requests':len(new), 'new_http_successes':successes,
         'new_failed_requests':len(new)-successes, 'all_available_response_hashes_verified':True,
         'no_unbounded_retry':True, 'no_historical_publication_claim':True})
    env={'python':platform.python_version(),'platform':platform.platform(),
         'packages':{p:importlib.metadata.version(p) for p in ['numpy','pandas']},
         'workflow':'CPU data/metadata audit; no model fitting', 'gpu_required':False}
    save('ENVIRONMENT.json',env)
    code=['scripts/stage3c1_fetch.py','scripts/stage3c1_rainfall_check.py',
          'scripts/stage3c1_finalize_audit.py','tests/test_stage3c1.py',
          str((fac/'audit_existing_facility_evidence.py').relative_to(ROOT)),
          str((DATA/'cohorts/audit_source_candidates.py').relative_to(ROOT)),
          'configs/'+VERSION+'/next_experiment_draft.json']
    save('CODE_VERSION.json', {'repository_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
         'stage_version':VERSION, 'uncommitted_scientific_files_exist':True,
         'content_sha256':{p:sha(ROOT/p) for p in code},
         'version_note':'HEAD alone is not the scientific version; content SHA and package manifest identify new files'})
    connection=json.loads((REPORT/'rainfall_connection/CONNECTION_CHECK.json').read_text())
    save('RUN_STATUS.json', {'stage':VERSION,'completed_utc':datetime.now(timezone.utc).isoformat(),
         'status':'COMPLETED_FEASIBILITY_AUDIT_STOP_PENDING_REVIEW',
         'executed':['19-query receipt audit','one fixed name-candidate polygon query',
             'bounded official rainfall metadata checks','nine seven-day rainfall samples',
             'ten SiteID candidate joins and conditional time alignment',
             '186 candidate pre2022 coverage/quality audit','six software tests',
             'draft config/hash validation','Stage3B byte preservation verification'],
         'not_executed':['rainfall forecasting ablation','expanded-source fitting','new Ridge/GRU training',
             '2024-2025 performance','reserved target performance','manuscript','App','paid compute'],
         'formal_weather_links':connection['formal_verified_development_spatial_links'],
         'rainfall_experiment_ready':False,'next_experiment_execute_allowed':False,
         'failed_or_missing_evidence':['five bounded grid-catalog access failures',
             'TDV physical facility/normal outfall/catchment mapping',
             'historical rainfall/TDV interval/timezone/publication evidence',
             'full source-period weather coverage','named independent target registry'],
         'science_outputs_preserved':preservation['status']=='passed',
         'qualified_sample_failures_retained':['13022','13025'],
         'software_error_history_retained':'rainfall_samples/SOFTWARE_NOTES.md',
         'next_step':'user review/provider answers; do not execute draft automatically'})
    print(json.dumps({'preservation':preservation['status'],'files':len(before['files']),
                      'new_requests':len(new),'successes':successes,'failed':len(new)-successes}))


if __name__ == '__main__':
    main()
