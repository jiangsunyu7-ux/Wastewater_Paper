"""Package saved Stage3C.1 feasibility evidence, then verify a clean offline replay.

This script never fits a forecasting model or calls a network endpoint. It refuses
to overwrite the delivery ZIP or its receipt. New scientific experiments are not
authorized by packaging a disabled future configuration draft.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
VERSION = "stage3c1_20261011_v1"
LIMIT = 24 * 1024**2
SKIP = {"__pycache__", ".git", ".cache", ".ipynb_checkpoints"}
RAW = "wastewater_data/raw/wessex_all_2016_2025.csv"
RAW_SHA = "22f494e2b96fe6fa9550c68971d50c752ddd291793fdc60334d64b2ef089f518"
SMALL_ARCHIVED_INPUTS = [
    "data/provenance/stage3b_20261011_v1/future_source_expansion_candidates_pre2022.csv",
    "data/provenance/reconciliation_20261009/coverage_2016_2021.csv",
    "data/provenance/DEVELOPMENT_SELECTION_20261009.json",
    "data/provenance/stage3b_20261011_v1/FACILITY_MAPPING.csv",
    "data/provenance/stage3b_20261011_v1/official_tdv_table_response.bin",
    "data/provenance/stage3b_20261011_v1/OFFICIAL_QUERY_INDEX.json",
]


def sha(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024**2), b""):
            result.update(block)
    return result.hexdigest()


def collect(root: Path) -> dict[str, Path]:
    paths = [
        f"reports/{VERSION}", f"data/provenance/{VERSION}", f"configs/{VERSION}",
        "requirements-stage3c1.txt", "tests/test_stage3c1.py",
        "scripts/package_stage3c1.py", "AGENTS.md", "STATUS.md",
        "RESEARCH_PLAN.md", "EXPERIMENT_PROTOCOL.md", "WORKFLOW.md",
    ] + SMALL_ARCHIVED_INPUTS
    paths += [str(p.relative_to(root)) for p in sorted((root/"scripts").glob("stage3c1_*.py"))]
    payload = {}
    for name in paths:
        source = root/name
        if not source.exists():
            raise FileNotFoundError(source)
        for p in ([source] if source.is_file() else sorted(source.rglob("*"))):
            relative = p.relative_to(root)
            if not p.is_file() or any(part in SKIP for part in relative.parts) or p.suffix in {".pyc", ".pyo"}:
                continue
            if p.is_symlink() or not p.resolve().is_relative_to(root.resolve()):
                raise ValueError(f"Unsafe payload source: {p}")
            payload[relative.as_posix()] = p
    required = [
        f"reports/{VERSION}/FEASIBILITY_ZH.md",
        f"reports/{VERSION}/REPRODUCE.md",
        f"reports/{VERSION}/RUN_STATUS.json",
        f"reports/{VERSION}/STAGE3B_PRESERVATION_AFTER.json",
        f"reports/{VERSION}/rainfall_connection/CONNECTION_CHECK.json",
        f"reports/{VERSION}/INDEPENDENT_REVIEW.json",
    ]
    for name in required:
        if name not in payload:
            raise FileNotFoundError(f"Required completed review artifact absent: {name}")
    if RAW in payload:
        raise ValueError("Full original raw CSV is deliberately an external dependency")
    return payload


def run(python: str, arguments: list[str], root: Path, log: str) -> str:
    done = subprocess.run([python, *arguments], cwd=root, text=True,
                          capture_output=True, timeout=120)
    output = done.stdout + done.stderr
    (root/log).write_text(output)
    if done.returncode:
        raise RuntimeError(f"Clean replay failed: {arguments}; {output[-3000:]}")
    return output


def validate_saved_receipts(root: Path) -> dict:
    """Reject stale referenced inputs, disabled-draft hashes or nested manifests."""
    report = root/f"reports/{VERSION}"
    next_check = json.loads((report/"NEXT_DRAFT_CHECK.json").read_text())
    next_path = root/f"configs/{VERSION}/next_experiment_draft.json"
    assert sha(next_path) == next_check["configuration_sha256"]
    assert sha(report/"NEXT_EXPERIMENT_DRAFT.md") == next_check["report_sha256"]
    assert not json.loads(next_path.read_text())["execute_allowed"]
    versions = json.loads((report/"CODE_VERSION.json").read_text())
    for path, expected in versions["content_sha256"].items():
        assert sha(root/path) == expected, path
    independent = json.loads((report/"INDEPENDENT_REVIEW.json").read_text())
    assert independent["ready_for_packaging"]
    for field in ["reviewed_hashes", "consolidated_reports_reviewed"]:
        for path, expected in independent[field].items():
            assert sha(root/path) == expected, path
    script = independent["independent_recheck_script"]
    assert sha(root/script["path"]) == script["sha256"]
    external = []
    source = root/f"data/provenance/{VERSION}/cohorts/SOURCE_POOL_AUDIT.json"
    for entry in json.loads(source.read_text())["inputs"]:
        if entry["path"] == RAW:
            assert entry["sha256"] == RAW_SHA
            external.append(entry["path"])
        else:
            p = root/entry["path"]
            assert p.stat().st_size == entry["bytes"] and sha(p) == entry["sha256"], entry["path"]
    nested = 0
    for manifest in (root/f"data/provenance/{VERSION}").glob("*/MANIFEST.json"):
        parsed = json.loads(manifest.read_text())
        # The facility manifest uses local relative paths; the catalog uses
        # project-relative paths. Retain their recorded conventions.
        if isinstance(parsed.get("files"), list):
            for record in parsed["files"]:
                p = root/record["path"]
                if not p.is_file():
                    p = manifest.parent/record["path"]
                assert sha(p) == record["sha256"], str(p)
                nested += 1
    return {"disabled_draft_hashes_passed": True,
            "recorded_scientific_code_hashes_passed": True,
            "independent_final_review_hashes_passed": True,
            "source_audit_small_input_hashes_passed": True,
            "nested_manifest_files_checked": nested,
            "external_inputs_excluded": external}


def clean_replay(zipped: Path, members: dict[str, str], python: str) -> dict:
    with tempfile.TemporaryDirectory(prefix="stage3c1_clean_replay_", dir="/tmp") as scratch:
        root = Path(scratch)
        with zipfile.ZipFile(zipped) as z:
            for name, expected in members.items():
                parsed = PurePosixPath(name)
                if parsed.is_absolute() or ".." in parsed.parts:
                    raise ValueError("Unsafe ZIP member")
                assert hashlib.sha256(z.read(name)).hexdigest() == expected, name
            z.extractall(root)
        assert not (root/RAW).exists()
        unit_output = run(python, ["-m", "unittest", "discover", "-s", "tests", "-p", "test_stage3c1.py", "-v"], root, "unit_tests.log")
        assert "Ran 6 tests" in unit_output and "\nOK\n" in unit_output
        run(python, ["scripts/stage3c1_rainfall_check.py", "--root", str(root), "--output", "verification/rainfall"], root, "rainfall_replay.log")
        saved = root/f"reports/{VERSION}/rainfall_connection"
        rebuilt = root/"verification/rainfall"
        assert json.loads((saved/"CONNECTION_CHECK.json").read_text()) == json.loads((rebuilt/"CONNECTION_CHECK.json").read_text())
        tables = sorted(saved.glob("*.csv*"))
        assert len(tables) == 6
        # Rebuilding uses identical code and fixed dependencies, so exact CSV
        # bytes (including deterministic gzip mtime=0) are the stated standard.
        for original in tables:
            assert original.read_bytes() == (rebuilt/original.name).read_bytes(), original.name
        independent_output = run(python, [f"reports/{VERSION}/independent_raw_recheck.py", "--root", str(root), "--rain-only"], root, "independent_rain_recheck.log")
        independent = json.loads(independent_output)
        assert independent["diagnostics"]["rain"]["records"] == 6048
        assert independent["diagnostics"]["cohort"]["status"] == "NOT_RECHECKED_raw_CSV_skipped_by_explicit_rain_only_option"
        assert all(independent["checks"].values())
        facility = root/f"data/provenance/{VERSION}/facilities"
        original_summary = json.loads((facility/"FACILITY_AUDIT_SUMMARY.json").read_text())
        original_mapping = (facility/"facility_mapping_status.csv").read_bytes()
        run(python, [str((facility/"audit_existing_facility_evidence.py").relative_to(root))], root, "facility_replay.log")
        assert json.loads((facility/"FACILITY_AUDIT_SUMMARY.json").read_text()) == original_summary
        assert (facility/"facility_mapping_status.csv").read_bytes() == original_mapping
        observed = json.loads((rebuilt/"CONNECTION_CHECK.json").read_text())
        return {
            "clean_temporary_extraction": True,
            "original_full_raw_csv_not_present": True,
            "local_python_executable": python,
            "unit_tests_executed": 6,
            "unit_tests_passed": 6,
            "rainfall_summary_exactly_reproduced": True,
            "rainfall_six_tables_byte_identical": True,
            "facility_summary_and_mapping_exactly_reproduced": True,
            "independently_implemented_rain_only_recheck_passed": True,
            "independent_daily_total_tolerance": {"atol": 1e-12, "rtol": 0},
            "rainfall_records": observed["raw_records"],
            "gauges": observed["raw_downloaded_gauges"],
            "formal_verified_spatial_links": observed["formal_verified_development_spatial_links"],
            "new_model_fits": 0,
            "network_requests": 0,
            "source_candidate_full_raw_replay": "NOT_RUN_IN_SMALL_PACKAGE; external same-SHA raw CSV required",
            "stage3b_preservation_replay": "NOT_RUN_IN_SMALL_PACKAGE; original full checkout required",
            "unit_test_output": (root/"unit_tests.log").read_text(),
            "facility_replay_output": (root/"facility_replay.log").read_text(),
            "independent_rain_recheck": independent,
        }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=str(ROOT))
    parser.add_argument("--output", default="delivery/20261012_stage3c1")
    parser.add_argument("--python", default=sys.executable)
    args = parser.parse_args()
    root = Path(args.root).resolve(); output = root/args.output
    output.mkdir(parents=True, exist_ok=True)
    destination = output/"Wastewater_Stage3C1_Feasibility_20261012.zip"
    receipt = output/"PACKAGE_CHECKS.json"
    if destination.exists() or receipt.exists():
        raise FileExistsError("Existing delivery is immutable; use a new output directory/version")
    payload = collect(root)
    saved_receipts = validate_saved_receipts(root)
    records = [{"path": name, "bytes": p.stat().st_size, "sha256": sha(p)}
               for name, p in sorted(payload.items())]
    start = (
        "# Stage3C.1 engineering-information feasibility audit\n\n"
        "Read reports/stage3c1_20261011_v1/FEASIBILITY_ZH.md and REPRODUCE.md.\n"
        "Extract into a NEW directory. Run sha256sum -c SHA256SUMS before checks.\n"
        "No forecasting model was trained in this stage. Rain connection samples\n"
        "are retrospective Qualified records with unverified historical facility\n"
        "links, timestamp boundaries and first-publication times. Formal model-ready\n"
        "links = 0. Keep 13022/13025 all-Suspect failures, not replace gauges.\n"
        "The next experiment draft is BLOCKED, execute_allowed=false. STOP for review.\n"
        "The full source-candidate raw audit needs the original same-SHA CSV;\n"
        "the Stage3B preservation check needs the original full checkout. Neither\n"
        "is claimed independently reproducible from this bounded small package.\n"
    ).encode()
    members = {r["path"]: r["sha256"] for r in records}
    members["START_HERE.md"] = hashlib.sha256(start).hexdigest()
    manifest = {
        "version": VERSION,
        "package_created_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": "engineering information and connection feasibility only",
        "files": records,
        "start_here_sha256": members["START_HERE.md"],
        "excluded": ["bytecode/cache", "old complete Stage3B runs and weights", RAW],
        "omitted_full_raw_input": {"path": RAW, "bytes": 73570225, "sha256": RAW_SHA,
                                   "retrieval": "Original user upload Wastewater_Part1_Plan_and_Raw.zip or existing read-only project copy"},
        "source_candidate_rebuild_other_inputs_included": SMALL_ARCHIVED_INPUTS,
        "requires_full_checkout_for_finalize_preservation_audit": True,
        "formal_model_ready_connections": 0,
        "new_model_fits": 0,
        "next_experiment_execute_allowed": False,
        "scientific_forecast_performance_not_recalculated": True,
    }
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2)+"\n").encode()
    members["MANIFEST.json"] = hashlib.sha256(manifest_bytes).hexdigest()
    checksums = "".join(f"{h}  {name}\n" for name, h in sorted(members.items())).encode()
    members["SHA256SUMS"] = hashlib.sha256(checksums).hexdigest()
    with zipfile.ZipFile(destination, "x", zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
        for name, p in sorted(payload.items()):
            zipped.write(p, name)
        zipped.writestr("START_HERE.md", start)
        zipped.writestr("MANIFEST.json", manifest_bytes)
        zipped.writestr("SHA256SUMS", checksums)
    assert destination.stat().st_size < LIMIT, "ZIP must be strictly below 24 MiB"
    with zipfile.ZipFile(destination) as zipped:
        assert zipped.testzip() is None, "CRC failure"
        assert len(zipped.namelist()) == len(set(zipped.namelist())) == len(members)
        assert set(zipped.namelist()) == set(members)
        for name, h in members.items():
            assert hashlib.sha256(zipped.read(name)).hexdigest() == h, name
    # Preserve the venv launch path: resolving its symlink would launch the
    # base interpreter and silently discard the pinned venv dependencies.
    replay = clean_replay(destination, members, str(Path(args.python).absolute()))
    # Source bytes cannot change while the immutable package is being checked.
    for name, p in payload.items():
        assert sha(p) == members[name], f"Source changed during packaging: {name}"
    package_sha = sha(destination)
    result = {
        "status": "CREATED_CRC_ALL_MEMBER_SHA256_AND_CLEAN_OFFLINE_REPLAY_PASSED",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "filename": destination.name, "bytes": destination.stat().st_size,
        "MiB": destination.stat().st_size/1024**2, "sha256": package_sha,
        "below_24_MiB": True, "payload_files": len(payload), "zip_members": len(members),
        "crc_checked_all_members": True, "every_member_sha256_verified": True,
        "zip_members_sha256": members,
        "saved_receipt_validation": saved_receipts,
        "clean_replay": replay,
    }
    receipt.write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n")
    (output/"MANIFEST.json").write_bytes(manifest_bytes)
    direct_documents = {
        "FEASIBILITY_ZH.md": f"reports/{VERSION}/FEASIBILITY_ZH.md",
        "NEXT_EXPERIMENT_DRAFT.md": f"reports/{VERSION}/NEXT_EXPERIMENT_DRAFT.md",
        "QUESTIONS_FOR_GUNA_PROVIDER.md": f"reports/{VERSION}/QUESTIONS_FOR_GUNA_PROVIDER.md",
        "next_experiment_draft.json": f"configs/{VERSION}/next_experiment_draft.json",
        "facility_mapping_status.csv": f"reports/{VERSION}/facility_mapping_status.csv",
        "field_time_alignment_examples.csv": f"reports/{VERSION}/rainfall_connection/field_time_alignment_examples.csv",
    }
    for direct_name, source_name in direct_documents.items():
        (output/direct_name).write_bytes((root/source_name).read_bytes())
    (output/"README.md").write_text(
        "# Stage3C.1 feasibility delivery\n\n"
        "已完成证据、原始样本连接及离线复核，未训练新模型。下一轮草案未执行，等待审查。\n\n"
        f"- [下载ZIP]({destination.name}?raw=true)（{result['MiB']:.3f} MiB，CRC/成员SHA/干净解压检查已通过）\n"
        "- [中文可行性报告](FEASIBILITY_ZH.md)\n"
        "- [下一轮不可执行草案](NEXT_EXPERIMENT_DRAFT.md)及[配置](next_experiment_draft.json)\n"
        "- [Guna/提供方待答问题](QUESTIONS_FOR_GUNA_PROVIDER.md)\n"
        "- [设施映射状态](facility_mapping_status.csv)及[时间字段样本](field_time_alignment_examples.csv)\n"
        "- [完整性与实际复核记录](PACKAGE_CHECKS.json)\n"
        "- [文件校验清单](SHA256SUMS)\n\n"
        "解压后读reports/stage3c1_20261011_v1/FEASIBILITY_ZH.md与REPRODUCE.md。\n"
        "全部实验边界及缺失工程证据保持明确；当前formal model-ready连接为0。\n"
        "完整186源候选原始审计需额外原上传同SHA CSV，Stage3B保护重审需旧完整checkout；包内未声称这些完全自包含。\n"
        "ZIP仓库可见性沿用用户授权；私有仓库需有权限的GitHub登录。\n"
    )
    (output/"SHA256SUMS").write_text("".join(
        f"{sha(p)}  {p.name}\n" for p in sorted(output.iterdir())
        if p.is_file() and p.name != "SHA256SUMS"))
    print(json.dumps({k: v for k, v in result.items() if k not in {"zip_members_sha256", "clean_replay"}}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
