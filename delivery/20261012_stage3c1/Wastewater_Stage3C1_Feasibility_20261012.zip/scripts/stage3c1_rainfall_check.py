"""Rebuild a bounded retrospective rainfall connection audit, never fit forecasts."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
VERSION = 'stage3c1_20261011_v1'
START, END = '2023-09-24', '2023-10-01'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def valid_value(row):
    value=row.get('value')
    return (value is not None and np.isfinite(value) and value>=0
            and row.get('quality')=='Good' and row.get('completeness')=='Complete')

def day_summary(records, day):
    """Nominal naive-clock bins only; not a verified provider rainfall day."""
    day=pd.Timestamp(day).tz_localize(None)
    expected=pd.date_range(day,periods=96,freq='15min')
    selected=[r for r in records if day<=pd.Timestamp(r['dateTime']).tz_localize(None)<day+pd.Timedelta(days=1)]
    grouped={}
    for r in selected:
        grouped.setdefault(pd.Timestamp(r['dateTime']).tz_localize(None),[]).append(r)
    conflicts=sum(len(v)>1 for v in grouped.values())
    valid=[v[0] for k,v in grouped.items() if k in expected and len(v)==1 and valid_value(v[0])]
    complete=(len(grouped)==96 and set(grouped)==set(expected) and len(valid)==96 and not conflicts)
    return {'nominal_stamp_day':str(day.date()),'expected_intervals':96,
            'returned_intervals':len(grouped),'valid_intervals':len(valid),
            'duplicate_timestamp_groups':conflicts,'complete_good_day':complete,
            'qualified_total_mm':sum(r['value'] for r in valid) if complete else np.nan,
            'partial_valid_sum_mm':sum(r['value'] for r in valid) if valid else np.nan,
            'daily_statistical_day_verified':False,'timezone_verified':False,
            'upper_interval_end_if_stamp_is_start_and_UTC':str((day+pd.Timedelta(days=1)).tz_localize('UTC'))}

def time_bounds(stamp, origin_day):
    """Explicit UTC/London and interval-start/end scenarios, not verified facts."""
    stamp=pd.Timestamp(stamp)
    moments=[stamp.tz_convert('UTC')] if stamp.tzinfo else [
        stamp.tz_localize(tz,ambiguous='raise',nonexistent='raise').tz_convert('UTC')
        for tz in ['UTC','Europe/London']]
    upper=max(moments)+pd.Timedelta(minutes=15)
    d=pd.Timestamp(origin_day).tz_localize(None)+pd.Timedelta(days=1)-pd.Timedelta(seconds=1)
    cutoff=min(d.tz_localize(tz).tz_convert('UTC') for tz in ['UTC','Europe/London'])
    return upper,cutoff,bool(upper<cutoff)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',default=str(ROOT))
    parser.add_argument('--output',default=f'reports/{VERSION}/rainfall_connection')
    args=parser.parse_args();root=Path(args.root);out=root/args.output;out.mkdir(parents=True,exist_ok=True)
    data=root/f'data/provenance/{VERSION}/rainfall_samples'
    plan=json.loads((data/'SAMPLE_REQUEST_PLAN.json').read_text())
    assert plan['no_station_switch_after_missing_data'] and len(plan['measure_urls'])==9
    links=pd.read_csv(data/'candidate_spatial_join.csv',dtype={'site_id':str,'rain_station_id':str})
    assert len(links)==10 and not links.model_eligible.any()
    all_rows=[];daily=[];gauges={};hashes={};source_receipts=[]
    for i,url in enumerate(plan['measure_urls'],1):
        path=data/f'readings_gauge_{i:02d}_20230924_20230930.json'
        meta=json.loads(path.with_suffix('.json.metadata.json').read_text())
        assert meta['status']=='downloaded' and meta['sha256']==sha(path)
        assert meta['url'].startswith(url+'/readings?')
        source=json.loads(path.read_text());rows=source['items']
        assert len(rows)<1000,'Potential truncated response is not complete coverage'
        assert source['meta']['version']=='2.1.1' and source['meta']['licenseName']=='OGL 3'
        gauge=links.loc[links.measure_url.eq(url),'rain_station_id'].iloc[0]
        gauges[gauge]=rows;hashes[str(path.relative_to(root))]=sha(path)
        source_receipts.append({'rain_station_id':gauge,'api_version':'2.1.1','license':'OGL 3',
                                'source_url':meta['url'],'source_sha256':meta['sha256'],
                                'retrieved_utc':meta['retrieved_utc'],'bytes':meta['bytes']})
        for r in rows:
            assert r['measure']['@id'].replace('http://','https://')==url
            t=pd.Timestamp(r['dateTime']).tz_localize(None)
            assert pd.Timestamp(START)<=t<pd.Timestamp(END),'Requested period escaped'
            explicit=pd.Timestamp(r['dateTime']).tzinfo is not None
            all_rows.append({'rain_station_id':gauge,'source_datetime_raw':r['dateTime'],
                'source_date':r.get('date'),'rainfall_mm_raw':r.get('value',np.nan),
                'quality':r.get('quality','unknown'),'completeness':r.get('completeness','unknown'),
                'value_present':'value' in r,'good_complete_nonnegative':valid_value(r),
                'timestamp_explicit_timezone':explicit,'interval_stamp_endpoint_verified':False,
                'historical_first_publication_verified':False,'dataset_category':'retrospective_qualified_observation',
                'measure_url':url,'source_file':str(path.relative_to(root))})
        for d in pd.date_range(START,periods=7):daily.append({'rain_station_id':gauge,**day_summary(rows,d)})
    raw=pd.DataFrame(all_rows);days=pd.DataFrame(daily)
    assert not raw.duplicated(['rain_station_id','source_datetime_raw']).any()
    raw.to_csv(out/'rainfall_readings_qualified.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    days.to_csv(out/'nominal_timestamp_day_summaries.csv',index=False)
    pd.DataFrame(source_receipts).to_csv(out/'sample_source_receipts.csv',index=False)
    linked=links.merge(days,on='rain_station_id',how='left',validate='many_to_many')
    linked.to_csv(out/'development_candidate_daily_join.csv',index=False)
    cov=[]
    for site,rows in linked.groupby('site_id'):
        cov.append({'site_id':site,'rain_station_id':rows.rain_station_id.iloc[0],
            'candidate_centroid_distance_km':rows.distance_km.iloc[0],'sample_days':len(rows),
            'expected_intervals':int(rows.expected_intervals.sum()),'returned_intervals':int(rows.returned_intervals.sum()),
            'valid_good_complete_intervals':int(rows.valid_intervals.sum()),
            'returned_coverage':float(rows.returned_intervals.sum()/rows.expected_intervals.sum()),
            'quality_usable_coverage':float(rows.valid_intervals.sum()/rows.expected_intervals.sum()),
            'effective_missing_or_excluded_fraction':float(1-rows.valid_intervals.sum()/rows.expected_intervals.sum()),
            'complete_good_days':int(rows.complete_good_day.sum()),
            'formal_site_spatial_link_verified':False,'historical_boundary_verified':False,
            'real_time_first_publication_verified':False,'model_ready':False})
    coverage=pd.DataFrame(cov);coverage.to_csv(out/'coverage_by_development_site.csv',index=False)
    temporal=[]
    # Engineering field/time examples only, no treated-volume labels or forecasts.
    for row in links.itertuples(index=False):
        for origin in pd.date_range('2023-09-26','2023-10-01'):
            weather_day=origin-pd.Timedelta(days=2)
            detail=day_summary(gauges[row.rain_station_id],weather_day)
            last_stamp=weather_day+pd.Timedelta(hours=23,minutes=45)
            upper,cutoff,passes=time_bounds(last_stamp,origin)
            assert passes
            for h in [1,3]:
                temporal.append({'site_id':row.site_id,'rain_station_id':row.rain_station_id,
                    'origin_day':str(origin.date()),'horizon':h,'target_day':str((origin+pd.Timedelta(days=h)).date()),
                    'rain_stamp_day_lag2':str(weather_day.date()),'rain_total_mm_retrospective_candidate':detail['qualified_total_mm'],
                    'good_complete_intervals':detail['valid_intervals'],'nominal_daily_value_complete':detail['complete_good_day'],
                    'rain_interval_end_upper_under_UTC_start_scenario':str(upper),
                    'earliest_origin_cutoff_under_UTC_or_London_day_end':str(cutoff),
                    'measured_before_cutoff_under_stated_scenarios':passes,
                    'rain_timestamp_timezone_verified':False,'rain_timestamp_interval_endpoint_verified':False,
                    'TDV_daily_time_boundary_verified':False,'first_publication_before_origin_verified':False,
                    'real_time_available_at_origin':False,'model_ready':False,
                    'interpretation':'Mechanical lag2 join using explicit timezone/endpoint scenarios; not verified deployment or historical catchment mapping'})
    temporal=pd.DataFrame(temporal);temporal.to_csv(out/'field_time_alignment_examples.csv',index=False)
    assert (pd.to_datetime(temporal.target_day)-pd.to_datetime(temporal.origin_day)).dt.days.eq(temporal.horizon).all()
    pair=temporal.pivot(index=['site_id','origin_day'],columns='horizon',values='rain_total_mm_retrospective_candidate')
    np.testing.assert_allclose(pair[1],pair[3],atol=0,rtol=0,equal_nan=True)
    summary={'status':'completed_feasibility_only','raw_downloaded_gauges':len(gauges),'raw_records':len(raw),
        'sample_dates':[START,'2023-09-30'],'downloaded_reading_bytes':sum(r['bytes'] for r in source_receipts),
        'unique_gauge_expected_intervals':9*7*96,'returned_timestamp_coverage':len(raw)/(9*7*96),
        'raw_missing_value_records':int((~raw.value_present).sum()),'quality_counts':raw.quality.value_counts().to_dict(),
        'valid_good_complete_records':int(raw.good_complete_nonnegative.sum()),
        'unique_gauge_quality_usable_coverage':float(raw.good_complete_nonnegative.mean()),
        'development_candidate_links':len(links),'formal_verified_development_spatial_links':0,
        'development_nominal_daily_rows':len(linked),'development_complete_good_days':int(linked.complete_good_day.sum()),
        'development_site_weighted_quality_usable_coverage':float(linked.valid_intervals.sum()/linked.expected_intervals.sum()),
        'excluded_sites_retained':coverage.loc[coverage.quality_usable_coverage.lt(1),'site_id'].tolist(),
        'alignment_example_rows':len(temporal),'alignment_passes_under_explicit_scenarios':int(temporal.measured_before_cutoff_under_stated_scenarios.sum()),
        'alignment_missing_qualified_values':int(temporal.rain_total_mm_retrospective_candidate.isna().sum()),
        'timestamps_without_explicit_timezone':int((~raw.timestamp_explicit_timezone).sum()),
        'interval_endpoint_and_day_definition_verified':False,'per_value_historical_publication_verified':False,
        'historical_weather_2016_2021_continuous_coverage_verified':False,'formal_model_ready_sites':0,
        'technical_connection_success_is_not_engineering_or_realtime_validation':True,
        'weather_forecast_archive_obtained':False,'model_fitting_performed':False,'final_performance_calculated':False,
        'input_sha256':hashes,'checker_sha256':sha(Path(__file__))}
    (out/'CONNECTION_CHECK.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
