"""Bounded public-evidence download; retain TLS checks and retrieval metadata."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import urllib.error
import urllib.request

def fetch(url, output, max_bytes=2*1024**2):
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    meta = output.with_suffix(output.suffix+'.metadata.json')
    if output.exists() or meta.exists():
        raise FileExistsError('Evidence is immutable; use a new name for a new query')
    rec = {'url':url, 'retrieved_utc':datetime.now(timezone.utc).isoformat(),
           'max_response_bytes':max_bytes, 'TLS_verification':True,
           'retrieval_date_is_not_historical_publication_time':True}
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'Wessex-research-feasibility/1.0','Accept':'application/json,text/html,text/csv,*/*'})
        with urllib.request.urlopen(req, timeout=30) as response:
            body=response.read(max_bytes+1)
            rec.update(http_status=response.status, final_url=response.url,
                       content_type=response.headers.get('Content-Type'),
                       response_last_modified=response.headers.get('Last-Modified'),
                       response_date=response.headers.get('Date'))
            if len(body)>max_bytes:
                raise ValueError('Response exceeded bounded sample size; full body not downloaded')
            output.write_bytes(body)
            rec.update(status='downloaded', bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
    except Exception as err:
        rec.update(status='failed', error_type=type(err).__name__, error=str(err))
        if isinstance(err,urllib.error.HTTPError):
            rec['http_status']=err.code
    meta.write_text(json.dumps(rec,indent=2)+'\n')
    return rec

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('url');ap.add_argument('output');ap.add_argument('--max-bytes',type=int,default=2*1024**2)
    args=ap.parse_args()
    print(json.dumps(fetch(args.url,args.output,args.max_bytes),indent=2))
