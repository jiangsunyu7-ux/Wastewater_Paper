# Stage3C.1 engineering-information feasibility audit

Read reports/stage3c1_20261011_v1/FEASIBILITY_ZH.md and REPRODUCE.md.
Extract into a NEW directory. Run sha256sum -c SHA256SUMS before checks.
No forecasting model was trained in this stage. Rain connection samples
are retrospective Qualified records with unverified historical facility
links, timestamp boundaries and first-publication times. Formal model-ready
links = 0. Keep 13022/13025 all-Suspect failures, not replace gauges.
The next experiment draft is BLOCKED, execute_allowed=false. STOP for review.
The full source-candidate raw audit needs the original same-SHA CSV;
the Stage3B preservation check needs the original full checkout. Neither
is claimed independently reproducible from this bounded small package.
