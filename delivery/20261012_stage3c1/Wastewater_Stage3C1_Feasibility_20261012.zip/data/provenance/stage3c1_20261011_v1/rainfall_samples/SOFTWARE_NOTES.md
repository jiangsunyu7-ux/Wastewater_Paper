# Retrieval and processing scope

Hydrology stations `type=Rainfall` returned HTTP400; the documented observedProperty=rainfall filter subsequently worked. The multi-series earliest endpoint returned HTML with the generic Accept header; the original response and metadata are preserved despite the originally chosen .json filename. Requesting the documented readings.json endpoint produced actual JSON with9 different earliest records. No rainfall station was replaced after observing coverage or QC.

The first combined shell also attempted to parse the HTML earliest response and exited1 after the separate rainfall checker had already completed. The HTML format was diagnosed and explicit JSON requested; the standalone rainfall checker and6 time/QA tests subsequently passed. No model fitting occurred. All fetched historical stamps were naive: UTC/London and interval-end checks are explicit scenarios, not proven historical availability.
