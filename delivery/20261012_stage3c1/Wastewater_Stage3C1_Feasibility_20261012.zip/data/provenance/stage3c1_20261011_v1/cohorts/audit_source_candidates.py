"""Pre-2022-only source eligibility and unassigned physical-group feasibility.

No forecasting code, future-period statistics, model loss or performance file is read.
The official archived responses contain no TDV-meter/physical-plant crosswalk.
"""
from __future__ import annotations

import calendar
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
OLD = ROOT / "data/provenance/stage3b_20261011_v1"
RAW = ROOT / "wastewater_data/raw/wessex_all_2016_2025.csv"
CANDIDATES = OLD / "future_source_expansion_candidates_pre2022.csv"
COVERAGE = ROOT / "data/provenance/reconciliation_20261009/coverage_2016_2021.csv"
SELECTION = ROOT / "data/provenance/DEVELOPMENT_SELECTION_20261009.json"
FIXED_MAPPING = OLD / "FACILITY_MAPPING.csv"
TDV_SCHEMA = OLD / "official_tdv_table_response.bin"
EXPECTED_RAW_SHA256 = "22f494e2b96fe6fa9550c68971d50c752ddd291793fdc60334d64b2ef089f518"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def normalized_name(name: str) -> str:
    # A conservative text screen, explicitly not a verified physical-facility key.
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", name.casefold())).strip()


def write_json(name: str, data: dict) -> None:
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def main() -> None:
    accepted = pd.read_csv(CANDIDATES, dtype={"site_id": str})
    original = pd.read_csv(COVERAGE, dtype={"site_id": str})
    selected = json.loads(SELECTION.read_text())
    fixed = pd.read_csv(FIXED_MAPPING, dtype={"site_id": str})
    schema = json.loads(TDV_SCHEMA.read_text())
    assert sha256(RAW) == EXPECTED_RAW_SHA256
    assert len(accepted) == 186 and accepted.site_id.nunique() == 186
    source_ids = selected["reserved_source_candidate_ids"]
    development_ids = selected["development_ids"]
    assert source_ids == ["13006", "13008", "13012"]
    assert development_ids == ["13013", "13015", "13016", "13017", "13022", "13024", "13025", "13028", "13029", "13031"]
    assert not set(accepted.site_id) & set(source_ids + development_ids)
    assert schema.get("relationships") == [] and not schema.get("geometryType")

    frames, names = [], []
    for chunk in pd.read_csv(RAW, dtype={"SiteID": str}, chunksize=100000):
        # Discard all post-2021 rows before names, quality or volume calculations.
        early = chunk.loc[chunk.Date.between("2016-01-01", "2021-12-31")].copy()
        early = early.loc[early.SiteName.str.contains("WATER RECYCLING CENTRE", regex=False, na=False)]
        names.append(early[["SiteID", "SiteName"]].drop_duplicates())
        frames.append(early.loc[early.SiteID.isin(accepted.site_id)].copy())
    raw = pd.concat(frames, ignore_index=True)
    name_pairs = pd.concat(names, ignore_index=True).drop_duplicates()
    assert raw.Date.between("2016-01-01", "2021-12-31").all()
    raw["value"] = pd.to_numeric(raw.TotalVolume, errors="coerce")
    raw["quality"] = raw.QualityFlag.str.strip().str.casefold()
    keys = ["SiteID", "Date"]
    variants = raw.drop_duplicates(keys + ["value", "quality", "Units"])
    conflict_keys = pd.MultiIndex.from_frame(variants.loc[variants.duplicated(keys, keep=False), keys]).unique()
    raw["conflict"] = pd.MultiIndex.from_frame(raw[keys]).isin(conflict_keys)
    raw["duplicate"] = raw.duplicated(keys, keep=False)
    raw["valid"] = raw.quality.eq("good") & np.isfinite(raw.value) & raw.value.ge(0) & raw.Units.eq("m3") & ~raw.conflict
    raw["original_coverage_valid"] = raw["valid"] & ~raw.duplicate
    raw["exclusion_reason"] = np.select(
        [raw.conflict, ~np.isfinite(raw.value), raw.Units.ne("m3"), raw.quality.eq("missing"),
         raw.quality.eq("suspect"), raw.quality.eq("good") & raw.value.lt(0), raw.valid],
        ["conflicting_site_day", "nonfinite_value", "non_m3_units", "Missing_encoded_or_missing_value",
         "Suspect", "Good_negative", "retained_Good_nonnegative"], default="unsupported_quality_flag")
    raw.loc[raw.duplicate].to_csv(OUT / "source_candidate_duplicate_records_pre2022.csv", index=False)
    raw.groupby(["SiteID", "exclusion_reason"]).size().reset_index(name="raw_rows").rename(columns={"SiteID": "site_id"}).to_csv(OUT / "source_candidate_disjoint_qa_counts_pre2022.csv", index=False)
    yearly, quality_rows = [], []
    for sid, g in raw.groupby("SiteID", sort=True):
        for year in range(2016, 2022):
            y = g.loc[g.Date.str[:4].eq(str(year))]
            n = y.loc[y.valid, "Date"].nunique()
            n_old = y.loc[y.original_coverage_valid, "Date"].nunique()
            days = 366 if calendar.isleap(year) else 365
            yearly.append({"site_id": sid, "year": year, "calendar_days": days,
                           "raw_rows": len(y), "valid_good_nonnegative_nonconflict_dates": n,
                           "coverage": n / days, "coverage_prior_duplicate_exclusion": n_old / days,
                           "original_coverage_valid_dates": n_old})
        quality_rows.append({"site_id": sid, "raw_rows": len(g), "unique_observed_dates": g.Date.nunique(),
                             "calendar_missing_dates": 2192 - g.Date.nunique(),
                             "valid_dates": g.loc[g.valid, "Date"].nunique(),
                             "good_zero_retained": int((g.valid & g.value.eq(0)).sum()),
                             "good_negative_excluded": int((g.quality.eq("good") & g.value.lt(0)).sum()),
                             "missing_zero_excluded": int((g.quality.eq("missing") & g.value.eq(0)).sum()),
                             "missing_nonzero_excluded": int((g.quality.eq("missing") & g.value.ne(0)).sum()),
                             "suspect_excluded": int(g.quality.eq("suspect").sum()),
                             "conflicting_site_days": g.loc[g.conflict, "Date"].nunique(),
                             "duplicate_rows": int(g.duplicate.sum()),
                             "non_m3_units": int(g.Units.ne("m3").sum()),
                             "nonfinite_rows": int((~np.isfinite(g.value)).sum()),
                             "calendar_span": "2016-01-01/2021-12-31",
                             "post_2021_rows_used": 0})
    years = pd.DataFrame(yearly)
    quality = pd.DataFrame(quality_rows)
    before = original.loc[original.site_id.isin(accepted.site_id)]
    comparison = years.merge(before, on=["site_id", "year"], suffixes=("_recheck", "_archived"), validate="one_to_one")
    assert len(comparison) == 1116
    assert (comparison.original_coverage_valid_dates == comparison.valid_nonnegative_dates).all()
    assert np.allclose(comparison.coverage_prior_duplicate_exclusion, comparison.coverage_archived, rtol=0, atol=1e-12)
    years.to_csv(OUT / "source_candidate_coverage_pre2022_rechecked.csv", index=False)
    quality.to_csv(OUT / "source_candidate_quality_pre2022.csv", index=False)
    comparison.to_csv(OUT / "coverage_arithmetic_comparison.csv", index=False)

    name_pairs["text_group_only"] = name_pairs.SiteName.map(normalized_name)
    text_groups = name_pairs.groupby("text_group_only").SiteID.apply(lambda ids: sorted(set(ids), key=int)).to_dict()
    pre_name_counts = name_pairs.groupby("SiteID").SiteName.nunique().to_dict()
    status = accepted.merge(years.groupby("site_id").agg(rechecked_minimum_year_coverage=("coverage", "min"),
                                                      rechecked_years=("year", "nunique")).reset_index(), on="site_id", validate="one_to_one")
    status = status.merge(quality, on="site_id", validate="one_to_one")
    status["pre2022_name_count"] = status.site_id.map(pre_name_counts)
    status["quality_eligible_pre2022"] = status.rechecked_years.eq(6) & status.rechecked_minimum_year_coverage.ge(.95) & status.pre2022_name_count.eq(1)
    status["name_screen_key_not_facility_id"] = status.site_name.map(normalized_name)
    status["same_normalized_name_ids_pre2022"] = status.name_screen_key_not_facility_id.map(lambda s: "|".join(text_groups[s]))
    status["same_name_other_id_count"] = status.same_normalized_name_ids_pre2022.str.split("|").map(len) - 1
    status["same_name_fixed_source_or_development_collision"] = status.name_screen_key_not_facility_id.map(lambda s: bool(set(text_groups[s]) & set(source_ids + development_ids)))
    status["physical_facility_id"] = "unknown"
    status["treated_effluent_outfall_id"] = "unknown"
    status["tdv_instrument_id"] = "unknown"
    status["verified_independent_target_eligible"] = False
    status["verified_source_group_eligible"] = False
    status["official_physical_crosswalk_available"] = False
    status["facility_evidence_status"] = "Released TDV SiteID/name directly observed; physical identity, instrument and normal treated-effluent outfall unresolved"
    status["geospatial_evidence_status"] = "No candidate-specific verified normal-outfall or plant coordinates in reused 19-query archive; storm-outfall coordinates not substituted"
    status["partition_status"] = "UNASSIGNED; reserve verified independent target groups before source expansion"
    status["model_performance_used"] = False
    status["raw_evidence_url"] = "https://services.arcgis.com/3SZ6e0uCvPROr4mS/arcgis/rest/services/Wessex_Water_Total_Daily_Volume_20162025/FeatureServer/0?f=pjson"
    status["archived_evidence_file"] = str(TDV_SCHEMA.relative_to(ROOT))
    status["reused_query_date"] = "2026-10-11"
    status.to_csv(OUT / "sourcecandidate_grouping_status.csv", index=False)

    all_coverage = original.groupby("site_id").agg(years=("year", "nunique"), minimum=("coverage", "min"))
    eligible_pre = all_coverage.index[(all_coverage.years.eq(6) & all_coverage.minimum.ge(.95))]
    eligible_pre = sorted([str(s) for s in eligible_pre if pre_name_counts.get(str(s)) == 1], key=int)
    unresolved_reservations = "No named independent target reservation registry in the inspected DEVELOPMENT_SELECTION file; protect any existing provider/user reservations before assignment"
    plan = {
        "status": "draft_blocked_by_unverified_physical_mapping; no IDs assigned or newly trained",
        "precedence": ["obtain existing protected-target reservation registry", "verify TDV meter/outfall/physical-facility crosswalk for all linked SiteIDs", "form conservative connected physical groups and protect all source/development relatives", "freeze independent target groups using only pre2022 eligibility and model-use inventory", "select additional source groups from remaining eligible groups"],
        "existing_sources": source_ids,
        "existing_used_development": development_ids,
        "used_development_windows": ["2022-01-01", "2022-07-01", "2023-01-01", "2023-07-01", "2023-10-01"],
        "existing_target_reservation_registry_status": unresolved_reservations,
        "target_assignment_now": [],
        "new_source_assignment_now": [],
        "group_eligibility": {"coverage_period": ["2016-01-01", "2021-12-31"], "each_year_min_good_nonnegative_nonconflict_coverage": .95, "require_units": "m3", "identity": "official dated TDV SiteID-to-instrument/outfall/physical-facility crosswalk, including historical aliases and transfers", "multiple_measurements": "keep all related SiteIDs in one partition; one preregistered target measurement per group unless provider confirms lawful sum; never sum without additivity evidence", "already_used_groups": "exclude three source and ten development facilities and all verified aliases/relatives, including newly merged cross-partition groups", "unknown_physical_identity": "remain UNASSIGNED, cannot certify independent facility holdout"},
        "target_selection_draft": {"activate_only_after": "existing target protections and official physical groups verified before any source expansion or target performance access", "ranking": "SHA256('WessexStage3C-target-v1|' + stable official physical_facility_id), ascending lexicographic; predetermined before target labels/performance", "fraction": .2, "count": "ceil(0.20 * M) verified eligible independent previously unused physical groups; require M >= 20, otherwise pause and revise prospectively", "ensure_group_exclusion": "remove every linked SiteID/permit/instrument from source and tuning pools, including noncandidate siblings", "model_use_check": "configuration/run/log inventory confirms reserved groups did not enter previous shared fitting, tuning or human performance selection; cannot prove off-project unseen history", "future_target_data": "no 2024-2025 performance or reserved-target performance in this stage; subsequent evaluation requires separate frozen protocol"},
        "source_pool_draft": {"activate_only_after": "target-reservation ledger frozen and verified; separate experiment, not combined with new rain features", "order": "SHA256('WessexStage3C-source-v1|' + stable official physical_facility_id), ascending; current 3-source baseline retained only if crosswalk confirms disjointness", "possible_nested_sizes": [3, 10, 30, 60], "insufficient_verified_groups": "do not replace based on performance or choose alternative targets; report unavailable pool size", "source_period": ["2016-01-01", "2021-12-31"], "source_assisted_validation": "LOSO physical groups, pre2021 training for 2021 pseudo-deployments; fixed rule no target-deployment score selection"},
        "no_execution_authorization": "Stage3C.1 feasibility only; proposal does not authorize target final testing or expansion training",
    }
    write_json("target_reservation_and_source_pool_draft.json", plan)
    inputs = [RAW, CANDIDATES, COVERAGE, SELECTION, FIXED_MAPPING, TDV_SCHEMA, OLD / "OFFICIAL_QUERY_INDEX.json", Path(__file__).resolve()]
    counts = {
        "accepted_candidate_siteids": len(status),
        "pre2022_year_rows_rechecked": len(years),
        "pre2022_candidate_raw_records": len(raw),
        "pre2022_candidate_valid_calendar_dates": int(quality.valid_dates.sum()),
        "pre2022_candidate_calendar_missing_dates": int(quality.calendar_missing_dates.sum()),
        "pre2022_quality_eligible_candidates": int(status.quality_eligible_pre2022.sum()),
        "accepted_minimum_annual_coverage": float(status.minimum_year_coverage.min()),
        "rechecked_minimum_annual_coverage": float(status.rechecked_minimum_year_coverage.min()),
        "pre2022_coverage_eligible_all_siteids_with_single_pre2022_name": len(eligible_pre),
        "candidate_name_screen_groups": status.name_screen_key_not_facility_id.nunique(),
        "candidate_same_name_multi_id_links": int(status.same_name_other_id_count.gt(0).sum()),
        "candidate_name_collision_with_fixed_partition": int(status.same_name_fixed_source_or_development_collision.sum()),
        "verified_physical_facility_groups": 0,
        "verified_independent_target_groups_assignable_now": 0,
        "verified_expansion_source_groups_assignable_now": 0,
        "new_target_ids_assigned": 0,
        "new_source_ids_assigned": 0,
        "post2021_rows_used_for_names_quality_or_coverage": 0,
        "forecast_performance_files_read": 0,
        "new_model_fits": 0,
        "raw_quality_counts": {k: int(quality[k].sum()) for k in ["good_zero_retained", "good_negative_excluded", "missing_zero_excluded", "missing_nonzero_excluded", "suspect_excluded", "conflicting_site_days", "duplicate_rows", "non_m3_units", "nonfinite_rows"]},
        "disjoint_exclusion_counts": {str(k): int(v) for k, v in raw.exclusion_reason.value_counts().items()},
    }
    write_json("SOURCE_POOL_AUDIT.json", {"status": "completed_feasibility_only", "executed_utc": datetime.now(timezone.utc).isoformat(), "version": "stage3c1_20261011_v1", "counts": counts, "checks": {"candidate_year_counts_equal_archived_coverage": True, "candidate_coverage_equal_with_atol_1e-12_rtol_0": True, "no_candidate_name_or_volume_filter_uses_post2021_records": True, "no_performance_or_forecasterror_used": True, "physical_identity_not_inferred_from_name": True, "storm_outfall_not_substituted": True}, "inputs": [{"path": str(p.relative_to(ROOT)), "bytes": p.stat().st_size, "sha256": sha256(p)} for p in inputs], "limitations": [unresolved_reservations, "The 19 reused queries establish no independent physical mapping for the 186 candidates; absence of a text collision does not establish disjoint facilities", "Protected future periods were discarded before eligibility calculations; the raw container was scanned for filtering and hashing, not forecast performance"]})
    print(json.dumps(counts, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
