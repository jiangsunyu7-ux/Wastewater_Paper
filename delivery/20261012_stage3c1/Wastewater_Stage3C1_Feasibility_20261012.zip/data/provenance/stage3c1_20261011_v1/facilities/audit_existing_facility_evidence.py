"""Read only saved official evidence; never inspect forecasting errors or fit models."""
from __future__ import annotations

import csv
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[4]
OLD = ROOT / "data/provenance/stage3b_20261011_v1"
NEW = Path(__file__).resolve().parent
REPORT = ROOT / "reports/stage3c1_20261011_v1"
DELIVERY_COPY = NEW / "reused_stage3b_official"


def input_path(name: str):
    original = OLD / name
    return original if original.exists() else DELIVERY_COPY / name


def copy_if_different(source: Path, target: Path):
    if source.resolve() != target.resolve():
        shutil.copyfile(source, target)


def load(name: str):
    return json.loads(input_path(name).read_bytes())


def rows(path: Path):
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, data: list[dict]):
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(data[0]))
        writer.writeheader()
        writer.writerows(data)


def signed_lonlat_centroid(rings):
    # Signed area respects Esri outer/hole orientation. This is a geometric
    # centroid in longitude/latitude coordinates, not a measured plant point.
    cross_sum = x_sum = y_sum = 0.0
    for ring in rings:
        for a, b in zip(ring, ring[1:] + ring[:1]):
            cross = a[0] * b[1] - b[0] * a[1]
            cross_sum += cross
            x_sum += (a[0] + b[0]) * cross
            y_sum += (a[1] + b[1]) * cross
    if abs(cross_sum) < 1e-16:
        raise ValueError("Degenerate polygon; do not invent a centroid")
    return x_sum / (3 * cross_sum), y_sum / (3 * cross_sum)


def epoch_ms_iso(value):
    return datetime.fromtimestamp(value / 1000, timezone.utc).isoformat() if value is not None else "unknown"


def main():
    query_files = [
        "official_metadata_queries.json", "facility_lookup_queries.json",
        "facility_lookup_service_queries.json", "facility_lookup_attribute_queries.json",
        "facility_lookup_further_queries.json", "facility_lookup_location_queries.json",
    ]
    queries = [entry for name in query_files for entry in load(name)]
    delivery_copy = DELIVERY_COPY
    delivery_copy.mkdir(exist_ok=True)
    for name in query_files:
        copy_if_different(input_path(name), delivery_copy / name)
    for name in ("FACILITY_MAPPING.csv", "catchment_name_candidates.csv"):
        copy_if_different(input_path(name), delivery_copy / name)
    query_index = []
    for entry in queries:
        raw_path = input_path(entry["saved_response_file"])
        actual = hashlib.sha256(raw_path.read_bytes()).hexdigest()
        expected = entry["saved_response_sha256"]
        if actual != expected:
            raise ValueError(f"Saved official response differs: {raw_path}")
        copied_path = delivery_copy / raw_path.name
        copy_if_different(raw_path, copied_path)
        assert hashlib.sha256(copied_path.read_bytes()).hexdigest() == expected
        response = json.loads(raw_path.read_bytes())
        query_index.append({
            "query_name": entry["query_name"], "queried_utc": entry["queried_utc"],
            "url": entry["url"], "response_path": str(raw_path.relative_to(ROOT)),
            "delivery_evidence_copy_path": str(copied_path.relative_to(ROOT)),
            "sha256": actual, "sha256_matches_original_receipt": True,
            "success": "error" not in response, "features_returned": len(response.get("features", [])),
            "geometry_records": sum("geometry" in v for v in response.get("features", [])),
            "error": json.dumps(response.get("error", {}), ensure_ascii=False),
        })
    assert len(queries) == 19
    write_csv(NEW / "REUSED_OFFICIAL_QUERY_INDEX.csv", query_index)

    mapping = rows(input_path("FACILITY_MAPPING.csv"))
    assert len(mapping) == 13
    old_catchment_candidates = rows(input_path("catchment_name_candidates.csv"))
    assert len(old_catchment_candidates) == 14
    storm_links = load("official_selected_overflow_link_attributes_response.bin")["features"]
    storm_geo = load("official_related_storm_outfall_location_candidates_response.bin")["features"]
    storm_geo_by_id = {v["attributes"]["Overflow_ID"]: v["geometry"] for v in storm_geo}
    storm_records = []
    for link in storm_links:
        attrs = link["attributes"]
        geom = storm_geo_by_id[attrs["OverflowID"]]
        storm_records.append({
            "site_id": attrs["SiteID"], "overflow_id": attrs["OverflowID"],
            "storm_overflow_longitude": geom["x"], "storm_overflow_latitude": geom["y"],
            "crs": "EPSG:4326", "object_type": "storm_overflow_outfall",
            "usable_as_normal_effluent_location": False,
            "usable_as_plant_site_location": False,
            "usable_as_sewage_catchment": False,
            "evidence": "official overflow_to_outfall SiteID attributes + outfall_location Overflow_ID geometry",
        })
    write_csv(NEW / "storm_overflow_coordinates_DO_NOT_USE_AS_PLANT.csv", storm_records)

    geo_path = NEW / "official_name_candidate_catchment_polygons_response.json"
    geo_data = json.loads(geo_path.read_bytes()) if geo_path.exists() else {}
    candidates_by_id = {v["attributes"]["BoundaryId"]: v for v in geo_data.get("features", [])}
    centroid_rows = []
    statuses = []
    for row in mapping:
        site_id = int(row["site_id"])
        boundary_id = int(row["catchment_boundary_id_candidate"])
        candidate = candidates_by_id.get(boundary_id)
        if candidate:
            assert candidate["attributes"]["BoundryNme"] == row["catchment_name_candidate"]
            lon, lat = signed_lonlat_centroid(candidate["geometry"]["rings"])
            points = [point for ring in candidate["geometry"]["rings"] for point in ring]
            assert min(p[0] for p in points) <= lon <= max(p[0] for p in points)
            assert min(p[1] for p in points) <= lat <= max(p[1] for p in points)
            attrs = candidate["attributes"]
            centroid_rows.append({
                "site_id": site_id, "partition": row["partition"],
                "provider_site_name": row["provider_site_name"],
                "candidate_boundary_id": boundary_id, "candidate_boundary_name": attrs["BoundryNme"],
                "candidate_polygon_centroid_longitude": lon,
                "candidate_polygon_centroid_latitude": lat,
                "crs": "EPSG:4326", "centroid_method": "signed polygon centroid in longitude-latitude plane",
                "spatial_proxy_type": "name_candidate_catchment_polygon_centroid",
                "siteid_to_catchment_verified": False, "plant_site_coordinate_verified": False,
                "normal_effluent_outfall_coordinate_verified": False,
                "boundary_version_from_epoch_ms": attrs.get("VersFrmDte"),
                "boundary_version_to_epoch_ms": attrs.get("VersToDate"),
                "boundary_version_from_utc": epoch_ms_iso(attrs.get("VersFrmDte")),
                "boundary_version_to_utc": epoch_ms_iso(attrs.get("VersToDate")),
                "polygon_validity_during_2022_2023_verified": False,
                "evidence_path": str(geo_path.relative_to(ROOT)),
                "caveat": "Official polygon exists; only name-match to TDV SiteID. Not plant position or verified catchment rainfall.",
            })
        linked = [v for v in storm_records if v["site_id"] == site_id]
        statuses.append({
            "site_id": site_id, "partition": row["partition"],
            "provider_site_name": row["provider_site_name"],
            "siteid_name_evidence": "direct_released_TDV_record",
            "physical_facility_id": "unknown", "physical_facility_verified": False,
            "normal_treated_effluent_outfall_id": "unknown", "normal_outfall_verified": False,
            "plant_site_longitude": "unknown", "plant_site_latitude": "unknown",
            "plant_site_coordinate_verified": False,
            "candidate_catchment_name": row["catchment_name_candidate"],
            "candidate_boundary_id": boundary_id,
            "catchment_evidence_level": "name_candidate_only",
            "siteid_to_catchment_verified": False,
            "candidate_polygon_available": bool(candidate),
            "candidate_polygon_crs": "EPSG:4326" if candidate else "unknown",
            "candidate_polygon_proxy_path": "candidate_catchment_centroids.csv" if candidate else "none",
            "candidate_polygon_version_from_utc": epoch_ms_iso(candidate["attributes"].get("VersFrmDte")) if candidate else "unknown",
            "candidate_polygon_version_to_utc": epoch_ms_iso(candidate["attributes"].get("VersToDate")) if candidate else "unknown",
            "polygon_validity_during_2022_2023_verified": False,
            "normal_outfall_coordinate_verified": False,
            "storm_overflow_ids_direct_links": "|".join(v["overflow_id"] for v in linked) or "none_returned",
            "storm_overflow_coordinate_count": len(linked),
            "tdv_multi_meter_same_physical_facility": "unresolved",
            "same_name_siteids_in_existing_map": row["linked_same_name_ids"],
            "same_name_does_not_prove_facility_independence": True,
            "cross_partition_conflict_directly_proven": False,
            "physical_partition_conflict_ruled_out": False,
            "unresolved": "TDV meter role; plant ID/site location; normal outfall; catchment crosswalk/history; linked TDV meters",
        })
    if centroid_rows:
        write_csv(NEW / "candidate_catchment_centroids.csv", centroid_rows)
    write_csv(REPORT / "facility_mapping_status.csv", statuses)
    write_csv(NEW / "facility_mapping_status.csv", statuses)
    summary = {
        "reused_official_queries": len(queries),
        "saved_response_hashes_verified": len(queries),
        "successful_original_requests": sum(v["success"] for v in query_index),
        "original_arcgis_errors_preserved": sum(not v["success"] for v in query_index),
        "original_all_name_candidates": len(old_catchment_candidates),
        "original_current_source_development_name_candidates": len(mapping),
        "extra_nonselected_candidate": {"BoundaryId": 23032, "BoundryNme": "BRADFORD ON TONE"},
        "direct_verified_physical_facilities": 0,
        "direct_verified_plant_coordinates": 0,
        "direct_verified_normal_effluent_outfalls": 0,
        "direct_verified_TDV_sewage_catchments": 0,
        "storm_links": len(storm_records),
        "storm_linked_site_ids": len(set(v["site_id"] for v in storm_records)),
        "candidate_polygon_centroids": len(centroid_rows),
        "candidate_development_centroids": sum(v["partition"] == "development" for v in centroid_rows),
        "new_query_receipt": "bounded_new_query_receipt.json",
        "uses_forecast_predictions_or_performance": False,
        "contains_verified_cross_facility_external_validation": False,
    }
    (NEW / "FACILITY_AUDIT_SUMMARY.json").write_text(json.dumps(summary, indent=2) + "\n")
    # Small mathematical checks do not manufacture scientific observations.
    rect = [[[0, 0], [2, 0], [2, 2], [0, 2], [0, 0]]]
    assert signed_lonlat_centroid(rect) == (1.0, 1.0)
    reversed_rect = [list(reversed(rect[0]))]
    assert signed_lonlat_centroid(reversed_rect) == (1.0, 1.0)
    geo_receipt = json.loads((NEW / "bounded_new_query_receipt.json").read_text())
    if geo_receipt["success"]:
        assert hashlib.sha256(geo_path.read_bytes()).hexdigest() == geo_receipt["response_sha256"]
        assert len(candidates_by_id) == 13
        assert 23032 not in candidates_by_id
    checks = {
        "status": "passed", "saved_official_response_hashes": 19,
        "delivery_evidence_copies_identical": 19,
        "new_geometry_receipt_hash": "passed",
        "centroid_rectangle_and_reversed_orientation": "passed",
        "all_plant_site_coordinate_verified_false": all(not v["plant_site_coordinate_verified"] for v in statuses),
        "all_normal_outfall_coordinate_verified_false": all(not v["normal_outfall_coordinate_verified"] for v in statuses),
        "all_siteid_to_catchment_verified_false": all(not v["siteid_to_catchment_verified"] for v in statuses),
        "all_historical_2022_2023_polygon_validity_unverified": all(not v["polygon_validity_during_2022_2023_verified"] for v in statuses),
        "no_forecast_performance_input": True,
    }
    (NEW / "FACILITY_CHECKS.json").write_text(json.dumps(checks, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
