from pathlib import Path
import urllib.request, urllib.error, json, hashlib, datetime, argparse
parser=argparse.ArgumentParser(description='Bounded official rainfall metadata fetch; never download full grids.')
parser.add_argument('--output',required=True,help='New output directory; existing query ledger is not overwritten.')
args=parser.parse_args()
ROOT=Path(args.output).resolve()
ROOT.mkdir(parents=True,exist_ok=True)
if (ROOT/'query_log.json').exists():
    raise SystemExit('Refusing to overwrite an existing query ledger; choose a new output directory.')
URLS=[
('ea_reference','https://environment.data.gov.uk/flood-monitoring/doc/reference#rainfall'),
('ea_rainfall_stations','https://environment.data.gov.uk/flood-monitoring/id/stations?parameter=rainfall&_limit=1000'),
('ea_archive_listing','https://environment.data.gov.uk/flood-monitoring/archive'),
('haduk_grid_official','https://www.metoffice.gov.uk/research/climate/maps-and-data/data/haduk-grid/haduk-grid'),
('haduk_grid_format','https://www.metoffice.gov.uk/research/climate/maps-and-data/data/haduk-grid/format'),
('ceh_gear_official','https://www.ceh.ac.uk/data/ceh-gridded-estimates-areal-rainfall-ceh-gear'),
('ea_rainfall_doc','https://environment.data.gov.uk/flood-monitoring/doc/rainfall'),
('ceda_haduk_catalog_search','https://catalogue.ceda.ac.uk/?q=HadUK-Grid'),
('ceh_gear_catalog','https://catalogue.ceh.ac.uk/documents/ee9ab43d-a4fe-4e73-afd5-cd4fc4c82556'),
]
ledger=[]
for name,url in URLS:
    rec={'id':name,'requested_url':url,'queried_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'max_bytes':1048576}
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'Wastewater-research-feasibility-audit/Stage3C1'})
        with urllib.request.urlopen(req,timeout=25) as response:
            data=response.read(1048577)
            rec.update(status=response.status,final_url=response.url,headers=dict(response.headers))
        rec['truncated']=len(data)>1048576
        data=data[:1048576]
        path=ROOT/(name+'.bin');path.write_bytes(data)
        rec.update(file=str(path.relative_to(ROOT)),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
    except Exception as exc:
        rec.update(status='error',error=type(exc).__name__+': '+str(exc))
    ledger.append(rec)
    (ROOT/'query_log.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2))
    print(name,rec['status'],rec.get('bytes'),rec.get('final_url'),flush=True)
