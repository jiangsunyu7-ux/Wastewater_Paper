from pathlib import Path
import pandas as pd,numpy as np,json,hashlib,collections,calendar,argparse
parser=argparse.ArgumentParser(description='Independently recheck archived rainfall and optionally pre2022 candidate-volume QA; never train forecasts.')
parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2])
parser.add_argument('--rain-only',action='store_true',help='Skip raw volume QA when the full raw CSV is not available.')
parser.add_argument('--raw-csv',type=Path,help='Optional path to original SHA-verified raw CSV.')
parser.add_argument('--output',type=Path,help='Optional JSON result path; default prints JSON only.')
args=parser.parse_args();root=args.root.resolve(); ver='stage3c1_20261011_v1'; p=root/'data/provenance'/ver; o=root/'reports'/ver
checks={}; diagnostics={}
r=[]
for fn in sorted((p/'rainfall_samples').glob('readings_gauge_*_20230924_20230930.json')):
 j=json.loads(fn.read_text()); m=json.loads(Path(str(fn)+'.metadata.json').read_text()); assert hashlib.sha256(fn.read_bytes()).hexdigest()==m['sha256']
 for v in j['items']:r.append({'file':fn.name,'t':v['dateTime'],'q':v.get('quality'),'c':v.get('completeness'),'v':v.get('value'), 'measure':v['measure']['@id'].replace('http:','https:')})
x=pd.DataFrame(r);valid=x.q.eq('Good')&x.c.eq('Complete')&np.isfinite(x.v)&x.v.ge(0)
assert len(x)==6048 and valid.sum()==4704 and x.q.value_counts().to_dict()=={'Good':4704,'Suspect':1344}
assert not x.duplicated(['file','t']).any() and not x.t.str.contains('Z|[+]\\d\\d:\\d\\d|[-]\\d\\d:\\d\\d').any()
links=pd.read_csv(p/'rainfall_samples/candidate_spatial_join.csv',dtype={'site_id':str}); x['day']=x.t.str[:10]; x['valid']=valid
lookup=x.groupby(['measure','day']).agg(n=('t','size'),valid=('valid','sum'),total=('v','sum')).reset_index()
j=links.merge(lookup,left_on='measure_url',right_on='measure',how='left'); assert len(j)==70
assert j.valid.sum()==56*96 and j.n.sum()==70*96
assert j.loc[j.valid.lt(96),'site_id'].unique().tolist()==['13022','13025'] or set(j.loc[j.valid.lt(96),'site_id'])=={'13022','13025'}
formal=(~links.model_eligible).all(); assert formal and links.site_id.nunique()==10 and links.measure_url.nunique()==9
saved=pd.read_csv(o/'rainfall_connection/development_candidate_daily_join.csv',dtype={'site_id':str}); s=saved.merge(j[['site_id','day','valid','total']],left_on=['site_id','nominal_stamp_day'],right_on=['site_id','day'],validate='one_to_one')
assert s.valid.eq(s.valid_intervals).all(); good=s.valid.eq(96); assert np.allclose(s.loc[good,'total'],s.loc[good,'qualified_total_mm'],atol=1e-12,rtol=0);assert s.loc[~good,'qualified_total_mm'].isna().all()
checks['raw_rain_download_hashes_counts_and_saved_daily_totals']=True
diagnostics['rain']={'records':len(x),'Good':int(valid.sum()),'Suspect':int(x.q.eq('Suspect').sum()),'unique_series_quality_coverage':valid.mean(),'SiteID_weighted_quality_coverage':j.valid.sum()/j.n.sum(),'formal_links':0,'invalid_sites':sorted(set(j.loc[j.valid.lt(96),'site_id'])),'naive_timestamps':len(x)}
if not args.rain_only:
    raw=args.raw_csv if args.raw_csv is not None else root/'wastewater_data/raw/wessex_all_2016_2025.csv'; assert hashlib.sha256(raw.read_bytes()).hexdigest()=='22f494e2b96fe6fa9550c68971d50c752ddd291793fdc60334d64b2ef089f518'
    ids=set(pd.read_csv(p/'cohorts/sourcecandidate_grouping_status.csv',dtype={'site_id':str}).site_id); pieces=[]
    for c in pd.read_csv(raw,dtype={'SiteID':str},chunksize=100000):
     c=c.loc[c.Date.ge('2016-01-01')&c.Date.le('2021-12-31')]; c=c.loc[c.SiteID.isin(ids)]; pieces.append(c)
    f=pd.concat(pieces,ignore_index=True); assert len(f)==407712
    f['num']=pd.to_numeric(f.TotalVolume,errors='coerce'); f['q']=f.QualityFlag.str.strip().str.lower(); k=['SiteID','Date']; variations=f.drop_duplicates(k+['num','q','Units']);confkeys=set(map(tuple,variations.loc[variations.duplicated(k,keep=False),k].values.tolist()))
    f['conflict']=[tuple(row) in confkeys for row in f[k].values.tolist()];ok=f.q.eq('good')&np.isfinite(f.num)&f.num.ge(0)&f.Units.eq('m3')&~f.conflict
    assert ok.sum()==404492 and len(confkeys)==2 and f.conflict.sum()==4
    qa=collections.Counter()
    for row in f.itertuples():
     reason='conflicting_site_day' if row.conflict else ('Missing_encoded_or_missing_value' if row.q=='missing' else 'Suspect' if row.q=='suspect' else 'Good_negative' if row.q=='good' and row.num<0 else 'retained_Good_nonnegative')
     qa[reason]+=1
    expected={'retained_Good_nonnegative':404492,'Suspect':2496,'Missing_encoded_or_missing_value':671,'Good_negative':49,'conflicting_site_day':4}; assert dict(qa)==expected
    f['valid']=ok; f['yr']=f.Date.str[:4].astype(int); yr=f.groupby(['SiteID','yr']).valid.sum();assert len(yr)==1116
    savedyr=pd.read_csv(p/'cohorts/source_candidate_coverage_pre2022_rechecked.csv',dtype={'site_id':str}); cmp=savedyr.set_index(['site_id','year']).valid_good_nonnegative_nonconflict_dates; assert yr.sort_index().equals(cmp.sort_index().rename('valid'))
    cover=[n/(366 if calendar.isleap(year) else 365) for (sid,year),n in yr.items()];assert min(cover)>=.95
    checks['independent_raw_candidate_186_pre2022_QA_and_year_counts']=True
    diagnostics['cohort']={'raw_rows':len(f),'valid':int(ok.sum()),'conflict_days':len(confkeys),'raw_missing_rows':int(f.q.eq('missing').sum()),'mutually_exclusive_exclusions':{k:v for k,v in qa.items() if k!='retained_Good_nonnegative'},'minimum_annual_coverage':min(cover),'physical_groups_verified':0}
else:
    diagnostics['cohort']={'status':'NOT_RECHECKED_raw_CSV_skipped_by_explicit_rain_only_option'}
poly=json.loads((p/'facilities/official_name_candidate_catchment_polygons_response.json').read_text()); vers=set(v['attributes']['VersFrmDte'] for v in poly['features']);assert len(poly['features'])==13 and vers=={1737936000000}
fac=pd.read_csv(p/'facilities/facility_mapping_status.csv');assert len(fac)==13;cent=pd.read_csv(p/'facilities/candidate_catchment_centroids.csv'); assert len(cent)==13
checks['13_catchment_polygons_2025_not_historical_2022_2023']=True
diagnostics['facility']={'polygons':13,'vers_from_utc':str(pd.Timestamp(1737936000000,unit='ms',tz='UTC')),'geometry_is_not_historical_meter_crosswalk':True}
cfg=json.loads((root/'configs'/ver/'next_experiment_draft.json').read_text()); assert cfg['execute_allowed']==False and cfg['readiness']=='BLOCKED' and all(g['passed']==False for g in cfg['activation_gates'])
assert cfg['all_windows_already_used_development'] and not cfg['additional_october_window_is_unused'] and cfg['explicit_nonexecution'];assert cfg['rain_features']['future_actual_rainfall_allowed']==False
checks['future_draft_all_activation_gates_blocked_not_executed']=True
result={'status':'independent_data_and_code_review_passed_with_qualification','checks':checks,'diagnostics':diagnostics,'recalculation_scope':('raw rainfall samples and candidate 2016-2021 raw volume records' if not args.rain_only else 'raw rainfall samples; volume raw check explicitly skipped')+'; no performance recomputation/training/final-period analysis','independent_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
if args.output is not None:
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
