# Stage 3C.1：降雨资料与信息时点核查

查询日期：2026-10-11（北京时间）；交付复核：2026-10-12。本报告的EA查询主要针对 **Flood Monitoring API**。另一个 **Hydrology API 2.1.1** 已在本轮实际返回2023年的Qualified历史雨量；详见[独立连接补充](RAINFALL_CONNECTION.md)。两个服务的历史查询限制和坐标政策不能混用。本报告只核查数据可获得性，**没有训练任何模型或计算新预测性能**。Stage3B追加的2023年10月窗口已属于使用过的开发历史；没有启用2024—2025年性能或预留设施。

当前结论是：EA雨量元数据与时间字段可以读取，公开网页也给出关键传输与归档延迟；但本轮尚不能证明2022—2023年每条雨量在原预测起点已经发布，更不能证明测点所在污水集水区。因此只能建立有明确限制的回顾性连接，实时部署和集水区平均降雨主张不成立。具体开发期数值样本和连接覆盖率由本轮独立连接核查文件提供，不能用当前站点快照数量代替历史覆盖率。

## 已实际核实的官方资料

| 数据 | 已核实内容 | 仍未知内容 |
|---|---|---|
| [EA Rainfall API](https://environment.data.gov.uk/flood-monitoring/doc/rainfall) | 翻斗式雨量计，15分钟累计，单位mm；遥测通常每天传输1—2次；API每15分钟更新不等于每站及时更新；OGL v3.0 | 每条值首次公开时间、历史修订、累计区间端点语义、对应雨量日边界 |
| [EA雨量站元数据快照](https://environment.data.gov.uk/flood-monitoring/id/stations?parameter=rainfall&_limit=1000) | 当前响应API版本0.9；991个有雨量系列的不同stationReference，1000个测量系列；其中3系列缺坐标。经纬度和英国国家格网字段可读 | 当前站点元数据不证明2022—2023年连续运营；限定返回条数，不声称全国完整枚举 |
| [EA archive说明](https://environment.data.gov.uk/flood-monitoring/archive) | 每日CSV档案为逐条观测；官方明确当天档案直到次日22:00才生成，以纳入迟到遥测；少数遥测可能延迟数日 | 22:00所属时区、历史特定文件首次发布、后续修订版本、逐值接收时点 |
| [Met Office HadUK-Grid](https://www.metoffice.gov.uk/research/climate/maps-and-data/data/haduk-grid/haduk-grid)与[格式页](https://www.metoffice.gov.uk/research/climate/maps-and-data/data/haduk-grid/format) | 本轮两请求均网络隧道403，已保留失败记录 | 许可、具体版本、2022—2023覆盖、分辨率、日界线、time bounds、发布时间均未核实 |
| [UKCEH GEAR候选页](https://www.ceh.ac.uk/data/ceh-gridded-estimates-areal-rainfall-ceh-gear)与[官方目录候选条目](https://catalogue.ceh.ac.uk/documents/ee9ab43d-a4fe-4e73-afd5-cd4fc4c82556) | 两请求均网络隧道403；未下载网格文件 | 未确认候选地址内容、版本及2022—2023覆盖，不据产品名补全元数据 |

本代理9次小型请求：4成功、5访问失败。每个响应最多1 MiB；未下载大网格或无关全量文件。原始响应、请求时间、HTTP头、SHA256及失败原因位于`data/provenance/stage3c1_20261011_v1/rainfall_catalog/query_log.json`。HTTP `Last-Modified`在2026年的当前服务快照上出现，**它不是2022—2023年首次发布时间证明**。许可来自EA文档及JSON `meta.licence`，而非本项目推断。声明使用EA数据应附：`this uses Environment Agency rainfall data from the real-time data API (Beta)`。

## 三类信息必须区分

1. **起点前已发布历史观测**：除测量时间外，应存在当时的接收／发布记录；先确认累计结束时刻不晚于起点，再确认值的实际公开时间不晚于起点。EA `dateTime`只表明观测适用时点，不能替代发布时间。API更新频率也不能替代该证明。
2. **历史天气预报**：需要可核查的issue time、valid time、累计起止、版本和下载来源。本轮没有取得符合此条件的定量降雨预报归档。EA五日洪水风险预报不是降雨数值预报，不能替代。未来真实雨量绝不能伪装成预报输入。
3. **事后档案、质控、插值或再分析**：当前下载的历史档案、未来若取得的插值网格，只能标为回顾性情景，除非额外找到当时的版本与发布证据。不能因为原始观测仪器实时工作而将多年后取得的最终档案自动判为实时可得。

## 字段与连接规则

- 使用`measure` URI识别测量系列，再连接`stationReference`；仅接受`parameter=rainfall`、`unitName=mm`、`period=900`且累计量语义适配的系列。真正0雨量保留；NaN、缺行、被省略的JSON `value`均为缺测，不能填0。
- 保存ISO8601时区；文档示例带`Z`，可按UTC表示解释，尚未确认提供方每日雨量统计的日界线。不要无证据假设网格日雨量都是00:00—24:00，也不要假设09:00—09:00。本轮没有宣称其中任何日界线已经核实。
- 15分钟量聚合为24小时候选输入前，需核对96个完整、唯一、连续区间及累计端点含义；不足96区间不当作真实完整日总量。允许把覆盖率作为特征／缺测标记，但具体缺测处理须事前冻结，不能看成绩再定。
- 如果`dateTime`到底代表累计开始还是结束尚不清楚，连接检查应先标未解决；可用`dateTime+15min`作为检查用保守结束上界，**这只是假设，不是提供方已证实语义**。不能据此跳过发布时间核验。
- 任何h=1/h=3输入只能来自共同的origin截止前，不能读取origin+h实际雨量。原体积每日标签的日界线与日终可得时点也尚未核实，整轮只能保持回顾性假设。
- Flood Monitoring雨量页面对保护信息的说明明确：该服务雨量站匿名且坐标减精到100m格。这不自动证明Hydrology具名坐标遵循同一减精规则。最近雨量计距离只是空间代理；EA `catchmentName`通常不能自动等同污水集水区。厂址坐标未确认时不能利用暴雨溢流排口坐标冒充正常出水测点，不能输出伪精确厂址匹配。
- 网格资料若将来可访问，必须保存原始坐标参考系、格点中心、边界、`time`/`time_bnds`、`calendar`、`units`、`cell_methods`和版本。仅在厂址有证据时可以称“厂址网格代理”；集水区平均降雨需要污水集水区边界证据。

## 有限查询停止与需要提供方回答的问题

本轮不再反复访问失败域名，也不发送邮件。Flood Monitoring雨量说明指出：该服务整站完整历史、或者超过12个月的数据，需要通过`enquiries@environment-agency.gov.uk`申请离线供给。**不能据此断言所有EA历史雨量都必须离线申请**：本轮Hydrology历史查询已成功取得2023年小样本，但完整源期/开发期覆盖仍未核实。

建议向Guna／提供方一次性核实：

1. 能否提供对应雨量计在2016—2023的稳定series ID、启停／迁移／更换记录，以及可复现的历史雨量文件和许可？
2. 15分钟`dateTime`是区间开始还是结束？累计起止是否UTC？每日归档`22:00`是什么时区，旧归档日以哪个时区划分？
3. 是否保留每条遥测接收／首次公开时间、质量标记发布时间和历史修订版本？若无，能否只将最终档案定位为回顾性观测？
4. SiteID到物理处理设施、正常处理后排口、厂址坐标、污水集水区及同厂多测点是否有正式映射？雨量站的河流集水区字段是否与污水汇水区域无关？
5. 每日处理后体积的统计区间、时区、发布延迟及质量标记修订流程是什么？不确认这些信息时，可否仅使用明示日终信息假设的回顾性分析？

当前可继续的边界是“使用最终发布观测和显式时间限制的SiteID回顾性探索”，不是实时应用验证、集水区平均雨量验证或独立物理水厂泛化。数值连接成功也不能消除这三项限制。下一轮只应冻结一种改变；不同时加降雨和扩源。

## 本轮证据与重建

`RAINFALL_SOURCE_CATALOG.csv`列出五类候选及所有未知元数据，`OFFICIAL_FACT_EXCERPTS.json`保存逐字引文、链接和响应SHA，`ea_rainfall_stations.csv`为字段连接用当前快照。运行下列命令只从已经保存的响应重建目录，不联网、不过模型：

```bash
.venv-stage2/bin/python data/provenance/stage3c1_20261011_v1/rainfall_catalog/build_catalog.py
```

若未来获准重查，`fetch_metadata.py --output <新目录>`限定为同九个小请求，并拒绝覆盖现有query ledger；不自动恢复本轮已失败的请求或下载全量数据。
