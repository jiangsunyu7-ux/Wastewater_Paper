# Stage 3C.1 设施与空间证据核查

核查日期：2026-10-11（北京时间）；本节只审查官方元数据和静态空间资料，没有读取预测误差或训练新模型。原 Stage3B 文件不改写。

当前可支持**名称候选的空间连接演示**，不能支持经核实的厂址降雨、真实污水集水区平均降雨或独立物理设施外部验证。13个既有源/开发 SiteID 的名称在发布 TDV 记录中有直接证据；物理设施ID、正常处理后排口、TDV测点坐标、同厂多TDV测点关系均未解决。

## 已有19次官方查询的复核

复用 Stage3B 全部19个查询记录及对应原始响应；19个保存响应的 SHA256 均与原回执一致，其中17个有效JSON成功，2个原请求因错误 layerId=0 返回 ArcGIS400。这两个失败保留；旧轮次已通过实际 layerId=1/2 查到溢流点/连接线，未在本轮重复查询。逐条网址、查询时间、文件路径、校验值和实际geometry条数见 `data/provenance/stage3c1_20261011_v1/facilities/REUSED_OFFICIAL_QUERY_INDEX.csv`。

| 证据对象 | 直接证据 | 不支持的推断 |
|---|---|---|
| TDV Table | 字段 SiteID/SiteName/Date/TotalVolume/Units/QualityFlag；type=Table，无geometry、relationships为空 | 没有厂址、正常排口、集水区或设施ID外键；不能由SiteID唯一性推断物理独立 |
| Sewer Catchment Boundaries | 官方多边形图层，原schema坐标系EPSG:27700，字段BoundaryId/BoundryNme/BndryType/版本日期 | 原属性查询全部returnGeometry=false；服务总extent不是任何单厂坐标；无TDV跨表关系 |
| overflow_to_outfall | 13条SiteID→OverflowID直接属性关联，涉及12个SiteID；13028关联13028B和13028S；13012未返回 | 两个OverflowID不等于两个TDV测点；不存在可推断的正常出水排口关联 |
| outfall_location | 13个Overflow_ID点坐标，查询输出EPSG:4326 | 暴雨溢流点不得充当厂址、正常处理后排口或集水区 |
| EDM2020–2023 | 官方说明SiteId表示Unique Identity of the Storm Overflow，OutfallLatitude/Longitude属于该溢流排口；原选定SiteId查询返回0条 | 不能将EDM坐标直接移植到同数字的TDV SiteID；0条不是不存在设施的证明 |

官方 TDV 说明直接定义 WRC/WTC 的 TDV 为 permitted outfall 向环境排放的出水体积，SPS则是前送WRC体积。因此保留目前WRC子集的 treated effluent volume 研究定位，但“某个SiteID具体对应哪个允许排口/哪台计量装置”仍需跨表证据。说明载有日历日/15分钟采样及每年4月1日前更新安排；它没有证明日终体积或最终QA标记在当时预测时点已发布。MCERTS说明也不能替代具体测点的认证状态和实时可用性证明。

旧 `catchment_name_candidates.csv` 实际含14个名称候选：当前13个Source/Development对应名称，以及非本轮站点 BRADFORD ON TONE（23032）。旧JSON写13不能当作全部CSV计数。本轮按已保存名称表固定13个BoundaryId，排除23032；**130xx→230xx不是已证明的设施/集水区编码换算规则**。

## 一次有界新查询：只补全名称候选多边形

为验证实际空间连接字段，仅追加一次官方查询：固定 BoundaryId `{23006,23008,23012,23013,23015,23016,23017,23022,23024,23025,23028,23029,23031}`，返回名称/类型/提供方/版本字段及多边形，outSR=4326。不扩大候选集合，不查询任何预测成绩。

请求成功，返回13个多边形、60,631字节。原响应 `facilities/official_name_candidate_catchment_polygons_response.json` 的 SHA256 为 `95dc2b0cac74dc8b9cbf997c56695b9525644aba9f80dc575028f505ad10ea39`；完整URL、UTC查询时刻、参数与状态见 `facilities/bounded_new_query_receipt.json`。Wessex该图层的官方许可为CC BY4.0（旧保存item说明）。

输出 `facilities/candidate_catchment_centroids.csv` 保留全部13行及原名/BoundaryId/空间来源。经度纬度质心按有符号多边形面积公式在经纬度平面计算，仅为可复查空间代理；不代表计量位置，不是降雨面积加权平均，也不保证质心位于每个不规则多边形内。10个开发SiteID均有这类名称候选代理，正式厂址/集水区连接的核实覆盖率仍为0/10。

13个多边形的字段均为 `VersFrmDte=2025-01-27T00:00:00Z`、`VersToDate=2025-11-10T00:00:00Z`。字段的版本语义及2022–2023边界历史尚未确认，故**2025快照名称候选的降雨连接演示不能冒充2022–2023真实集水区平均降雨**。这些2025字段是静态元数据，不涉及2024–2025体积预测性能。任何下一轮只可先明确标注回顾性空间代理情景，或等待历史跨表映射。

## 当前13个SiteID的映射状态

完整机器可读表：`reports/stage3c1_20261011_v1/facility_mapping_status.csv`，并在 `data/provenance/stage3c1_20261011_v1/facilities/` 保存副本。以下每行的厂址、正常排口、真实污水集水区和同厂多TDV关系均为 **unknown / unverified**。

| SiteID | 分区 | TDV发布名称简写 | 集水区名称候选/BoundaryId | 直接关联的暴雨溢流ID |
|---|---|---|---|---|
|13006|source|Almondsbury|ALMONDSBURY /23006|13006S|
|13008|source|Amesbury|AMESBURY /23008|13008S|
|13012|source|Aust|AUST /23012|未返回|
|13013|development|Avonmouth (Bristol)|AVONMOUTH /23013|13013S|
|13015|development|Barford St Martin|BARFORD ST MARTIN /23015|13015S|
|13016|development|Bath (Saltford)|SALTFORD /23016|13016S|
|13017|development|Beckington|BECKINGTON /23017|13017S|
|13022|development|Bishops Lydeard|BISHOPS LYDEARD /23022|13022S|
|13024|development|Blackheath|BLACKHEATH /23024|13024S|
|13025|development|Blagdon|BLAGDON /23025|13025S|
|13028|development|Bowerhill|BOWERHILL /23028|13028B、13028S|
|13029|development|Box|BOX /23029|13029S|
|13031|development|Bradford on Avon|BRADFORD ON AVON /23031|13031S|

现有映射的linked_same_name_ids在13行各只列自身；这只说明旧表未发现同名重复ID，不排除更名、多个排口/仪表、同厂不同名称或污水转输关系。当前没有直接证明的source–target物理冲突，**也没有证据排除冲突**。不能将unknown改成confirmed。后续保留独立目标设施必须先取得稳定设施分组，并把同设施全部测点放在同一分区；如暂时无官方分组，候选可按名称保守锁定为未知组并隔离，但不能称物理外部验证。

## 应向Guna或数据提供方提出的问题

没有自动发送任何消息。建议一次请求下列可表格化答复，避免继续重复公共端点检索：

1. 请提供这13个SiteID及后续候选的稳定physical_facility_id、历史名称/别名、同厂全部TDV SiteID与生效日期；哪些记录为同一仪表/排口的替换、更名或重复？
2. 各TDV测点的计量角色是什么：最终处理出水、多个允许排口之和、某单排口、旁通或转输？请给正常排口permit_reference/outfall_id，不使用Overflow_ID替代。
3. 请提供厂址、实际计量点及正常排口坐标，注明坐标系、对象类型、精度及迁移/改造历史；这三种坐标不能混填。
4. 各SiteID对应哪些Sewage Catchment BoundaryId？请给2022–2023有效多边形版本和跨表键；名称候选是否正确，特别是AVONMOUTH↔AVONMOUTH (BRISTOL)、SALTFORD↔BATH (SALTFORD)？2025两个版本日期字段具体含义是什么？
5. 哪些设施存在污水转输、共用上游管网、共用计量或一厂多排口？独立目标设施划分应该排除或合并哪些关联组？13028B/13028S是溢流对象，是否另有TDV仪表关系？
6. TDV日历日的起止时刻、时区及夏令时规则是什么？Date代表累计开始还是结束日期？请确认公开说明中86,000秒的文字是否为86,400秒的排版问题，不据此自行重算原值。
7. 日终预测时何时能读取当天15分钟累计或TDV？Good/Suspect/Missing何时首次发布，手动质控何时可能修订？能否提供2022–2023的as-of发布时间/修订历史或保守稳定延迟？年度公开下载时间不能证明次日可用。
8. 对上述站点，Good零值、Good负值及Missing非零值有哪些已知编码或仪表例外？具体MCERTS认证/未认证期间和不可比计量过程是什么？此问题不授权修改已保存清理/结果。

在答复前，可继续的边界是**发布后QA筛选的SiteID回顾性研究、明确标注2025名称候选空间代理、迟滞降雨事后资料的情景检查**；不能声称厂级独立泛化、集水区雨量机制解释或真实实时部署验证。下一轮具体是否可执行须由总体降雨来源/发布时间审查共同决定，本节没有运行扩源、天气消融或最终测试。

## 主要官方证据链接

- [Wessex TDV官方item及数据说明](https://www.arcgis.com/sharing/rest/content/items/10b910ef3524448e9a5c8691f802dcd2?f=json)
- [TDV表schema](https://services.arcgis.com/3SZ6e0uCvPROr4mS/arcgis/rest/services/Wessex_Water_Total_Daily_Volume_20162025/FeatureServer/0?f=pjson)
- [污水集水区官方item](https://www.arcgis.com/sharing/rest/content/items/3e3eca4ed2904fb0bea32a1fdd06a613?f=json)
- [污水集水区schema](https://services.arcgis.com/3SZ6e0uCvPROr4mS/arcgis/rest/services/Wessex_Water_Sewer_Catchment_Boundaries_view/FeatureServer/0?f=pjson)
- [Overflow_ID点schema](https://services.arcgis.com/3SZ6e0uCvPROr4mS/arcgis/rest/services/outfall_location/FeatureServer/1?f=pjson)
- [SiteID→OverflowID线schema](https://services.arcgis.com/3SZ6e0uCvPROr4mS/arcgis/rest/services/overflow_to_outfall/FeatureServer/2?f=pjson)
- [EDM2020–2023官方说明](https://www.arcgis.com/sharing/rest/content/items/4fca49fcd50e44928c23f8400f6e6322?f=json)

复核命令（只读取保存证据、写新Stage3C.1输出）：

```bash
python data/provenance/stage3c1_20261011_v1/facilities/audit_existing_facility_evidence.py
```

逐查询原响应可从 `REUSED_OFFICIAL_QUERY_INDEX.csv` 中的 `response_path` 定位；新查询有独立回执。原科学输出不在本核查脚本的输入集合中。
