# Stage3C.1 evidence checks and reproduction

本包是工程信息与数据连接的可行性审查包，不是新的预测实验。原Stage3B全部结果保持不变；下一轮降雨消融配置为不可执行草案。先将ZIP解压到**新的空目录**，不要覆盖旧项目。所有下列证据检查只读取已保存官方响应，不联网、不训练Ridge或GRU、不计算2024—2025预测性能。

## 文件完整性

解压后先在包根目录执行：

```bash
sha256sum -c SHA256SUMS
```

`MANIFEST.json`逐个登记科学证据、代码、说明与配置的大小和SHA256；`SHA256SUMS`校验全部载荷和MANIFEST。外层`PACKAGE_CHECKS.json`登记ZIP的大小、SHA256、CRC检查、每一ZIP成员的SHA256及本机干净解压复核。SHA清单不可能包含自身散列，自身完整性由外层ZIP SHA及成员校验记录保护。

## 现有环境的最小检查

在完整项目已有环境中：

```bash
.venv-stage2/bin/python -m unittest discover -s tests -p test_stage3c1.py -v
.venv-stage2/bin/python scripts/stage3c1_rainfall_check.py --root . --output verification/stage3c1_rainfall
```

在新的解压目录中，已有可用Python只需安装两个记录依赖；下面创建的是单独环境。下载Python依赖需要网络，而后续证据检查可以离线执行：

```bash
python3 -m venv .venv-stage3c1
.venv-stage3c1/bin/python -m pip install -r requirements-stage3c1.txt
.venv-stage3c1/bin/python -m unittest discover -s tests -p test_stage3c1.py -v
.venv-stage3c1/bin/python scripts/stage3c1_rainfall_check.py --root . --output verification/stage3c1_rainfall
```

检查应有6项软件测试通过。真实雨量样本重算应得到9个雨量系列、6048条记录、4704条Good/Complete有效记录、1344条Suspect、10个开发SiteID对应70个名义时钟日及56个完整Good日。13022和13025的两系列整段Suspect保留，日值为缺失。形式上已证实的空间连接数和可部署连接数均为0。120条字段/时间连接检查只是在明确UTC/London及累计区间起止假设下通过，不等同于官方日界线、历史发布时间或设施映射获证实。

与保存结果核对：

```bash
.venv-stage3c1/bin/python - <<'PY'
import json
from pathlib import Path
import pandas as pd
saved = Path('reports/stage3c1_20261011_v1/rainfall_connection')
rebuilt = Path('verification/stage3c1_rainfall')
assert json.loads((saved/'CONNECTION_CHECK.json').read_text()) == json.loads((rebuilt/'CONNECTION_CHECK.json').read_text())
for source in sorted(saved.glob('*.csv*')):
    pd.testing.assert_frame_equal(pd.read_csv(source), pd.read_csv(rebuilt/source.name), check_exact=True)
print('Saved rainfall summary and all six CSV tables exactly reproduced')
PY
```

浮点结果的CSV序列化、软件版本变化可能影响文本逐位一致。交付时使用上述固定版本，已执行完全相同的干净解压检查；其他环境如有差异应记录版本和容差，不写成逐位一致。

另外，包内提供与主连接脚本分别实现的原始样本重审。小包可离线执行以下命令（明确跳过依赖外部CSV的186站体积审计）：

```bash
.venv-stage3c1/bin/python reports/stage3c1_20261011_v1/independent_raw_recheck.py --root . --rain-only --output verification/independent_rain_recheck.json
```

它独立核对实际JSON的SHA、QA计数、70条SiteID日连接及候选多边形版本。日总量核对使用预明示`atol=1e-12, rtol=0`，不能把该部分描述为浮点逐位一致。`--rain-only`输出应明确体积原始重审未执行；它不是新的预测实验，也不是外部实验室独立复现。

## 设施证据的离线重审

设施审查脚本使用包内19份原官方响应及本次13个候选多边形，自包含，不需要原Stage3B的所有结果。该脚本会重写其输出表，故建议在ZIP的另一份**临时副本**中运行，保留原交付证据：

```bash
.venv-stage3c1/bin/python data/provenance/stage3c1_20261011_v1/facilities/audit_existing_facility_evidence.py
```

应得到19个原响应SHA检查、17次原成功/2次原错误、13个名称候选多边形、0个已核实物理设施/正常出水排口/TDV集水区关系。官方多边形版本始于2025-01-27，不能视为2022—2023的历史关系证据。暴雨溢流坐标独立保存并明确禁止替代正常处理后排口、厂址或污水集水区。

## 186候选源站点的完整原始数据重审

包中含运行代码、186站覆盖/质量审查表及全部必要的小型输入，但未重复附入73,570,225字节全量原始CSV。不能仅凭本包宣称完整重建此原始审计。

外部必要输入：

- 路径：`wastewater_data/raw/wessex_all_2016_2025.csv`
- SHA256：`22f494e2b96fe6fa9550c68971d50c752ddd291793fdc60334d64b2ef089f518`
- 获取：用户原上传`Wastewater_Part1_Plan_and_Raw.zip`中的同名原文件，或项目已有只读副本。官方TDV元数据网址已随证据保留，但当前实时重新下载可能不是同一文件版本，须核对SHA，不得替代后声称逐位复现。

在另一份临时解压副本中放入此**同SHA**原始文件后执行：

```bash
.venv-stage3c1/bin/python data/provenance/stage3c1_20261011_v1/cohorts/audit_source_candidates.py
.venv-stage3c1/bin/python reports/stage3c1_20261011_v1/independent_raw_recheck.py --root . --raw-csv wastewater_data/raw/wessex_all_2016_2025.csv --output verification/independent_full_recheck.json
```

代码在任何名称、体积和质量计算前过滤到2016—2021。应重算407712原始行、404492有效Good非负非冲突站日；互斥排除为Missing 671、Suspect 2496、Good负值49及冲突4行。Missing原始总673行含冲突中的2行，不能相加重复计数。所有186站逐年覆盖率≥95%，但物理设施分组和独立目标组均未核实，不能因此称186座独立水厂。

## 原结果保护及本包未包含内容

`scripts/stage3c1_finalize_audit.py`需完整原项目及其2724个Stage3B受保护文件，不能在本小包中独立重算旧文件保护检查。包内保留实际逐SHA保护检查报告及摘要；要再次执行该脚本，使用原完整checkout。原Stage3B预测、权重、图件和既有大型交付不在本可行性ZIP中重复附入，仍保留原路径和原交付。未提供真实历史天气预报、逐雨量值首次发布日志、已核实设施/正常出水排口坐标或历史集水区crosswalk；这些缺口有明确记录，不能使用名称或暴雨排口自行补全。

`scripts/stage3c1_fetch.py`是有限下载工具，普通证据复核无需运行；`next_experiment_draft.json`的`execute_allowed=false`。完成上述核验后停止，本包没有启动下一轮消融、扩源训练、独立最终测试、预测区间、论文或App的命令。
