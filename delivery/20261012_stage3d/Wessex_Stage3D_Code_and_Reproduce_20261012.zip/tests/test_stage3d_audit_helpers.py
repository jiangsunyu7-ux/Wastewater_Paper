"""Regression checks for failures encountered in the real independent audit."""
from pathlib import Path
import importlib.util
import unittest
import numpy as np
import pandas as pd

spec=importlib.util.spec_from_file_location('d_audit_helpers',Path(__file__).resolve().parents[1]/'scripts/check_stage3d_results.py')
audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)


class AuditHelperTests(unittest.TestCase):
    def test_numpy_task_scalars_have_native_fingerprint(self):
        native={'task':('13013','2022-01-01',30,3),'signature':'unchanged'}
        grouped={'task':('13013','2022-01-01',np.int64(30),np.int64(3)),'signature':'unchanged'}
        self.assertEqual(audit.hash_value(native),audit.hash_value(grouped))

    def test_boolean_float_metric_frame_keeps_exact_mask_checks(self):
        a=pd.DataFrame({'width':[1.,2.],'covered':[True,False]})
        b=pd.DataFrame({'width':[1.,2.],'covered':[True,False]})
        audit.close(a,b,atol=0,rtol=0)
        b.loc[1,'covered']=True
        with self.assertRaises(AssertionError):audit.close(a,b,atol=0,rtol=0)


if __name__=='__main__':unittest.main()
