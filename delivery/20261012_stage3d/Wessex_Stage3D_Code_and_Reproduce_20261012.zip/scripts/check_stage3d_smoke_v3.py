"""Independently check all twelve fixed two-SiteID interval smoke conditions."""
from pathlib import Path
import argparse
import importlib.util
import json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
VERSION='stage3d_interval_v1'


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=ROOT);a=ap.parse_args();root=a.root
    spec=importlib.util.spec_from_file_location('independent_interval_audit',root/'scripts/check_stage3d_results.py')
    independent=importlib.util.module_from_spec(spec);spec.loader.exec_module(independent)
    cfg=json.loads((root/f'configs/{VERSION}/full.json').read_text())
    freeze=json.loads((root/cfg['frozen_manifest']).read_text())
    for name,expected in freeze['files_sha256'].items():assert independent.digest(root/name)==expected,name
    signature=independent.hash_value(dict(files=freeze['files_sha256'],numpy=np.__version__,pandas=pd.__version__))
    manifest=json.loads((root/f'runs/{VERSION}/smoke/manifest.json').read_text())
    assert manifest['status']=='COMPLETED' and manifest['completed_conditions']==12
    assert manifest['signature']==signature and manifest['expected_prediction_rows']==12960
    path=root/f'runs/{VERSION}/smoke/predictions_all.csv.gz'
    assert independent.digest(path)==manifest['predictions_sha256']
    p=independent.read_csv(path);assert len(p)==12960
    assert set(p.site_id)=={'13013','13015'} and set(p.episode)=={'2022-01-01'}
    series=independent.load_series(root,cfg);examples=[];scores_checked=0;endpoints=0;latest=[]
    libraries={}
    for pool in cfg['pools']:
        library=independent.read_csv(root/cfg['source_output']/pool['pool_id']/'source_errors_final.csv.gz')
        for horizon in cfg['horizons']:
            chunks=[library[library.horizon.eq(horizon)&library.site_id.eq(site_)].score.to_numpy(float) for site_ in pool['site_ids']]
            libraries[pool['pool_id'],horizon]=(np.concatenate(chunks),np.concatenate([np.full(len(v),1/(len(chunks)*len(v))) for v in chunks]))
    for (site,first,b,h),q in p.groupby(['site_id','episode','budget','horizon']):
        left=pd.Timestamp(first)-pd.Timedelta(days=b);end=pd.Timestamp(first)-pd.Timedelta(days=1)
        cal=independent.allowed_errors(series[site],left,end,h)
        assert len(cal['values'])>=14 and np.isfinite(cal['scale'])
        origins=pd.date_range(first,periods=60)
        centers,inputs=independent.persistence(series[site],origins,left)
        assert cal['targets'].max()<=end and cal['origins'].min()>=left and cal['latest_inputs'].min()>=left
        for (pool,method,c),rows in q.groupby(['pool_id','method','nominal_coverage']):
            rows=rows.sort_values('origin')
            values,weights=libraries[pool,h]
            gamma=float(rows.gamma.iloc[0])
            qhat=independent.mixture_quantile(cal['values'],values,weights,gamma,c)
            radius=cal['scale']*qhat
            independent.close(rows.persistence_m3,centers)
            independent.close(rows.lower_m3,centers-radius);independent.close(rows.upper_m3,centers+radius)
            independent.close(rows.scale_m3,cal['scale']);assert rows.calibration_samples.eq(len(cal['values'])).all()
            if pool==cfg['primary_pool_id'] and b==30 and c==.9:
                examples.append(rows.head(3))
            scores_checked+=len(rows)
        nested=q.pivot(index=['origin','pool_id','method'],columns='nominal_coverage',values=['lower_m3','upper_m3'])
        assert not (nested.lower_m3[.8]<nested.lower_m3[.9]).any()
        assert not (nested.upper_m3[.8]>nested.upper_m3[.9]).any()
        for g,method in [(0,'LOCAL'),(1,'SHARED')]:
            m=q[q.method.eq('MIXTURE')&q.gamma.eq(g)]
            z=m.merge(q[q.method.eq(method)],on=['origin','pool_id','nominal_coverage'],suffixes=('','_ref'))
            for col in ['lower_m3','upper_m3']:assert np.array_equal(z[col],z[col+'_ref'],equal_nan=True)
            endpoints+=len(z)
        folder=root/f'runs/{VERSION}/smoke/jobs/{site}_{first}_B{b}_H{h}'
        state=independent.read_json(folder/'status.json')
        assert state['status']=='COMPLETED' and state['prediction_rows']==1080
        independent.hash_artifacts(folder,state,['intervals.csv','calibration.csv','diagnostics.json'])
        latest.append(dict(site_id=site,budget=int(b),horizon=int(h),calibration_samples=len(cal['values']),
                          latest_target=str(cal['targets'].max().date()),latest_input=str(cal['latest_inputs'].max().date())))
    report=root/f'reports/{VERSION}'
    pd.concat(examples,ignore_index=True).to_csv(report/'SMOKE_MANUAL_RECORDS.csv',index=False)
    result=dict(status='PASSED',signature=signature,conditions=12,interval_rows_checked=scores_checked,
        source_bank_count=3,nested_80_90_pairs=6480,gamma_endpoint_rows_checked=endpoints,
        calendar_bounds_checked=latest,original_sites=['13013','13015'],fixed_first_window='2022-01-01',
        smoke_predictions_sha256=independent.digest(path),checker_sha256=independent.digest(__file__),
        numerical_tolerance_not_bitwise_claim=True,real_data=True)
    (report/'SMOKE_CHECK.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
