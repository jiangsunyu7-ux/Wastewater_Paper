#!/usr/bin/env python3
"""Render Stage3D empirical intervals from saved, verified results only.

This script does not fit, choose gamma, rank sites, select examples, or read
2024--2025 values. All time-series examples are fixed before evaluation: the
first window, B30, both horizons, all ten original development SiteIDs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import xml.etree.ElementTree as ET

os.environ.setdefault("MPLCONFIGDIR", "/tmp/wastewater-stage3d-matplotlib")
os.environ.setdefault("XDG_CACHE_HOME", "/tmp/wastewater-stage3d-fontconfig")
Path(os.environ["XDG_CACHE_HOME"]).mkdir(parents=True, exist_ok=True)
import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
VERSION = "stage3d_interval_v1"
SITES = ["13013", "13015", "13016", "13017", "13022", "13024", "13025", "13028", "13029", "13031"]
WINDOWS = ["2022-01-01", "2022-07-01", "2023-01-01", "2023-07-01", "2023-10-01"]
ORDERS = ["20261012", "20261013", "20261014"]
BUDGETS = [30, 90, 180]
HORIZONS = [1, 3]
METHODS = ["LOCAL", "SHARED", "MIXTURE"]
COLORS = {"LOCAL": "#666666", "SHARED": "#009E73", "MIXTURE": "#0072B2"}
ORDER_COLORS = {"20261012": "#0072B2", "20261013": "#D55E00", "20261014": "#009E73"}
NOTE = "Reused development windows; retrospective quality flags; unverified physical-facility mapping."


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1048576), b""):
            h.update(chunk)
    return h.hexdigest()


def read_table(path):
    return pd.read_csv(path, dtype={"site_id": str, "order_label": str, "pool_id": str}, low_memory=False)


def display_schema(frame, table):
    """Explicit saved-unit field renames for plotting, without recomputation."""
    if table == "summary.csv":
        frame = frame.rename(columns={"equal_station_coverage": "mean_coverage",
                                      "equal_station_interval_score_m3": "mean_interval_score",
                                      "equal_station_mean_width_m3": "mean_width"})
    elif table == "metrics_by_station.csv":
        frame = frame.rename(columns={"skill_vs_local": "skill"})
    elif table == "predictions_all.csv.gz":
        frame = frame.rename(columns={"episode": "window_start", "truth_m3": "truth",
                                      "persistence_m3": "persistence", "lower_m3": "lower", "upper_m3": "upper"})
    if "order_label" not in frame and "pool_id" in frame:
        frame = frame.copy()
        frame["order_label"] = frame.pool_id.str.extract(r"^order(2026101[234])_K30$", expand=False)
        if frame.order_label.isna().any():
            raise ValueError(f"{table}: unexpected pool outside the three fixed K30 pools")
    return frame


def require_columns(frame, columns, table):
    missing = set(columns) - set(frame)
    if missing:
        raise ValueError(f"{table}: missing saved fields {sorted(missing)}")


def choose(frame, **conditions):
    result = frame
    for column, value in conditions.items():
        if isinstance(value, float):
            result = result[np.isclose(result[column].astype(float), value, rtol=0, atol=1e-12)]
        else:
            result = result[result[column].eq(value)]
    return result


def one(frame, **conditions):
    result = choose(frame, **conditions)
    if len(result) != 1:
        raise ValueError(f"Expected one saved row for {conditions}, found {len(result)}")
    return result.iloc[0]


def axis_style(ax, zero=False):
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color="#DDDDDD", linewidth=.5, zorder=0)
    if zero:
        ax.axhline(0, color="#777777", lw=.8, zorder=1)


def save(fig, output, name):
    for ext in ("pdf", "svg", "png"):
        fig.savefig(output / f"{name}.{ext}", bbox_inches="tight", dpi=180)
    plt.close(fig)


def save_data(frame, output, name):
    frame.to_csv(output / f"{name}_plotting.csv", index=False)


def mean_curve(summary, method, order, horizon, column, coverage=.9):
    return np.array([one(summary, order_label=order, method=method, budget=b,
                        horizon=horizon, nominal_coverage=coverage)[column] for b in BUDGETS], float)


def plot_coverage(summary, output):
    data = summary.copy()
    save_data(data, output, "nominal_actual_coverage")
    fig, axes = plt.subplots(3, 2, figsize=(11, 10), sharex=True)
    for row, budget in enumerate(BUDGETS):
        for col, horizon in enumerate(HORIZONS):
            ax = axes[row, col]
            ax.plot([80, 90], [80, 90], color="#AAAAAA", ls="--", lw=1, label="Nominal coverage")
            for method in METHODS:
                orders = [ORDERS[0]] if method == "LOCAL" else ORDERS
                for oi, order in enumerate(orders):
                    vals = [one(data, order_label=order, method=method, budget=budget,
                                horizon=horizon, nominal_coverage=c).mean_coverage * 100 for c in (.8, .9)]
                    color = COLORS[method] if order == ORDERS[0] else ORDER_COLORS[order]
                    ax.plot([80, 90], vals, color=color, marker="o" if method == "MIXTURE" else "s" if method == "SHARED" else "D",
                            ls="-" if method == "MIXTURE" else "--" if method == "SHARED" else ":",
                            lw=1.4, ms=4, alpha=1 if order == ORDERS[0] else .8,
                            label=f"{method}, order {order}" if method != "LOCAL" else "LOCAL (same across source pools)")
            ax.set_title(f"B={budget} days; h={horizon} day(s)")
            ax.set_xticks([80, 90]); axis_style(ax)
            if row == 2:
                ax.set_xlabel("Nominal coverage (%)")
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=2, fontsize=8, frameon=False, bbox_to_anchor=(.5, .035))
    fig.supylabel("Equal-SiteID mean empirical coverage (%)", x=.005)
    fig.suptitle("Nominal and observed coverage: all fixed source compositions", y=.985)
    fig.text(.5, .005, NOTE, ha="center", fontsize=8)
    fig.tight_layout(rect=(.035, .19, 1, .96))
    save(fig, output, "nominal_actual_coverage")


def plot_score_width(summary, output):
    data = choose(summary, nominal_coverage=.9)
    save_data(data, output, "score_width_by_budget")
    fig, axes = plt.subplots(2, 2, figsize=(11, 8), sharex=True)
    for col, horizon in enumerate(HORIZONS):
        for row, (metric, label) in enumerate([("mean_interval_score", "Mean 90% interval score (m³)"),
                                              ("mean_width", "Mean 90% interval width (m³)")]):
            ax = axes[row, col]
            for method in METHODS:
                ax.plot(BUDGETS, mean_curve(data, method, ORDERS[0], horizon, metric),
                        color=COLORS[method], marker="o", lw=1.6, label=f"{method}, order {ORDERS[0]}")
            for order in ORDERS[1:]:
                ax.plot(BUDGETS, mean_curve(data, "MIXTURE", order, horizon, metric),
                        color=ORDER_COLORS[order], marker="s", ls="--", lw=1.2,
                        label=f"MIXTURE, order {order}")
            axis_style(ax); ax.set_xticks(BUDGETS); ax.set_ylabel(label)
            ax.set_title(f"Forecast horizon {horizon} day(s)")
            if row == 1:
                ax.set_xlabel("Initial local calendar history (days)")
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=2, fontsize=8, frameon=False, bbox_to_anchor=(.5, .035))
    fig.suptitle("Raw-unit interval score and width: equal-SiteID averages", y=.985)
    fig.text(.5, .005, NOTE, ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .18, 1, .96))
    save(fig, output, "score_width_by_budget")


def plot_site_skill(metrics, output):
    data = choose(metrics, nominal_coverage=.9)
    data = data[data.method.isin(["SHARED", "MIXTURE"])]
    save_data(data, output, "site_interval_skill")
    fig, axes = plt.subplots(3, 2, figsize=(12, 10), sharex=True)
    for row, budget in enumerate(BUDGETS):
        for col, horizon in enumerate(HORIZONS):
            ax = axes[row, col]
            x = np.arange(len(SITES), dtype=float)
            for oi, order in enumerate(ORDERS):
                for mi, method in enumerate(["SHARED", "MIXTURE"]):
                    q = choose(data, order_label=order, method=method, budget=budget, horizon=horizon)
                    if len(q) != len(SITES) or set(q.site_id) != set(SITES):
                        raise ValueError("Missing or duplicate SiteID metrics; no performance-based exclusion is allowed")
                    values = q.set_index("site_id").loc[SITES, "skill"].to_numpy(float)*100
                    ax.scatter(x+(oi-1)*.22+(mi-.5)*.06, values, color=ORDER_COLORS[order],
                               marker="o" if method == "MIXTURE" else "s", s=24,
                               facecolors=ORDER_COLORS[order] if method == "MIXTURE" else "none",
                               linewidth=.9, zorder=3, label=f"{method}, order {order}")
            axis_style(ax, zero=True)
            ax.set_title(f"B={budget} days; h={horizon} day(s)")
            ax.set_xticks(x, SITES, rotation=55, ha="right"); ax.tick_params(labelbottom=True)
            if row == 2:
                ax.set_xlabel("Development SiteID")
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=2, fontsize=8, frameon=False, bbox_to_anchor=(.5, .035))
    fig.supylabel("Per-SiteID 90% interval-score skill vs LOCAL (%)", x=.005)
    fig.suptitle("All SiteIDs retained: negative values indicate interval negative transfer", y=.985)
    fig.text(.5, .005, NOTE, ha="center", fontsize=8)
    fig.tight_layout(rect=(.035, .17, 1, .96))
    save(fig, output, "site_interval_skill")


def plot_primary(intervals, output):
    q = intervals[intervals.constraint.eq("raw") & intervals.co_primary.eq(True) & intervals.block_days.eq(14)].copy()
    q = q.sort_values("horizon")
    if len(q) != 2 or not q.finite_replicates.eq(5000).all():
        raise ValueError("Two complete 5000-resample primary comparisons are required")
    save_data(q, output, "primary_interval_score")
    fig, ax = plt.subplots(figsize=(10, 3.5))
    pos = np.arange(2)
    ax.hlines(pos, q.lower_ci.to_numpy(float)*100, q.upper_ci.to_numpy(float)*100, color="#0072B2", lw=2)
    ax.scatter(q.mean_station_skill.to_numpy(float)*100, pos, color="#0072B2", s=35, zorder=3)
    ax.axvline(0, color="#777777", lw=.9)
    ax.set_yticks(pos, [f"h={h}: MIXTURE vs LOCAL" for h in q.horizon]); ax.invert_yaxis()
    ax.grid(axis="x", color="#DDDDDD", lw=.5); ax.spines[["top", "right"]].set_visible(False)
    ax.set_xlabel("Equal-SiteID mean paired interval-score skill (%)")
    ax.set_title("Prespecified primary analysis: order 20261012, B30, 90% intervals")
    fig.text(.5, .065, "5000 synchronous 14-day calendar-block / SiteID resamples; Bonferroni-adjusted 97.5% intervals.",
             ha="center", fontsize=8)
    fig.text(.5, .01, NOTE, ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .16, 1, 1))
    save(fig, output, "primary_interval_score")


def plot_cross_budget(intervals, output):
    q = intervals[(intervals.constraint.eq("raw")) & (intervals.block_days.eq(14)) &
                  (intervals.kind.eq("history_budget_comparison")) & np.isclose(intervals.nominal_coverage, .9)].copy()
    save_data(q, output, "cross_budget_interval_score")
    fig, axes = plt.subplots(1, 2, figsize=(11, 5))
    comparisons = [(30, 90), (30, 180), (90, 180)]
    for ax, horizon in zip(axes, HORIZONS):
        for oi, order in enumerate(ORDERS):
            points = [one(q, order_label=order, budget=b, reference_budget=rb, horizon=horizon) for b, rb in comparisons]
            x = np.arange(3)+(oi-1)*.2
            ax.vlines(x, [p.lower_ci*100 for p in points], [p.upper_ci*100 for p in points], color=ORDER_COLORS[order], lw=1.2)
            ax.scatter(x, [p.mean_station_skill*100 for p in points], color=ORDER_COLORS[order], s=28, label=f"Order {order}", zorder=3)
        ax.set_xticks(np.arange(3), ["MIX30 / LOCAL90", "MIX30 / LOCAL180", "MIX90 / LOCAL180"], rotation=15, ha="right")
        ax.set_title(f"Forecast horizon {horizon} day(s)"); axis_style(ax, zero=True)
        ax.set_xlabel("Initial-history comparison")
    axes[0].set_ylabel("Equal-SiteID paired interval-score skill (%)")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=3, fontsize=8, frameon=False, bbox_to_anchor=(.5, .085))
    fig.suptitle("Cross-budget 90% interval scores: exploratory, without a non-inferiority margin", y=.985)
    fig.text(.5, .04, "Raw-unit scores; 5000 synchronous 14-day calendar-block / SiteID resamples; exploratory 95% intervals.", ha="center", fontsize=8)
    fig.text(.5, .005, NOTE, ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .2, 1, .92))
    save(fig, output, "cross_budget_interval_score")


def plot_gamma(gamma, output):
    save_data(gamma, output, "source_selected_gamma")
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5), sharey=True)
    for ax, horizon in zip(axes, HORIZONS):
        for order in ORDERS:
            values = [one(gamma, order_label=order, budget=b, horizon=horizon).gamma for b in BUDGETS]
            ax.plot(BUDGETS, values, marker="o", color=ORDER_COLORS[order], lw=1.5, label=f"Order {order}")
        ax.set_title(f"Forecast horizon {horizon} day(s)")
        ax.set_xticks(BUDGETS); ax.set_yticks([0, .25, .5, .75, 1]); ax.set_ylim(-.05, 1.05)
        ax.set_xlabel("Initial local calendar history (days)"); axis_style(ax)
    axes[0].set_ylabel("Source-selected mixture weight, gamma")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=3, fontsize=8, frameon=False, bbox_to_anchor=(.5, .08))
    fig.suptitle("Fixed source-only validation choices, shared by 80% and 90% intervals", y=.985)
    fig.text(.5, .035, "Gamma=0 is LOCAL; gamma=1 is SHARED. No target deployment losses enter selection.", ha="center", fontsize=8)
    fig.text(.5, .005, NOTE, ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .19, 1, .94))
    save(fig, output, "source_selected_gamma")


def plot_timeseries(predictions, output, horizon):
    data = choose(predictions, order_label=ORDERS[0], budget=30, horizon=horizon, nominal_coverage=.9)
    data = data[pd.to_datetime(data.window_start).eq(pd.Timestamp("2022-01-01"))].copy()
    data["target_date"] = pd.to_datetime(data.target_date)
    data["origin"] = pd.to_datetime(data.origin)
    if set(data.site_id) != set(SITES):
        raise ValueError("Fixed example window must contain every development SiteID")
    if len(data) != len(SITES)*60*len(METHODS):
        raise ValueError("Fixed example window must retain all rows, including missing observations")
    save_data(data, output, f"fixed_first_window_h{horizon}")
    fig, axes = plt.subplots(5, 2, figsize=(13, 14), sharex=True)
    for ax, site in zip(axes.ravel(), SITES):
        site_data = data[data.site_id.eq(site)]
        baseline = choose(site_data, method="LOCAL").sort_values("target_date")
        dates = baseline.target_date
        for method in METHODS:
            m = choose(site_data, method=method).sort_values("target_date")
            if len(m) != 60 or not m.target_date.equals(dates):
                # Index labels differ between method blocks; compare values.
                if len(m) != 60 or not np.array_equal(m.target_date.to_numpy(), dates.to_numpy()):
                    raise ValueError("Unequal fixed-window calendar dates")
            if not np.array_equal(m.persistence.to_numpy(float), baseline.persistence.to_numpy(float), equal_nan=True):
                raise ValueError("Interval methods must retain exactly the same Persistence center")
            lower, upper = m.lower.to_numpy(float), m.upper.to_numpy(float)
            if method == "LOCAL":
                ax.plot(dates, lower, color=COLORS[method], lw=.8, ls=":", label="LOCAL 90% interval")
                ax.plot(dates, upper, color=COLORS[method], lw=.8, ls=":")
            else:
                ax.fill_between(dates, lower, upper, color=COLORS[method], alpha=.09 if method == "SHARED" else .14,
                                label=f"{method} 90% interval")
                ax.plot(dates, lower, color=COLORS[method], lw=.7, ls="--" if method == "SHARED" else "-")
                ax.plot(dates, upper, color=COLORS[method], lw=.7, ls="--" if method == "SHARED" else "-")
        ax.plot(dates, baseline.persistence, color="#222222", lw=1.1, label="Persistence (common center)")
        ax.plot(dates, baseline.truth, color="#D55E00", lw=1.1, marker=".", ms=3, label="Valid observed daily volume")
        ax.set_title(f"SiteID {site}"); ax.set_ylabel("Daily treated effluent volume (m³)")
        ax.xaxis.set_major_locator(mdates.WeekdayLocator(byweekday=mdates.MO, interval=2))
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b")); axis_style(ax)
        ax.tick_params(axis="x", rotation=30, labelbottom=True)
    for ax in axes[-1, :]:
        ax.set_xlabel("Target date (2022)")
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=3, fontsize=9, frameon=False, bbox_to_anchor=(.5, .026))
    fig.suptitle(f"Fixed first development window: all 10 SiteIDs, B30, h={horizon}, order 20261012", y=.985)
    fig.text(.5, .003, "Raw bounds; gaps retained; empirical intervals without a finite-sample coverage guarantee. " + NOTE,
             ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .075, 1, .965))
    save(fig, output, f"fixed_first_window_h{horizon}")


def draw_executed_workflow(output):
    """Native editable draw.io cells and matching vector exports, after completion."""
    nodes = [
        ("context", 50, 25, 1140, 75,
         "STAGE3D EXECUTED DEVELOPMENT EXPERIMENT\nSiteID exploration; retrospective published-quality filtering; physical mapping / real-time availability unverified"),
        ("pools", 50, 145, 535, 90,
         "Three frozen K=30 source pools\nOrders 20261012 / 20261013 / 20261014\nNo protected group enters source fitting or validation"),
        ("target", 655, 145, 535, 110,
         "10 unchanged target SiteIDs; five USED 2022–2023 windows\nInitial history [T−B, T−1], B=30 / 90 / 180\nLegal Persistence errors; h=1 / 3; at least 14 valid errors"),
        ("select", 50, 305, 535, 130,
         "SOURCE-ONLY GAMMA SELECTION\nLeave one known association group out\nOther sources: errors / scales through 2020 only\nHeld SiteID: 2021 Jan / Jul; 14 origins per window\nEqual-SiteID / window normalized 90% interval score\nGamma ∈ {0, 0.25, 0.5, 0.75, 1}; ties prefer smaller gamma"),
        ("freeze", 655, 315, 535, 105,
         "TARGET CALIBRATION, THEN FREEZE FOR 60 ORIGINS\nScale: median of legal positive initial-history volumes\nLOCAL empirical errors / gamma / quantiles fixed\nOnly available lag observations update Persistence\nNo deployment labels enter calibration or selection"),
        ("final", 50, 475, 535, 95,
         "FINAL SOURCE ERROR LIBRARY\nLegal source observations and labels in 2016–2021\nEach source SiteID has equal total empirical weight\nHistorical targets do not cross 2021 boundary"),
        ("interval", 50, 625, 1140, 110,
         "SAME PERSISTENCE CENTER FOR ALL METHODS\nLOCAL / SHARED / MIXTURE empirical distributions; q_c = inf{x: F(x) ≥ c}\nRaw intervals: Persistence ± local scale × q_c; c = 80% / 90%\nRaw bounds primary; lower=max(0, lower) sensitivity for EVERY method\nGamma endpoints reproduce baselines; 80% bounds nested inside 90% bounds"),
        ("evaluate", 50, 790, 1140, 110,
         "PAIRED DEVELOPMENT EVALUATION\nStage3C2 common calendars; documented calibration exclusions; h=3 is origin+3 that day\nRaw-unit interval score / coverage / width / lower & upper misses; all SiteIDs / budgets / pools retained\n5000 synchronous calendar-block / SiteID resamples; 14 days main, 7 / 28 sensitivity\nTwo B30 / 90% / main-order MIXTURE vs LOCAL contrasts: Bonferroni 97.5% intervals"),
        ("stop", 50, 950, 1140, 75,
         "STOP AFTER THIS BOUNDED ROUND\nStage3C2 negative point-prediction evidence retained; interval evidence is a separate question\nNo 2024–2025 performance; no rainfall / new networks / pool expansion / App / manuscript")
    ]
    edges = [("pools", "select"), ("select", "final"), ("target", "freeze"),
             ("final", "interval"), ("freeze", "interval"), ("interval", "evaluate"), ("evaluate", "stop")]
    mxfile = ET.Element("mxfile", host="app.diagrams.net", version="24.7.17")
    diagram = ET.SubElement(mxfile, "diagram", name="Executed Stage3D empirical intervals", id="stage3d")
    model = ET.SubElement(diagram, "mxGraphModel", page="1", pageWidth="1240", pageHeight="1060")
    tree = ET.SubElement(model, "root")
    ET.SubElement(tree, "mxCell", id="0"); ET.SubElement(tree, "mxCell", id="1", parent="0")
    for nid, x, y, w, h, label in nodes:
        cell = ET.SubElement(tree, "mxCell", id=nid, value=label, vertex="1", parent="1",
                             style="rounded=1;whiteSpace=wrap;html=0;fillColor=#EEF5FA;strokeColor=#33566B;fontSize=13;fontFamily=Arial;")
        ET.SubElement(cell, "mxGeometry", x=str(x), y=str(y), width=str(w), height=str(h), **{"as": "geometry"})
    for i, (start, end) in enumerate(edges):
        cell = ET.SubElement(tree, "mxCell", id=f"edge{i}", source=start, target=end, edge="1", parent="1",
                             style="edgeStyle=orthogonalEdgeStyle;endArrow=block;strokeColor=#33566B;")
        ET.SubElement(cell, "mxGeometry", relative="1", **{"as": "geometry"})
    ET.ElementTree(mxfile).write(output / "executed_stage3d.drawio", encoding="utf-8", xml_declaration=True)
    # Exports use exactly the same native-cell texts and coordinates, rather than
    # a screenshot or generated image. The editable .drawio remains authoritative.
    fig, ax = plt.subplots(figsize=(12.4, 10.6)); ax.set_xlim(0, 1240); ax.set_ylim(1060, 0); ax.axis("off")
    lookup = {n[0]: n for n in nodes}
    for start, end in edges:
        _, x, y, w, h, _ = lookup[start]; _, tx, ty, tw, th, _ = lookup[end]
        ax.add_patch(FancyArrowPatch((x+w/2, y+h), (tx+tw/2, ty), arrowstyle="-|>", mutation_scale=12,
                                    color="#33566B", lw=1, zorder=1))
    for _, x, y, w, h, label in nodes:
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=8",
                                   facecolor="#EEF5FA", edgecolor="#33566B", lw=1, zorder=2))
        ax.text(x+w/2, y+h/2, label, ha="center", va="center", fontsize=8, color="#172B39", zorder=3,
                linespacing=1.4)
    fig.tight_layout(pad=0)
    save(fig, output, "executed_stage3d")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--config", default=f"configs/{VERSION}/full.json")
    parser.add_argument("--results", default=f"reports/{VERSION}/results")
    parser.add_argument("--output", default=f"figures/{VERSION}")
    parser.add_argument("--gamma", default=f"reports/{VERSION}/results/gamma_distribution.csv")
    args = parser.parse_args()
    cfg_path, results, output = [args.root / p for p in (args.config, args.results, args.output)]
    cfg = json.loads(cfg_path.read_text())
    integrity_path = results / "evaluation_validation.json"
    integrity = json.loads(integrity_path.read_text())
    if integrity.get("status") != "COMPLETED" or not integrity.get("experiment_integrity", {}).get("all_expected_tasks_verified"):
        raise ValueError("An incomplete evaluation cannot be plotted as complete")
    if cfg.get("physical_mapping_verified") is not False:
        raise ValueError("Stage3D physical mapping must remain unverified")
    paths = {name: results / name for name in ["summary.csv", "metrics_by_station.csv", "paired_block_intervals.csv", "predictions_all.csv.gz"]}
    paths["gamma_distribution.csv"] = args.root / args.gamma
    recorded = integrity.get("files_sha256", {})
    for name, path in paths.items():
        if name in recorded and sha256(path) != recorded[name]:
            raise ValueError(f"Saved result hash differs: {name}")
        if not path.is_file():
            raise FileNotFoundError(path)
    output.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.titlesize": 10,
                         "axes.labelsize": 9, "figure.titlesize": 12, "pdf.fonttype": 42,
                         "ps.fonttype": 42, "svg.fonttype": "none"})
    summary = display_schema(read_table(paths["summary.csv"]), "summary.csv")
    metrics = display_schema(read_table(paths["metrics_by_station.csv"]), "metrics_by_station.csv")
    intervals = display_schema(read_table(paths["paired_block_intervals.csv"]), "paired_block_intervals.csv")
    predictions = display_schema(read_table(paths["predictions_all.csv.gz"]), "predictions_all.csv.gz")
    gamma = display_schema(read_table(paths["gamma_distribution.csv"]), "gamma_distribution.csv")
    gamma_keys = ["order_label", "budget", "horizon"]
    if len(gamma) != 18 or gamma.duplicated(gamma_keys).any() or set(gamma.order_label) != set(ORDERS):
        raise ValueError("Expected exactly the 18 source-selected gamma choices; target conditions cannot select new gamma")
    gamma_freeze_path = args.root / cfg["gamma_freeze"]
    gamma_freeze = json.loads(gamma_freeze_path.read_text())
    if gamma_freeze.get("status") != "FROZEN_SOURCE_ONLY_GAMMA_BEFORE_TARGET_INTERVALS" or gamma_freeze.get("target_deployment_scores_used") is not False:
        raise ValueError("The gamma choices must come from the frozen source-only validation")
    for pool in cfg["pools"]:
        for budget in BUDGETS:
            for horizon in HORIZONS:
                saved = one(gamma, pool_id=pool["pool_id"], budget=budget, horizon=horizon)
                expected_gamma = gamma_freeze["selected_gamma"][pool["pool_id"]][f"B{budget}_H{horizon}"]
                if saved.gamma != expected_gamma:
                    raise ValueError("Plot gamma differs from source-only pre-deployment freeze")
    if set(map(str, cfg["development_ids"])) != set(SITES) or cfg["budgets"] != BUDGETS or cfg["horizons"] != HORIZONS:
        raise ValueError("Plotting is limited to the registered Stage3D targets/budgets/horizons")
    for frame in [summary, metrics]:
        require_columns(frame, ["constraint", "order_label", "method", "budget", "horizon", "nominal_coverage"], "metric table")
    summary = summary[summary.constraint.eq("raw")]; metrics = metrics[metrics.constraint.eq("raw")]
    require_columns(summary, ["mean_coverage", "mean_interval_score", "mean_width"], "summary")
    require_columns(metrics, ["skill", "site_id"], "station metrics")
    require_columns(predictions, ["order_label", "method", "budget", "horizon", "nominal_coverage", "window_start", "site_id", "origin", "target_date", "persistence", "truth", "lower", "upper"], "predictions")
    if set(predictions.window_start) != set(WINDOWS) or set(predictions.site_id) != set(SITES):
        raise ValueError("Unexpected deployment window or target SiteID in interval output")
    if pd.to_datetime(predictions.target_date).dt.year.gt(2023).any():
        raise ValueError("Final-period performance may not enter Stage3D figures")
    plot_coverage(summary, output)
    plot_score_width(summary, output)
    plot_site_skill(metrics, output)
    plot_primary(intervals, output)
    plot_cross_budget(intervals, output)
    plot_gamma(gamma, output)
    for horizon in HORIZONS:
        plot_timeseries(predictions, output, horizon)
    draw_executed_workflow(output)
    captions = [
        ("nominal_actual_coverage", "Does sharing improve empirical coverage at both fixed nominal levels?", "summary.csv",
         "Equal-SiteID empirical coverage for LOCAL, SHARED and source-selected MIXTURE intervals on matched evaluation dates. "
         "All three fixed source compositions, local-history budgets and horizons are shown. The diagonal joins the two nominal levels; "
         "it is not a fitted calibration curve. Equal or nominal coverage does not establish conditional or finite-sample guarantees."),
        ("score_width_by_budget", "How do interval score and width change with initial local history?", "summary.csv",
         "Raw-unit 90% interval score and mean interval width, first computed within each SiteID and then averaged equally. "
         "Main-order LOCAL, SHARED and MIXTURE curves are shown with MIXTURE source-composition sensitivities; complete plot data retain all methods and compositions. "
         "A narrower interval is not beneficial if its miss penalty increases."),
        ("site_interval_skill", "Which SiteIDs experience interval negative transfer?", "metrics_by_station.csv",
         "Per-SiteID 90% interval-score skill relative to the same-budget LOCAL method. Negative values indicate negative transfer. "
         "Every original target SiteID, both shared methods, all three source compositions, budgets and horizons are displayed. "
         "Undefined zero-reference skills remain explicitly missing in the saved plotting data."),
        ("primary_interval_score", "Does the prespecified B30 MIXTURE improve interval score relative to LOCAL?", "paired_block_intervals.csv",
         "The two prespecified order-20261012 B30 comparisons at 90% nominal coverage. Dots show equal-SiteID paired interval-score skill. "
         "Lines are Bonferroni-adjusted 97.5% percentile intervals using 5000 synchronized 14-day calendar-block and whole-SiteID resamples. "
         "These are reused-window development comparisons, not independent confirmation or predictive-coverage guarantees."),
        ("cross_budget_interval_score", "Can shorter-history MIXTURE compare favourably with longer-history LOCAL intervals?", "paired_block_intervals.csv",
         "Cross-budget 90% comparisons use raw-unit interval scores before per-SiteID relative gains. All three source compositions "
         "and both horizons are retained. Lines show exploratory 95% intervals from synchronized 14-day calendar-block and SiteID resampling. "
         "No equivalence or non-inferiority margin was defined; crossing zero does not demonstrate equivalence."),
        ("source_selected_gamma", "How much source information is selected by legal source-only validation?", "gamma_distribution.csv",
         "One gamma is selected for each source pool, local-history budget and horizon by held-group source validation in 2021, "
         "using other sources only through 2020. Both nominal coverages use the same gamma. Gamma zero reproduces LOCAL exactly, "
         "so an unchanged result cannot be attributed to cross-SiteID information."),
        ("fixed_first_window_h1", "How do fixed-method intervals behave for every target in the first deployment window?", "predictions_all.csv.gz",
         "Fixed examples for every original target SiteID: first origin 2022-01-01, 60 origins, B30, horizon one day, main source order, "
         "90% nominal coverage. All methods retain the identical Persistence center. Raw bounds and observed-calendar gaps are retained; "
         "SiteIDs and dates were fixed before results were viewed."),
        ("fixed_first_window_h3", "How do third-day fixed-method intervals behave for every target in the first window?", "predictions_all.csv.gz",
         "The same fixed examples as the one-day panel, predicting origin+3 that day's volume, not a three-day sum. "
         "All ten original target SiteIDs, raw bounds and calendar gaps are retained; no outcome-based example selection occurs."),
        ("executed_stage3d", "Which source and target information was used and frozen?", "config / verified completion record",
         "Executed Stage3D empirical-interval workflow. Native draw.io text, nodes and arrows remain editable. "
         "Source-only selection, final source-library dates, bounded initial target calibration and frozen 60-origin deployment are explicit. "
         "Mapping and historical information-arrival uncertainties are disclosed; 2024–2025 performance remains excluded.")
    ]
    pd.DataFrame(captions, columns=["figure", "research_question", "result_source", "caption_english"]).to_csv(output / "FIGURE_SOURCES.csv", index=False)
    sources = {name: sha256(path) for name, path in paths.items()}
    provenance = dict(status="PLOTTED_FROM_SAVED_COMPLETE_EVALUATION", config_sha256=sha256(cfg_path),
                      script_sha256=sha256(Path(__file__)), sources_sha256=sources,
                      evaluation_validation_sha256=sha256(integrity_path), physical_mapping_verified=False,
                      gamma_freeze_sha256=sha256(gamma_freeze_path),
                      verified_real_time=False, all_windows_used_development=True, raw_bounds_primary=True,
                      fixed_examples=dict(window_start="2022-01-01", budget=30, horizons=HORIZONS,
                                          site_ids=SITES, order_label=ORDERS[0], nominal_coverage=.9),
                      matplotlib_version=matplotlib.__version__, pandas_version=pd.__version__, numpy_version=np.__version__,
                      figures_sha256={f.name: sha256(f) for f in sorted(output.iterdir()) if f.suffix in {".pdf", ".svg", ".png", ".drawio"}},
                      plotting_data_sha256={f.name: sha256(f) for f in sorted(output.glob("*_plotting.csv"))})
    (output / "FIGURE_PROVENANCE.json").write_text(json.dumps(provenance, ensure_ascii=False, indent=2)+"\n")
    print(f"Created eight real-result plot groups and editable executed workflow: {output}")


if __name__ == "__main__":
    main()
