# Stage3C2 Code_and_Reproduce

Read reports/stage3c2_source_scale_v1/REPRODUCE.md and ANALYSIS_ZH.md.
Extract packages into one NEW root; duplicate members must have identical SHA.
Code package refits K3 and smoke; merged packages verify cached full tasks and
recompute all metrics. These are separate declared reproduction scopes.
The complete 186-candidate eligibility rebuild needs the omitted original raw
CSV (22f494e2b96fe6fa9550c68971d50c752ddd291793fdc60334d64b2ef089f518) and archived project metadata. Canonical/raw-excerpt QA
and all frozen prediction inputs are self-contained.
All five windows are USED development; physical_mapping_verified=false;
no claim of independent physical plants or verified real-time arrival.
Stop after this finite CPU source-scale round. No weather/GRU/final-period fit.
