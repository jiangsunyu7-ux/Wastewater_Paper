"""Frozen CPU source-scale development, preserving Stage3B's feature algebra."""
from __future__ import annotations
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from copy import deepcopy
import json
import multiprocessing
from pathlib import Path
import resource
import subprocess
import sys
import time
import traceback

import numpy as np
import pandas as pd
import sklearn

from .common import sha256, utc_now, write_json
from .shared_data import load_series
from .stage3a_data import compact
from .stage3b_experiment import hash_value, array_hash
from .stage3b_models import (calibration_fold, choose_parameters, estimate_bias,
    initial_data, reconstruct, residual_target, ridge_fit)
from .stage3c2_source import prepare_source_bank

ROOT=Path(__file__).resolve().parents[2]
VERSION='stage3c2_source_scale_v1'
ANCHORS=['persistence','weekly_persistence','local_residual_ridge_selected']
SHARED=['shared_residual_ridge_selected','shared_residual_ridge_bias_selected']
REQUIRED={'predictions.csv','selection.json','parameters.json','ridge_parameters.npz','diagnostics.json','validation_grid.csv'}
G={}


def load_config(path):
    cfg=json.loads((ROOT/path).read_text())
    if cfg['version']!=VERSION or cfg['analysis_unit']!='station_exploratory' or cfg['physical_mapping_verified']:
        raise ValueError('Only explicitly unverified SiteID development is permitted')
    expected={'source_ids':['13006','13008','13012'],
      'development_ids':['13013','13015','13016','13017','13022','13024','13025','13028','13029','13031'],
      'evaluation_origins':['2022-01-01','2022-07-01','2023-01-01','2023-07-01','2023-10-01'],
      'budgets':[30,90,180],'horizons':[1,3],'ridge_alphas':[.0001,.001,.01,.1,1,10],
      'lambdas':[0,.25,.5,1],'evaluation_days':60,'sequence_length':7,
      'source_training_start':'2016-01-01','source_training_end':'2021-12-31',
      'source_selection_train_end':'2020-12-31','verified_real_time':False,
      'qa_mode':'published_good_only_retrospective'}
    for k,v in expected.items():
        if cfg.get(k)!=v:raise ValueError('Unplanned configuration change: '+k)
    freeze=json.loads((ROOT/cfg['frozen_manifest']).read_text())
    for name,digest in freeze['files_sha256'].items():
        if not (ROOT/name).is_file() or sha256(ROOT/name)!=digest:
            raise ValueError('Frozen file changed: '+name)
    if freeze['files_sha256'].get(path)!=sha256(ROOT/path):raise ValueError('Config not in freeze')
    pools=json.loads((ROOT/cfg['source_pool_definition']).read_text())
    if cfg['pools']!=pools['pools']:raise ValueError('Source pools differ from frozen cohort')
    if set(pools['source_union_ids']) & set(pools['protected_ids']):
        raise ValueError('Protected SiteID in source pool')
    if set(pools['source_union_ids']) & set(cfg['development_ids']):raise ValueError('Source/target overlap')
    if cfg['verified_real_time'] or not cfg['all_windows_already_used_development']:
        raise ValueError('False real-time/unseen-window declaration')
    return cfg,hash_value({'files':freeze['files_sha256'],'numpy':np.__version__,
                         'pandas':pd.__version__,'sklearn':sklearn.__version__}),pools


def expected_tasks(cfg,mode):
    sites=cfg['smoke_ids'] if mode=='smoke' else cfg['development_ids']
    dates=[cfg['evaluation_origins'][0]] if mode=='smoke' else cfg['evaluation_origins']
    return [(s,d,b,h) for d in dates for s in sites for b in cfg['budgets'] for h in cfg['horizons']]


def task_key(task):
    s,d,b,h=task;return f'{s}_{d}_B{b}_H{h}'


def validate_job(folder,fingerprint,rows):
    folder=Path(folder);p=folder/'status.json'
    if not p.exists():return False
    state=json.loads(p.read_text())
    if state.get('fingerprint')!=fingerprint:raise ValueError('Changed job fingerprint: '+str(folder))
    if state.get('status')!='COMPLETED':return False
    hashes=state.get('outputs_sha256',{})
    if not REQUIRED.issubset(hashes) or state.get('prediction_rows')!=rows:
        raise ValueError('Incomplete completed-job declaration')
    for name,digest in hashes.items():
        if not (folder/name).is_file() or sha256(folder/name)!=digest:
            raise ValueError('Completed job missing/modified: '+name)
    return True


def initialize(cfg,series,banks,signature,output,pools):
    G.update(cfg=cfg,series=series,banks=banks,signature=signature,output=Path(output),pools=pools)


def select_all(series,date,budget,horizon,cfg,banks):
    """One legal local CV fit per alpha shared across every pool comparison."""
    train,val,fold=calibration_fold(series,date,budget,horizon,cfg)
    selections={};all_grid=[]
    if fold['valid']:
        if pd.Timestamp('2020-12-31')>=val.origins.min():raise AssertionError('Future source proxy')
        xt,xv=compact(train.X),compact(val.X);rt,rv=residual_target(train),residual_target(val)
        local_rows=[]
        for a in cfg['ridge_alphas']:
            pred=ridge_fit(xt,rt,a).predict(xv)
            for lam in cfg['lambdas']:
                e=float(lam)*pred-rv
                local_rows.append(dict(family='local_residual_ridge',alpha=float(a),shrinkage=float(lam),
                  validation_mae=float(np.mean(np.abs(e))),validation_mse=float(np.mean(e**2)),
                  bias_normalized=0.,fitting_labels=len(train.y),validation_labels=len(val.y)))
        for pool_id,bank in banks.items():
            rows=list(local_rows)
            for a in cfg['ridge_alphas']:
                m=bank['proxy'][horizon][float(a)];bias=estimate_bias(m,train)
                for family,b in [('shared_residual_ridge',0.),('shared_residual_ridge_bias',bias)]:
                    pred=m.predict(xv)+b
                    for lam in cfg['lambdas']:
                        e=float(lam)*pred-rv
                        rows.append(dict(family=family,alpha=float(a),shrinkage=float(lam),
                          validation_mae=float(np.mean(np.abs(e))),validation_mse=float(np.mean(e**2)),
                          bias_normalized=b,fitting_labels=len(train.y),validation_labels=len(val.y)))
            selections[pool_id]=choose_parameters(rows)
            all_grid.extend(dict(row,pool_id=pool_id) for row in rows)
        fold.update(shared_proxy_fit_end='2020-12-31',source_assisted=False,
                    choice_source='budget_internal_chronological_validation')
    else:
        key=f'B{budget}_H{horizon}'
        local=banks['K3']['source_selection']['fallback_settings'][key]['parameters']
        for pool_id,bank in banks.items():
            params=deepcopy(bank['source_selection']['fallback_settings'][key]['parameters'])
            params['local_residual_ridge_selected']=deepcopy(local['local_residual_ridge_selected'])
            selections[pool_id]=params
        fold.update(source_assisted=True,choice_source='LOSO_source_simulated_same_budget_validation',
                    fallback_key=key,fallback_reason='insufficient internal fitting/validation labels',
                    fallback_source_fit_end='2020-12-31',
                    fallback_validation_end=banks['K3']['source_selection']['fallback_settings'][key]['validation_end'],
                    local_hyperparameter_source_pool='K3',source_pseudo_validation_folds=6)
    return {'fold':fold,'parameters_by_pool':selections,'residual_validation':all_grid,
            'selection_uses_deployment_labels':False}


def target_worker(task):
    cfg,banks,pools=G['cfg'],G['banks'],G['pools'];site,date,budget,horizon=task
    folder=G['output']/'jobs'/task_key(task);folder.mkdir(parents=True,exist_ok=True)
    fingerprint=hash_value({'signature':G['signature'],'task':task,'pools':[p['pool_id'] for p in pools]})
    rows_expected=60*(3+2*len(pools));started=time.perf_counter()
    if validate_job(folder,fingerprint,rows_expected):
        return {'task':task_key(task),'status':'CACHED','seconds':time.perf_counter()-started}
    prior=json.loads((folder/'status.json').read_text()) if (folder/'status.json').exists() else {}
    state={'status':'RUNNING','fingerprint':fingerprint,'attempt':prior.get('attempt',0)+1,
           'started_utc':utc_now(),'expected_prediction_rows':rows_expected}
    write_json(folder/'status.json',state)
    try:
        series=G['series'][site];train,test,diag=initial_data(series,date,budget,horizon,cfg);diag['site_id']=site
        selected=select_all(series,date,budget,horizon,cfg,banks)
        write_json(folder/'selection.json',selected)
        pd.DataFrame(selected['residual_validation']).to_csv(folder/'validation_grid.csv',index=False)
        xt,xd=compact(train.X),compact(test.X);r=residual_target(train)
        localparam=selected['parameters_by_pool']['K3']['local_residual_ridge_selected']
        lm=ridge_fit(xt,r,localparam['alpha'])
        outputs=[('baseline','persistence',test.persistence.copy(),{}),
                 ('baseline','weekly_persistence',test.weekly.copy(),{}),
                 ('baseline','local_residual_ridge_selected',
                  reconstruct(test.persistence,lm.predict(xd),0,localparam['shrinkage'],test.scale),dict(localparam,bias_m3=0.))]
        saved={'baseline_local_coef':lm.coef_,'baseline_local_intercept':lm.intercept_}
        params={'baseline::local_residual_ridge_selected':dict(localparam,bias_m3=0.,local_bias_calibration_labels=0)}
        for pool in pools:
            pool_id=pool['pool_id'];bank=banks[pool_id]
            for name in SHARED:
                decision=selected['parameters_by_pool'][pool_id][name]
                m=bank['final'][horizon][float(decision['alpha'])]
                bias=estimate_bias(m,train) if name=='shared_residual_ridge_bias_selected' else 0.
                p=dict(decision,bias_normalized=bias,bias_m3=bias*test.scale,
                       local_bias_calibration_labels=len(train.y) if bias or 'bias' in name else 0)
                values=reconstruct(test.persistence,m.predict(xd),bias,decision['shrinkage'],test.scale)
                outputs.append((pool_id,name,values,p));params[pool_id+'::'+name]=p
                saved[pool_id+'__'+name+'__coef']=m.coef_;saved[pool_id+'__'+name+'__intercept']=m.intercept_
                saved[pool_id+'__'+name+'__bias']=bias
        write_json(folder/'parameters.json',params);np.savez(folder/'ridge_parameters.npz',**saved)
        available=test.X[:,:,1].sum(axis=1)>0;rows=[]
        metadata={p['pool_id']:p for p in pools}
        for pool_id,name,values,choice in outputs:
            for j,(origin,target) in enumerate(zip(test.origins,test.targets)):
                yhat=float(values[j])
                if name not in ['persistence','weekly_persistence'] and choice.get('shrinkage')!=0 and not available[j]:yhat=np.nan
                pool=metadata.get(pool_id,{'k':0,'order_label':None})
                rows.append(dict(site_id=site,episode=date,budget=budget,horizon=horizon,
                  origin=str(origin.date()),target_date=str(target.date()),model=name,pool_id=pool_id,
                  policy_id=pool_id+'::'+name,k=pool['k'],
                  order_label=('baseline' if pool_id=='baseline' else 'common' if pool_id=='K3' else str(pool['order_label'])),seed=0,
                  truth_m3=float(test.y[j]*test.scale),prediction_m3=yhat,
                  prediction_nonnegative_m3=max(0.,yhat) if np.isfinite(yhat) else np.nan,
                  budget_start=diag['budget_start'],fit_end=diag['fit_end'],last_train_target=diag['last_train_target'],
                  latest_input_date=str(origin.date()),scale_m3=test.scale,training_labels=len(train.y),
                  high_threshold_m3=diag['high_threshold_m3'],threshold_observations=diag['threshold_observations'],
                  threshold_start=diag['threshold_start'],threshold_end=diag['threshold_end'],
                  alpha=choice.get('alpha'),shrinkage=choice.get('shrinkage'),bias_m3=choice.get('bias_m3',0.),
                  analysis_unit='station_exploratory',physical_mapping_verified=False,
                  qa_mode='published_good_only_retrospective',window_class='reused_development',
                  source_assisted_tuning=selected['fold']['source_assisted'],
                  validation_labels=selected['fold']['validation_labels']))
        frame=pd.DataFrame(rows)
        assert len(frame)==rows_expected and frame.policy_id.nunique()==3+2*len(pools)
        assert (pd.to_datetime(frame.target_date)-pd.to_datetime(frame.origin)).dt.days.eq(horizon).all()
        frame.to_csv(folder/'predictions.csv',index=False)
        diag.update(training_X_sha256=array_hash(train.X),training_y_sha256=array_hash(train.y),
          training_residual_sha256=array_hash(r),evaluation_X_sha256=array_hash(test.X),
          validation=selected['fold'],parameters=params,source_final_fit_end='2021-12-31',
          local_individual_weight=1/len(train.y),local_weights_sum=1.,physical_mapping_verified=False,
          point_prediction_only=True,device='cpu',policies_completed=len(outputs),
          local_fit_reused_across_all_pools=True)
        write_json(folder/'diagnostics.json',diag)
        state.update(status='COMPLETED',finished_utc=utc_now(),seconds=time.perf_counter()-started,
          prediction_rows=len(frame),policy_count=len(outputs),peak_RSS_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
          outputs_sha256={name:sha256(folder/name) for name in sorted(REQUIRED)})
        write_json(folder/'status.json',state)
        return {'task':task_key(task),'status':'COMPLETED','seconds':state['seconds']}
    except Exception as e:
        (folder/f"failure_attempt_{state['attempt']}.txt").write_text(traceback.format_exc())
        state.update(status='FAILED',error=str(e),seconds=time.perf_counter()-started,finished_utc=utc_now())
        write_json(folder/'status.json',state)
        return {'task':task_key(task),'status':'FAILED','error':str(e)}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--config',default=f'configs/{VERSION}/full.json')
    ap.add_argument('--mode',choices=['k3-check','smoke','full','resume','sources'],default='full')
    ap.add_argument('--workers',type=int,default=2);ap.add_argument('--max-jobs',type=int)
    a=ap.parse_args();cfg,signature,pooldef=load_config(a.config);started=time.perf_counter()
    mode='full' if a.mode=='resume' else a.mode
    if mode!='k3-check':
        gate=ROOT/f'reports/{VERSION}/K3_REPRODUCTION_CHECK.json'
        if (not gate.is_file() or json.loads(gate.read_text()).get('status')!='PASSED'
            or json.loads(gate.read_text()).get('signature')!=signature):
            raise ValueError('K3 gate must reproduce Stage3B predictions and parameters before expansion')
    pools=[p for p in cfg['pools'] if p['pool_id']=='K3'] if mode=='k3-check' else cfg['pools']
    ids=list(dict.fromkeys(s for p in pools for s in p['site_ids']))
    load_started=time.perf_counter()
    series=load_series(ROOT/cfg['canonical_csv'],ids+cfg['development_ids'])
    data_seconds=time.perf_counter()-load_started;banks={};source_started=time.perf_counter()
    for pool in pools:
        bank,_=prepare_source_bank(cfg,series,pool['site_ids'],ROOT/cfg['source_output']/pool['pool_id'],
            related_ids=pooldef['source_related_ids'],signature=signature,pool_id=pool['pool_id'])
        banks[pool['pool_id']]=bank
        print(f"source pool {pool['pool_id']} ready cached={bank['cache_reused']}",flush=True)
    source_seconds=time.perf_counter()-source_started
    if mode=='sources':return
    output=ROOT/f"runs/{VERSION}/{mode.replace('-','_')}";output.mkdir(parents=True,exist_ok=True)
    mp=output/'manifest.json'
    if mp.exists() and json.loads(mp.read_text())['signature']!=signature:raise ValueError('Run signature mismatch')
    tasks=expected_tasks(cfg,mode);selected=tasks[:a.max_jobs] if a.max_jobs is not None else tasks
    rows_expected=60*(3+2*len(pools))
    manifest={'status':'RUNNING','signature':signature,'mode':mode,'config_path':a.config,
      'config_sha256':sha256(ROOT/a.config),'expected_conditions':len(tasks),'expected_policies':3+2*len(pools),
      'expected_prediction_rows':len(tasks)*rows_expected,'pool_ids':[p['pool_id'] for p in pools],
      'started_utc':utc_now(),'code_version':{'git_head':subprocess.run(
        ['git','rev-parse','HEAD'],cwd=ROOT,capture_output=True,text=True).stdout.strip() or None},
      'physical_mapping_verified':False,'all_windows_used_development':True,'device':'cpu','workers':a.workers}
    write_json(mp,manifest)
    args=(cfg,{s:series[s] for s in cfg['development_ids']},banks,signature,output,pools)
    results=[];work_start=time.perf_counter()
    if a.workers==1:
        initialize(*args)
        for task in selected:
            results.append(target_worker(task));print(f"{mode} {len(results)}/{len(selected)} {results[-1]}",flush=True)
    else:
        with ProcessPoolExecutor(max_workers=a.workers,mp_context=multiprocessing.get_context('spawn'),
                                 initializer=initialize,initargs=args) as executor:
            futures={executor.submit(target_worker,t):t for t in selected}
            for f in as_completed(futures):
                results.append(f.result());print(f"{mode} {len(results)}/{len(selected)} {results[-1]}",flush=True)
                if len(results)%10==0:write_json(output/'progress.json',{'completed_this_call':len(results),'expected':len(tasks),'last':results[-1],'utc':utc_now()})
    target_seconds=time.perf_counter()-work_start;statuses=[]
    for task in tasks:
        folder=output/'jobs'/task_key(task)
        fp=hash_value({'signature':signature,'task':task,'pools':[p['pool_id'] for p in pools]})
        valid=validate_job(folder,fp,rows_expected)
        state=json.loads((folder/'status.json').read_text()) if (folder/'status.json').exists() else {'status':'NOT_EXECUTED'}
        statuses.append(dict(task=task_key(task),status=state['status'],validated=valid,
                             folder=str(folder.relative_to(ROOT))))
    completed=sum(s['validated'] for s in statuses);failed=sum(s['status']=='FAILED' for s in statuses)
    manifest.update(status='COMPLETED' if completed==len(tasks) else 'PARTIAL',completed_conditions=completed,
      failed_conditions=failed,not_completed_conditions=len(tasks)-completed,
      counts_this_call={s:sum(r['status']==s for r in results) for s in ['COMPLETED','CACHED','FAILED']},
      finished_utc=utc_now(),seconds_this_call=time.perf_counter()-started,
      phase_seconds={'data_load':data_seconds,'source_training_or_cache':source_seconds,'target_training_or_cache':target_seconds},
      peak_RSS_parent_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
      peak_RSS_children_KiB=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
      outputs_and_fingerprints_verified=completed==len(tasks))
    write_json(output/'completion.json',statuses);write_json(output/'completion_this_call.json',results)
    if completed==len(tasks):
        aggregate=pd.concat([pd.read_csv(output/'jobs'/s['task']/'predictions.csv',dtype={'site_id':str}) for s in statuses],ignore_index=True)
        aggregate.to_csv(output/'predictions_all.csv.gz',index=False,compression={'method':'gzip','mtime':0})
        manifest['predictions_sha256']=sha256(output/'predictions_all.csv.gz')
        assert len(aggregate)==manifest['expected_prediction_rows']
    write_json(mp,manifest);print(json.dumps(manifest,indent=2),flush=True)
    if manifest['status']!='COMPLETED':raise SystemExit(3)


if __name__=='__main__':main()
