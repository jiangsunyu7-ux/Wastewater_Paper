"""Independent individual K3 forecasts/choices/coefficients against archived3B."""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from wastewater.common import sha256,write_json

ROOT=Path(__file__).resolve().parents[1]
VERSION='stage3c2_source_scale_v1'
MODELS=['persistence','weekly_persistence','local_residual_ridge_selected',
        'shared_residual_ridge_selected','shared_residual_ridge_bias_selected']
KEYS=['site_id','episode','budget','horizon','origin','target_date','model']


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--run',default=f'runs/{VERSION}/k3_check')
    ap.add_argument('--output',default=f'reports/{VERSION}/K3_REPRODUCTION_CHECK.json')
    a=ap.parse_args();run=ROOT/a.run;old=ROOT/'runs/stage3b_20261011_v1/full'
    m=json.loads((run/'manifest.json').read_text())
    assert m['status']=='COMPLETED' and m['completed_conditions']==m['expected_conditions']==300
    new=pd.read_csv(run/'predictions_all.csv.gz',dtype={'site_id':str})
    oldframes=[pd.read_csv(p,dtype={'site_id':str}) for p in sorted((old/'jobs').glob('*/predictions.csv'))]
    before=pd.concat(oldframes,ignore_index=True);before=before[before.model.isin(MODELS)]
    n=new.set_index(KEYS).sort_index();b=before.set_index(KEYS).sort_index()
    assert n.index.equals(b.index) and len(n)==90000
    np.testing.assert_allclose(n.truth_m3,b.truth_m3,atol=0,rtol=0,equal_nan=True)
    np.testing.assert_allclose(n.prediction_m3/n.scale_m3,b.prediction_m3/b.scale_m3,
                               atol=1e-10,rtol=1e-10,equal_nan=True)
    for column in ['alpha','shrinkage','training_labels','scale_m3','high_threshold_m3']:
        np.testing.assert_allclose(n[column],b[column],atol=0,rtol=0,equal_nan=True)
    for column in ['budget_start','fit_end','last_train_target','latest_input_date','threshold_start','threshold_end']:
        assert n[column].equals(b[column])
    base=n[n.index.get_level_values('model')=='persistence']
    oldbase=b[b.index.get_level_values('model')=='persistence']
    np.testing.assert_allclose(base.prediction_m3,oldbase.prediction_m3,atol=0,rtol=0,equal_nan=True)
    parameters=0;validationchecks=0
    for folder in sorted((run/'jobs').iterdir()):
        s=json.loads((folder/'selection.json').read_text())
        prev=json.loads((old/'jobs'/folder.name/'selection.json').read_text())
        for name in MODELS[2:]:
            choice=s['parameters_by_pool']['K3'][name];ref=prev['parameters'][name]
            assert choice['alpha']==ref['alpha'] and choice['shrinkage']==ref['shrinkage']
            np.testing.assert_allclose(choice['validation_mae'],ref['validation_mae'],atol=1e-12,rtol=1e-12)
            parameters+=1
        fold=s['fold'];ref=prev['fold']
        for k in ['fitting_labels','validation_labels','fit_end','normalization_fit_start','normalization_fit_end','source_assisted','valid']:
            assert fold[k]==ref[k]
        if fold['valid']:
            arows=pd.DataFrame(s['residual_validation']).drop(columns=['pool_id'])
            brows=pd.DataFrame(prev['residual_validation'])
            columns=['family','alpha','shrinkage']
            aa=arows.set_index(columns).sort_index();bb=brows.set_index(columns).sort_index()
            assert aa.index.equals(bb.index)
            np.testing.assert_allclose(aa.validation_mae,bb.validation_mae,atol=1e-12,rtol=1e-12)
            validationchecks+=len(aa)
    source=ROOT/f'runs/{VERSION}/source/K3';oldsrc=ROOT/'runs/stage3b_20261011_v1/source'
    arraychecks=0
    for f in sorted(source.glob('*.npz')):
        with np.load(f) as aa,np.load(oldsrc/f.name) as bb:
            assert sorted(aa.files)==sorted(bb.files)
            for k in aa.files:
                np.testing.assert_allclose(aa[k],bb[k],atol=1e-10,rtol=1e-10)
                arraychecks+=1
    delta=(n.prediction_m3/n.scale_m3-b.prediction_m3/b.scale_m3).abs().max()
    result={'status':'PASSED','signature':m['signature'],'prediction_rows_compared':len(n),
      'source_array_checks':arraychecks,'parameter_choices_checked':parameters,
      'internal_validation_scores_checked':validationchecks,'maximum_normalized_prediction_difference':float(delta),
      'prediction_tolerance':{'normalized_atol':1e-10,'rtol':1e-10},
      'validation_tolerance':{'normalized_atol':1e-12,'rtol':1e-12},
      'persistence_exact':True,'truth_history_thresholds_choices_exact':True,
      'scope':'five corresponding policies, all300conditions/5 usedwindows; numerical tolerance is not bitwise replication',
      'old_predictions_source':'immutable individual Stage3B job predictions, not rounded summaries',
      'new_predictions_sha256':sha256(run/'predictions_all.csv.gz'),'checker_sha256':sha256(Path(__file__))}
    out=ROOT/a.output;out.parent.mkdir(exist_ok=True,parents=True);write_json(out,result)
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
