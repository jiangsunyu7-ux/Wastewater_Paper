"""Independent saved-evidence audit for the frozen Stage3C2 source-scale run.

No C2 evaluator, training runner, or parameter-choice functions are imported.
Calendar features, legal Persistence, weighted normal equations, validation
scores, loss aggregation and bootstrap draws are implemented independently.
The scientific training run must already exist; this script never trains or
selects a new scientific candidate and never reads final-period performance.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path
import time
import warnings

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
VERSION = "stage3c2_source_scale_v1"
KEYS = ["site_id", "episode", "horizon", "origin", "target_date"]
ROWS = KEYS + ["budget", "pool_id", "model"]
METRIC = ["evaluation_set", "constraint", "site_id", "pool_id", "model", "budget", "horizon"]
LOCAL = "local_residual_ridge_selected"
PRIMARY = "shared_residual_ridge_bias_selected"
TIE = 1e-12
COUNTS = {}
FEATURE_CACHE = {}


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def count(name, n=1):
    COUNTS[name] = COUNTS.get(name, 0) + int(n)


def close(actual, expected, atol=1e-10, rtol=1e-10):
    np.testing.assert_allclose(actual, expected, atol=atol, rtol=rtol, equal_nan=True)


def csv(path):
    return pd.read_csv(path, dtype={"site_id": str, "pool_id": str, "order_label": str}, low_memory=False)


def linked(site, related):
    neighbours = {}
    for key, members in related.items():
        group = {str(key), *map(str, members)}
        for member in group:
            neighbours.setdefault(member, set()).update(group)
    seen, waiting = {str(site)}, [str(site)]
    while waiting:
        node = waiting.pop()
        for member in neighbours.get(node, ()):
            if member not in seen:
                seen.add(member)
                waiting.append(member)
    return seen


def audit_cohort(root, cfg, definition):
    folder = root / "data/provenance" / VERSION
    group = pd.read_csv(folder / "partition_group_ledger.csv", dtype=str)
    eligible = group[group.partition.isin(["temporary_protection", "added_source", "eligible_not_selected"])].copy()
    eligible["independent_hash"] = eligible.provisional_group_id.map(
        lambda x: hashlib.sha256(("Wessex-C2-reserve-v1|" + x).encode()).hexdigest())
    assert eligible.independent_hash.equals(eligible.reserve_sha256)
    ordered = eligible.sort_values(["independent_hash", "provisional_group_id"])
    protected = set(ordered.head(math.ceil(.2 * len(ordered))).provisional_group_id)
    assert protected == set(definition["protected_provisional_groups"])
    available = ordered[~ordered.provisional_group_id.isin(protected)]
    rankings = pd.read_csv(folder / "source_candidate_rankings.csv", dtype=str)
    for label in [20261012, 20261013, 20261014]:
        q = available.copy()
        q["source_hash"] = q.provisional_group_id.map(lambda x: hashlib.sha256(
            (f"Wessex-C2-order-v1|{label}|" + x).encode()).hexdigest())
        q = q.sort_values(["source_hash", "provisional_group_id"])
        rank = rankings[rankings.order_label.eq(str(label))].sort_values("rank", key=lambda x: x.astype(int))
        assert rank.provisional_group_id.tolist() == q.provisional_group_id.tolist()
        assert rank.source_rank_sha256.tolist() == q.source_hash.tolist()
        pools = {p["k"]: p for p in cfg["pools"] if p["order_label"] == label}
        for k in [10, 30]:
            assert pools[k]["site_ids"] == cfg["source_ids"] + q.head(k - 3).representative_site_id.tolist()
        assert set(pools[10]["site_ids"]) < set(pools[30]["site_ids"])
    assert not set(definition["source_union_ids"]) & set(definition["protected_ids"])
    assert not set(definition["source_union_ids"]) & set(cfg["development_ids"])
    related = definition["source_related_ids"]
    for p in cfg["pools"]:
        assert len(p["site_ids"]) == p["k"] == len(set(p["site_ids"]))
        for site in p["site_ids"]:
            assert not (linked(site, related) - {site}) & set(p["site_ids"])
            assert not linked(site, related) & (set(cfg["development_ids"]) | set(definition["protected_ids"]))
    assert cfg["physical_mapping_verified"] is False and cfg["verified_real_time"] is False
    count("source_rankings_checked", 3)
    count("provisionally_protected_groups_checked", len(protected))


def load_series(root, cfg):
    data = csv(root / cfg["canonical_csv"])
    assert data.date.max() <= "2023-12-31"
    assert not data.duplicated(["site_id", "date"]).any()
    close(data.observed_input_m3, data.candidate_value_m3, atol=0, rtol=0)
    values = data.observed_input_m3.dropna()
    assert np.isfinite(values).all() and values.ge(0).all()
    result = {}
    index = pd.date_range("2016-01-01", "2023-12-31")
    for site, rows in data.groupby("site_id"):
        result[site] = rows.assign(date=pd.to_datetime(rows.date)).set_index("date").observed_input_m3.reindex(index)
    return result


def scale(series, left, end):
    observed = series.loc[left:end].dropna()
    positive = observed[observed.gt(0)]
    return float(positive.median()) if len(positive) else 1.


def samples(series, origins, h, left, normalizer, training=False):
    """Own calendar construction, including all-seven-day availability mask."""
    origins = pd.DatetimeIndex(origins)
    dates = origins.to_numpy()[:, None] - np.arange(6, -1, -1)[None, :] * np.timedelta64(1, "D")
    observed = series.reindex(pd.DatetimeIndex(dates.ravel())).to_numpy().reshape(dates.shape)
    observed[dates < np.datetime64(pd.Timestamp(left))] = np.nan
    mask = np.isfinite(observed)
    x = np.concatenate([np.where(mask, observed / normalizer, 1.)[:, [6, 5, 0]],
                        mask[:, [6, 5, 0]].astype(float)], axis=1).astype(np.float32).astype(float)
    p = np.full(len(origins), np.nan)
    for lag in range(8):
        d = origins - pd.Timedelta(days=lag)
        candidates = series.reindex(d).to_numpy()
        candidates[d < pd.Timestamp(left)] = np.nan
        use = np.isnan(p) & np.isfinite(candidates)
        p[use] = candidates[use]
    target = origins + pd.Timedelta(days=h)
    weekly_date = target - pd.Timedelta(days=7)
    weekly = series.reindex(weekly_date).to_numpy()
    weekly[(weekly_date < pd.Timestamp(left)) | (weekly_date > origins)] = np.nan
    y = series.reindex(target).to_numpy() / normalizer
    available = mask.any(axis=1)
    keep = np.isfinite(y) & np.isfinite(p) & available if training else np.ones(len(y), dtype=bool)
    return dict(x=x[keep], y=y[keep], p=p[keep], weekly=weekly[keep], origins=origins[keep],
                targets=target[keep], available=available[keep], scale=normalizer)


def training(series, left, end, h, normalizer):
    return samples(series, pd.date_range(left, pd.Timestamp(end) - pd.Timedelta(days=h)),
                   h, left, normalizer, training=True)


def normal_equation(x, y, alpha, weights=None):
    w = np.full(len(y), 1. / len(y)) if weights is None else weights
    close(w.sum(), 1., atol=1e-14, rtol=0)
    mean_x, mean_y = w @ x, float(w @ y)
    xc = x - mean_x
    coefficient = np.linalg.solve(xc.T @ (xc * w[:, None]) + float(alpha) * np.eye(x.shape[1]),
                                  xc.T @ (w * (y - mean_y)))
    return coefficient, mean_y - mean_x @ coefficient


def residual(data):
    return data["y"] - data["p"] / data["scale"]


def source_data(series, cfg, ids, h, end):
    arrays, diagnostics = [], []
    for site in ids:
        key = site, h, end
        if key not in FEATURE_CACHE:
            norm = scale(series[site], cfg["source_training_start"], end)
            FEATURE_CACHE[key] = training(series[site], cfg["source_training_start"], end, h, norm)
        q = FEATURE_CACHE[key]
        assert q["targets"].max() <= pd.Timestamp(end)
        arrays.append((q["x"], residual(q), np.full(len(q["y"]), 1. / (len(ids) * len(q["y"])))))
        diagnostics.append(q)
    return np.concatenate([v[0] for v in arrays]), np.concatenate([v[1] for v in arrays]), np.concatenate([v[2] for v in arrays]), diagnostics


def check_hashes(folder, state, required):
    hashes = state.get("outputs_sha256", {})
    assert set(required) <= set(hashes)
    for name, expected in hashes.items():
        assert (folder / name).is_file() and digest(folder / name) == expected, str(folder / name)
        count("completed_member_hash_checks")


def choose(grid, family):
    q = grid[grid.family.eq(family)].groupby(["alpha", "shrinkage"], as_index=False).validation_mae.mean()
    return q.sort_values(["validation_mae", "shrinkage", "alpha"], kind="stable").iloc[0]


def check_choice(choice, row):
    assert choice["alpha"] == row.alpha and choice["shrinkage"] == row.shrinkage
    close(choice["validation_mae"], row.validation_mae, atol=1e-12, rtol=1e-12)
    count("selected_parameter_choices_checked")


def independent_grid(train, validation, shared, cfg):
    x, xv, r, rv = train["x"], validation["x"], residual(train), residual(validation)
    rows = []
    for j, alpha in enumerate(cfg["ridge_alphas"]):
        coef, intercept = normal_equation(x, r, alpha)
        sc, si = shared["residual_coefs"][j], shared["residual_intercepts"][j]
        bias = float(np.mean(r - (x @ sc + si)))
        for family, predicted, b in [("local_residual_ridge", xv @ coef + intercept, 0.),
                                    ("shared_residual_ridge", xv @ sc + si, 0.),
                                    ("shared_residual_ridge_bias", xv @ sc + si + bias, bias)]:
            for lam in cfg["lambdas"]:
                e = float(lam) * predicted - rv
                rows.append(dict(family=family, alpha=float(alpha), shrinkage=float(lam),
                                 validation_mae=np.mean(abs(e)), validation_mse=np.mean(e * e), bias_normalized=b))
    return pd.DataFrame(rows)


def compare_grid(saved, independently_calculated):
    keys = ["family", "alpha", "shrinkage"]
    a, b = saved.set_index(keys).sort_index(), independently_calculated.set_index(keys).sort_index()
    assert a.index.equals(b.index)
    close(a[["validation_mae", "validation_mse", "bias_normalized"]],
          b[["validation_mae", "validation_mse", "bias_normalized"]])
    count("independent_validation_grid_scores_checked", len(a))


def audit_source_models(root, cfg, definition, series):
    related = definition["source_related_ids"]
    banks = {}
    for pool in cfg["pools"]:
        folder = root / cfg["source_output"] / pool["pool_id"]
        state = read_json(folder / "status.json")
        assert state["status"] == "completed" and state["completed_model_groups"] == state["expected_model_groups"] == 10
        assert state["completed_pseudo_folds"] == state["expected_pseudo_folds"] == 36
        required = [f"{name}_H{h}.npz" for name in ["final", "proxy", *["loso_" + s for s in cfg["source_ids"]]] for h in cfg["horizons"]]
        check_hashes(folder, state, required + ["selection.json", "source_diagnostics.json", "pseudo_validation_folds.json", "residual_fallback_grid.csv"])
        bank = {"selection": read_json(folder / "selection.json")}
        diagnostics = read_json(folder / "source_diagnostics.json")
        assert len(diagnostics) == 10
        for group in diagnostics:
            end = "2021-12-31" if group["group"] == "final" else "2020-12-31"
            ids = pool["site_ids"]
            if group["group"].startswith("loso_"):
                excluded = linked(group["group"][5:], related)
                ids = [s for s in ids if s not in excluded]
            assert group["source_ids"] == ids and group["fit_end"] == end
            x, y, weights, per_site = source_data(series, cfg, ids, group["horizon"], end)
            assert group["total_training_labels"] == len(y)
            close(group["weight_sum"], 1., atol=1e-14, rtol=0)
            assert group["intercept_penalized"] is False
            for site_diag, independent in zip(group["sites"], per_site):
                assert site_diag["training_labels"] == len(independent["y"])
                close(site_diag["scale_m3"], independent["scale"], atol=0, rtol=0)
                close(site_diag["weight_sum"], 1 / len(ids), atol=0, rtol=0)
                close(site_diag["individual_sample_weight"], 1 / (len(ids) * len(independent["y"])), atol=0, rtol=0)
                assert site_diag["normalization_fit_end"] == end and site_diag["last_train_target"] <= end
            name = f"{group['group']}_H{group['horizon']}"
            with np.load(folder / (name + ".npz"), allow_pickle=False) as saved:
                model = {key: saved[key].copy() for key in saved.files}
            close(model["alphas"], cfg["ridge_alphas"], atol=0, rtol=0)
            for j, alpha in enumerate(model["alphas"]):
                coefficient, intercept = normal_equation(x, y, alpha, weights)
                close(model["residual_coefs"][j], coefficient)
                close(model["residual_intercepts"][j], intercept)
                count("independent_source_residual_normal_equation_checks")
            bank[name] = model
        grid = csv(folder / "residual_fallback_grid.csv")
        folds = read_json(folder / "pseudo_validation_folds.json")
        assert len(folds) == 36 and len(grid) == 36 * 72
        for fold in folds:
            site, date, b, h = fold["held_out_source"], fold["date"], fold["budget"], fold["horizon"]
            assert site in cfg["source_ids"] and date in cfg["source_pseudo_origins"]
            excluded = linked(site, related)
            assert fold["excluded_linked_ids"] == sorted(excluded)
            assert fold["shared_fit_sites"] == [s for s in pool["site_ids"] if s not in excluded]
            assert fold["shared_fit_end"] == "2020-12-31" and pd.Timestamp(date) > pd.Timestamp("2020-12-31")
            left, end = pd.Timestamp(date) - pd.Timedelta(days=b), pd.Timestamp(date) - pd.Timedelta(days=1)
            norm = scale(series[site], left, end)
            tr = training(series[site], left, end, h, norm)
            val = samples(series[site], pd.date_range(date, periods=14), h, left, norm, training=True)
            assert tr["targets"].max() <= end and val["targets"].max() <= pd.Timestamp("2021-12-31")
            assert len(tr["y"]) == fold["fitting_labels"] and len(val["y"]) == fold["validation_labels"]
            saved = grid[grid.fold_id.eq(fold["fold_id"])]
            compare_grid(saved, independent_grid(tr, val, bank[f"loso_{site}_H{h}"], cfg))
            count("independent_source_pseudo_folds_checked")
        for b, h in itertools.product(cfg["budgets"], cfg["horizons"]):
            q = grid[grid.budget.eq(b) & grid.horizon.eq(h)]
            choices = bank["selection"]["fallback_settings"][f"B{b}_H{h}"]["parameters"]
            for family in ["local_residual_ridge", "shared_residual_ridge", "shared_residual_ridge_bias"]:
                check_choice(choices[family + "_selected"], choose(q, family))
        banks[pool["pool_id"]] = bank
        print(f"independent source audit {pool['pool_id']} complete", flush=True)
    return banks


def audit_targets(root, cfg, series, banks, predictions, manifest):
    jobroot = root / cfg["output"] / "jobs"
    signature = manifest["signature"]
    for i, (episode, site, budget, h) in enumerate(itertools.product(
            cfg["evaluation_origins"], cfg["development_ids"], cfg["budgets"], cfg["horizons"])):
        name = f"{site}_{episode}_B{budget}_H{h}"
        folder = jobroot / name
        state = read_json(folder / "status.json")
        assert state["status"] == "COMPLETED" and state["prediction_rows"] == 60 * 17
        task = [site, episode, budget, h]
        expected = hashlib.sha256(json.dumps(dict(signature=signature, task=task,
            pools=[p["pool_id"] for p in cfg["pools"]]), sort_keys=True, allow_nan=False).encode()).hexdigest()
        assert state["fingerprint"] == expected
        check_hashes(folder, state, ["predictions.csv", "selection.json", "parameters.json", "ridge_parameters.npz", "diagnostics.json", "validation_grid.csv"])
        q = csv(folder / "predictions.csv")
        assert len(q) == 60 * 17
        aggregate = predictions[predictions.site_id.eq(site) & predictions.episode.eq(episode)
                                & predictions.budget.eq(budget) & predictions.horizon.eq(h)]
        ak = ["pool_id", "model", "origin", "target_date"]
        qa, qb = q.set_index(ak).sort_index(), aggregate.set_index(ak).sort_index()
        assert qa.index.equals(qb.index)
        for column in ["truth_m3", "prediction_m3", "prediction_nonnegative_m3", "scale_m3", "alpha", "shrinkage", "bias_m3"]:
            if column in ('alpha', 'shrinkage'):
                close(qa[column], qb[column], atol=0, rtol=0)
            else:
                close(qa[column], qb[column], atol=1e-8, rtol=1e-12)
        left, end = pd.Timestamp(episode) - pd.Timedelta(days=budget), pd.Timestamp(episode) - pd.Timedelta(days=1)
        norm = scale(series[site], left, end)
        tr = training(series[site], left, end, h, norm)
        test = samples(series[site], pd.date_range(episode, periods=60), h, left, norm)
        assert tr["targets"].max() <= end
        diag, selection, choices = read_json(folder / "diagnostics.json"), read_json(folder / "selection.json"), read_json(folder / "parameters.json")
        assert diag["training_labels"] == len(tr["y"]) and diag["deployment_label_updates"] is False
        assert diag["normalization_fit_start"] == str(left.date()) and diag["normalization_fit_end"] == str(end.date())
        close(diag["scale_m3"], norm, atol=0, rtol=0)
        threshold_left = pd.Timestamp(episode) - pd.Timedelta(days=30)
        threshold_history = series[site].loc[threshold_left:end].dropna()
        threshold = float(threshold_history.quantile(.9)) if len(threshold_history) >= 14 else np.nan
        close(q.high_threshold_m3, threshold, atol=1e-8, rtol=1e-12)
        assert q.threshold_start.eq(str(threshold_left.date())).all() and q.threshold_end.eq(str(end.date())).all()
        assert selection["selection_uses_deployment_labels"] is False
        fold = selection["fold"]
        split = end - pd.Timedelta(days=math.ceil(.2 * budget) - 1)
        fit_end = split - pd.Timedelta(days=1)
        cvscale = scale(series[site], left, fit_end)
        fit = training(series[site], left, fit_end, h, cvscale)
        val = samples(series[site], pd.date_range(split, end - pd.Timedelta(days=h)), h, left, cvscale, training=True)
        valid = len(fit["y"]) >= cfg["validation_min_fit_labels"] and len(val["y"]) >= cfg["validation_min_labels"]
        assert bool(fold["valid"]) == valid
        assert len(fit["y"]) == fold["fitting_labels"] and len(val["y"]) == fold["validation_labels"]
        assert fold["normalization_fit_end"] == str(fit_end.date())
        assert fit["targets"].max() < split and val["targets"].max() <= end
        if valid:
            assert not fold["source_assisted"] and fold["shared_proxy_fit_end"] == "2020-12-31"
            grid = csv(folder / "validation_grid.csv")
            assert len(grid) == 7 * 72
            for pool in cfg["pools"]:
                pool_id = pool["pool_id"]
                saved = grid[grid.pool_id.eq(pool_id)]
                compare_grid(saved, independent_grid(fit, val, banks[pool_id][f"proxy_H{h}"], cfg))
                for family in ["local_residual_ridge", "shared_residual_ridge", "shared_residual_ridge_bias"]:
                    check_choice(selection["parameters_by_pool"][pool_id][family + "_selected"], choose(saved, family))
        else:
            assert fold["source_assisted"] and fold["local_hyperparameter_source_pool"] == "K3"
            assert fold["fallback_source_fit_end"] == "2020-12-31"
            for pool in cfg["pools"]:
                pool_id = pool["pool_id"]
                source = banks[pool_id]["selection"]["fallback_settings"][f"B{budget}_H{h}"]["parameters"]
                for model in [LOCAL, "shared_residual_ridge_selected", PRIMARY]:
                    choice = selection["parameters_by_pool"][pool_id][model]
                    expected = banks["K3"]["selection"]["fallback_settings"][f"B{budget}_H{h}"]["parameters"][model] if model == LOCAL else source[model]
                    assert choice == expected
                    count("source_assisted_parameter_choices_checked")
        with np.load(folder / "ridge_parameters.npz", allow_pickle=False) as stored:
            for (pool_id, model), actual in q.groupby(["pool_id", "model"], sort=False):
                actual = actual.sort_values("origin")
                close(actual.truth_m3 / norm, test["y"], atol=1e-12, rtol=1e-12)
                if model == "persistence":
                    expected = test["p"]
                elif model == "weekly_persistence":
                    expected = test["weekly"]
                else:
                    decision = choices[pool_id + "::" + model]
                    alpha, lam = decision["alpha"], decision["shrinkage"]
                    assert alpha in cfg["ridge_alphas"] and lam in cfg["lambdas"]
                    if model == LOCAL:
                        coef, intercept = normal_equation(tr["x"], residual(tr), alpha)
                        close(stored["baseline_local_coef"], coef)
                        close(stored["baseline_local_intercept"], intercept)
                        bias = 0.
                    else:
                        index = cfg["ridge_alphas"].index(alpha)
                        source = banks[pool_id][f"final_H{h}"]
                        coef, intercept = source["residual_coefs"][index], source["residual_intercepts"][index]
                        close(stored[pool_id + "__" + model + "__coef"], coef, atol=0, rtol=0)
                        close(stored[pool_id + "__" + model + "__intercept"], intercept, atol=0, rtol=0)
                        bias = float(np.mean(residual(tr) - (tr["x"] @ coef + intercept))) if model == PRIMARY else 0.
                        close(stored[pool_id + "__" + model + "__bias"], bias)
                        close(decision["bias_normalized"], bias)
                    close(decision["bias_m3"] / norm, bias)
                    expected = test["p"].copy() if lam == 0 else test["p"] + lam * (test["x"] @ coef + intercept + bias) * norm
                    if lam != 0:
                        expected[~test["available"]] = np.nan
                    if lam == 0:
                        assert np.array_equal(actual.prediction_m3.to_numpy(), test["p"], equal_nan=True)
                        count("lambda_zero_exact_task_checks")
                close(actual.prediction_m3.to_numpy() / norm, expected / norm)
                count("independent_prediction_reconstruction_tasks_checked")
        count("independent_target_jobs_checked")
        if (i + 1) % 30 == 0:
            print(f"independent target audit {i+1}/300", flush=True)


def compare_frame(expected, saved, keys, columns, atol=1e-8, rtol=1e-12):
    a, b = expected.set_index(keys).sort_index(), saved.set_index(keys).sort_index()
    assert a.index.equals(b.index)
    close(a[columns], b[columns], atol=atol, rtol=rtol)
    count("independent_metric_or_loss_rows_checked", len(a))


def station_metrics(daily, per_episode=False):
    keys = METRIC[:]
    if per_episode:
        keys.insert(1, "episode")
    result = daily.groupby(keys).agg(n_dates=("origin", "size"), mae_m3=("absolute_error", "mean"), mse=("squared_error", "mean")).reset_index()
    result["rmse_m3"] = np.sqrt(result.pop("mse"))
    basekeys = [k for k in keys if k not in ["pool_id", "model"]]
    base = result[result.pool_id.eq("baseline") & result.model.eq("persistence")][basekeys + ["mae_m3"]]
    result = result.merge(base.rename(columns={"mae_m3": "persistence_mae_m3"}), on=basekeys, validate="many_to_one")
    result["skill_vs_persistence"] = 1 - result.mae_m3 / result.persistence_mae_m3.where(result.persistence_mae_m3.gt(0))
    return result, keys


def check_summaries(metric, summary, per_episode=False):
    keys = ["evaluation_set", "constraint", "pool_id", "model", "budget", "horizon"]
    if per_episode:
        keys.insert(1, "episode")
    s = summary.set_index(keys)
    for key, group in metric.groupby(keys):
        row = s.loc[key]
        skill = group.skill_vs_persistence.dropna()
        close(row.mean_skill, skill.mean(), atol=1e-12, rtol=1e-12)
        close(row.median_skill, skill.median(), atol=1e-12, rtol=1e-12)
        wins, ties, losses = int(skill.gt(TIE).sum()), int(skill.abs().le(TIE).sum()), int(skill.lt(-TIE).sum())
        assert row.winning_stations == wins and row.tied_stations == ties and row.worse_stations == losses
        close([row.win_fraction, row.tie_fraction, row.loss_fraction], np.array([wins, ties, losses]) / len(skill), atol=1e-12, rtol=1e-12)
        count("independent_summary_rows_checked")


def audit_arithmetic(root, cfg, report, p):
    assert len(p) == 300 * 17 * 60 and not p.duplicated(ROWS).any()
    assert p.seed.eq(0).all() and p.physical_mapping_verified.eq(False).all()
    assert pd.to_datetime(p.target_date).max() <= pd.Timestamp("2023-12-31")
    assert (pd.to_datetime(p.target_date) - pd.to_datetime(p.origin)).dt.days.eq(p.horizon).all()
    assert pd.to_datetime(p.last_train_target).le(pd.to_datetime(p.fit_end)).all()
    assert pd.to_datetime(p.latest_input_date).le(pd.to_datetime(p.origin)).all()
    assert p.groupby(KEYS).size().eq(3 * 17).all()
    common = (np.isfinite(p.truth_m3) & np.isfinite(p.prediction_m3) & p.prediction_row_present).groupby([p[k] for k in KEYS]).all()
    assert np.array_equal(p.common_evaluation.to_numpy(), p.set_index(KEYS).index.map(common))
    close(p.prediction_nonnegative_m3, np.maximum(0., p.prediction_m3), atol=0, rtol=0)
    threshold_range = p.groupby(KEYS).high_threshold_m3.agg(["min", "max"])
    close(threshold_range["min"], threshold_range["max"], atol=0, rtol=0)
    truth_range = p.groupby(KEYS).truth_m3.agg(["min", "max"])
    # Truth was reconstructed as (volume/allowed-history-scale)*scale.
    # Across B this can differ in the last binary bits, as specified by the
    # predeclared metric/truth tolerance; this is not a different label.
    close(truth_range["min"], truth_range["max"], atol=1e-8, rtol=1e-12)
    frames = []
    for constraint, prediction in [("raw", "prediction_m3"), ("all_models_nonnegative", "prediction_nonnegative_m3")]:
        q = p[p.common_evaluation].copy()
        error = q[prediction] - q.truth_m3
        q["absolute_error"], q["squared_error"] = abs(error), error * error
        q["constraint"] = constraint
        frames.append(q)
    daily = pd.concat(frames, ignore_index=True)
    loss_keys = ["evaluation_set", "constraint"] + ROWS
    compare_frame(daily, csv(report / "daily_losses.csv.gz"), loss_keys, ["absolute_error", "squared_error"])
    high = daily[daily.truth_m3.ge(daily.high_threshold_m3) & daily.high_threshold_m3.notna()]
    for values, name, summary, episode in [(daily, "metrics_by_station.csv", "summary.csv", False),
                                          (daily, "metrics_by_station_window.csv", "summary_by_window.csv", True),
                                          (high, "high_volume_metrics_by_station.csv", "high_volume_summary.csv", False)]:
        calculated, keys = station_metrics(values, episode)
        saved = csv(report / name)
        assert not saved[saved.n_dates.eq(0)].mae_m3.notna().any()
        compare_frame(calculated, saved[saved.n_dates.gt(0)], keys,
                      ["n_dates", "mae_m3", "rmse_m3", "persistence_mae_m3", "skill_vs_persistence"])
        check_summaries(calculated, csv(report / summary), episode)
    for pairname, values in [("paired_comparisons_by_station.csv", daily), ("high_volume_paired_by_station.csv", high)]:
        pairs = csv(report / pairname)
        averaged = values.groupby(["constraint", "site_id", "budget", "horizon", "pool_id", "model"]).absolute_error.agg(["mean", "size"])
        for row in pairs.itertuples(index=False):
            akey = row.constraint, row.site_id, row.budget, row.horizon, row.pool_id, row.model
            bkey = row.constraint, row.site_id, row.reference_budget, row.horizon, row.reference_pool_id, row.reference
            a, b = averaged.loc[akey], averaged.loc[bkey]
            skill = 1 - a["mean"] / b["mean"] if b["mean"] > 0 else np.nan
            close([row.mae_m3, row.reference_mae_m3, row.skill], [a["mean"], b["mean"], skill], atol=1e-8, rtol=1e-12)
            assert row.n_dates == a["size"] == b["size"] == row.reference_n_dates
            assert bool(row.negative_transfer) == bool(skill < -TIE)
            assert bool(row.win) == bool(skill > TIE) and bool(row.tie) == bool(abs(skill) <= TIE)
            count("independent_paired_station_rows_checked")
    cross = csv(report / "cross_budget_by_station.csv")
    pairs = csv(report / "paired_comparisons_by_station.csv")
    comparison_keys = ["id", "constraint", "site_id"]
    compare_frame(pairs[pairs.kind.eq("history_budget_comparison")], cross, comparison_keys, ["mae_m3", "reference_mae_m3", "skill", "n_dates"])
    assert set(zip(cross.budget, cross.reference_budget)) == {(30, 90), (30, 180), (90, 180)}
    transfer = csv(report / "negative_transfer_summary.csv")
    for row in transfer.itertuples(index=False):
        q = pairs[pairs.kind.eq("same_budget_transfer") & pairs.constraint.eq(row.constraint) & pairs.pool_id.eq(row.pool_id)
                  & pairs.model.eq(row.model) & pairs.budget.eq(row.budget) & pairs.horizon.eq(row.horizon) & pairs.reference.eq(row.reference)]
        assert row.negative_transfer_stations == q.negative_transfer.sum()
        close(row.negative_transfer_fraction, q.negative_transfer.sum() / q.skill.notna().sum(), atol=1e-12, rtol=1e-12)
    choice = p[["site_id", "episode", "budget", "horizon", "pool_id", "model", "alpha", "shrinkage", "bias_m3"]].drop_duplicates()
    assert not choice.duplicated(["site_id", "episode", "budget", "horizon", "pool_id", "model"]).any()
    fallback = csv(report / "lambda_fallback.csv")
    for row in fallback.itertuples(index=False):
        q = choice[choice.pool_id.eq(row.pool_id) & choice.model.eq(row.model) & choice.budget.eq(row.budget) & choice.horizon.eq(row.horizon)]
        assert row.tasks == len(q) and row.selected_lambda_zero == q.shrinkage.eq(0).sum()
        close(row.fallback_fraction, q.shrinkage.eq(0).mean(), atol=0, rtol=0)
    base = p[p.pool_id.eq("baseline") & p.model.eq("persistence")].set_index(KEYS + ["budget"]).prediction_m3
    zero = p[p.shrinkage.eq(0)]
    assert np.array_equal(zero.prediction_m3.to_numpy(), base.reindex(zero.set_index(KEYS + ["budget"]).index).to_numpy(), equal_nan=True)
    count("lambda_zero_exact_prediction_rows_checked", len(zero))
    index = csv(report / "paired_evaluation_index.csv.gz").set_index(KEYS)
    assert index.index.sort_values().equals(common.index.sort_values())
    assert np.array_equal(index.sort_index().common_evaluation, common.sort_index())
    count("global_common_calendar_groups_checked", len(common))
    return daily


def independent_primary_intervals(cfg, report, daily):
    """Primitive date gathering, unlike evaluator's optimized rolling sums."""
    saved = csv(report / "paired_block_intervals.csv")
    rows = saved[saved.co_primary.eq(True) & saved.constraint.eq("raw") & saved.subset.eq("all_dates")]
    assert len(rows) == 6 * 3
    assert set(rows.block_days) == {7, 14, 28} and rows.replicates.eq(5000).all()
    close(rows.confidence_level, 1 - .05 / 6, atol=1e-15, rtol=0)
    checked = []
    policies = [(cfg["primary_pool_id"], PRIMARY), ("baseline", "persistence"), ("K3", PRIMARY), ("baseline", LOCAL)]
    ids, episodes = cfg["development_ids"], cfg["evaluation_origins"]
    length = cfg["evaluation_days"]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        for h in cfg["horizons"]:
            q = daily[daily.constraint.eq("raw") & daily.budget.eq(30) & daily.horizon.eq(h)]
            arrays = np.full((len(ids), len(episodes) * length, 4), np.nan)
            for row in q.itertuples(index=False):
                policy = row.pool_id, row.model
                if policy in policies:
                    date = episodes.index(row.episode) * length + (pd.Timestamp(row.origin) - pd.Timestamp(row.episode)).days
                    arrays[ids.index(row.site_id), date, policies.index(policy)] = row.absolute_error
            for block in [7, 14, 28]:
                started = time.perf_counter()
                rng = np.random.default_rng(cfg["bootstrap"]["seed"] + h * 100 + block)
                values = np.empty((5000, 3))
                for replicate in range(5000):
                    picked_dates = []
                    for episode in range(len(episodes)):
                        starts = rng.integers(0, length - block + 1, size=math.ceil(length / block))
                        dates = np.concatenate([np.arange(start, start + block) for start in starts])[:length]
                        assert dates.min() >= 0 and dates.max() < length
                        picked_dates.extend((dates + episode * length).tolist())
                    picked_sites = rng.integers(0, len(ids), size=len(ids))
                    means = np.nanmean(arrays[picked_sites][:, picked_dates], axis=1)
                    with np.errstate(divide="ignore", invalid="ignore"):
                        skills = np.where(means[:, 1:] > 0, 1 - means[:, [0]] / means[:, 1:], np.nan)
                    values[replicate] = np.nanmean(skills, axis=0)
                for j, reference in enumerate(policies[1:]):
                    result = rows[rows.horizon.eq(h) & rows.block_days.eq(block) & rows.reference_pool_id.eq(reference[0]) & rows.reference.eq(reference[1])]
                    assert len(result) == 1
                    row = result.iloc[0]
                    quantile = np.nanquantile(values[:, j], [.025, .975, .05 / 12, 1 - .05 / 12])
                    actual = row[["lower_95", "upper_95", "lower_bonferroni_6", "upper_bonferroni_6"]].to_numpy(float)
                    close(actual, quantile, atol=1e-10, rtol=1e-10)
                    checked.append(dict(horizon=h, block_days=block, reference_pool=reference[0], reference_model=reference[1],
                                        max_absolute_difference=float(np.nanmax(abs(actual - quantile))), replicates=5000))
                print(f"independent primitive bootstrap H{h}/L{block}/5000 done {time.perf_counter()-started:.2f}s", flush=True)
    count("independent_primary_interval_rows_checked", len(checked))
    return checked


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=ROOT)
    ap.add_argument("--config", default=f"configs/{VERSION}/full.json")
    ap.add_argument("--output", default=f"reports/{VERSION}/INDEPENDENT_CHECK.json")
    ap.add_argument("--arithmetic-only", action="store_true", help="Does not imply full model/selection reconstruction")
    args = ap.parse_args()
    root = args.root.resolve()
    started = time.perf_counter()
    cfg = read_json(root / args.config)
    report, run = root / cfg["report_output"], root / cfg["output"]
    freeze = read_json(root / cfg["frozen_manifest"])
    for path, expected in freeze["files_sha256"].items():
        assert digest(root / path) == expected, path
    definition = read_json(root / cfg["source_pool_definition"])
    audit_cohort(root, cfg, definition)
    manifest = read_json(run / "manifest.json")
    assert manifest["status"] == "COMPLETED" and manifest["completed_conditions"] == manifest["expected_conditions"] == 300
    assert manifest["expected_prediction_rows"] == 306000
    assert manifest["config_sha256"] == digest(root / args.config)
    assert manifest["predictions_sha256"] == digest(run / "predictions_all.csv.gz")
    predictions = csv(report / "predictions_all.csv.gz")
    daily = audit_arithmetic(root, cfg, report, predictions)
    intervals = independent_primary_intervals(cfg, report, daily)
    if not args.arithmetic_only:
        series = load_series(root, cfg)
        banks = audit_source_models(root, cfg, definition, series)
        audit_targets(root, cfg, series, banks, predictions, manifest)
    result = dict(status="PASSED", mode="arithmetic_only" if args.arithmetic_only else "full_independent_evidence_audit",
                  counts=COUNTS, bootstrap_checks=intervals, checker_sha256=digest(Path(__file__)),
                  config_sha256=digest(root / args.config), predictions_sha256=digest(report / "predictions_all.csv.gz"),
                  daily_losses_sha256=digest(report / "daily_losses.csv.gz"),
                  tolerances={"metric_absolute_m3": 1e-8, "metric_rtol": 1e-12,
                              "normalized_model_atol": 1e-10, "normalized_model_rtol": 1e-10,
                              "bootstrap_skill_atol": 1e-10, "bootstrap_skill_rtol": 1e-10},
                  evidence_independence="Independent feature, baseline, normal-equation, validation, metric and primitive-bootstrap implementation; no evaluator/runner import",
                  numerical_tolerance_is_not_bitwise_replication=True, no_new_model_training=True,
                  physical_mapping_verified=False, verified_real_time=False, final_2024_2025_performance_used=False,
                  elapsed_seconds=time.perf_counter()-started)
    output = root / args.output
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
