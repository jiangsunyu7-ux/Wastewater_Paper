"""Create the one-time, pre-deployment Stage3C2 specification/content receipt."""
import json
from pathlib import Path
from wastewater.common import sha256,utc_now,write_json

ROOT=Path(__file__).resolve().parents[1]
VERSION='stage3c2_source_scale_v1'
names=['STAGE3C2_PROTOCOL.md',f'configs/{VERSION}/full.json',
       f'data/provenance/{VERSION}/source_pool_definition.json',
       f'data/derived/{VERSION}/daily_candidates.csv',f'data/derived/{VERSION}/manifest.json']
names += ['src/wastewater/'+name for name in ['common.py','shared_data.py','stage3a_data.py',
          'stage3b_models.py','stage3b_experiment.py','stage3c2_source.py','stage3c2_experiment.py','stage3c2_evaluation.py']]
names += ['scripts/'+name for name in ['prepare_stage3c2.py','verify_stage3c2_data.py','check_stage3c2_k3.py','summarize_stage3c2.py','freeze_stage3c2.py']]
names += [str(p.relative_to(ROOT)) for p in sorted((ROOT/'tests').glob('test_stage3c2*.py'))]
freeze=ROOT/f'configs/{VERSION}/FREEZE.json'
if freeze.exists():raise RuntimeError('Frozen specification already exists; do not overwrite')
if list((ROOT/f'runs/{VERSION}').glob('*/jobs/*/predictions.csv')):
    raise RuntimeError('Cannot claim pre-deployment freeze after predictions exist')
result={'status':'FROZEN_BEFORE_STAGE3C2_DEPLOYMENT_PREDICTIONS','frozen_utc':utc_now(),
        'files_sha256':{n:sha256(ROOT/n) for n in names},'expected_target_conditions':300,
        'expected_policies':17,'expected_prediction_rows':306000,'unique_source_pools':7,
        'primary_pool_id':'order20261012_K30','primary_model':'shared_residual_ridge_bias_selected',
        'physical_mapping_verified':False,'reused_development_windows':True,
        'source_pool_rankings_not_performance_selected':True,
        'no_final_period_performance':True,'scope':'prospective frozen development specification; not independent final testing or external preregistration'}
write_json(freeze,result)
print(json.dumps({'status':result['status'],'frozen_files':len(names),'freeze_sha256':sha256(freeze)}))
