"""Recompute matched-date source-scale point metrics and paired block intervals.

No training occurs. A missing run integrity record leaves status PARTIAL even
if available prediction rows happen to have no numerical failures.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import numpy as np

from wastewater.common import sha256
from wastewater.stage3c2_evaluation import summarize_predictions


def verify_run(root, config_path, run, frame, prediction_path):
    """Verify frozen config, each required job artifact, and aggregate values.

    Re-reading the expected task registry prevents a partial run with zero
    failures from being reported as completed. Model fitting is never called.
    """
    from wastewater.stage3c2_experiment import load_config, expected_tasks, task_key, validate_job
    from wastewater.stage3b_experiment import hash_value
    cfg, signature, _ = load_config(config_path)
    manifest = json.loads((run / 'manifest.json').read_text())
    if manifest.get('mode') != 'full':
        raise ValueError('Scientific full evaluation requires mode=full; smoke/K3 checks have their own software audit')
    if manifest.get('signature') != signature or manifest.get('config_sha256') != sha256(root / config_path):
        raise ValueError('Run/configuration fingerprint mismatch')
    if manifest.get('predictions_sha256') != sha256(prediction_path):
        raise ValueError('Aggregate prediction checksum mismatch or incomplete run')
    tasks = expected_tasks(cfg, 'full'); policies = cfg['evaluation_policies']
    expected_rows = cfg['evaluation_days'] * len(policies)
    rows = []
    for task in tasks:
        job = run / 'jobs' / task_key(task)
        fingerprint = hash_value(dict(signature=signature, task=task, pools=[p['pool_id'] for p in cfg['pools']]))
        if not validate_job(job, fingerprint, expected_rows):
            raise ValueError('Expected task is not a fully validated completed task: ' + task_key(task))
        job_frame = pd.read_csv(job / 'predictions.csv', dtype={'site_id': str, 'pool_id': str, 'order_label': str}, low_memory=False)
        if len(job_frame) != expected_rows:
            raise ValueError('Wrong task prediction count: ' + task_key(task))
        rows.append(job_frame)
    if manifest.get('status') != 'COMPLETED' or manifest.get('completed_conditions') != len(tasks) or manifest.get('expected_conditions') != len(tasks):
        raise ValueError('Partial run cannot be promoted to completed by evaluation')
    if len(frame) != len(tasks) * expected_rows:
        raise ValueError('Incomplete aggregate row count')
    job_predictions = pd.concat(rows, ignore_index=True)
    keys = ['site_id', 'episode', 'budget', 'horizon', 'origin', 'target_date', 'pool_id', 'model']
    columns = ['prediction_m3', 'prediction_nonnegative_m3', 'truth_m3', 'high_threshold_m3', 'alpha', 'shrinkage', 'bias_m3', 'scale_m3']
    compared = frame[keys + columns].merge(job_predictions[keys + columns], on=keys, how='outer', suffixes=('', '_job'),
                                           indicator=True, validate='one_to_one')
    if not compared._merge.eq('both').all():
        raise ValueError('Aggregate does not contain exactly the saved task forecasts')
    tolerance = cfg.get('prediction_tolerance', dict(normalized_atol=1e-10, rtol=1e-10))
    checks = []
    for column in columns:
        a = compared[column].to_numpy(float); b = compared[column + '_job'].to_numpy(float)
        scale = compared.scale_m3.to_numpy(float) if column.endswith('_m3') and column != 'scale_m3' else 1.
        atol = float(tolerance.get('normalized_atol', 1e-10)); rtol = float(tolerance.get('rtol', 1e-10))
        if column in ['alpha', 'shrinkage']:
            passed = np.array_equal(a, b, equal_nan=True)
        else:
            passed = np.allclose(a / scale, b / scale, atol=atol, rtol=rtol, equal_nan=True)
        if not passed:
            raise ValueError('Aggregate values differ from saved jobs: ' + column)
        finite = np.isfinite(a) & np.isfinite(b)
        checks.append(dict(column=column, finite_rows=int(finite.sum()),
                           maximum_absolute_difference=float(np.max(np.abs(a[finite]-b[finite]))) if finite.any() else 0.,
                           passed=True, bitwise_csv_values=bool(np.array_equal(a, b, equal_nan=True))))
    return cfg, dict(status='VERIFIED', all_expected_tasks_verified=True, expected_conditions=len(tasks),
                     completed_conditions=len(tasks), expected_policy_conditions=len(tasks)*len(policies),
                     expected_prediction_rows=len(frame), config_sha256=sha256(root/config_path),
                     predictions_sha256=sha256(prediction_path), manifest_sha256=sha256(run/'manifest.json'),
                     aggregate_checks=checks, normalized_atol=float(tolerance.get('normalized_atol',1e-10)),
                     rtol=float(tolerance.get('rtol',1e-10)), tolerance_not_bitwise_reproduction_claim=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True)
    parser.add_argument('--run', required=True, help='Frozen full run directory containing manifest.json and jobs/')
    parser.add_argument('--predictions', help='Defaults to RUN/predictions_all.csv.gz')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    resolve = lambda path: Path(path) if Path(path).is_absolute() else root / path
    run = resolve(args.run)
    prediction_path = resolve(args.predictions) if args.predictions else run / 'predictions_all.csv.gz'
    frame = pd.read_csv(prediction_path, dtype={'site_id': str, 'pool_id': str, 'order_label': str}, low_memory=False)
    config_path = str(resolve(args.config).resolve().relative_to(root.resolve()))
    cfg, integrity = verify_run(root, config_path, run, frame, prediction_path)
    _, _, _, ci = summarize_predictions(frame, cfg, resolve(args.output), integrity)
    print(ci[ci.co_primary.eq(True) & ci.block_days.eq(14)][['horizon', 'reference_pool_id', 'reference',
          'mean_station_skill', 'lower_ci', 'upper_ci']].to_string(index=False))


if __name__ == '__main__':
    main()
