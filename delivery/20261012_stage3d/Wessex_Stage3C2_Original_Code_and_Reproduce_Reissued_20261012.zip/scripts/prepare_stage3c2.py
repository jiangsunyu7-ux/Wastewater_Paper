"""Prepare frozen SiteID-level source pools without reading prediction errors.

All eligibility/name screening uses 2016--2021 raw records. Registered target
IDs and historical model-use IDs are read only from named metadata fields.
No forecasting model is imported, fitted, selected or evaluated here.
"""
from __future__ import annotations

import argparse
import calendar
import hashlib
import json
import math
import re
import resource
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "stage3c2_source_scale_v1"
RAW_SHA = "22f494e2b96fe6fa9550c68971d50c752ddd291793fdc60334d64b2ef089f518"
CANONICAL_SHA = "40f6e6fdb1d09d0afa9c19ba31729b156811ca1cdbb0b317484fdf5fea1d854f"
ORIGINAL_SOURCES = ["13006", "13008", "13012"]
DEVELOPMENT = ["13013", "13015", "13016", "13017", "13022", "13024", "13025", "13028", "13029", "13031"]
ORDER_LABELS = [20261012, 20261013, 20261014]
USE_KEYS = {"source_ids", "source_site_ids", "development_ids", "smoke_ids", "site_id",
            "site_ids", "reserved_source_candidate_ids", "target_site_ids"}
PROTECT_KEYS = {"protected_target_ids", "reserved_target_ids", "holdout_ids", "reserved_target_site_ids",
                "target_holdout_ids", "test_ids", "test_site_ids", "final_test_ids", "target_assignment_now"}


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def digest(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def normalize_name(name):
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", name.casefold())).strip()


def name_keys(name):
    stem = re.sub(r"\s+WATER RECYCLING CENTRE\s*$", "", name, flags=re.I).strip()
    base = normalize_name(re.sub(r"\([^)]*\)", "", stem))
    # Bracket labels are candidate aliases, never evidence of physical identity.
    aliases = [normalize_name(s) for s in re.findall(r"\(([^)]*)\)", stem)]
    return normalize_name(stem), base, aliases


def ids_from(value):
    if isinstance(value, (str, int)):
        text = str(value)
        return [text] if re.fullmatch(r"\d{5}", text) else []
    if isinstance(value, list):
        return [s for v in value for s in ids_from(v)]
    return []


def metadata_inventory(root, candidates):
    """Never open performance CSVs or read errors as selection criteria."""
    records, used, protected, register_evidence = [], set(), set(), []
    paths = []
    for folder in ("configs", "data/provenance", "runs"):
        for path in (root / folder).rglob("*.json"):
            if VERSION in path.parts or "stage3c1" in str(path):
                continue
            if folder == "runs" and path.name not in {"manifest.json", "diagnostics.json", "data_diagnostics.json", "source_diagnostics.json", "selection.json"}:
                continue
            paths.append(path)
    # The feasibility-only reservation draft is inspected for explicitly assigned
    # target IDs; its candidate and source lists are not historical model use.
    feasibility = root / "data/provenance/stage3c1_20261011_v1/cohorts/target_reservation_and_source_pool_draft.json"
    paths.append(feasibility)
    for path in sorted(set(paths)):
        obj = json.loads(path.read_text())
        evidence = {"path": str(path.relative_to(root)), "sha256": sha256(path), "bytes": path.stat().st_size,
                    "metadata_field_ids": [], "protected_field_ids": [], "read_prediction_errors": False}
        actual_use = path != feasibility and path.name not in {"data_provenance_audit.json", "official_snapshot_evidence.json"}
        def visit(value):
            if isinstance(value, dict):
                for key, val in value.items():
                    if key in PROTECT_KEYS:
                        found = ids_from(val)
                        evidence["protected_field_ids"].extend(found)
                        protected.update(found)
                        if found:
                            register_evidence.append({"path": evidence["path"], "field": key, "ids": found})
                    if actual_use and key in USE_KEYS:
                        found = ids_from(val)
                        evidence["metadata_field_ids"].extend(found)
                        used.update(found)
                    # Recurse only to find named ID metadata; numeric losses and
                    # forecasts are ignored and never contribute to any decision.
                    if isinstance(val, (dict, list)):
                        visit(val)
            elif isinstance(value, list):
                for val in value:
                    if isinstance(val, (dict, list)):
                        visit(val)
        visit(obj)
        evidence["metadata_field_ids"] = sorted(set(evidence["metadata_field_ids"]), key=int)
        evidence["protected_field_ids"] = sorted(set(evidence["protected_field_ids"]), key=int)
        records.append(evidence)
    # Also inventory model/task paths: the station ID is a metadata identity,
    # while model weights and per-date loss files are not loaded.
    path_ids = set()
    model_files = []
    for path in (root / "runs").rglob("*"):
        if path.is_file() and path.suffix in {".pt", ".npz", ".pkl"} and VERSION not in path.parts:
            found = re.findall(r"(?:loso|site|target|station)[_-]?(\d{5})", str(path), re.I)
            path_ids.update(found)
            model_files.append({"path": str(path.relative_to(root)), "bytes": path.stat().st_size, "path_site_ids": found})
    used.update(path_ids)
    status = "未找到具名正式保留目标登记；不能据此认定不存在外部名单" if not register_evidence else "发现具名保留目标字段，全部尊重并保守传播关联组"
    return {"status": status, "registered_protected_ids": sorted(protected, key=int),
            "historical_used_ids": sorted(used, key=int), "candidate_ids_with_prior_use": sorted(set(candidates) & used, key=int),
            "register_evidence": register_evidence, "json_metadata_inventory": records,
            "model_file_identity_inventory": model_files, "forecast_performance_used_for_selection": False,
            "scope_limitation": "Local files only; no assurance about Guna/provider/off-project reservations. Candidate eligibility audits are not model use."}


def clean_raw(raw):
    raw = raw.copy()
    raw["value"] = pd.to_numeric(raw.TotalVolume, errors="coerce").astype(float)
    raw["quality"] = raw.QualityFlag.str.strip().str.casefold()
    key = ["SiteID", "Date"]
    variants = raw.drop_duplicates(key + ["value", "quality", "Units"])
    conflicts = pd.MultiIndex.from_frame(variants.loc[variants.duplicated(key, keep=False), key]).unique()
    raw["conflict"] = pd.MultiIndex.from_frame(raw[key]).isin(conflicts)
    raw["valid"] = raw.quality.eq("good") & np.isfinite(raw.value) & raw.value.ge(0) & raw.Units.eq("m3") & ~raw.conflict
    raw["exclusion_reason"] = np.select([raw.conflict, ~np.isfinite(raw.value), raw.Units.ne("m3"),
         raw.quality.eq("missing"), raw.quality.eq("suspect"), raw.quality.eq("good") & raw.value.lt(0), raw.valid],
        ["conflicting_site_day", "nonfinite_value", "non_m3_units", "Missing", "Suspect", "Good_negative", "retained_Good_nonnegative"],
        default="unsupported_quality_flag")
    return raw


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--resume", action="store_true", help="Verify and reuse every hashed completed output")
    args = ap.parse_args()
    root = args.root.resolve()
    out = root / "data/provenance" / VERSION
    derived = root / "data/derived" / VERSION
    status = out / "PREPARATION_STATUS.json"
    raw_path = root / "wastewater_data/raw/wessex_all_2016_2025.csv"
    old_canonical = root / "data/derived/wessex_qa_v3_20261009/daily_candidates.csv"
    candidates_path = root / "data/provenance/stage3b_20261011_v1/future_source_expansion_candidates_pre2022.csv"
    audited_years = root / "data/provenance/stage3c1_20261011_v1/cohorts/source_candidate_coverage_pre2022_rechecked.csv"
    inputs = [raw_path, old_canonical, candidates_path, audited_years, Path(__file__).resolve()]
    start = time.monotonic()
    assert sha256(raw_path) == RAW_SHA, "Raw version changed"
    assert sha256(old_canonical) == CANONICAL_SHA, "Stage3B QA version changed"
    fingerprints = {str(p.relative_to(root)): sha256(p) for p in inputs}
    if status.exists():
        saved = json.loads(status.read_text())
        if not args.resume:
            raise ValueError("Existing version outputs; use --resume to verify without overwriting")
        assert saved["status"] == "COMPLETED" and saved["inputs_sha256"] == fingerprints
        for name, expected in saved["outputs_sha256"].items():
            assert (root / name).is_file() and sha256(root / name) == expected, name
        print(json.dumps({"status": "COMPLETED", "cache": "verified", "outputs": len(saved["outputs_sha256"])}))
        return
    out.mkdir(parents=True, exist_ok=True)
    derived.mkdir(parents=True, exist_ok=True)
    cand = pd.read_csv(candidates_path, dtype={"site_id": str})
    assert len(cand) == 186 and cand.site_id.nunique() == 186
    assert not set(cand.site_id) & set(ORIGINAL_SOURCES + DEVELOPMENT)
    inventory = metadata_inventory(root, set(cand.site_id))
    write_json(out / "historical_use_and_protection_inventory.json", inventory)
    early_frames, name_frames, target_frames = [], [], []
    for chunk in pd.read_csv(raw_path, dtype={"SiteID": str}, chunksize=100000):
        # Names and candidate QA are filtered before reading any post-2021 values.
        early = chunk.loc[chunk.Date.between("2016-01-01", "2021-12-31")]
        wrc = early.loc[early.SiteName.str.contains("WATER RECYCLING CENTRE", regex=False, na=False)]
        name_frames.append(wrc[["SiteID", "SiteName"]].drop_duplicates())
        early_frames.append(wrc.loc[wrc.SiteID.isin(set(cand.site_id) | set(ORIGINAL_SOURCES))])
        target_frames.append(chunk.loc[chunk.SiteID.isin(DEVELOPMENT) & chunk.Date.between("2016-01-01", "2023-12-31")])
    names = pd.concat(name_frames, ignore_index=True).drop_duplicates().sort_values(["SiteID", "SiteName"])
    early = clean_raw(pd.concat(early_frames, ignore_index=True))
    parents = {sid: sid for sid in names.SiteID.unique()}
    def find(a):
        while parents[a] != a:
            parents[a] = parents[parents[a]]
            a = parents[a]
        return a
    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parents[max(ra, rb, key=int)] = min(ra, rb, key=int)
    key_index = {"full": {}, "base": {}, "alias": {}}
    for row in names.itertuples(index=False):
        full, base, aliases = name_keys(row.SiteName)
        key_index["full"].setdefault(full, set()).add(row.SiteID)
        key_index["base"].setdefault(base, set()).add(row.SiteID)
        for a in aliases:
            key_index["alias"].setdefault(a, set()).add(row.SiteID)
    edges = []
    def link(ids, reason, evidence):
        ids = sorted(ids, key=int)
        for i, a in enumerate(ids):
            for b in ids[i+1:]:
                union(a, b)
                edges.append({"site_id_a": a, "site_id_b": b, "relation": reason,
                              "name_evidence": evidence, "physical_relation_verified": False})
    for typ in ("full", "base"):
        for key, ids in key_index[typ].items():
            if len(ids) > 1:
                link(ids, "same_normalized_name" if typ == "full" else "same_main_name_different_bracket_label_suspected", key)
    for alias, ids in key_index["alias"].items():
        if alias in key_index["base"]:
            link(ids | key_index["base"][alias], "bracket_alias_matches_other_main_name_suspected", alias)
    groups = {}
    for sid in parents:
        groups.setdefault(find(sid), []).append(sid)
    groups = {"provisional:" + "|".join(sorted(ids, key=int)): sorted(ids, key=int) for ids in groups.values()}
    site_to_group = {sid: gid for gid, ids in groups.items() for sid in ids}
    # Reused official evidence establishes name matches only and no plant/meter
    # crosswalk. It does not upgrade these provisional text screens to verified.
    official_files = [root / "data/provenance/stage3b_20261011_v1/FACILITY_MAPPING.csv",
        root / "data/provenance/stage3c1_20261011_v1/facilities/facility_mapping_status.csv",
        root / "data/provenance/stage3b_20261011_v1/official_tdv_table_response.bin"]
    official_map = pd.read_csv(official_files[1], dtype={"site_id": str})
    assert not official_map.physical_facility_verified.any()
    pd.DataFrame(edges, columns=["site_id_a", "site_id_b", "relation", "name_evidence", "physical_relation_verified"]).drop_duplicates().to_csv(out / "association_edges.csv", index=False)
    names["provisional_group_id"] = names.SiteID.map(site_to_group)
    names["physical_facility_id"] = "unknown"
    names["physical_mapping_verified"] = False
    names.to_csv(out / "name_and_provisional_group_inventory_pre2022.csv", index=False)
    candidate_raw = early.loc[early.SiteID.isin(cand.site_id)].copy()
    years = []
    for sid, g in candidate_raw.groupby("SiteID", sort=True):
        for year in range(2016, 2022):
            sub = g.loc[g.Date.str[:4].eq(str(year))]
            days = 366 if calendar.isleap(year) else 365
            valid = sub.loc[sub.valid, "Date"].nunique()
            years.append({"site_id": sid, "year": year, "valid_dates": int(valid), "calendar_days": days, "coverage": valid / days})
    year_df = pd.DataFrame(years)
    old_years = pd.read_csv(audited_years, dtype={"site_id": str})
    compare = year_df.merge(old_years[["site_id", "year", "valid_good_nonnegative_nonconflict_dates"]], on=["site_id", "year"], validate="one_to_one")
    assert len(compare) == 1116 and compare.valid_dates.eq(compare.valid_good_nonnegative_nonconflict_dates).all()
    year_df.to_csv(out / "source_candidate_annual_coverage.csv", index=False)
    candidate_raw.groupby(["SiteID", "exclusion_reason"]).size().reset_index(name="raw_rows").rename(columns={"SiteID": "site_id"}).to_csv(out / "source_candidate_disjoint_qa_counts.csv", index=False)
    coverage = year_df.groupby("site_id").coverage.min().to_dict()
    name_count = names.groupby("SiteID").SiteName.nunique().to_dict()
    eligible = {sid for sid in cand.site_id if coverage[sid] >= .95 and name_count.get(sid) == 1}
    used = set(inventory["historical_used_ids"]) | set(ORIGINAL_SOURCES + DEVELOPMENT)
    protected_existing = set(inventory["registered_protected_ids"])
    used_groups = {site_to_group[sid] for sid in used if sid in site_to_group}
    protected_groups = {site_to_group[sid] for sid in protected_existing if sid in site_to_group}
    for gid in groups:
        if set(groups[gid]) & set(ORIGINAL_SOURCES) and set(groups[gid]) & set(DEVELOPMENT):
            raise ValueError("Known/suspected original source-development group conflict; stop")
    representatives = {}
    for gid, ids in groups.items():
        available = sorted(set(ids) & eligible, key=int)
        if available and gid not in used_groups and gid not in protected_groups:
            representatives[gid] = available[0]
    reserve_rank = sorted(representatives, key=lambda g: (digest("Wessex-C2-reserve-v1|" + g), g))
    n_reserve = math.ceil(.2 * len(reserve_rank))
    temporary_groups = set(reserve_rank[:n_reserve])
    remaining = {g: s for g, s in representatives.items() if g not in temporary_groups}
    ranking_rows, pools = [], [{"pool_id": "K3", "order_label": None, "k": 3, "site_ids": ORIGINAL_SOURCES}]
    for order in ORDER_LABELS:
        ordered = sorted(remaining, key=lambda g: (digest(f"Wessex-C2-order-v1|{order}|{g}"), g))
        for rank, gid in enumerate(ordered, 1):
            ranking_rows.append({"order_label": order, "rank": rank, "provisional_group_id": gid,
                "site_id": remaining[gid], "source_rank_sha256": digest(f"Wessex-C2-order-v1|{order}|{gid}")})
        for k in (10, 30):
            if len(ordered) < k - 3:
                raise ValueError(f"Insufficient predetermined source groups for K={k}; no criteria relaxations")
            ids = ORIGINAL_SOURCES + [remaining[g] for g in ordered[:k-3]]
            pools.append({"pool_id": f"order{order}_K{k}", "order_label": order, "k": k, "site_ids": ids})
    pd.DataFrame(ranking_rows).to_csv(out / "source_candidate_rankings.csv", index=False)
    source_union = sorted({s for p in pools for s in p["site_ids"]}, key=int)
    protected_all = protected_groups | temporary_groups
    protected_ids = sorted({s for g in protected_all for s in groups[g]} | protected_existing, key=int)
    assert not set(source_union + DEVELOPMENT) & set(protected_ids)
    group_records = []
    for gid, ids in sorted(groups.items()):
        candidates = sorted(set(ids) & set(cand.site_id), key=int)
        if not candidates and not set(ids) & set(ORIGINAL_SOURCES + DEVELOPMENT + list(protected_existing)):
            continue
        if gid in protected_groups:
            part, reason = "registered_protection", "existing named target register/linked group"
        elif gid in temporary_groups:
            part, reason = "temporary_protection", "lowest fixed reserve SHA256; never fitted/tuned/evaluated in this round"
        elif set(ids) & set(DEVELOPMENT):
            part, reason = "development", "original fixed target IDs; linked siblings excluded from sources"
        elif set(ids) & set(ORIGINAL_SOURCES):
            part, reason = "original_source", "original K3 source group fixed; linked siblings not separately sampled"
        elif gid in used_groups:
            part, reason = "excluded_prior_use", "historical model/config identity metadata indicates prior use"
        elif gid in remaining:
            part = "added_source" if remaining[gid] in source_union else "eligible_not_selected"
            reason = "fixed pre-performance source-rank prefix" if part == "added_source" else "not in any fixed top27 source ordering"
        else:
            part, reason = "excluded_quality_or_name", "not eligible under every-year coverage and one-name rules"
        group_records.append({"provisional_group_id": gid, "all_pre2022_related_siteids": "|".join(ids),
            "candidate_siteids": "|".join(candidates), "representative_site_id": representatives.get(gid, ""),
            "partition": part, "reason": reason, "reserve_sha256": digest("Wessex-C2-reserve-v1|"+gid),
            "reserve_rank": reserve_rank.index(gid)+1 if gid in representatives else "",
            "physical_facility_id": "unknown", "physical_mapping_verified": False,
            "known_or_suspected_multi_measurement": len(ids)>1})
    group_df = pd.DataFrame(group_records)
    group_df.to_csv(out / "partition_group_ledger.csv", index=False)
    group_df.loc[group_df.partition.isin(["temporary_protection", "registered_protection"])].to_csv(out / "temporary_and_registered_protection.csv", index=False)
    eligibility = cand.copy()
    eligibility["rechecked_minimum_year_coverage"] = eligibility.site_id.map(coverage)
    eligibility["pre2022_name_count"] = eligibility.site_id.map(name_count)
    eligibility["provisional_group_id"] = eligibility.site_id.map(site_to_group)
    eligibility = eligibility.merge(group_df[["provisional_group_id", "partition", "reason", "representative_site_id"]], on="provisional_group_id", validate="many_to_one")
    eligibility["physical_mapping_verified"] = False
    eligibility["predictions_or_errors_used_for_selection"] = False
    eligibility.to_csv(out / "all_186_candidate_eligibility_and_partition.csv", index=False)
    source_related = {sid: groups[site_to_group[sid]] for sid in ORIGINAL_SOURCES}
    definition = {"version": VERSION, "stage": "development", "analysis_unit": "station_exploratory",
        "physical_mapping_verified": False, "verified_real_time": False,
        "original_source_ids": ORIGINAL_SOURCES, "development_ids": DEVELOPMENT,
        "smoke_ids": ["13013", "13015"], "order_labels": ORDER_LABELS, "pool_sizes": [3,10,30], "pools": pools,
        "source_related_ids": source_related, "source_union_ids": source_union,
        "source_to_provisional_group": {sid: site_to_group[sid] for sid in source_union},
        "all_related_ids_by_provisional_group": {site_to_group[sid]: groups[site_to_group[sid]] for sid in source_union + DEVELOPMENT},
        "protected_ids": protected_ids, "protected_provisional_groups": sorted(protected_all),
        "temporary_protection_group_count": n_reserve, "eligible_unused_group_count_before_reservation": len(reserve_rank),
        "registered_protection_status": inventory["status"],
        "group_rule": "connected exact normalized names, same bracket-stripped main name, or exact bracket alias/main-name match; provisional:<all group SiteIDs numeric ascending joined by '|'>",
        "representative_rule": "lowest numeric eligible candidate SiteID in provisional group; noneligible linked meters remain same partition but cannot be selected",
        "reserve_rule": "ceil(0.20*N); sort SHA256('Wessex-C2-reserve-v1|' + provisional_group_id) ascending; existing protection first",
        "source_order_rule": "SHA256('Wessex-C2-order-v1|' + str(order_label) + '|' + provisional_group_id) ascending; tie group_id",
        "canonical_csv": f"data/derived/{VERSION}/daily_candidates.csv",
        "source_period": ["2016-01-01", "2021-12-31"], "development_maximum": "2023-12-31",
        "source_b30_validation_exclusion": "remove original pseudo-target SiteID and all known/suspected related IDs; fit other sources only through 2020-12-31",
        "no_independent_physical_facility_validation_claim": True,
        "frozen_before_any_stage3c2_predictions": True}
    write_json(out / "source_pool_definition.json", definition)
    flat = [{"pool_id": p["pool_id"], "order_label": p["order_label"], "k": p["k"], "pool_position": i+1,
             "site_id": sid, "provisional_group_id": site_to_group[sid], "physical_mapping_verified": False}
            for p in pools for i, sid in enumerate(p["site_ids"])]
    pd.DataFrame(flat).to_csv(out / "nested_source_pool_members.csv", index=False)
    # Only selected source rows and original target rows are delivered for models;
    # protected groups are absent, even from caches or pseudo-deployments.
    selected_raw = pd.concat([early.loc[early.SiteID.isin(source_union)], clean_raw(pd.concat(target_frames, ignore_index=True))], ignore_index=True)
    selected_raw = selected_raw.sort_values(["SiteID", "Date", "OBJECTID"])
    selected_raw[["OBJECTID", "SiteName", "SiteID", "Date", "TotalVolume", "Units", "QualityFlag"]].to_csv(
        out / "selected_model_raw_records.csv.gz", index=False, compression={"method":"gzip", "mtime":0})
    selected_raw.loc[~selected_raw.valid].to_csv(out / "excluded_selected_raw_records.csv.gz", index=False, compression={"method":"gzip", "mtime":0})
    first = selected_raw.drop_duplicates(["SiteID", "Date"])
    canonical = pd.DataFrame({"site_id": first.SiteID, "date": first.Date,
        "candidate_value_m3": first.value.where(first.valid), "observed_input_m3": first.value.where(first.valid),
        "target_quality_valid": first.valid.astype(int), "conflict": first.conflict.astype(int),
        "source_records": first.OBJECTID.astype(str), "input_changed_from_v2": np.nan,
        "qa_mode": "published_good_only_retrospective"})
    prior = pd.read_csv(old_canonical, dtype={"site_id": str})
    old_scope = prior.loc[prior.site_id.isin(DEVELOPMENT) | (prior.site_id.isin(ORIGINAL_SOURCES) & prior.date.le("2021-12-31"))]
    new_scope = canonical.loc[canonical.site_id.isin(DEVELOPMENT + ORIGINAL_SOURCES)]
    pair = old_scope.merge(new_scope, on=["site_id","date"], suffixes=("_old","_new"), validate="one_to_one", how="outer", indicator=True)
    assert pair._merge.eq("both").all()
    for column in ["candidate_value_m3", "observed_input_m3"]:
        a, b = pair[column+"_old"].to_numpy(), pair[column+"_new"].to_numpy()
        assert np.array_equal(np.isnan(a), np.isnan(b))
        assert np.array_equal(a[np.isfinite(a)], b[np.isfinite(b)])
    assert pair.target_quality_valid_old.eq(pair.target_quality_valid_new).all()
    assert pair.conflict_old.eq(pair.conflict_new).all()
    # Preserve all archived ancillary fields for old cohorts; new sites have no
    # v2 comparison rather than fabricating input_changed_from_v2=False.
    canonical = pd.concat([old_scope, canonical.loc[~canonical.site_id.isin(DEVELOPMENT + ORIGINAL_SOURCES)]], ignore_index=True).sort_values(["site_id","date"])
    assert not set(canonical.site_id) & set(protected_ids)
    assert canonical.loc[canonical.site_id.isin(source_union), "date"].le("2021-12-31").all()
    assert canonical.loc[canonical.site_id.isin(DEVELOPMENT), "date"].le("2023-12-31").all()
    canonical.to_csv(derived / "daily_candidates.csv", index=False)
    canonical.to_csv(derived / "daily_candidates.csv.gz", index=False, compression={"method":"gzip", "mtime":0})
    all_inputs = {str(p.relative_to(root)): {"sha256": sha256(p), "bytes":p.stat().st_size} for p in inputs + official_files}
    summary = {"status":"COMPLETED", "version":VERSION, "candidate_count":186, "candidate_eligible_count":len(eligible),
        "name_screen_pre2022_siteids":names.SiteID.nunique(), "candidate_eligible_unused_provisional_groups":len(reserve_rank),
        "temporary_protected_groups":n_reserve, "temporary_protected_ids":len(protected_ids),
        "prior_use_candidate_ids":inventory["candidate_ids_with_prior_use"], "source_union_count":len(source_union),
        "canonical_rows":len(canonical), "original_cohort_exact_comparison_rows":len(pair),
        "original_cohort_value_mask_comparison":"exact float64 values and masks; no tolerance used",
        "source_pool_count":len(pools), "no_candidate_post2021_quality_or_performance_selection":True,
        "protected_records_in_model_inputs":0, "physical_mapping_verified":False, "model_fits":0,
        "post2023_performance_read":False, "input_files":all_inputs,
        "seconds":time.monotonic()-start, "peak_rss_mib":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024}
    write_json(out / "PREPARATION_AUDIT.json", summary)
    manifest = {"status":"completed", "version":VERSION,
                "outputs_sha256": {"daily_candidates.csv":sha256(derived / "daily_candidates.csv"),
                                   "daily_candidates.csv.gz":sha256(derived / "daily_candidates.csv.gz")},
                "raw_sha256":RAW_SHA, "qa_rule":"Good & finite & nonnegative & Units=m3 & no conflicting site-day; no interpolation",
                "source_fitting_cutoff":"2021-12-31", "target_cutoff":"2023-12-31", "physical_mapping_verified":False}
    write_json(derived / "manifest.json", manifest)
    members = [p for folder in (out,derived) for p in folder.iterdir() if p.is_file() and p != status]
    outputs = {str(p.relative_to(root)):sha256(p) for p in sorted(members)}
    write_json(status, {"status":"COMPLETED", "expected_output_files":len(outputs), "completed_output_files":len(outputs),
        "inputs_sha256":fingerprints, "outputs_sha256":outputs, "completed_utc":datetime.now(timezone.utc).isoformat()})
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
