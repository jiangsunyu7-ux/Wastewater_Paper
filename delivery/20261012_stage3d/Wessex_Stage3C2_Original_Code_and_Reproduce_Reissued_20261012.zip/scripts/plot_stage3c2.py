#!/usr/bin/env python3
"""Plot the finite source-scale experiment from saved, complete evaluations.

No fitting, synthetic curves, prediction ensembles, or outcome-dependent
source/window selection is performed here. All registered source compositions
are shown. Raw forecasts are primary; the uniformly clipped sensitivity remains
in the underlying tables rather than replacing the primary plots.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
VERSION = "stage3c2_source_scale_v1"
SHARED = "shared_residual_ridge_selected"
BIAS = "shared_residual_ridge_bias_selected"
LOCAL = "local_residual_ridge_selected"
COLORS = {"20261012": "#0072B2", "20261013": "#D55E00", "20261014": "#009E73"}
MODELS = [(SHARED, "Shared residual Ridge", "--", "s"),
          (BIAS, "Shared residual Ridge + bias", "-", "o")]
NOTE = "All five windows previously used; retrospective quality flags; unverified physical mapping."


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_csv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, dtype={"site_id": str, "order_label": str, "pool_id": str})


def one(frame: pd.DataFrame, **conditions) -> pd.Series:
    chosen = frame
    for key, value in conditions.items():
        chosen = chosen[chosen[key].eq(value)]
    if len(chosen) != 1:
        raise ValueError(f"Expected one saved row for {conditions}, found {len(chosen)}")
    return chosen.iloc[0]


def style_axis(ax):
    ax.axhline(0, color="#555555", lw=.8, zorder=1)
    ax.grid(axis="y", color="#DDDDDD", lw=.5, zorder=0)
    ax.spines[["top", "right"]].set_visible(False)
    ax.tick_params(length=3)


def save(fig, output: Path, name: str):
    for extension in ("pdf", "svg", "png"):
        fig.savefig(output / f"{name}.{extension}", bbox_inches="tight", dpi=180)
    plt.close(fig)


def curves(summary, budget, horizon, model, order):
    rows = [one(summary, budget=budget, horizon=horizon, model=model, pool_id="K3")]
    rows += [one(summary, budget=budget, horizon=horizon, model=model,
                 pool_id=f"order{order}_K{k}") for k in (10, 30)]
    return np.asarray([r.mean_skill for r in rows], dtype=float) * 100


def plot_source_scale(summary, cfg, output):
    fig, axes = plt.subplots(3, 2, figsize=(11, 10), sharex=True)
    for row, budget in enumerate(cfg["budgets"]):
        for col, horizon in enumerate(cfg["horizons"]):
            ax = axes[row, col]
            for order, color in COLORS.items():
                for model, model_label, linestyle, marker in MODELS:
                    ax.plot([3, 10, 30], curves(summary, budget, horizon, model, order),
                            color=color, ls=linestyle, marker=marker, ms=4,
                            lw=1.5, label=f"{order}: {model_label}", zorder=3)
            local = one(summary, pool_id="baseline", model=LOCAL, budget=budget, horizon=horizon)
            ax.axhline(local.mean_skill * 100, color="#777777", ls=":", lw=1.3,
                       label="Strong local residual Ridge")
            style_axis(ax)
            ax.set_title(f"Initial history {budget} days; horizon {horizon} day(s)")
            ax.set_xticks([3, 10, 30])
            if row == 2:
                ax.set_xlabel("Source SiteIDs, K")
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=2, frameon=False, fontsize=8,
               bbox_to_anchor=(.5, .035))
    fig.supylabel("Equal-SiteID mean MAE skill vs Persistence (%)", x=.005)
    fig.suptitle("Source-pool scale and composition: both shared residual policies", y=.985)
    fig.text(.5, .005, NOTE, ha="center", fontsize=8)
    fig.tight_layout(rect=(.035, .19, 1, .96))
    save(fig, output, "source_scale_skill")


def plot_negative_transfer(pairs, cfg, output):
    q = pairs[pairs.kind.eq("same_budget_transfer") & pairs.constraint.eq("raw")]
    fig, axes = plt.subplots(3, 2, figsize=(12, 10), sharex=True)
    sites = list(map(str, cfg["development_ids"]))
    for row, budget in enumerate(cfg["budgets"]):
        for col, horizon in enumerate(cfg["horizons"]):
            ax = axes[row, col]
            positions = np.arange(len(sites), dtype=float)
            for order_idx, (order, color) in enumerate(COLORS.items()):
                for model_idx, (model, model_label, _, marker) in enumerate(MODELS):
                    pool = f"order{order}_K30"
                    subset = q[q.budget.eq(budget) & q.horizon.eq(horizon) & q.pool_id.eq(pool) & q.model.eq(model)]
                    if set(subset.site_id) != set(sites) or len(subset) != len(sites):
                        raise ValueError(f"Missing transfer comparisons: {pool}, {model}, B{budget}, h{horizon}")
                    values = subset.set_index("site_id").loc[sites].skill.to_numpy(float) * 100
                    ax.scatter(positions + (order_idx - 1) * .2 + (model_idx - .5) * .06,
                               values, s=22, color=color, marker=marker,
                               label=f"{order}: {model_label}",
                               facecolors="none" if model_idx == 0 else color, linewidths=.9, zorder=3)
            style_axis(ax)
            ax.set_title(f"Initial history {budget} days; horizon {horizon} day(s)")
            ax.set_xticks(positions, sites, rotation=55, ha="right")
            ax.tick_params(labelbottom=True)
            if row == 2:
                ax.set_xlabel("Development SiteID")
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=2, frameon=False, fontsize=8,
               bbox_to_anchor=(.5, .035))
    fig.supylabel("Per-SiteID MAE skill vs matched local Ridge (%)", x=.005)
    fig.suptitle("K=30 per-SiteID transfer: negative values denote negative transfer", y=.985)
    fig.text(.5, .005, NOTE, ha="center", fontsize=8)
    fig.tight_layout(rect=(.035, .17, 1, .96))
    save(fig, output, "negative_transfer_by_site")


def plot_cross_budget(intervals, cfg, output):
    q = intervals[intervals.constraint.eq("raw") & intervals.block_days.eq(14)
                  & intervals.kind.eq("history_budget_comparison")]
    fig, axes = plt.subplots(3, 2, figsize=(11, 10), sharex=True)
    for row, (budget, ref_budget) in enumerate([(30, 90), (30, 180), (90, 180)]):
        for col, horizon in enumerate(cfg["horizons"]):
            ax = axes[row, col]
            for order, color in COLORS.items():
                for model, model_label, linestyle, marker in MODELS:
                    points = [one(q, budget=budget, reference_budget=ref_budget,
                                  horizon=horizon, model=model, pool_id="K3")]
                    points += [one(q, budget=budget, reference_budget=ref_budget,
                                   horizon=horizon, model=model, pool_id=f"order{order}_K{k}") for k in (10, 30)]
                    values = np.asarray([r.mean_station_skill for r in points]) * 100
                    ax.plot([3, 10, 30], values, color=color, ls=linestyle, marker=marker,
                            ms=4, lw=1.3, label=f"{order}: {model_label}")
                    if order == "20261012" and model == BIAS:
                        lower = np.asarray([r.lower_ci for r in points]) * 100
                        upper = np.asarray([r.upper_ci for r in points]) * 100
                        ax.vlines([3, 10, 30], lower, upper, color=color, alpha=.55, lw=1.2,
                                  label="Order 20261012 + bias: exploratory 95% CI")
            style_axis(ax)
            ax.set_title(f"Shared {budget} days vs local {ref_budget} days; horizon {horizon}")
            ax.set_xticks([3, 10, 30])
            if row == 2:
                ax.set_xlabel("Source SiteIDs, K")
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=2, frameon=False, fontsize=8,
               bbox_to_anchor=(.5, .035))
    fig.supylabel("Equal-SiteID mean MAE skill vs longer-history local (%)", x=.005)
    fig.suptitle("Cross-budget comparisons: descriptive evidence, without an equivalence margin", y=.985)
    fig.text(.5, .005, NOTE, ha="center", fontsize=8)
    fig.tight_layout(rect=(.035, .19, 1, .96))
    save(fig, output, "cross_budget_skill")


def plot_baselines(summary, cfg, output):
    """Keep weak/negative controls visible separately from source-scale curves."""
    fig,axes=plt.subplots(1,2,figsize=(11,4))
    for ax,h in zip(axes,cfg['horizons']):
        for j,(model,label,color) in enumerate([
            ('persistence','Persistence','#555555'),
            ('weekly_persistence','Weekly persistence','#D55E00'),
            (LOCAL,'Local residual Ridge','#0072B2')]):
            vals=[one(summary,pool_id='baseline',model=model,budget=b,horizon=h).mean_skill*100 for b in cfg['budgets']]
            ax.bar(np.arange(3)+(j-1)*.23,vals,width=.23,color=color,label=label)
        ax.set_xticks(np.arange(3),[f'B{b}' for b in cfg['budgets']]);style_axis(ax)
        ax.set_title(f'Forecast horizon {h} day(s)');ax.set_xlabel('Initial local history')
    axes[0].set_ylabel('Equal-SiteID MAE skill vs Persistence (%)')
    handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',ncol=3,frameon=False,bbox_to_anchor=(.5,.055))
    fig.suptitle('Matched baseline performance: all negative values retained')
    fig.text(.5,.005,NOTE,ha='center',fontsize=8);fig.tight_layout(rect=(0,.2,1,.9))
    save(fig,output,'baseline_comparison')


def plot_lambda(fallback, cfg, output):
    pools = [p["pool_id"] for p in cfg["pools"]]
    labels = ["K3 (common)"] + [f"{p['order_label']}: K{p['k']}" for p in cfg["pools"][1:]]
    conditions = [(b, h) for b in cfg["budgets"] for h in cfg["horizons"]]
    fig, axes = plt.subplots(1, 2, figsize=(12, 5), sharey=True)
    for ax, (model, title, _, _) in zip(axes, MODELS):
        values = np.empty((len(pools), len(conditions)))
        for i, pool in enumerate(pools):
            for j, (budget, horizon) in enumerate(conditions):
                saved = one(fallback, pool_id=pool, model=model, budget=budget, horizon=horizon)
                if saved.tasks != len(cfg["development_ids"]) * len(cfg["origins"]) or saved.missing_lambda != 0:
                    raise ValueError("Incomplete initial-history parameter choices")
                values[i, j] = saved.fallback_fraction * 100
        # Render individual cells as vector paths, not an embedded raster image.
        image = ax.pcolormesh(np.arange(len(conditions)+1)-.5,
                              np.arange(len(pools)+1)-.5, values,
                              vmin=0, vmax=100, cmap="Blues", shading="flat")
        ax.set_ylim(len(pools)-.5, -.5)
        for i in range(len(pools)):
            for j in range(len(conditions)):
                ax.text(j, i, f"{values[i,j]:.0f}%", ha="center", va="center",
                        color="white" if values[i,j] > 55 else "black", fontsize=8)
        ax.set_title(title)
        ax.set_xticks(range(len(conditions)), [f"B{b}\nh{h}" for b, h in conditions])
        ax.set_yticks(range(len(pools)), labels)
    colorbar=fig.colorbar(image, ax=axes.tolist(), label="Initial-history tasks selecting lambda = 0 (%)", fraction=.022, pad=.025)
    if colorbar.solids is not None:
        colorbar.solids.set_rasterized(False)
    fig.suptitle("Frozen shrinkage choices: zero correction is Persistence, not a sharing gain", y=.985)
    fig.text(.5, .005, NOTE, ha="center", fontsize=8)
    fig.subplots_adjust(left=.18, right=.88, bottom=.13, top=.82, wspace=.16)
    save(fig, output, "lambda_fallback")


def plot_primary(intervals, output):
    q = intervals[intervals.constraint.eq("raw") & intervals.co_primary.eq(True) & intervals.block_days.eq(14)].copy()
    if len(q) != 6 or not q.finite_replicates.eq(5000).all():
        raise ValueError("Six complete 5000-replicate primary intervals required")
    reference_order = {"persistence": 0, BIAS: 1, LOCAL: 2}
    reference_label = {"persistence": "Persistence", BIAS: "K3 shared residual + bias", LOCAL: "Strong local residual Ridge"}
    q["reference_order"] = q.reference.map(reference_order)
    q = q.sort_values(["horizon", "reference_order"]).reset_index(drop=True)
    fig, ax = plt.subplots(figsize=(10, 5))
    y = np.arange(len(q))
    ax.vlines(0, -.5, len(q)-.5, color="#555555", lw=.9)
    ax.hlines(y, q.lower_ci.to_numpy() * 100, q.upper_ci.to_numpy() * 100,
              color="#0072B2", lw=2)
    ax.scatter(q.mean_station_skill.to_numpy() * 100, y, color="#0072B2", s=30, zorder=3)
    ax.set_yticks(y, [f"h={r.horizon}: vs {reference_label[r.reference]}" for _, r in q.iterrows()])
    ax.invert_yaxis()
    ax.set_xlabel("Equal-SiteID mean paired MAE skill (%)")
    ax.grid(axis="x", color="#DDDDDD", lw=.5)
    ax.spines[["top", "right"]].set_visible(False)
    ax.set_title("Prespecified candidate: order 20261012, K30, residual + bias, B30")
    fig.text(.5, .055, "5000 synchronous 14-day block/SiteID resamples; six-comparison Bonferroni intervals (99.167%).",
             ha="center", fontsize=8)
    fig.text(.5, .01, NOTE, ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .1, 1, 1))
    save(fig, output, "six_primary_comparisons")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--config", default=f"configs/{VERSION}/full.json")
    parser.add_argument("--results", default=f"reports/{VERSION}/results")
    parser.add_argument("--output", default=f"figures/{VERSION}")
    args = parser.parse_args()
    cfg_path, results, output = [args.root / p for p in (args.config, args.results, args.output)]
    cfg = json.loads(cfg_path.read_text())
    integrity = json.loads((results / "evaluation_validation.json").read_text())
    if integrity.get("status") != "COMPLETED" or not integrity.get("experiment_integrity", {}).get("all_expected_tasks_verified"):
        raise ValueError("Partial evaluation must not be plotted as a completed experiment")
    if cfg.get("physical_mapping_verified") is not False or not cfg.get("all_windows_already_used_development"):
        raise ValueError("Scientific context differs from Stage3C2 frozen protocol")
    paths = {name: results / name for name in ["summary.csv", "paired_comparisons_by_station.csv",
                                              "paired_block_intervals.csv", "lambda_fallback.csv"]}
    for name, path in paths.items():
        if sha256(path) != integrity["files_sha256"][name]:
            raise ValueError(f"Saved evaluation SHA differs: {name}")
    output.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9,
                         "axes.titlesize": 10, "axes.labelsize": 9, "figure.titlesize": 12,
                         "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none"})
    summary = read_csv(paths["summary.csv"])
    summary = summary[summary.constraint.eq("raw")]
    pairs = read_csv(paths["paired_comparisons_by_station.csv"])
    intervals = read_csv(paths["paired_block_intervals.csv"])
    fallback = read_csv(paths["lambda_fallback.csv"])
    plot_source_scale(summary, cfg, output)
    plot_baselines(summary, cfg, output)
    plot_negative_transfer(pairs, cfg, output)
    plot_cross_budget(intervals, cfg, output)
    plot_lambda(fallback, cfg, output)
    plot_primary(intervals, output)
    captions = [
        ("source_scale_skill", "Does increasing the frozen source pool improve skill vs Persistence?",
         "summary.csv", "Source-pool scale for all three prespecified compositions and both shared residual Ridge policies. "
         "Each point is the equal-SiteID mean of per-SiteID MAE skill relative to Persistence, pooling five previously used "
         "development windows within each of ten SiteIDs. Local residual Ridge is a matched local comparator; weekly persistence "
         "and local controls, including all negative values, are shown separately in baseline_comparison; "
         "the common K3 point is drawn for each source ordering. All budgets and horizons use matched dates."),
        ("negative_transfer_by_site", "Which SiteIDs exhibit negative transfer, and is it composition-dependent?",
         "paired_comparisons_by_station.csv", "Per-SiteID K30 MAE skill relative to the fairly tuned, same-budget local "
         "residual Ridge. Negative values indicate negative transfer. Open squares denote sharing without local bias; "
         "filled circles denote sharing with bias. All three frozen source compositions, budgets, horizons and SiteIDs are retained."),
        ("cross_budget_skill", "How do shorter-history shared models compare with longer-history local models?",
         "paired_block_intervals.csv", "Paired cross-budget MAE skill for all source compositions and both shared "
         "policies. Vertical intervals for order 20261012 with bias are exploratory 95% intervals using 5000 synchronized "
         "14-day blocks within windows and whole-SiteID resampling. A confidence interval crossing zero does not establish "
         "equivalence; no engineering non-inferiority margin has been specified."),
        ("lambda_fallback", "How often does legal validation select no correction to Persistence?",
         "lambda_fallback.csv", "Fraction of the 50 frozen initial-history tasks per budget and horizon that selected "
         "lambda=0. Parameters are counted once per SiteID-window, rather than once per forecast day. "
         "Selecting zero correction exactly returns Persistence and is not evidence of a sharing gain."),
        ("six_primary_comparisons", "Does the prespecified B30 K30 candidate outperform all three references at both horizons?",
         "paired_block_intervals.csv", "Six prespecified B30 contrasts for order 20261012 K30 shared residual Ridge "
         "with local bias and legally selected shrinkage. Dots are equal-SiteID mean paired MAE skills. Intervals are "
         "Bonferroni-adjusted 99.1667% percentile intervals from 5000 synchronized 14-day calendar-block and whole-SiteID "
         "resamples. All windows are reused development history; physical grouping and real-time information availability remain unverified."),
    ]
    captions.append(('baseline_comparison','How do all fixed simple/local controls compare with Persistence?',
        'summary.csv','Equal-SiteID MAE skill of Persistence, weekly persistence and the legally tuned local residual Ridge '
        'on the same matched dates, for every budget and horizon. All negative controls are retained. Five windows are reused development history.'))
    pd.DataFrame(captions, columns=["figure", "research_question", "result_source", "caption_english"]).to_csv(
        output / "FIGURE_SOURCES.csv", index=False)
    provenance = {"status": "PLOTTED_FROM_SAVED_COMPLETE_EVALUATION", "config_sha256": sha256(cfg_path),
                  "script_sha256": sha256(Path(__file__)),
                  "sources_sha256": {name: sha256(path) for name, path in paths.items()},
                  "evaluation_validation_sha256": sha256(results / "evaluation_validation.json"),
                  "constraint": "raw", "physical_mapping_verified": False,
                  "verified_real_time": False, "all_windows_used_development": True,
                  "matplotlib_version": matplotlib.__version__, "pandas_version": pd.__version__,
                  "numpy_version": np.__version__,
                  "figures_sha256": {f.name: sha256(f) for f in sorted(output.iterdir()) if f.suffix in {".pdf", ".svg", ".png"}}}
    (output / "FIGURE_PROVENANCE.json").write_text(json.dumps(provenance, ensure_ascii=False, indent=2) + "\n")
    print(f"Created six real-result figures in PDF/SVG/PNG: {output}")


if __name__ == "__main__":
    main()
