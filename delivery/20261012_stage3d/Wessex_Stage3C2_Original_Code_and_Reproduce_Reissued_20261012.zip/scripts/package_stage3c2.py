"""Package actual frozen Stage3C2 results and replay them in clean roots.

Creates independently extractable ZIPs below 24 MiB. The Code package can
really refit all 300 K3 conditions and seven-bank/twelve-condition smoke;
merged packages can verify full caches and recompute all saved metrics.
The original full raw-container eligibility audit is explicitly external.
No publication, final-period performance or new model search is performed.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tempfile
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
VERSION = "stage3c2_source_scale_v1"
DAY = "20261012"
LIMIT = 24 * 1024**2
SKIP = {"__pycache__", ".git", ".cache", ".ipynb_checkpoints"}
RAW = "wastewater_data/raw/wessex_all_2016_2025.csv"
RAW_SHA = "22f494e2b96fe6fa9550c68971d50c752ddd291793fdc60334d64b2ef089f518"
LARGE_TABLES = {"predictions_all.csv.gz", "daily_losses.csv.gz",
                "missing_or_failed_predictions.csv.gz", "paired_evaluation_index.csv.gz"}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024**2), b""):
            h.update(block)
    return h.hexdigest()


def save_json(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False)+"\n")


def add_path(root, payload, name, required=True):
    path = root/name
    if not path.exists():
        if required:
            raise FileNotFoundError(path)
        return
    for p in ([path] if path.is_file() else sorted(path.rglob("*"))):
        relative = p.relative_to(root)
        if not p.is_file() or any(part in SKIP for part in relative.parts) or p.suffix in {".pyc", ".pyo"}:
            continue
        if p.is_symlink() or not p.resolve().is_relative_to(root):
            raise ValueError("Unsafe payload source: "+str(p))
        key = relative.as_posix()
        if key in payload and sha(payload[key]) != sha(p):
            raise ValueError("Conflicting payload source: "+key)
        payload[key] = p


def validate_completion(root):
    """Require every frozen source and full task, not a failed=0 counter."""
    sys.path.insert(0, str(root/"src"))
    from wastewater.stage3c2_experiment import load_config, expected_tasks, task_key, validate_job
    from wastewater.stage3b_experiment import hash_value
    cfg, signature, _ = load_config(f"configs/{VERSION}/full.json")
    full = root/f"runs/{VERSION}/full"
    manifest = json.loads((full/"manifest.json").read_text())
    tasks = expected_tasks(cfg, "full")
    if manifest.get("status") != "COMPLETED" or manifest.get("completed_conditions") != 300 or len(tasks) != 300:
        raise ValueError("Full Stage3C2 is not actually complete")
    if manifest.get("signature") != signature or manifest.get("expected_prediction_rows") != 306000:
        raise ValueError("Full signature/task count differs")
    for task in tasks:
        fingerprint = hash_value(dict(signature=signature, task=task, pools=[p["pool_id"] for p in cfg["pools"]]))
        if not validate_job(full/"jobs"/task_key(task), fingerprint, 1020):
            raise ValueError("Expected full task incomplete: "+task_key(task))
    if sha(full/"predictions_all.csv.gz") != manifest.get("predictions_sha256"):
        raise ValueError("Aggregate full predictions checksum differs")
    report = root/f"reports/{VERSION}"
    run_status = json.loads((report/"RUN_STATUS.json").read_text())
    if str(run_status.get("status", "")).upper() != "COMPLETED":
        raise ValueError("Final scientific RUN_STATUS not COMPLETED")
    evaluation = json.loads((report/"results/evaluation_validation.json").read_text())
    if evaluation.get("status") != "COMPLETED" or not evaluation["experiment_integrity"].get("all_expected_tasks_verified"):
        raise ValueError("Evaluation does not independently verify complete full tasks")
    for name, expected in evaluation["files_sha256"].items():
        if sha(report/"results"/name) != expected:
            raise ValueError("Evaluated table changed: "+name)
    gate = json.loads((report/"K3_REPRODUCTION_CHECK.json").read_text())
    if gate.get("status") != "PASSED" or gate.get("signature") != signature or gate.get("prediction_rows_compared") != 90000:
        raise ValueError("Actual full K3 gate absent or stale")
    independent = json.loads((report/"INDEPENDENT_CHECK.json").read_text())
    if independent.get("status") != "PASSED" or independent.get("mode") != "full_independent_evidence_audit":
        raise ValueError("Independent full model/selection/metric audit has not passed")
    if independent.get("checker_sha256") != sha(root/"scripts/check_stage3c2_results.py"):
        raise ValueError("Independent checker changed after accepted receipt")
    return dict(signature=signature, target_conditions=300, policies=17,
                model_conditions=5100, expected_prediction_rows=306000,
                all_expected_job_outputs_and_hashes_verified=True,
                saved_evaluation_table_hashes_verified=True,
                independent_full_model_selection_metric_audit_passed=True,
                full_K3_prediction_rows_independently_compared=90000,
                physical_mapping_verified=False, final_period_performance_used=False)


def collect(root):
    freeze = json.loads((root/f"configs/{VERSION}/FREEZE.json").read_text())
    code = {}; quick = {}; predictions = {}
    for name in freeze["files_sha256"]:
        add_path(root, code, name)
    for name in [f"configs/{VERSION}/FREEZE.json", "src/wastewater/__init__.py",
                 "requirements-stage3c2.txt", "scripts/package_stage3c2.py",
                 "scripts/plot_stage3c2.py", "scripts/check_stage3c2_results.py",
                 "scripts/monitor_stage3c2.py", f"reports/{VERSION}/REPRODUCE.md"]:
        add_path(root, code, name)
    add_path(root, code, f"data/derived/{VERSION}")
    add_path(root, code, f"data/provenance/{VERSION}")
    preparation = json.loads((root/f"data/provenance/{VERSION}/PREPARATION_AUDIT.json").read_text())
    for name in preparation["input_files"]:
        if name != RAW:
            add_path(root, code, name)
    # Original bytes, sufficient for the unchanged archived five-policy checker.
    old = root/"runs/stage3b_20261011_v1/full/jobs"
    folders = sorted(old.iterdir())
    if len(folders) != 300:
        raise ValueError("Original Stage3B reference task set incomplete")
    for folder in folders:
        for basename in ["predictions.csv", "selection.json"]:
            add_path(root, code, str((folder/basename).relative_to(root)))
    arrays = sorted((root/"runs/stage3b_20261011_v1/source").glob("*.npz"))
    if len(arrays) != 10:
        raise ValueError("Original Stage3B source array set incomplete")
    for path in arrays:
        add_path(root, code, str(path.relative_to(root)))
    for path in sorted((root/f"reports/{VERSION}").rglob("*")):
        if path.is_file() and path.name not in LARGE_TABLES and "__pycache__" not in path.parts:
            add_path(root, quick, str(path.relative_to(root)))
    for name in ["STAGE3C2_PROTOCOL.md", f"configs/{VERSION}", f"figures/{VERSION}",
                 f"data/provenance/{VERSION}/source_pool_definition.json",
                 f"data/provenance/{VERSION}/COHORT_AND_INPUT_NOTES_ZH.md",
                 f"data/provenance/{VERSION}/nested_source_pool_members.csv",
                 f"data/provenance/{VERSION}/temporary_and_registered_protection.csv",
                 f"data/provenance/{VERSION}/partition_group_ledger.csv"]:
        add_path(root, quick, name)
    add_path(root, predictions, f"runs/{VERSION}")
    add_path(root, predictions, f"reports/{VERSION}/results")
    # Shared documentation/config files remain exactly identical across packages.
    for name in ["STAGE3C2_PROTOCOL.md", f"configs/{VERSION}", f"reports/{VERSION}/REPRODUCE.md"]:
        add_path(root, predictions, name)
    all_payloads = [quick, code, predictions]
    if any(RAW in payload for payload in all_payloads):
        raise ValueError("Full original raw container intentionally external")
    for payload in all_payloads:
        for name, path in payload.items():
            if f"{VERSION}" not in name and name.startswith("runs/") and payload is not code:
                raise ValueError("Unexpected older run in new result package")
            if path.stat().st_size == 0 and path.name not in {"__init__.py"}:
                # Empty validation CSV is legitimate for B30 fallback (newline).
                raise ValueError("Empty payload file: "+name)
    return [("Quick_Review", quick), ("Code_and_Reproduce", code),
            ("Predictions_and_Diagnostics", predictions)]


def start_text(category):
    return (f"# Stage3C2 {category}\n\n"
        f"Read reports/{VERSION}/REPRODUCE.md and ANALYSIS_ZH.md.\n"
        "Extract packages into one NEW root; duplicate members must have identical SHA.\n"
        "Code package refits K3 and smoke; merged packages verify cached full tasks and\n"
        "recompute all metrics. These are separate declared reproduction scopes.\n"
        "The complete 186-candidate eligibility rebuild needs the omitted original raw\n"
        f"CSV ({RAW_SHA}) and archived project metadata. Canonical/raw-excerpt QA\n"
        "and all frozen prediction inputs are self-contained.\n"
        "All five windows are USED development; physical_mapping_verified=false;\n"
        "no claim of independent physical plants or verified real-time arrival.\n"
        "Stop after this finite CPU source-scale round. No weather/GRU/final-period fit.\n").encode()


def write_archive(path, payload, category, part):
    token = category+(f"_Part{part:02d}" if part else "")
    records = [dict(path=name, bytes=p.stat().st_size, sha256=sha(p)) for name, p in sorted(payload.items())]
    start = start_text(category)
    members = {r["path"]: r["sha256"] for r in records}
    members[f"START_HERE_{token}.md"] = hashlib.sha256(start).hexdigest()
    manifest = dict(version=VERSION, category=category, part=part,
                    created_utc=datetime.now(timezone.utc).isoformat(), files=records,
                    excluded_original_raw=dict(path=RAW, sha256=RAW_SHA,
                        retrieval="User Wastewater_Part1_Plan_and_Raw.zip or existing original checkout"),
                    eligibility_full_rebuild_external=True,
                    physical_mapping_verified=False, all_windows_used_development=True)
    manifest_name = f"PACKAGE_{token}_MANIFEST.json"
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2)+"\n").encode()
    members[manifest_name] = hashlib.sha256(manifest_bytes).hexdigest()
    sums = "".join(f"{digest}  {name}\n" for name, digest in sorted(members.items())).encode()
    sums_name = f"PACKAGE_{token}_SHA256SUMS"
    members[sums_name] = hashlib.sha256(sums).hexdigest()
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, p in sorted(payload.items()):
            z.write(p, name)
        z.writestr(f"START_HERE_{token}.md", start)
        z.writestr(manifest_name, manifest_bytes)
        z.writestr(sums_name, sums)
    with zipfile.ZipFile(path) as z:
        bad = z.testzip()
        if bad:
            raise ValueError("ZIP CRC failure: "+bad)
        if set(z.namelist()) != set(members) or len(z.namelist()) != len(members):
            raise ValueError("ZIP duplicate/missing members")
        for name, digest in members.items():
            if hashlib.sha256(z.read(name)).hexdigest() != digest:
                raise ValueError("ZIP member SHA mismatch: "+name)
    return dict(path=str(path), category=category, part=part, bytes=path.stat().st_size,
                MiB=path.stat().st_size/1024**2, sha256=sha(path), members=members,
                CRC_and_all_member_SHA256_passed=True)


def make_packages(output, category, payload):
    base = f"Wastewater_Stage3C2_{category}_{DAY}"
    first = output/(base+".zip")
    if first.exists() or list(output.glob(base+"_Part*.zip")):
        raise FileExistsError("Delivery already exists; use a NEW output/version")
    print(f"packaging {category}: {len(payload)} files", flush=True)
    candidate = write_archive(first, payload, category, None)
    if candidate["bytes"] < LIMIT:
        return [candidate]
    first.unlink()
    # Split according to actual per-file deflated sizes, then check real archives.
    weights = []
    with tempfile.NamedTemporaryFile(suffix=".zip", dir=output) as scratch:
        with zipfile.ZipFile(scratch.name, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            for name, p in sorted(payload.items()):
                z.write(p, name)
                weights.append((name, z.getinfo(name).compress_size+len(name)*2+200))
    limit = 22*1024**2; chunks = []; chunk = {}; size = 0
    for name, weight in weights:
        if weight > limit:
            raise ValueError("Single file too large for a safe independent ZIP: "+name)
        if chunk and size+weight > limit:
            chunks.append(chunk); chunk = {}; size = 0
        chunk[name] = payload[name]; size += weight
    if chunk:
        chunks.append(chunk)
    result = []
    for i, part in enumerate(chunks, 1):
        item = write_archive(output/(base+f"_Part{i:02d}.zip"), part, category, i)
        if item["bytes"] >= LIMIT:
            raise ValueError("Actual split ZIP still exceeds strict 24 MiB limit")
        result.append(item)
    return result


def safe_extract(packages, destination):
    """Validate declared members and reject nonidentical overlay collisions."""
    root = Path(destination).resolve(); root.mkdir(parents=True, exist_ok=True)
    files = 0
    for package in packages:
        with zipfile.ZipFile(package) as z:
            if len(z.namelist()) != len(set(z.namelist())) or z.testzip():
                raise ValueError("Invalid ZIP CRC or duplicate members: "+str(package))
            manifests = [n for n in z.namelist() if n.startswith("PACKAGE_") and n.endswith("_MANIFEST.json")]
            if len(manifests) != 1:
                raise ValueError("Exactly one package manifest expected")
            manifest = json.loads(z.read(manifests[0]))
            if manifest["version"] != VERSION:
                raise ValueError("Mixed scientific versions")
            expected = {r["path"]: r["sha256"] for r in manifest["files"]}
            sums = [n for n in z.namelist() if n.startswith("PACKAGE_") and n.endswith("_SHA256SUMS")]
            if len(sums) != 1:
                raise ValueError("Package SHA file missing")
            for line in z.read(sums[0]).decode().splitlines():
                digest, name = line.split("  ", 1); expected[name] = digest
            for name in z.namelist():
                parsed = PurePosixPath(name)
                if parsed.is_absolute() or ".." in parsed.parts or "\\" in name or parsed.parts[0].endswith(":"):
                    raise ValueError("Unsafe ZIP path: "+name)
                data = z.read(name)
                digest = hashlib.sha256(data).hexdigest()
                if name not in sums and expected.get(name) != digest:
                    raise ValueError("Member not validated: "+name)
                target = root.joinpath(*parsed.parts)
                if target.is_symlink() or not target.resolve().is_relative_to(root):
                    raise ValueError("Unsafe existing symlink path: "+str(target))
                if target.exists():
                    if not target.is_file() or sha(target) != digest:
                        raise ValueError("Refusing differing existing file: "+str(target))
                else:
                    target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(data)
                files += 1
    return dict(packages=len(packages), validated_file_instances=files,
                differing_existing_members_rejected=True)


def run_checked(python, arguments, root, logs, label, timeout=1800):
    path = logs/(label+".log"); path.parent.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env.update(PYTHONPATH=str(root/"src"), OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1",
               MKL_NUM_THREADS="1", MPLCONFIGDIR=str(root/".mpl-cache"))
    started = time.perf_counter()
    print("clean replay "+label, flush=True)
    with path.open("w") as handle:
        process = subprocess.Popen([python, *arguments], cwd=root, env=env,
                                   stdout=handle, stderr=subprocess.STDOUT)
        while True:
            try:
                code = process.wait(timeout=45)
                break
            except subprocess.TimeoutExpired:
                elapsed = time.perf_counter()-started
                if elapsed > timeout:
                    process.kill(); process.wait()
                    raise TimeoutError(f"Clean replay timeout: {label}; see {path}")
                with path.open("rb") as reader:
                    reader.seek(max(0,path.stat().st_size-1000))
                    tail = reader.read().decode(errors="replace").splitlines()
                last = tail[-1] if tail else "no buffered child progress yet"
                print(f"clean replay {label}: {elapsed:.1f}s; {last}",flush=True)
    if code:
        raise RuntimeError(f"Clean replay {label} failed ({code}); see {path}")
    return dict(command=[python,*arguments], cwd="clean temporary root", exit_code=code,
                seconds=time.perf_counter()-started, log_path=str(path), log_sha256=sha(path))


def compare_forecasts(reference, rebuilt):
    import numpy as np
    import pandas as pd
    keys = ["site_id", "episode", "budget", "horizon", "origin", "target_date", "pool_id", "model"]
    dtype = dict(site_id=str, pool_id=str, order_label=str)
    a = pd.read_csv(reference, dtype=dtype).set_index(keys).sort_index()
    b = pd.read_csv(rebuilt, dtype=dtype).set_index(keys).sort_index()
    if not a.index.equals(b.index):
        raise ValueError("Forecast date/policy keys differ")
    for column in ["alpha", "shrinkage", "truth_m3", "scale_m3", "training_labels"]:
        np.testing.assert_array_equal(a[column].to_numpy(), b[column].to_numpy())
    observed = []
    for column in ["prediction_m3", "prediction_nonnegative_m3", "bias_m3"]:
        aa = a[column].to_numpy(float)/a.scale_m3.to_numpy(float)
        bb = b[column].to_numpy(float)/b.scale_m3.to_numpy(float)
        np.testing.assert_allclose(aa, bb, atol=1e-10, rtol=1e-10, equal_nan=True)
        finite = np.isfinite(aa)&np.isfinite(bb)
        observed.append(dict(column=column, maximum_normalized_absolute_difference=float(np.max(np.abs(aa[finite]-bb[finite]))) if finite.any() else 0.))
    return dict(rows=len(a), date_and_policy_keys_exact=True, alpha_lambda_truth_scale_training_count_exact=True,
                normalized_atol=1e-10, rtol=1e-10, tolerance_not_bitwise_claim=True, checks=observed)


def compare_tables(reference, rebuilt):
    import numpy as np
    import pandas as pd
    checked = []
    for path in sorted(reference.glob("*.csv*")):
        if path.name == "predictions_all.csv.gz":
            continue
        a = pd.read_csv(path, low_memory=False); b = pd.read_csv(rebuilt/path.name, low_memory=False)
        if list(a.columns) != list(b.columns) or len(a) != len(b):
            raise ValueError("Recomputed table schema/length changed: "+path.name)
        max_relative = 0.
        for column in a:
            if pd.api.types.is_numeric_dtype(a[column]) and pd.api.types.is_numeric_dtype(b[column]):
                aa = a[column].to_numpy(float); bb = b[column].to_numpy(float)
                np.testing.assert_allclose(aa, bb, atol=1e-10, rtol=1e-10, equal_nan=True,
                                           err_msg=path.name+":"+column)
                finite = np.isfinite(aa)&np.isfinite(bb)
                if finite.any():
                    max_relative = max(max_relative, float(np.max(np.abs(aa[finite]-bb[finite])/(1+np.abs(aa[finite])))))
            elif not a[column].fillna("<NA>").astype(str).equals(b[column].fillna("<NA>").astype(str)):
                raise ValueError("Recomputed table nonnumeric field changed: "+path.name+":"+column)
        checked.append(dict(table=path.name, rows=len(a), numeric_atol=1e-10, numeric_rtol=1e-10,
                            maximum_scaled_absolute_difference=max_relative))
    if not checked:
        raise ValueError("No saved evaluation tables")
    return checked


def clean_replay(root, packages, python, output):
    logs = output/"clean_replay_logs"; commands = []
    code_packages = [p["path"] for p in packages if p["category"]=="Code_and_Reproduce"]
    with tempfile.TemporaryDirectory(prefix="stage3c2_code_replay_", dir="/tmp") as directory:
        clean = Path(directory)
        extraction = safe_extract(code_packages, clean)
        if (clean/f"runs/{VERSION}").exists() or (clean/f"reports/{VERSION}/K3_REPRODUCTION_CHECK.json").exists():
            raise ValueError("Cold code replay unexpectedly contains new-run/gate caches")
        cfg = f"configs/{VERSION}/full.json"
        commands.append(run_checked(python, ["-m","unittest","discover","-s","tests","-p","test_stage3c2*.py","-v"], clean, logs,"unit_tests"))
        commands.append(run_checked(python,["scripts/verify_stage3c2_data.py","--root",str(clean),"--output","verification/data.json"],clean,logs,"independent_data_qa"))
        commands.append(run_checked(python,["-m","wastewater.stage3c2_experiment","--config",cfg,"--mode","k3-check","--workers","2"],clean,logs,"cold_k3_all_300"))
        commands.append(run_checked(python,["scripts/check_stage3c2_k3.py"],clean,logs,"independent_archived_k3_gate"))
        gate = json.loads((clean/f"reports/{VERSION}/K3_REPRODUCTION_CHECK.json").read_text())
        commands.append(run_checked(python,["-m","wastewater.stage3c2_experiment","--config",cfg,"--mode","smoke","--workers","2"],clean,logs,"cold_seven_pool_smoke"))
        smoke = compare_forecasts(root/f"runs/{VERSION}/smoke/predictions_all.csv.gz",clean/f"runs/{VERSION}/smoke/predictions_all.csv.gz")
        commands.append(run_checked(python,["-m","wastewater.stage3c2_experiment","--config",cfg,"--mode","smoke","--workers","2"],clean,logs,"validated_cached_smoke"))
        manifest = json.loads((clean/f"runs/{VERSION}/smoke/manifest.json").read_text())
        if manifest["counts_this_call"] != dict(COMPLETED=0,CACHED=12,FAILED=0):
            raise ValueError("Resume did not skip exactly twelve verified smoke tasks")
        cached_smoke = compare_forecasts(root/f"runs/{VERSION}/smoke/predictions_all.csv.gz",clean/f"runs/{VERSION}/smoke/predictions_all.csv.gz")
    with tempfile.TemporaryDirectory(prefix="stage3c2_full_evaluate_", dir="/tmp") as directory:
        clean = Path(directory)
        merged = safe_extract([p["path"] for p in packages],clean)
        commands.append(run_checked(python,["-m","wastewater.stage3c2_experiment","--config",cfg,"--mode","resume","--workers","2"],clean,logs,"validated_full_300_cache_resume"))
        manifest = json.loads((clean/f"runs/{VERSION}/full/manifest.json").read_text())
        if manifest["counts_this_call"] != dict(COMPLETED=0,CACHED=300,FAILED=0):
            raise ValueError("Full cache resume incomplete")
        full = compare_forecasts(root/f"runs/{VERSION}/full/predictions_all.csv.gz",clean/f"runs/{VERSION}/full/predictions_all.csv.gz")
        commands.append(run_checked(python,["scripts/summarize_stage3c2.py","--config",cfg,"--run",f"runs/{VERSION}/full","--output","verification/results"],clean,logs,"all_saved_forecast_evaluation_5000_resamples"))
        tables = compare_tables(root/f"reports/{VERSION}/results",clean/"verification/results")
        checked = json.loads((clean/"verification/results/evaluation_validation.json").read_text())
        if checked["status"] != "COMPLETED":
            raise ValueError("Independent clean evaluation incomplete")
        commands.append(run_checked(python,["scripts/check_stage3c2_results.py","--root",str(clean),"--output","verification/independent_check.json"],clean,logs,"independent_full_source_selection_metric_bootstrap_reconstruction"))
        independent = json.loads((clean/"verification/independent_check.json").read_text())
        if independent["status"] != "PASSED" or independent["mode"] != "full_independent_evidence_audit":
            raise ValueError("Clean independent full audit did not pass")
    return dict(status="PASSED", code_only_clean_extraction=extraction, merged_clean_extraction=merged,
                no_network_calls=True, original_full_raw_csv_omitted=True,
                source_eligibility_full_raw_rebuild="NOT_EXECUTED; same-SHA original raw and historical metadata external",
                cold_training_executed=dict(K3_target_conditions=300,smoke_target_conditions=12,source_banks=7),
                independent_archived_K3_gate=gate, smoke_forecast_comparison=smoke,
                smoke_cached_replay=cached_smoke, full_validated_cache_tasks=300,
                full_saved_forecast_comparison=full, full_source_scale_cold_retraining="NOT_REPEATED_IN_PACKAGE_REPLAY; original full experiment and clean smoke are separate scopes",
                recomputed_evaluation_tables=tables, resamples_each_block=5000,
                independent_full_audit=independent,
                commands=commands, tolerance_not_bitwise_replication=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=ROOT)
    ap.add_argument("--output", default=f"delivery/{DAY}_stage3c2")
    ap.add_argument("--python", default=sys.executable)
    ap.add_argument("--extract", nargs="+")
    ap.add_argument("--destination", type=Path)
    args = ap.parse_args()
    if args.extract:
        if not args.destination:
            ap.error("--extract requires --destination")
        print(json.dumps(safe_extract(args.extract,args.destination),indent=2));return
    root = args.root.resolve()
    if root != ROOT:
        raise ValueError("Build from the intended checkout; use extraction mode for other roots")
    output = root/args.output;output.mkdir(parents=True,exist_ok=True)
    if (output/"PACKAGE_CHECKS.json").exists():
        raise FileExistsError("Do not overwrite completed package receipts")
    started = time.perf_counter()
    completion = validate_completion(root)
    categories = collect(root); packages = []
    for category,payload in categories:
        packages.extend(make_packages(output,category,payload))
    package_seconds = time.perf_counter()-started
    print("All ZIPs passed CRC/member SHA; beginning actual clean replay",flush=True)
    replay = clean_replay(root,packages,args.python,output)
    public = [{k:v for k,v in p.items() if k not in {"members","path"}}|dict(file=Path(p["path"]).name) for p in packages]
    receipt = dict(status="PASSED", version=VERSION, created_utc=datetime.now(timezone.utc).isoformat(),
                   package_script_sha256=sha(Path(__file__)), strict_ZIP_limit_bytes=LIMIT,
                   scientific_completion_checked=completion, packages=public, clean_replay=replay,
                   timings_seconds=dict(package_creation_and_member_checks=package_seconds,
                                        clean_replay_and_total=time.perf_counter()-started))
    save_json(output/"PACKAGE_CHECKS.json",receipt)
    save_json(output/"MANIFEST.json",dict(version=VERSION,files=[dict(file=p["file"],bytes=p["bytes"],sha256=p["sha256"]) for p in public]))
    sums = "".join(f"{sha(p)}  {p.name}\n" for p in sorted(output.iterdir()) if p.is_file() and p.name!="SHA256SUMS")
    (output/"SHA256SUMS").write_text(sums)
    print(json.dumps(dict(status="PASSED",packages=public,package_checks=str(output/"PACKAGE_CHECKS.json")),indent=2))


if __name__ == "__main__":
    main()
