"""Measure a CPU command's live process-tree RSS/PSS and preserve its exit code."""
import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
import subprocess
import time

ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--label',required=True);ap.add_argument('--log',required=True);ap.add_argument('--receipt',required=True)
ap.add_argument('command',nargs=argparse.REMAINDER);args=ap.parse_args()
cmd=args.command[1:] if args.command and args.command[0]=='--' else args.command
if not cmd:raise ValueError('A command is required')
log=Path(args.log);receipt=Path(args.receipt);log.parent.mkdir(exist_ok=True,parents=True);receipt.parent.mkdir(exist_ok=True,parents=True)
if receipt.exists():raise ValueError('Cost receipt already exists; use a new invocation name')

def descendants(pid):
    found={pid};pending=[pid]
    while pending:
        q=pending.pop()
        # multiprocessing can create workers from its management thread;
        # reading only the leader's children omits those processes.
        children=[]
        try:
            for t in Path(f'/proc/{q}/task').iterdir():
                try:children.extend((t/'children').read_text().split())
                except OSError:pass
        except OSError:continue
        for child in children:
            child=int(child)
            if child not in found:found.add(child);pending.append(child)
    return found

def memory(pid):
    rss=pss=0
    try:
        for line in Path(f'/proc/{pid}/smaps_rollup').read_text().splitlines():
            if line.startswith('Rss:'):rss=int(line.split()[1])
            elif line.startswith('Pss:'):pss=int(line.split()[1])
    except OSError:
        try:
            for line in Path(f'/proc/{pid}/status').read_text().splitlines():
                if line.startswith('VmRSS:'):rss=int(line.split()[1])
        except OSError:pass
    return rss,pss

started=time.perf_counter();stamp=datetime.now(timezone.utc).isoformat();peakrss=peakpss=samples=peakprocesses=0;last=started
with log.open('w') as stream:
    process=subprocess.Popen(cmd,stdout=stream,stderr=subprocess.STDOUT)
    while process.poll() is None:
        values=[memory(p) for p in descendants(process.pid)];peakprocesses=max(peakprocesses,len(values));peakrss=max(peakrss,sum(v[0] for v in values));peakpss=max(peakpss,sum(v[1] for v in values));samples+=1
        if time.perf_counter()-last>=30:
            print(f'{args.label}: elapsed={time.perf_counter()-started:.1f}s; peak sampled tree PSS={peakpss/1024:.1f}MiB; progress in {log}',flush=True);last=time.perf_counter()
        time.sleep(.1)
    code=process.wait()
result={'label':args.label,'command':cmd,'started_utc':stamp,'finished_utc':datetime.now(timezone.utc).isoformat(),
        'exit_code':code,'wall_seconds':time.perf_counter()-started,'sample_period_seconds':.1,
        'samples':samples,'maximum_processes_sampled':peakprocesses,
        'peak_sampled_process_tree_RSS_KiB':peakrss,'peak_sampled_process_tree_PSS_KiB':peakpss,
        'memory_limit':'sampled memory; short peaks between samples can be missed; RSS can double-count shared pages; PSS apportions them',
        'log':str(log),'GPU_used':False}
receipt.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
raise SystemExit(code)
