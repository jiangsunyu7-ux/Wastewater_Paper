"""Independently rebuild delivered Stage3C2 model-input QA from raw excerpts.

The omitted full raw container is needed to rebuild *candidate eligibility*,
but this check and all source/target forecasts use the delivered excerpt and
canonical only. No model or performance file is loaded.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--output", type=Path)
    args = ap.parse_args()
    root = args.root.resolve()
    folder = root / "data/provenance/stage3c2_source_scale_v1"
    definition_path = folder / "source_pool_definition.json"
    definition = json.loads(definition_path.read_text())
    canonical_path = root / definition["canonical_csv"]
    excerpt = folder / "selected_model_raw_records.csv.gz"
    raw = pd.read_csv(excerpt, dtype={"SiteID": str})
    canonical = pd.read_csv(canonical_path, dtype={"site_id":str})
    raw["numeric"] = pd.to_numeric(raw.TotalVolume, errors="coerce").astype(float)
    raw["quality"] = raw.QualityFlag.str.strip().str.casefold()
    key = ["SiteID", "Date"]
    variant = raw.drop_duplicates(key+["numeric","quality","Units"])
    badkeys = pd.MultiIndex.from_frame(variant.loc[variant.duplicated(key,keep=False),key]).unique()
    raw["conflict"] = pd.MultiIndex.from_frame(raw[key]).isin(badkeys)
    raw["valid"] = raw.quality.eq("good") & raw.Units.eq("m3") & np.isfinite(raw.numeric) & raw.numeric.ge(0) & ~raw.conflict
    first = raw.drop_duplicates(key).copy()
    rebuilt = first[["SiteID","Date","conflict","valid"]].rename(columns={"SiteID":"site_id","Date":"date"})
    rebuilt["rebuilt_value"] = first.numeric.where(first.valid)
    pair = canonical.merge(rebuilt,on=["site_id","date"],how="outer",indicator=True,validate="one_to_one",suffixes=("_canonical","_rebuilt"))
    assert pair._merge.eq("both").all(), "Raw excerpt/canonical date set differs"
    for column in ("candidate_value_m3","observed_input_m3"):
        a = pair[column].to_numpy(float); b = pair.rebuilt_value.to_numpy(float)
        assert np.array_equal(np.isnan(a),np.isnan(b)), column + " invalid mask differs"
        mask = np.isfinite(b)
        assert np.array_equal(a[mask],b[mask]), column + " value differs"
    assert pair.target_quality_valid.eq(pair.valid.astype(int)).all()
    assert pair.conflict_canonical.eq(pair.conflict_rebuilt.astype(int)).all()
    protected = set(definition["protected_ids"])
    assert not set(canonical.site_id) & protected
    assert not set(raw.SiteID) & protected
    assert set(canonical.site_id) == set(definition["source_union_ids"]+definition["development_ids"])
    assert canonical.loc[canonical.site_id.isin(definition["source_union_ids"]),"date"].between("2016-01-01","2021-12-31").all()
    assert canonical.loc[canonical.site_id.isin(definition["development_ids"]),"date"].between("2016-01-01","2023-12-31").all()
    # Verify the protection and source ranking from their fixed strings rather
    # than trusting selected-pool lists.
    ledger = pd.read_csv(folder / "partition_group_ledger.csv",dtype={"provisional_group_id":str,"representative_site_id":str})
    reservoir = ledger.loc[ledger.reserve_rank.notna()].copy()
    reservoir["independent_hash"] = reservoir.provisional_group_id.map(lambda x:hashlib.sha256(("Wessex-C2-reserve-v1|"+x).encode()).hexdigest())
    assert reservoir.independent_hash.eq(reservoir.reserve_sha256).all()
    reservoir = reservoir.sort_values(["independent_hash","provisional_group_id"])
    n = int(np.ceil(.2*len(reservoir)))
    expected_protection = set(reservoir.head(n).provisional_group_id)
    assert expected_protection == set(ledger.loc[ledger.partition.eq("temporary_protection"),"provisional_group_id"])
    remaining = reservoir.loc[~reservoir.provisional_group_id.isin(expected_protection)]
    for label in definition["order_labels"]:
        ranking = remaining.assign(h=remaining.provisional_group_id.map(lambda x:hashlib.sha256(f"Wessex-C2-order-v1|{label}|{x}".encode()).hexdigest())).sort_values(["h","provisional_group_id"])
        for k in (10,30):
            expected_ids = definition["original_source_ids"] + ranking.head(k-3).representative_site_id.tolist()
            matching = [p for p in definition["pools"] if p["order_label"]==label and p["k"]==k]
            assert len(matching)==1 and matching[0]["site_ids"]==expected_ids
    for pool in definition["pools"]:
        assert len(pool["site_ids"])==pool["k"] and len(set(pool["site_ids"]))==pool["k"]
        assert pool["site_ids"][:3] == definition["original_source_ids"]
        assert not set(pool["site_ids"]) & set(definition["protected_ids"]+definition["development_ids"])
        groups = [definition["source_to_provisional_group"][s] for s in pool["site_ids"]]
        assert len(set(groups))==len(groups)
    result = {"status":"PASSED", "canonical_rows":len(canonical),"raw_excerpt_rows":len(raw),
        "values_and_masks":"exact float64 equality, no tolerance", "valid_observations":int(first.valid.sum()),
        "Good_zero_retained":int((first.valid & first.numeric.eq(0)).sum()),
        "Missing_zero_excluded_raw_rows":int((raw.quality.eq("missing") & raw.numeric.eq(0)).sum()),
        "protected_input_records":0,"source_after2021_records":0,"target_after2023_records":0,
        "source_rankings_independently_verified":True,"temporary_protection_rank_independently_verified":True,
        "physical_mapping_verified":False,"no_model_or_performance_files_read":True,
        "dependency_scope":"QA and frozen pool arithmetic self-contained; rebuilding 186-candidate eligibility requires original full raw file and Stage3C1 audit inputs",
        "sha256":{str(p.relative_to(root)):sha(p) for p in (canonical_path,excerpt,definition_path,Path(__file__).resolve())}}
    text = json.dumps(result,ensure_ascii=False,indent=2)+"\n"
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(text)
    print(text)


if __name__ == "__main__":
    main()
