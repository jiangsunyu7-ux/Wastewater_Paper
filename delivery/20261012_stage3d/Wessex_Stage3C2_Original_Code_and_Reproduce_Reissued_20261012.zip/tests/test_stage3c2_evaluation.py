"""Synthetic software fixtures only; never reported as experimental results."""
import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

from wastewater.stage3c2_evaluation import (
    LOCAL, PRIMARY_MODEL, aggregate_station_metrics, bootstrap_station_means,
    calendar_draw_indices, paired_block_intervals, prepare_predictions,
    station_metrics, summarize_predictions,
)


class Stage3C2EvaluationTests(unittest.TestCase):
    def config(self):
        return dict(development_ids=['a', 'b'], origins=['2022-01-01', '2023-10-01'],
                    budgets=[30, 90, 180], horizons=[1, 3], evaluation_days=4,
                    evaluation_policies=[dict(pool_id=p, model=m, k=k, order_label=o) for p, m, k, o in [
                        ('baseline', 'persistence', 0, 'baseline'), ('baseline', LOCAL, 0, 'baseline'),
                        ('K3', PRIMARY_MODEL, 3, 'common'), ('order20261012_K30', PRIMARY_MODEL, 30, '20261012')]],
                    bootstrap=dict(blocks=[2], replicates=30, seed=20261012))

    def predictions(self):
        cfg = self.config(); rows = []
        for site, truth, p_error, candidate_error in [('a', 10., 1., .5), ('b', 1000., 100., 150.)]:
            for episode in cfg['origins']:
                for budget in cfg['budgets']:
                    for horizon in cfg['horizons']:
                        for origin in pd.date_range(episode, periods=cfg['evaluation_days']):
                            for policy in cfg['evaluation_policies']:
                                err = candidate_error if policy['pool_id'] == 'order20261012_K30' else p_error
                                rows.append(dict(policy, site_id=site, episode=episode, budget=budget, horizon=horizon,
                                    origin=str(origin.date()), target_date=str((origin + pd.Timedelta(days=horizon)).date()),
                                    seed=0, truth_m3=truth, prediction_m3=truth + err, high_threshold_m3=truth,
                                    fit_end=str((pd.Timestamp(episode)-pd.Timedelta(days=1)).date()),
                                    last_train_target=str((pd.Timestamp(episode)-pd.Timedelta(days=1)).date()),
                                    latest_input_date=str(origin.date())))
        return pd.DataFrame(rows)

    def daily(self, p):
        p = p[p.common_evaluation].copy(); p['constraint'] = 'raw'
        error = p.prediction_m3 - p.truth_m3
        p['absolute_error'] = error.abs(); p['squared_error'] = error ** 2
        return p

    def test_equal_siteid_skill_and_five_episode_pooling(self):
        cfg = self.config(); m = station_metrics(self.daily(prepare_predictions(self.predictions(), cfg)), cfg)
        summary = aggregate_station_metrics(m)
        row = summary[summary.pool_id.eq('order20261012_K30') & summary.budget.eq(30) & summary.horizon.eq(1) & summary.constraint.eq('raw')].iloc[0]
        self.assertAlmostEqual(row.mean_skill, 0.)
        self.assertNotAlmostEqual(row.mean_skill, 1-150.5/101.)
        self.assertEqual(row.winning_stations, 1); self.assertEqual(row.worse_stations, 1)
        self.assertEqual(row.min_dates, 8)

    def test_incomplete_conditions_remain_visible(self):
        p = self.predictions()
        absent = p.site_id.eq('a') & p.pool_id.eq('order20261012_K30') & p.budget.eq(30) & p.horizon.eq(1)
        result = prepare_predictions(p[~absent], self.config())
        self.assertEqual(len(result), len(p)); self.assertEqual(int((~result.prediction_row_present).sum()), 8)
        self.assertFalse(result[result.site_id.eq('a') & result.horizon.eq(1)].common_evaluation.any())
        second = prepare_predictions(result, self.config())
        np.testing.assert_array_equal(result.common_evaluation, second.common_evaluation)

    def test_horizon_future_training_and_threshold_guards(self):
        for column, value in [('target_date', '2022-01-04'), ('latest_input_date', '2022-01-02'),
                              ('last_train_target', '2022-01-01'), ('high_threshold_m3', 100.)]:
            p = self.predictions(); p.loc[0, column] = value
            with self.assertRaises(ValueError): prepare_predictions(p, self.config())
        cfg = self.config(); cfg['origins'] = ['2024-01-01']
        with self.assertRaises(ValueError): prepare_predictions(self.predictions(), cfg)

    def test_exact_lambda_zero_and_uniform_nonnegative(self):
        p = self.predictions(); p['shrinkage'] = np.nan
        candidate = p.pool_id.eq('order20261012_K30')
        p.loc[candidate, 'shrinkage'] = 0
        with self.assertRaisesRegex(ValueError, 'lambda=0'): prepare_predictions(p, self.config())
        p = self.predictions(); p['prediction_nonnegative_m3'] = p.prediction_m3
        p.loc[0, 'prediction_nonnegative_m3'] += .001
        with self.assertRaises(ValueError): prepare_predictions(p, self.config())

    def test_reference_zero_is_explicitly_undefined(self):
        p = self.predictions(); index = p.site_id.eq('a') & p.model.eq('persistence')
        p.loc[index, 'prediction_m3'] = p.loc[index, 'truth_m3']
        metrics = station_metrics(self.daily(prepare_predictions(p, self.config())), self.config())
        group = metrics[metrics.site_id.eq('a') & metrics.constraint.eq('raw')]
        self.assertTrue(group.zero_reference_mae.all()); self.assertTrue(group.skill_vs_persistence.isna().all())

    def test_fast_bootstrap_equals_original_calendar_algorithm(self):
        errors = np.arange(2*8*3, dtype=float).reshape(2, 8, 3); errors[:, 2, :] = np.nan
        actual = bootstrap_station_means(errors, 2, 4, 3, 21, 73, batch_size=5)
        expected = []
        for site_idx, date_idx in calendar_draw_indices(2, 2, 4, 3, 21, 73):
            expected.append(np.nanmean(errors[site_idx][:, date_idx], axis=1))
            self.assertTrue((date_idx[:4] < 4).all()); self.assertTrue((date_idx[4:] >= 4).all())
        np.testing.assert_allclose(actual, np.array(expected), atol=1e-12, rtol=1e-12)

    def test_six_main_comparisons_correct_multiplicity(self):
        cfg = self.config(); daily = self.daily(prepare_predictions(self.predictions(), cfg))
        ci, paired = paired_block_intervals(daily, cfg, progress=lambda *a, **k: None)
        primary = ci[ci.co_primary]
        self.assertEqual(len(primary), 6)
        np.testing.assert_allclose(primary.confidence_level, 1-.05/6)
        np.testing.assert_allclose(primary.mean_station_skill, 0.)
        self.assertTrue((primary.lower_ci <= primary.lower_95).all())
        self.assertTrue((primary.upper_ci >= primary.upper_95).all())
        self.assertTrue(paired.n_dates.eq(8).all())

    def test_no_integrity_never_claims_completed(self):
        with tempfile.TemporaryDirectory() as tmp:
            summarize_predictions(self.predictions(), self.config(), tmp, progress=lambda *a, **k: None)
            state = json.loads((Path(tmp)/'evaluation_validation.json').read_text())
            self.assertTrue(state['evaluation_outputs_complete'])
            self.assertEqual(state['status'], 'PARTIAL')


if __name__ == '__main__':
    unittest.main()
