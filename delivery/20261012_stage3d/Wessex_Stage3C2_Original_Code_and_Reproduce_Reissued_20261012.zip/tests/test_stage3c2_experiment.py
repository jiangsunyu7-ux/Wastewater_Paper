"""Completion/cache integrity; scientific dates and formulas reuse Stage3B."""
import json
from pathlib import Path
import tempfile
import unittest
from wastewater.common import sha256
from wastewater.stage3c2_experiment import REQUIRED,validate_job


class CompletionTests(unittest.TestCase):
    def test_partial_with_no_failures_cannot_complete(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);(p/'status.json').write_text(json.dumps({'status':'PARTIAL','failed':0,'fingerprint':'x'}))
            self.assertFalse(validate_job(p,'x',60))

    def test_missing_member_and_corruption_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);hashes={}
            for f in REQUIRED:(p/f).write_text(f);hashes[f]=sha256(p/f)
            status={'status':'COMPLETED','fingerprint':'x','prediction_rows':60,'outputs_sha256':hashes}
            (p/'status.json').write_text(json.dumps(status));self.assertTrue(validate_job(p,'x',60))
            with self.assertRaises(ValueError):validate_job(p,'different',60)
            (p/'predictions.csv').write_text('corrupted')
            with self.assertRaises(ValueError):validate_job(p,'x',60)
            del hashes['diagnostics.json'];(p/'status.json').write_text(json.dumps(status))
            with self.assertRaises(ValueError):validate_job(p,'x',60)


if __name__=='__main__':unittest.main()
