"""Source-pool tests use synthetic calendars, never target performance."""
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
import pandas as pd

from wastewater.stage3b_experiment import source_pool
from wastewater.stage3b_models import calibration_fold, candidate_scores, ridge_fit, residual_target
from wastewater.stage3c2_source import (linked_sites, source_arrays,
    source_candidate_scores, validate_completed_source_cache, validate_source_settings)


def fixture():
    cfg = dict(source_training_start="2016-01-01", source_training_end="2021-12-31",
        source_selection_train_end="2020-12-31", source_pseudo_validation_days=14,
        source_pseudo_origins=["2021-01-01", "2021-07-01"], budgets=[30, 90, 180], horizons=[1, 3],
        ridge_alphas=[.0001, .001, .01, .1, 1., 10.], lambdas=[0, .25, .5, 1], min_train_labels=14,
        local_validation_fraction=.2, validation_min_fit_labels=30, validation_min_labels=10)
    dates = pd.date_range("2016-01-01", "2023-12-31")
    series = {}
    for index, site in enumerate(["13006", "13008", "13012", "17001"]):
        values = (index+1) * (100. + 30.*np.sin(np.arange(len(dates))/19.))
        values[19::67] = np.nan
        values[33::421] = 0.
        series[site] = pd.Series(values, index=dates)
    return cfg, series


class SourcePoolTests(unittest.TestCase):
    def test_k3_arrays_are_exactly_stage3b(self):
        cfg, series = fixture()
        ids = ["13006", "13008", "13012"]
        for horizon in [1, 3]:
            expected = source_pool(series, cfg, horizon, "2020-12-31", ids)
            actual = source_arrays(series, cfg, horizon, "2020-12-31", ids)
            for left, right in zip(expected[:4], actual[:4]):
                np.testing.assert_array_equal(left, right)
            self.assertEqual(expected[4], actual[4])

    def test_equal_site_weight_and_missing_placeholder_one(self):
        cfg, series = fixture()
        ids = ["13006", "13008", "13012", "17001"]
        series["17001"].loc["2017-01-01":"2018-12-31"] = np.nan
        x, y, residual, weights, diagnostics = source_arrays(series, cfg, 3, "2020-12-31", ids)
        self.assertAlmostEqual(weights.sum(), 1.)
        offset = 0
        for info in diagnostics:
            count = info["training_labels"]
            self.assertAlmostEqual(weights[offset:offset+count].sum(), .25)
            offset += count
        self.assertEqual(offset, len(y))
        self.assertTrue(np.any(x[:, 3:] == 0))
        self.assertTrue(np.all(x[:, :3][x[:, 3:] == 0] == 1.))
        self.assertTrue(np.isfinite(residual).all())

    def test_future_source_records_do_not_change_features_or_fit(self):
        cfg, series = fixture()
        ids = ["13006", "13008", "13012"]
        before = source_arrays(series, cfg, 3, "2020-12-31", ids)
        changed = {s: v.copy() for s, v in series.items()}
        for values in changed.values():
            values.loc["2021-01-01":] = 999999999.
        after = source_arrays(changed, cfg, 3, "2020-12-31", ids)
        for left, right in zip(before[:4], after[:4]):
            np.testing.assert_array_equal(left, right)
        a = ridge_fit(before[0], before[2], .01, before[3])
        b = ridge_fit(after[0], after[2], .01, after[3])
        np.testing.assert_array_equal(a.coef_, b.coef_)
        self.assertEqual(a.intercept_, b.intercept_)
        self.assertTrue(all(d["last_train_target"] <= "2020-12-31" for d in after[4]))

    def test_related_links_are_undirected_and_transitive(self):
        relations = {"13006": ["17001"], "17002": ["17001"]}
        self.assertEqual(linked_sites("17002", relations), {"13006", "17001", "17002"})
        cfg, _ = fixture()
        with self.assertRaises(ValueError):
            validate_source_settings(cfg, ["13006", "13008", "13012", "17002"], relations)

    def test_pseudo_grid_is_stage3b_exact_with_local_cache_reuse(self):
        cfg, series = fixture()
        for horizon in [1, 3]:
            train, val, _ = calibration_fold(series["13006"], "2021-01-01", 30, horizon, cfg, pseudo=True)
            x, _, r, weights, _ = source_arrays(series, cfg, horizon, "2020-12-31", ["13008", "13012"])
            shared = {float(a): ridge_fit(x, r, a, weights) for a in cfg["ridge_alphas"]}
            expected = candidate_scores(train, val, shared, cfg)
            actual = source_candidate_scores(train, val, shared, cfg)
            self.assertEqual(expected, actual)
            # The local cache must not leak metadata mutations into other pools.
            actual[0]["pool_id"] = "synthetic-first-pool"
            other_x, _, other_r, other_weights, _ = source_arrays(series, cfg, horizon, "2020-12-31", ["13008", "17001"])
            other = {float(a): ridge_fit(other_x, other_r, a, other_weights) for a in cfg["ridge_alphas"]}
            self.assertEqual(candidate_scores(train, val, other, cfg), source_candidate_scores(train, val, other, cfg))

    def test_partial_zero_failures_is_not_complete(self):
        cfg, _ = fixture()
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            (folder / "status.json").write_text(json.dumps(dict(status="partial", failed=0, fingerprint="fixture")))
            self.assertFalse(validate_completed_source_cache(folder, "fixture", cfg))

    def test_completed_without_outputs_is_rejected(self):
        cfg, _ = fixture()
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            (folder / "status.json").write_text(json.dumps(dict(status="completed", fingerprint="fixture",
                expected_model_groups=10, completed_model_groups=10,
                expected_pseudo_folds=36, completed_pseudo_folds=36, outputs_sha256={})))
            with self.assertRaises(ValueError):
                validate_completed_source_cache(folder, "fixture", cfg)


if __name__ == "__main__":
    unittest.main()
