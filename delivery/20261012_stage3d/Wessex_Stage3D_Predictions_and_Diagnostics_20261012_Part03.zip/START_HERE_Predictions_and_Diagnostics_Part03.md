# Stage3D Predictions_and_Diagnostics

Read reports/stage3d_interval_v1/REPRODUCE.md and ANALYSIS_ZH.md.
Extract every new Stage3D part into one NEW root; overlays require identical SHA.
All intervals use the same frozen Persistence centre. Empirical interval
quantiles have no finite-sample, conditional or conformal guarantee.
Code-only cold source/gamma and smoke reproduction is separate from merged
full-cache verification and saved-interval evaluation. Actual scope is
recorded in the external PACKAGE_CHECKS.json receipt.
The original Stage3C2 reissue files are byte-identical archives, not new
forecasts; keep their five parts separate from the new Stage3D packages.
All five windows are already-used development. physical_mapping_verified=false.
Historical QA publication and daily observation arrival are unverified.
Stop after this finite CPU round; no final-period performance or new models.
