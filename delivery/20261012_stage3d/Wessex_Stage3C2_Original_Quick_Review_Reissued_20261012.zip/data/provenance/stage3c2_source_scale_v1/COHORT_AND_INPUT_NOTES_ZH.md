# Stage3C2 分区与输入核查

本轮仅为 `station_exploratory`。所有物理设施身份继续为 unknown，`physical_mapping_verified=false`。没有重新查接口，没有读取候选预测误差，没有使用2024—2025性能。

186个既有候选按2016—2021数据再次复核：1116个站点年度覆盖均≥95%，其中407712条原始记录，404492个有效日。分离排除为Good负数49、Missing671、Suspect2496、冲突4行。Missing原始标签673中有2行属于冲突，不能双计。原3源及原10开发测点35796条原范围记录的值和缺失位置与Stage3B完全一致，没有采用数值容差。

预2022的255个WRC SiteID名称用于保守关联筛查，只对186合格候选分区。发现MARNHULL 13198/13199和WIVELISCOMBE 13354/13355同主名不同括号标签，作为疑似关联连通组；不认定同一物理设施。13355不属于186候选、不达本轮入选集合，仍与13354同组而不选作测点。组代表为组内**合格候选**最低数值SiteID；13199因此不被单独拟合。其他名称不同也不能作为设施独立证据，别名与跨站点关联仍可能遗漏。

扫描4979份既有配置/运行/元数据JSON及模型路径的ID字段，未发现186候选已经参加项目模型使用的记录。未找到具名正式保留目标登记；不能认定不存在用户、Guna或提供方的外部保留名单。既有3源、10开发和它们的已知/疑似关联组首先排除，再从185个未使用候选provisional组按预定SHA256冻结37=ceil(0.20×185)临时保护组，剩148组。这个保护池不参加拟合、调参或性能评价，也不是经认证的最终独立水厂测试集。

源排序是SHA256("Wessex-C2-order-v1|"+str(排序标识)+"|"+provisional_group_id)。三种标识20261012/20261013/20261014各自构成3⊂10⊂30，原3前缀固定。共有7个不同池，三套入选源并集73个SiteID，包括70新增源测点。全体入选/保护/未选及非代表测点见`source_measurement_use_ledger.csv`和`partition_group_ledger.csv`。

模型canonical和配套真实raw excerpt只包含入选源2016—2021与固定开发测点2016—2023。37保护组的观测不在任何模型输入，且不作为伪目标验证。发布后Good、有限、非负、m3且无冲突有效；真实Good零保留，Missing零和Suspect/负值/冲突屏蔽。缺失不插值，参数仍由旧Stage3B特征函数计算，其中归一化占位值1及有效mask。新测点没有Stage2对照，所以`input_changed_from_v2`留空；不能写成False来伪造比较。

读取与独立核验：

```bash
.venv-stage2/bin/python scripts/verify_stage3c2_data.py --root . --output data/provenance/stage3c2_source_scale_v1/DATA_VERIFICATION.json
.venv-stage2/bin/python scripts/prepare_stage3c2.py --resume
```

`verify_stage3c2_data.py`从所附raw excerpt独立重建全部189236行QA，逐值、mask、日期集合完全一致；43个Good零保留，240个Missing零原行排除，源排序和保护SHA独立计算通过。它不需要全量raw，不读取任何预测或模型误差。重新构建186候选资格仍依赖73,570,225字节的原始全CSV（SHA256 `22f494e2b96fe6fa9550c68971d50c752ddd291793fdc60334d64b2ef089f518`）和Stage3C1年度审计；单包没有这份原始大文件时，不声称完整重建全候选资格。仅复核现有输入/运行模型可使用交付canonical及excerpt。

仍需提供方核实TDV SiteID—物理设施—正常处理后排口—测量计的历史对应、更名/转移/多测点，以及外部保留目标名单和日体积/质量标记的历史可得时间。在此之前，只能报告SiteID级回顾性开发探索。
