# Stage3C2启动：可比性和完成状态审计

审计日期：2026-10-12。本文件在新扩源性能计算前阅读实际文件形成，记录旧代码事实和新版本要求，不修改Stage3B或Stage3C.1原科学字节。本轮优先顺序由用户明确更改为有限SiteID级扩源探索，旧天气草案仍未执行。新预测完成及K3逐条核验结果应看本版本独立输出，不能把本文审查当训练已完成。

## 实际阅读证据与旧完成状态

已读根AGENTS.md、STAGE3B_PROTOCOL.md、Stage3B full配置、shared_data.py、stage3a_data.py、stage3b_models.py、stage3b_experiment.py、stage3b_evaluation.py、汇总/独立核验/诊断/打包脚本、原smoke与full manifest/completion、Stage3C.1报告、映射状态、来源候选审计和天气草案。原smoke来自实际`--smoke`分支与12条completion，不推测测点。

旧Stage3B `runs/stage3b_20261011_v1/full/manifest.json`为completed、300 expected/300 completed、0 failed、0 not_executed。旧RUN_STATUS列198000条逐条预测、388938条两约束daily_losses及全部固定11策略；目前已做共享残差、bias和GRU归档，不能再说仅三个基线。该状态事实不等于本轮已经完整重现；本轮K3需重新对对应五策略逐条核验。

原smoke：SiteID13013/13015，首origin2022-01-01，B30/90/180，h1/3，共12条件。完整开发固定10个SiteID、五窗口、300目标条件。2023-10窗口已查看，C2全部标为已使用开发，2024—2025性能不运行。

## 占位值与特征：草案错误不进入代码

实际`shared_data.build_samples`的`volume=np.where(mask, observed/scale, 1.0)`，缺失数值为**归一化1.0**而非0。`stage3a_data.compact`选择序列位置[6,5,0]：当前、前1日、前6日体积，然后同位置mask；列序固定`[v0,v1,v6,m0,m1,m6]`。7日tensor为float32，紧凑Ridge继承其舍入，再在Ridge中转float；新版本不能因重写float64提取改变归档可比性。

Stage3C.1未执行的`next_experiment_draft.json` volume_features.values写normalized missing0，这是**文档草案与实际Stage3B不一致**。旧文件保留；C2新协议明确写1.0及mask，并只读复用实际shared_data/compact。此修复仅校正新阶段说明，不篡改Stage3B结果、也不将天气模型置为已完成。

尺度为允许历史正观测中位数，无正值1m³；Good零仍有mask1。训练筛选既有`usable`要求合法目标、有限Persistence和底层7日张量至少一项观测。Persistence找origin至origin−7最后合法体积；周预测用origin+h−7。残差以同Persistence构造，h3为第三日单日。

## 完成状态风险与本轮要求

旧训练入口最终manifest的`completed==len(all_tasks)`判定正确，不存在已证实的Stage3B300任务被partial冒充。具体风险是：

1. `stage3b_experiment.main`最后只在failed或结果failed时返回失败；`--max-jobs`造成partial但failed=0可以退出0，调用方若仅看退出码就误判完成。
2. `stage3b_evaluation.summarize_predictions`虽补缺失预测并报告missing_prediction_rows，却无条件写evaluation_validation.status='completed'；独立summarize脚本未先核验full manifest。因此“指标程序完成”可被误当“科学全配置完成”。
3. 旧最终计数收集状态字符串；源/任务cache在复用时核对其已记成员SHA，但空或缺失必要成员集合不由计数本身保证。C2要注册必要输出集合并在最终完整性检查再次校验，不能只查failed=0或已列成员。

现有Stage3B完整结果300/300，配套旧独立checker核验输出；上述风险本身**不改变旧科学结论**。修复仅写C2新入口/状态层：expected任务完整集合、指纹、必要文件和成员SHA通过才COMPLETED；partial、运行中、未执行、失败、输出缺失各自登记；resume只跳过已验证完成，保留失败attempt日志。测试必须实际覆盖partial/failed0、成员缺失和配置不匹配。

## K3门槛和统计可比性

预设归一化预测/bias/验证loss `atol=1e-10, rtol=1e-10`；日期/missing位置和alpha/lambda必须相同，lambda0与Persistence为精确拷贝。先12条件再全部300条件。记录逐条数量、最大差、选参不一致清单与原因，不比较四舍五入汇总替代门槛，不宣称逐位一致。

本地源辅助B30参数仍由原3源固定六fold选择，不借扩源优化本地。共享各池相同原3伪目标及2021Jan/Jul14日起点，held及关联测点从源训练剔除，训练≤2020；目标B90/180前缀尺度、purged label和bias保持原实现。残差与直接体积不是新算法；源等权w总和1，alpha对应平均MSE惩罚；记录实际池K和源训练样本。

所有共享/本地/P比较均同日期，逐SiteID误差比后等权，不能把共享相对本地技能当相对P。主分析汇总全部五个已用窗口；六主比较统一Bonferroni，5000同步分层时间块，与旧1000且原四/十月分开区间不能当逐值同一统计任务。扩源模型导致缺失时公开共同覆盖和失败，不无声删配置。物理身份与历史QA/日体积发布仍unknown，不支撑独立水厂或实时验证。

## 已实际核对文件SHA256

| 文件 | SHA256 |
|---|---|
| shared_data.py | 3814e7bb507fc7bbb19d63608982cc585f695c5b11b935fb53f380958a84f86a |
| stage3a_data.py | e07486e7a26097a3561f2d8b7c749c5b582a5ae15c49d82ab703d51c057f9bea |
| stage3b_models.py | 6e9c7eba6db81a382f9d21b0a5305be3750d75f20294598fa837bba47a8ef316 |
| stage3b_experiment.py | 18743b08dc357ec63b20eb6801afd6d37151ab122055fac55b5f5253d976e942 |
| stage3b_evaluation.py（本轮实际现存版本） | c38592ef582548f22b092f2fcdfebe10168f550e6dcab8dc53edf552c4ba1c16 |
| Stage3B full.json | d9225bce0bc649774f2a3b0bd9408b08b458c46e253a43a3d168ced1c525a00f |
| STAGE3B_PROTOCOL.md | 087f3d80a6b9fe0758dea97b85b5021649f66317f3d8b6c3fa6089ad5426068c |
| C1 next_experiment_draft.json | 9989af88a091f4632b549e60ad742ca7c3b5dcc68ecff99a1c88b227e20e6242 |
| C1 FEASIBILITY_ZH.md | 2058030462595a9900560d0e9ce88260457090f1c6e1065aa0060b1c4ebec756 |

旧smoke早期runtime记录stage3b_evaluation SHA020ae...，并非本轮现存c38592...；旧归档还有后续软件修正轨迹，不能混称所有阶段同一源码。本轮从现存字节建立保留清单，并以各实际使用依赖SHA冻结新入口，旧版本记录不覆盖。

此报告是启动审计，待真实K3 replay、全任务和独立指标检查后，在新结果文件记录最终结论。本轮本身不需要重训GRU、天气或访问最终期性能。
