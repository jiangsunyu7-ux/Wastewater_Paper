# Stage 3A delivery and stopping boundary

Read reports/stage3a_20261010/ANALYSIS_ZH.md and STAGE3A_PROTOCOL.md first.
The accepted run is runs/stage3a_20261010_v3: 240 conditions, three original
seeds, all original budgets/horizons and fixed development SiteIDs/windows.
Published QA is retrospective; physical identity and real-time arrival are
unverified. No final 2024–2025 performance, intervals, residual model, source
expansion, app or rewritten full manuscript is included. STOP after Stage 3A.

Extract every Stage3A Code_Data, Runs part and Reports_Figures part into a NEW
shared ROOT. Verify every ZIP's SHA256SUMS and CRC; skip extracting SHA256SUMS
to avoid manifest collisions. Conflicting files must not be overwritten.

The unchanged original Stage 2 archives are dependencies and remain separately
available from the Stage 2 GitHub delivery. Keep all three under
deliverables/stage2_20261010/ and independently copy to
preservation/stage2_before_stage3a_20261010/. Extract Stage2 Runs and Reports
into ROOT; do NOT overlay Stage2 Code's older document payload on Stage3A Code.
Stage3A Code already contains the preserved original scientific source,
configurations, QA data and supporting metadata. Stage2 Runs are needed for
archived epoch40/head10 checks, and Stage2 Reports supply original comparators.
The new CPU notebook performs this checksum-checked import and rejects conflicts.

See STAGE3A_IMPLEMENTATION.md for run commands and preflight fixes. Changed
scientific code/data/config/initial weights require a new version. Completed
jobs are checksum-verified and cached; incomplete training resumes from atomic
optimizer/shuffle checkpoints. Failed preflight versions and logs are retained,
not silently replaced. Software fixtures are not scientific measurements.

All new ZIPs are smaller than 24 MiB, with complete per-member SHA256 manifests.
Raw million-row CSV and virtual environments are excluded. Derived QA data
reproduce this version; rebuilding raw QA needs original uploaded data packages.
CPU validation is actual; live Colab/Drive and GPU execution are not claimed.
