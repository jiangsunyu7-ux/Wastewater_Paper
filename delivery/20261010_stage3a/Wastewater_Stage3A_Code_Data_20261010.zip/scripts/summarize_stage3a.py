"""Matched-date Stage 3A reporting with all original Stage 2 comparators."""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd

import summarize_shared_v3 as stats
from wastewater.common import sha256,write_json

MODELS=stats.MODELS+['local_ridge42_tuned','local_ridge_lags_tuned','shared_ridge_lags','shared_ridge_lags_bias',
                   'local_gru_selected','shared_gru_selected','shared_gru_head_selected']
TRANSFER={'shared_ridge':'local_ridge42_tuned','shared_ridge_bias':'local_ridge42_tuned',
          'shared_ridge_lags':'local_ridge_lags_tuned','shared_ridge_lags_bias':'local_ridge_lags_tuned',
          'shared_gru':'local_gru_selected','shared_gru_adapt':'local_gru_selected',
          'shared_gru_selected':'local_gru_selected','shared_gru_head_selected':'local_gru_selected'}


def contrasts():
    pairs=[]
    def add(m,b,ref,rb,h,kind):
        pairs.append(dict(id=f'{m}_B{b}_vs_{ref}_B{rb}_H{h}',model=m,budget=b,reference=ref,reference_budget=rb,horizon=h,kind=kind))
    for h in [1,3]:
        for b in [30,90,180]:
            for model in MODELS:
                if model not in ['persistence','weekly_persistence']:add(model,b,'persistence',b,h,'vs_persistence')
            for model,local in TRANSFER.items():add(model,b,local,b,h,'same_budget_transfer')
            for model,ref in [('local_ridge42_tuned','local_ridge'),('local_ridge_lags_tuned','local_ridge'),('local_gru_selected','local_gru'),('shared_gru_selected','shared_gru'),('shared_gru_head_selected','shared_gru_adapt')]:add(model,b,ref,b,h,'training_or_feature_diagnostic')
        for b,rb in [(30,90),(30,180),(90,180)]:
            for model,local in TRANSFER.items():add(model,b,local,rb,h,'history_budget_comparison')
    return pairs


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--run',default='runs/stage3a_20261010_v3/full');ap.add_argument('--output',default='reports/stage3a_20261010/results');args=ap.parse_args()
    root=Path(__file__).resolve().parents[1];out=root/args.output;out.mkdir(parents=True,exist_ok=True)
    manifest=json.loads((root/args.run/'manifest.json').read_text());cfg=manifest['config']
    if manifest['status']!='completed' or manifest['failed_conditions']:raise ValueError('Incomplete Stage 3A scientific run')
    completion=json.loads((root/args.run/'completion.json').read_text());frames=[];diagnostics=[];selections=[];endpoint_frames=[];curve_frames=[];checks=[]
    for c in completion:
        job=root/c['folder'];status=json.loads((job/'status.json').read_text())
        if status['status']!='completed':raise ValueError('Failed scientific job')
        for name,h in status['outputs_sha256'].items():
            if sha256(job/name)!=h:raise ValueError('Changed completed output')
        frames.append(pd.read_csv(job/'predictions.csv',dtype={'site_id':str}))
        diag=json.loads((job/'diagnostics.json').read_text());sel=diag['selection']
        selections.append(dict({k:diag[k] for k in ['site_id','episode','budget','horizon','training_labels']},
            **sel['fold'],local_epoch=sel['local_epoch'],head_epoch=sel['head_epoch'],alpha42=sel['ridge_alphas']['42'],alpha_lags=sel['ridge_alphas']['lags'],shared_epoch=diag['source_shared_epoch']))
        for t in diag['training']:
            for family in ['local','head']:
                d=t[family];diagnostics.append(dict(site_id=diag['site_id'],episode=diag['episode'],budget=diag['budget'],horizon=diag['horizon'],seed=t['seed'],training_seed=d['seed'],family=family,**{k:v for k,v in d.items() if k not in ['metadata','seed']}))
            checks.extend(dict(task=c['task'],seed=t['seed'],family=k,**v) for k,v in t['stage2_endpoint_checks'].items())
        for f in job.glob('endpoint_predictions_seed*.csv'):endpoint_frames.append(pd.read_csv(f,dtype={'site_id':str}))
        for f in job.glob('*/curve.csv'):
            frame=pd.read_csv(f);frame['task']=c['task'];frame['trajectory']=f.parent.name;curve_frames.append(frame)
    old_path=root/'reports/shared_v3_20261009/predictions_all.csv';old=pd.read_csv(old_path,dtype={'site_id':str})
    p=pd.concat([old.drop(columns=['common_evaluation'],errors='ignore'),*frames],ignore_index=True)
    keys=['site_id','episode','horizon','origin','target_date']
    sizes=p.groupby(keys).size()
    if not sizes.eq(81).all() or len(sizes)!=4800:raise AssertionError('Missing model/seed/budget predictions')
    bounds=p.groupby(keys).truth_m3.agg(['min','max'])
    if ((bounds['max']-bounds['min'])>1e-8+1e-12*bounds['min'].abs()).any():raise AssertionError('Model truths differ beyond float roundtrip')
    if p.duplicated(keys+['budget','model','seed']).any():raise AssertionError('Duplicate condition')
    origin=pd.to_datetime(p.origin);target=pd.to_datetime(p.target_date)
    if not ((target-origin).dt.days==p.horizon).all():raise AssertionError('Horizon misalignment')
    if target.max()>pd.Timestamp('2023-12-31'):raise AssertionError('Forbidden final data')
    if (pd.to_datetime(p.last_train_target)>pd.to_datetime(p.fit_end)).any():raise AssertionError('Fit label leakage')
    finite=np.isfinite(p.truth_m3)&np.isfinite(p.prediction_m3);valid=finite.groupby([p[k] for k in keys]).all()
    p['common_evaluation']=p.set_index(keys).index.map(valid).astype(bool);p.to_csv(out/'predictions_all.csv',index=False)
    ep=pd.concat(endpoint_frames,ignore_index=True);ep['common_evaluation']=ep.set_index(keys).index.map(valid).astype(bool);ep.to_csv(out/'endpoint_predictions.csv',index=False)
    pd.DataFrame(selections).to_csv(out/'validation_selections.csv',index=False);pd.DataFrame(diagnostics).to_csv(out/'training_diagnostics.csv',index=False);pd.DataFrame(checks).to_csv(out/'stage2_endpoint_checks.csv',index=False)
    pd.concat(curve_frames,ignore_index=True).to_csv(out/'target_training_curves.csv',index=False)
    availability=p.groupby(['site_id','episode','budget','horizon','model','seed']).agg(origins=('origin','size'),valid_truths=('truth_m3','count'),predictions=('prediction_m3','count'),common_dates=('common_evaluation','sum'),negative_predictions=('prediction_m3',lambda x:int(x.lt(0).sum()))).reset_index();availability.to_csv(out/'availability.csv',index=False)
    common=p[p.common_evaluation].copy();daily_frames=[];seed_frames=[];group=keys+['budget','model']
    for constraint,column in [('raw','prediction_m3'),('all_models_nonnegative','prediction_nonnegative_m3')]:
        f=common.copy();err=f[column]-f.truth_m3;f['absolute_error']=err.abs();f['squared_error']=err**2;f['constraint']=constraint
        seed=stats.station_metrics(f,['constraint','site_id','budget','horizon','model','seed']);seed_frames.append(seed)
        daily=f.groupby(group).agg(absolute_error=('absolute_error','mean'),squared_error=('squared_error','mean'),truth_m3=('truth_m3','first'),high_threshold_m3=('high_threshold_m3','first'),seed_count=('seed','nunique')).reset_index();daily['constraint']=constraint;daily_frames.append(daily)
    daily=pd.concat(daily_frames,ignore_index=True);daily.to_csv(out/'daily_losses.csv',index=False)
    metric=stats.station_metrics(daily,['constraint','site_id','budget','horizon','model']);metric.to_csv(out/'metrics_by_station.csv',index=False)
    pd.concat(seed_frames,ignore_index=True).to_csv(out/'metrics_by_station_seed.csv',index=False)
    summary=stats.aggregate_station_metrics(metric);summary.to_csv(out/'summary.csv',index=False)
    high=daily[daily.truth_m3.ge(daily.high_threshold_m3)].copy();hm=stats.station_metrics(high,['constraint','site_id','budget','horizon','model']);hm.to_csv(out/'high_volume_metrics_by_station.csv',index=False);stats.aggregate_station_metrics(hm).to_csv(out/'high_volume_summary.csv',index=False)
    stats.MODELS=MODELS;stats.contrasts=contrasts
    ci,paired=stats.block_intervals(daily[daily.constraint.eq('raw')],cfg);ci.to_csv(out/'paired_block_intervals.csv',index=False);paired.to_csv(out/'paired_comparisons_by_station.csv',index=False)
    hi,hp=stats.block_intervals(high[high.constraint.eq('raw')],cfg);hi.to_csv(out/'high_volume_block_intervals.csv',index=False);hp.to_csv(out/'high_volume_paired_by_station.csv',index=False)
    trans=paired[paired.kind.eq('same_budget_transfer')].groupby(['model','budget','horizon','reference']).agg(stations=('site_id','size'),mean_skill_vs_local=('skill','mean'),median_skill_vs_local=('skill','median'),negative_transfer_stations=('negative_transfer','sum')).reset_index();trans['negative_transfer_fraction']=trans.negative_transfer_stations/trans.stations;trans.to_csv(out/'negative_transfer_summary.csv',index=False)
    endpoint=ep[ep.common_evaluation].copy();error=endpoint.prediction_m3-endpoint.truth_m3;endpoint['absolute_error']=error.abs();endpoint['squared_error']=error**2
    em=endpoint.groupby(['site_id','budget','horizon','model','seed']).agg(n_dates=('origin','size'),mae_m3=('absolute_error','mean'),mse=('squared_error','mean')).reset_index();em['rmse_m3']=np.sqrt(em.pop('mse'));em.to_csv(out/'endpoint_metrics_by_station_seed.csv',index=False)
    checksum=json.loads((root/'preservation/stage2_before_stage3a_20261010/manifest.json').read_text());changed=[f for f,h in checksum['files_sha256'].items() if sha256(root/f)!=h]
    if changed:raise AssertionError(f'Stage 2 changed: {changed}')
    write_json(out/'validation.json',dict(status='passed',stage2_preserved_files=len(checksum['files_sha256']),stage2_changed_files=changed,new_conditions=len(completion),prediction_rows=len(p),endpoint_prediction_rows=len(ep),common_site_episode_horizon_origin_groups=int(valid.sum()),candidate_groups=len(valid),final_performance_used=False,seed_aggregation='per-date loss mean, no seed independence and no prediction ensemble',run_manifest_sha256=sha256(root/args.run/'manifest.json'),stage2_predictions_sha256=sha256(old_path),outputs_sha256={f.name:sha256(f) for f in out.iterdir() if f.is_file()}))
    print(summary[summary.constraint.eq('raw')].to_string(index=False))


if __name__=='__main__':main()
