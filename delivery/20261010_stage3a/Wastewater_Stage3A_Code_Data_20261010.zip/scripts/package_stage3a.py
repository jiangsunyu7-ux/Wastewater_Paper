"""Package checked Stage 3A outputs, keeping every ZIP strictly below 24 MiB."""
import hashlib
import json
import os
from pathlib import Path
import tempfile
import zipfile
import zlib
from wastewater.common import sha256,write_json

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'deliverables/stage3a_20261010'
LIMIT=24*1024**2;TARGET=22*1024**2
SKIP={'__pycache__','.git','.cache','.ipynb_checkpoints'}


def collect(paths):
    files={}
    for name in paths:
        p=ROOT/name
        if not p.exists():raise FileNotFoundError(p)
        for f in ([p] if p.is_file() else sorted(p.rglob('*'))):
            if f.is_file() and not any(s in SKIP for s in f.relative_to(ROOT).parts) and f.suffix not in ['.pyc','.pyo']:
                if f.is_symlink() or not f.resolve().is_relative_to(ROOT):raise ValueError('Unsafe payload')
                files[str(f.relative_to(ROOT))]=f
    return files


def instructions():
    return '''# Stage 3A delivery and stopping boundary

Read reports/stage3a_20261010/ANALYSIS_ZH.md and STAGE3A_PROTOCOL.md first.
The accepted run is runs/stage3a_20261010_v3: 240 conditions, three original
seeds, all original budgets/horizons and fixed development SiteIDs/windows.
Published QA is retrospective; physical identity and real-time arrival are
unverified. No final 2024–2025 performance, intervals, residual model, source
expansion, app or rewritten full manuscript is included. STOP after Stage 3A.

Extract every Stage3A Code_Data, Runs part and Reports_Figures part into a NEW
shared ROOT. Verify every ZIP's SHA256SUMS and CRC; skip extracting SHA256SUMS
to avoid manifest collisions. Conflicting files must not be overwritten.

The unchanged original Stage 2 archives are dependencies and remain separately
available from the Stage 2 GitHub delivery. Keep all three under
deliverables/stage2_20261010/ and independently copy to
preservation/stage2_before_stage3a_20261010/. Extract Stage2 Runs and Reports
into ROOT; do NOT overlay Stage2 Code's older document payload on Stage3A Code.
Stage3A Code already contains the preserved original scientific source,
configurations, QA data and supporting metadata. Stage2 Runs are needed for
archived epoch40/head10 checks, and Stage2 Reports supply original comparators.
The new CPU notebook performs this checksum-checked import and rejects conflicts.

See STAGE3A_IMPLEMENTATION.md for run commands and preflight fixes. Changed
scientific code/data/config/initial weights require a new version. Completed
jobs are checksum-verified and cached; incomplete training resumes from atomic
optimizer/shuffle checkpoints. Failed preflight versions and logs are retained,
not silently replaced. Software fixtures are not scientific measurements.

All new ZIPs are smaller than 24 MiB, with complete per-member SHA256 manifests.
Raw million-row CSV and virtual environments are excluded. Derived QA data
reproduce this version; rebuilding raw QA needs original uploaded data packages.
CPU validation is actual; live Colab/Drive and GPU execution are not claimed.
'''


def compressed_size(files):
    total=0
    for name,p in files.items():
        c=zlib.compressobj(6,zlib.DEFLATED,-15);size=0
        with p.open('rb') as f:
            for b in iter(lambda:f.read(1024**2),b''):size+=len(c.compress(b))
        size+=len(c.flush());total+=size+len(name.encode())*3+300
    return total


def archive(folder,files,label,index,count):
    name=f'Wastewater_Stage3A_{label}_20261010'+(f'_Part{index:02d}' if count>1 else '')+'.zip';p=folder/name
    checks={}
    with zipfile.ZipFile(p,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,f in sorted(files.items()):z.write(f,n);checks[n]=sha256(f)
        n=f'START_HERE_STAGE3A_{label}_{index:02d}.md';body=instructions().encode();z.writestr(n,body);checks[n]=hashlib.sha256(body).hexdigest()
        z.writestr('SHA256SUMS',''.join(f'{h}  {n}\n' for n,h in sorted(checks.items())))
    assert p.stat().st_size<LIMIT
    with zipfile.ZipFile(p) as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
        for n,h in checks.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
    return dict(filename=name,bytes=p.stat().st_size,sha256=sha256(p),member_count=len(checks)+1,payload_files=len(files),part=index,parts=count,crc_and_all_member_hashes_passed=True)


def parts(files,label):
    groups={}
    for n,p in files.items():
        bits=Path(n).parts
        if label=='Runs' and 'jobs' in bits:key='/'.join(bits[:bits.index('jobs')+2])
        else:key=n
        groups.setdefault(key,{})[n]=p
    chunks=[];current={};size=0
    for key,atom in sorted(groups.items()):
        amount=compressed_size(atom)
        if amount>=TARGET:raise ValueError(f'One complete artifact exceeds size target: {key}')
        if current and size+amount>TARGET:chunks.append(current);current={};size=0
        current.update(atom);size+=amount
    if current:chunks.append(current)
    return chunks


def main():
    cfg=json.loads((ROOT/'configs/stage3a_20261010/full.json').read_text());m=json.loads((ROOT/cfg['output']/'manifest.json').read_text());v=json.loads((ROOT/'reports/stage3a_20261010/results/validation.json').read_text())
    assert m['status']=='completed' and m['completed_conditions']==240 and not m['failed_conditions'] and v['status']=='passed'
    for f,h in m['provenance']['core_sha256'].items():assert sha256(ROOT/'src/wastewater'/f)==h
    assert sha256(ROOT/cfg['canonical_csv'])==m['provenance']['data_sha256']
    preserved=json.loads((ROOT/'preservation/stage2_before_stage3a_20261010/manifest.json').read_text())
    for f,h in preserved['files_sha256'].items():assert sha256(ROOT/f)==h
    docs=['AGENTS.md','STATUS.md','EXPERIMENT_PROTOCOL.md','RESEARCH_PLAN.md','STAGE3A_PROTOCOL.md','STAGE3A_IMPLEMENTATION.md','WORKFLOW.md','README.md','requirements.txt','requirements-stage2.txt','.gitignore','claim_traceability_stage3a.csv']
    provenance=['data/provenance/DEVELOPMENT_SELECTION_20261009.json','data/provenance/DEVELOPMENT_STATIONS_20261009.csv','data/provenance/SMOKE_STATIONS_20261009.csv','data/provenance/FACILITY_MAPPING.csv','data/provenance/FACILITY_MAPPING_V3_20261009.csv','data/provenance/SOURCE_REGISTRY.csv','data/provenance/SEMANTICS_AND_TIMING_20261009.md','data/provenance/reconciliation_20261009','data/provenance/stage2_facility_access_20261009','data/provenance/paper_idea_20261009_extracted.txt']
    # Avoid including full raw audit tables; retained QA-derived experiment files are sufficient.
    provenance=[x for x in provenance if x!='data/provenance/reconciliation_20261009']+['data/provenance/reconciliation_20261009/coverage_2016_2021.csv','data/provenance/reconciliation_20261009/eligible_station_ids_2016_2021.json','data/provenance/reconciliation_20261009/reconciliation.json','data/provenance/reconciliation_20261009/conflicting_original_records.csv']
    code=collect(docs+['src','tests','configs','scripts','notebooks','data/derived/wessex_qa_v3_20261009']+provenance+['data/derived/wessex_audit_20261009/manifest.json','data/derived/wessex_audit_20261009/rules.json','data/derived/wessex_audit_20261009/summary.json'])
    for folder in ['preservation/stage2_before_stage3a_20261010','deliverables/stage2_20261010']:
        for p in (ROOT/folder).iterdir():
            if p.is_file() and p.suffix!='.zip':code[str(p.relative_to(ROOT))]=p
    for p in (ROOT/'wastewater_data/metadata').glob('wessex_*'):code[str(p.relative_to(ROOT))]=p
    runs=collect(['runs/stage3a_20261010','runs/stage3a_20261010_v2','runs/stage3a_20261010_v3'])
    reports=collect(['reports/stage3a_20261010','figures/stage3a_20261010'])
    for p in (ROOT/'validation').glob('stage3a*'):
        if p.is_file() and p.name!='stage3a_package_checks.json':reports[str(p.relative_to(ROOT))]=p
    assert not (set(code)&set(runs) or set(code)&set(reports) or set(runs)&set(reports))
    if OUT.exists():raise FileExistsError('Delivery is immutable; use a new directory')
    OUT.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='stage3a_delivery_',dir=OUT.parent) as td:
        folder=Path(td);records=[]
        for label,files in [('Code_Data',code),('Runs',runs),('Reports_Figures',reports)]:
            chunks=parts(files,label)
            for i,chunk in enumerate(chunks,1):records.append(archive(folder,chunk,label,i,len(chunks)))
        (folder/'SHA256SUMS').write_text(''.join(f"{r['sha256']}  {r['filename']}\n" for r in records))
        (folder/'README.md').write_text(instructions())
        receipt=dict(status='passed',all_new_zip_sizes_below_24_MiB=True,packages=records,
            stage2_preserved_files=len(preserved['files_sha256']),scientific_run_manifest_sha256=sha256(ROOT/cfg['output']/'manifest.json'),
            original_stage2_archives_required=True,model_training_executed_by_packager=False,raw_final_period_data_packaged=False)
        write_json(folder/'package_checks.json',receipt);os.rename(folder,OUT)
    write_json(ROOT/'validation/stage3a_package_checks.json',receipt)
    print(json.dumps(receipt,indent=2))


if __name__=='__main__':main()
