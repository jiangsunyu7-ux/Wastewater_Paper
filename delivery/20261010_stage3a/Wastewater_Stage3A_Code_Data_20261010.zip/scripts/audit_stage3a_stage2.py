"""Read-only Stage-2 training and Ridge-design audit for Stage 3A.

Reads only frozen QA-v3 canonical data (ending in 2023), saved checkpoints,
parameters, and provenance. Does not train, select a new model, or calculate
prediction-window performance. Outputs are independent of Stage-2 directories.
"""
import argparse
import hashlib
import json
import math
import platform
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from wastewater.shared_data import load_series, scale_from_history, train_samples
from wastewater.shared_experiment import source_pool


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                   allow_nan=False) + '\n')


def checkpoint_audit(path, relative_path, identity, curves, source_state=None):
    # No device remapping: record the devices actually serialized by Stage 2.
    # The audited core explicitly allocates its tensors/model on CPU.
    state = torch.load(path, weights_only=False)
    meta = state['metadata']
    losses = np.asarray(state['losses'], dtype=float)
    require(len(losses) == state['epoch'] == meta['epochs'], f'Incomplete checkpoint: {path}')
    require(np.isfinite(losses).all(), f'Nonfinite loss: {path}')
    model = state['model']
    require(all(value.device.type == 'cpu' for value in model.values()),
            f'Stage-2 checkpoint does not contain CPU tensors: {path}')
    total_parameters = sum(value.numel() for value in model.values())
    head_parameters = sum(value.numel() for name, value in model.items() if name.startswith('head.'))
    require(head_parameters == meta['hidden'] + 1, f'Unexpected head: {path}')
    trainable = head_parameters if meta['head_only'] else total_parameters
    actual_steps = [int(value['step']) for value in state['optimizer']['state'].values()]
    batches = math.ceil(meta['n'] / meta['batch_size'])
    require(actual_steps and min(actual_steps) == max(actual_steps) == state['epoch'] * batches,
            f'Optimizer step mismatch: {path}')
    require(len(actual_steps) == (2 if meta['head_only'] else len(model)),
            f'Optimizer parameter membership mismatch: {path}')
    groups = state['optimizer']['param_groups']
    require(len(groups) == 1 and groups[0]['lr'] == meta['lr'], f'Learning-rate mismatch: {path}')
    if source_state is not None:
        require(meta['head_only'], 'Only head adaptation accepts a source state')
        require(all(torch.equal(value, source_state['model'][name])
                    for name, value in model.items() if name.startswith('gru.')),
                f'Frozen encoder changed: {path}')
    # Late improvement is descriptive training-objective evidence, not a
    # convergence, validation, overfitting, or generalization test.
    span = min(10, len(losses) // 2)
    prior_mean = float(np.mean(losses[-2 * span:-span]))
    last_mean = float(np.mean(losses[-span:]))
    record = dict(identity, checkpoint=relative_path, checkpoint_sha256=sha(path),
                  hidden=int(meta['hidden']), epochs=int(state['epoch']),
                  effective_training_seed=int(meta['seed']),
                  training_labels=int(meta['n']), batch_size=int(meta['batch_size']),
                  batches_per_epoch=batches, optimizer_steps=min(actual_steps),
                  optimizer_parameter_tensors=len(actual_steps), total_parameters=total_parameters,
                  trainable_parameters=trainable, head_parameters=head_parameters,
                  learning_rate=float(meta['lr']), weight_decay=float(groups[0]['weight_decay']),
                  saved_tensor_devices=','.join(sorted({str(v.device) for v in model.values()})),
                  fit_seconds=float(state['elapsed_seconds']), first_training_mse=float(losses[0]),
                  last_training_mse=float(losses[-1]), late_mean_training_mse=last_mean,
                  previous_mean_training_mse=prior_mean, late_mean_span_epochs=span,
                  late_relative_training_mse_decrease=(1 - last_mean / prior_mean if prior_mean > 0 else 0),
                  final_step_relative_training_mse_decrease=(1 - losses[-1] / losses[-2]
                                                            if len(losses) > 1 and losses[-2] > 0 else 0),
                  total_relative_training_mse_decrease=(1 - losses[-1] / losses[0] if losses[0] > 0 else 0),
                  encoder_equals_source=bool(source_state is not None),
                  loss_is_dynamic_epoch_minibatch_weighted_mse=True)
    for epoch, value in enumerate(losses, 1):
        curves.append(dict(identity, checkpoint=relative_path, hidden=int(meta['hidden']),
                           epoch=epoch, optimizer_steps_at_epoch=epoch * batches,
                           normalized_training_mse=float(value)))
    return state, record


CHANNELS = ['volume', 'observed_mask', 'input_weekday_sin', 'input_weekday_cos',
            'target_weekday_sin', 'target_weekday_cos']


def design_audit(X, y, weights, alpha, identity, columns, spectra, parameters=None,
                 origin_weekdays=None):
    matrix = X.reshape(len(X), -1).astype(float)
    weights = np.asarray(weights, dtype=float)
    require(matrix.shape[1] == 42 and np.isclose(weights.sum(), 1), 'Unexpected Ridge design')
    mean = np.average(matrix, axis=0, weights=weights)
    centered = matrix - mean
    weighted = centered * np.sqrt(weights)[:, None]
    singular = np.linalg.svd(weighted, compute_uv=False)
    largest = float(singular[0])
    exact_tol = largest * max(weighted.shape) * np.finfo(float).eps
    effective_tol = largest * 1e-6
    exact_rank = int(np.sum(singular > exact_tol))
    effective_rank = int(np.sum(singular > effective_tol))
    effective_condition = largest / float(singular[effective_rank - 1]) if effective_rank else None
    exact_condition = largest / float(singular[exact_rank - 1]) if exact_rank else None
    eigenvalues = singular ** 2
    effective_df = float(np.sum(eigenvalues / (eigenvalues + alpha)))
    std = np.sqrt(np.sum(weights[:, None] * centered ** 2, axis=0))
    constants = std <= 1e-12
    nonconstant = ~constants
    correlation = np.zeros((42, 42))
    if nonconstant.any():
        standardized = weighted[:, nonconstant] / std[nonconstant]
        correlation[np.ix_(nonconstant, nonconstant)] = standardized.T @ standardized
    near_collinear_pairs = int(np.sum(np.triu(np.abs(correlation) >= .999999, k=1)))
    calendar = matrix[:, np.tile(np.arange(6) >= 2, 7)]
    calendar_centered = calendar - np.average(calendar, axis=0, weights=weights)
    calendar_singular = np.linalg.svd(calendar_centered * np.sqrt(weights)[:, None], compute_uv=False)
    calendar_effective_rank = int(np.sum(calendar_singular > calendar_singular[0] * 1e-6))
    projection_relative_error = None
    if origin_weekdays is not None:
        angle = np.asarray(origin_weekdays) * (2 * np.pi / 7)
        basis = np.stack([np.ones(len(angle)), np.sin(angle), np.cos(angle)], axis=1)
        coefficient = np.linalg.lstsq(basis, calendar, rcond=None)[0]
        projection_relative_error = float(np.linalg.norm(calendar - basis @ coefficient) / np.linalg.norm(calendar))
    record = dict(identity, training_labels=len(y), feature_columns=42,
                  alpha=float(alpha), sample_weights_sum=float(weights.sum()),
                  centered_rank_float64_tolerance=exact_rank,
                  centered_effective_rank_relative_1e6=effective_rank,
                  largest_weighted_singular_value=largest,
                  centered_condition_nonzero_float64=exact_condition,
                  centered_condition_effective_relative_1e6=effective_condition,
                  rank_float64_threshold=exact_tol, rank_effective_threshold=effective_tol,
                  constant_columns=int(constants.sum()), near_collinear_abs_cor_999999_pairs=near_collinear_pairs,
                  calendar_effective_rank_relative_1e6=calendar_effective_rank,
                  calendar_projection_relative_error=projection_relative_error,
                  effective_df_penalized=effective_df,
                  effective_df_including_unpenalized_intercept=effective_df + 1,
                  effective_df_per_training_label=(effective_df + 1) / len(y),
                  ridge_normal_matrix_condition_full=((largest ** 2 + alpha) / alpha
                                                     if exact_rank < 42 else
                                                     (largest ** 2 + alpha) / (float(singular[-1]) ** 2 + alpha)),
                  volume_feature_std_min=float(std[::6].min()),
                  volume_feature_std_max=float(std[::6].max()),
                  volume_feature_max=float(X[:, :, 0].max()),
                  mask_feature_std_min=float(std[1::6].min()),
                  mask_feature_std_max=float(std[1::6].max()),
                  normalized_target_mean=float(np.mean(y)),
                  normalized_target_std=float(np.std(y)))
    if parameters is not None:
        coefficient, intercept = parameters
        residual = y - (matrix @ coefficient + intercept)
        mse = float(np.sum(weights * residual ** 2))
        record.update(training_weighted_mse=mse, coefficient_l2=float(np.linalg.norm(coefficient)),
                      ridge_penalty=float(alpha * np.sum(coefficient ** 2)),
                      ridge_training_objective=float(mse + alpha * np.sum(coefficient ** 2)))
    for i, value in enumerate(singular):
        spectra.append(dict(identity, index=i + 1, weighted_singular_value=float(value),
                            effective_df_contribution=float(value ** 2 / (value ** 2 + alpha))))
    for index in range(42):
        lag, channel = divmod(index, 6)
        columns.append(dict(identity, column=index, day_offset=lag - 6,
                            channel=CHANNELS[channel], weighted_mean=float(mean[index]),
                            weighted_std=float(std[index]), constant=bool(constants[index])))
    return record


def grouped_summary(frame, groups, measures):
    rows = []
    for key, part in frame.groupby(groups, dropna=False, sort=True):
        key = key if isinstance(key, tuple) else (key,)
        row = dict(zip(groups, key))
        row['records'] = len(part)
        for measure in measures:
            values = part[measure].dropna()
            row.update({measure + '_min': float(values.min()),
                        measure + '_median': float(values.median()),
                        measure + '_max': float(values.max())})
        rows.append(row)
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', default='runs/shared_v3_20261009/full')
    parser.add_argument('--output', default='reports/stage3a_20261010/audit')
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    folder, output = root / args.run, root / args.output
    require(folder.resolve() != output.resolve() and not output.resolve().is_relative_to(folder.resolve()),
            'Audit output must not overwrite the frozen Stage-2 run')
    output.mkdir(parents=True, exist_ok=True)
    manifest = read(folder / 'manifest.json')
    cfg = manifest['config']
    require(manifest['status'] == 'completed' and manifest['completed_jobs'] == 960, 'Incomplete Stage-2 run')
    provenance = {'run_manifest': sha(folder / 'manifest.json'),
                  'canonical': sha(root / cfg['canonical_csv']),
                  'selection': sha(root / cfg['source_output'] / 'selection.json'),
                  'checker_script': sha(__file__),
                  'stage2_environment': sha(root / 'validation/stage2_environment.json'),
                  'existing_independent_checkpoint_checks': sha(root / 'validation/stage2_checkpoint_real_checks.json'),
                  'core': {name: sha(root / 'src/wastewater' / name)
                           for name in manifest['provenance']['core']}}
    require(provenance['canonical'] == manifest['provenance']['data'], 'Changed QA-v3 canonical')
    require(provenance['core'] == manifest['provenance']['core'], 'Changed Stage-2 core')
    decision = read(root / cfg['source_output'] / 'selection.json')
    require(decision['signature'] == manifest['signature'], 'Changed selection signature')
    source_series = load_series(root / cfg['canonical_csv'], cfg['source_ids'])
    target_series = load_series(root / cfg['canonical_csv'], cfg['development_ids'])
    checkpoint_rows, curves, ridge_rows, columns, spectra, source_states = [], [], [], [], [], {}
    for horizon in cfg['horizons']:
        X, y, w, diagnostic = source_pool(source_series, cfg, horizon, cfg['source_training_end'])
        require(all(row['last_train_target'] <= '2021-12-31' for row in diagnostic), 'Source boundary violated')
        alpha = decision['selected'][str(horizon)]['alpha']
        ridge_rows.append(design_audit(X, y, w, alpha,
            {'family': 'source', 'site_id': 'pooled3', 'episode': '2016-2021', 'budget': 0, 'horizon': horizon},
            columns, spectra))
        for seed in cfg['seeds']:
            path = root / cfg['source_output'] / f'final_h{horizon}_seed{seed}.pt'
            state, record = checkpoint_audit(path, str(path.relative_to(root)),
                {'family': 'shared_gru', 'site_id': 'pooled3', 'episode': '2016-2021',
                 'budget': 0, 'horizon': horizon, 'replicate_seed': seed}, curves)
            require(state['metadata']['signature'] == manifest['signature'], 'Source signature mismatch')
            source_states[horizon, seed] = state
            checkpoint_rows.append(record)
        for hidden in cfg['gru_hidden_candidates']:
            path = root / cfg['source_output'] / f'select_h{horizon}_hidden{hidden}.pt'
            state, record = checkpoint_audit(path, str(path.relative_to(root)),
                {'family': 'source_selection_gru', 'site_id': 'pooled3', 'episode': '2016-2020',
                 'budget': 0, 'horizon': horizon, 'replicate_seed': cfg['selection_seed']}, curves)
            require(state['metadata']['signature'] == manifest['signature'], 'Selection signature mismatch')
            checkpoint_rows.append(record)
    for site in cfg['development_ids']:
        series = target_series[site]
        for episode in cfg['origins']:
            for budget in cfg['budgets']:
                left = pd.Timestamp(episode) - pd.Timedelta(days=budget)
                end = pd.Timestamp(episode) - pd.Timedelta(days=1)
                scale = scale_from_history(series, left, end)
                for horizon in cfg['horizons']:
                    identity = {'site_id': site, 'episode': episode, 'budget': budget, 'horizon': horizon}
                    task = f'{site}_{episode}_B{budget}_H{horizon}'
                    train = train_samples(series, left, end, horizon, scale)
                    require(train.targets.max() <= end and train.origins.min() >= left, 'Budget boundary violated')
                    base = folder / 'jobs' / ('baseline_' + task)
                    diag = read(base / 'diagnostics.json')
                    status = read(base / 'status.json')
                    require(status['status'] == 'completed', 'Baseline not complete')
                    require(sha(base / 'ridge_parameters.npz') == status['outputs_sha256']['ridge_parameters.npz'],
                            'Changed saved Ridge parameters')
                    require(hashlib.sha256(train.X.tobytes()).hexdigest() == diag['training_X_sha256'],
                            'Reconstructed training tensor differs')
                    require(len(train.y) == diag['training_labels'] and scale == diag['scale_m3'],
                            'Reconstructed labels/scale differ')
                    with np.load(base / 'ridge_parameters.npz') as coefficients:
                        parameters = (coefficients['local_coef'], float(coefficients['local_intercept']))
                        row = design_audit(train.X, train.y, np.ones(len(train.y)) / len(train.y),
                            decision['selected'][str(horizon)]['alpha'], dict(identity, family='local'),
                            columns, spectra, parameters=parameters,
                            origin_weekdays=train.origins.dayofweek.to_numpy())
                        ridge_rows.append(dict(row, scale_m3=scale))
                    for seed in cfg['seeds']:
                        job = folder / 'jobs' / f'gru_seed{seed}_{task}'
                        status = read(job / 'status.json')
                        require(status['status'] == 'completed', 'GRU not complete')
                        for kind, family in [('local', 'local_gru'), ('adapt', 'shared_gru_adapt')]:
                            path = job / f'{kind}.pt'
                            require(sha(path) == status['outputs_sha256'][path.name], 'Changed saved checkpoint')
                            state, record = checkpoint_audit(path, str(path.relative_to(root)),
                                dict(identity, family=family, replicate_seed=seed), curves,
                                source_states[horizon, seed] if kind == 'adapt' else None)
                            require(state['metadata']['signature'] == status['fingerprint'], 'Target signature mismatch')
                            require(state['metadata']['n'] == len(train.y), 'Checkpoint training count differs')
                            checkpoint_rows.append(record)
    checkpoints = pd.DataFrame(checkpoint_rows)
    ridges = pd.DataFrame(ridge_rows)
    checkpoints.to_csv(output / 'training_checkpoints.csv', index=False)
    pd.DataFrame(curves).to_csv(output / 'training_loss_curves.csv', index=False)
    ridges.to_csv(output / 'ridge_design_by_condition.csv', index=False)
    pd.DataFrame(columns).to_csv(output / 'ridge_feature_columns.csv', index=False)
    pd.DataFrame(spectra).to_csv(output / 'ridge_weighted_singular_values.csv', index=False)
    training_summary = grouped_summary(checkpoints, ['family', 'budget', 'horizon', 'hidden'],
        ['training_labels', 'optimizer_steps', 'first_training_mse', 'last_training_mse',
         'late_relative_training_mse_decrease', 'fit_seconds'])
    training_summary.to_csv(output / 'training_summary.csv', index=False)
    ridge_summary = grouped_summary(ridges, ['family', 'budget', 'horizon'],
        ['training_labels', 'centered_rank_float64_tolerance', 'centered_effective_rank_relative_1e6',
         'constant_columns', 'near_collinear_abs_cor_999999_pairs',
         'centered_condition_effective_relative_1e6', 'effective_df_penalized',
         'effective_df_per_training_label', 'volume_feature_std_min', 'volume_feature_std_max'])
    ridge_summary.to_csv(output / 'ridge_design_summary.csv', index=False)
    family_statistics = {}
    for family, part in checkpoints.groupby('family'):
        family_statistics[family] = {
            'fits': len(part), 'training_label_range': [int(part.training_labels.min()), int(part.training_labels.max())],
            'total_parameters': sorted(part.total_parameters.unique().tolist()),
            'trainable_parameters': sorted(part.trainable_parameters.unique().tolist()),
            'updates_per_fit': sorted(part.optimizer_steps.unique().tolist()),
            'total_stored_fit_seconds': float(part.fit_seconds.sum()),
            'late_mean_span': sorted(part.late_mean_span_epochs.unique().tolist()),
            'late_training_mse_relative_decrease_median': float(part.late_relative_training_mse_decrease.median()),
            'fraction_late_training_mse_decrease_above_5pct': float(part.late_relative_training_mse_decrease.gt(.05).mean()),
            'fraction_late_training_mse_decrease_below_0': float(part.late_relative_training_mse_decrease.lt(0).mean())}
    audit = {'status': 'passed', 'checked_utc': datetime.now(timezone.utc).isoformat(),
             'stage': 'stage3a_read_only_stage2_audit', 'training_executed': False,
             'prediction_window_performance_calculated': False,
             'final_period_records_read': False, 'QA': 'published_good_only_retrospective',
             'online_QA_availability_verified': False, 'physical_facility_identity_verified': False,
             'input_sha256': provenance, 'checkpoint_count': len(checkpoints),
             'local_ridge_conditions': int(ridges.family.eq('local').sum()),
             'all_adapted_encoders_equal_source': bool(checkpoints.loc[checkpoints.family.eq('shared_gru_adapt'),
                                                                       'encoder_equals_source'].all()),
             'family_statistics': family_statistics,
             'ridge_objective': 'sum_i w_i*(y_i-intercept-X_i beta)^2 + alpha*||beta||^2; SUM(w)=1',
             'effective_df': 'sum_j s_j^2/(s_j^2+alpha), with s=svd(sqrt(W)*(X-weighted_mean)); intercept adds one',
             'rank_note': 'Float32 weekday encoding introduces rounding modes. Relative 1e-6 effective rank also reported.',
             'loss_note': 'Saved epoch loss is minibatch-weighted MSE at changing parameters. Target one-batch curve is pre-update; source curve is not a fixed-final-state objective.',
             'interpretation_limits': ['Training-loss decrease does not establish validation improvement or adequate convergence.',
                                      'Short budgets have fewer than 42 labels but effective rank is much smaller than the nominal 42 columns.',
                                      'Shared/local equal epochs do not imply equal optimizer updates or equal adequacy; matching every update mechanically is not required.',
                                      'Source-selected alpha/hidden are source-data-assisted local comparator settings, not independent local optimum.'],
             'runtime': {'python': platform.python_version(), 'torch': torch.__version__,
                         'current_cuda_available': torch.cuda.is_available(),
                         'stage2_environment': read(root / 'validation/stage2_environment.json')},
             'outputs_sha256': {p.name: sha(p) for p in sorted(output.glob('*.csv'))}}
    write(output / 'audit.json', audit)
    local = checkpoints[checkpoints.family.eq('local_gru')]
    source = checkpoints[checkpoints.family.eq('shared_gru')]
    adaptation = checkpoints[checkpoints.family.eq('shared_gru_adapt')]
    local_ridge = ridges[ridges.family.eq('local')]
    text = [
        '# Stage 3A：Stage 2只读训练审计', '',
        f'真实审计{len(checkpoints)}个checkpoint（含4个来源选参），240个本地Ridge历史设计。未训练新模型、未计算预测窗口误差、未读取2024–2025原始记录。', '',
        f'已执行骨干hidden=8，总参数393；冻结编码器适配仅9个头参数。来源每次40epochs×26batch=1040优化步；本地40epochs×1batch=40步；适配10epochs×1batch=10步。720个适配编码器逐张量等于相应来源。设备记录为CPU、AdamW学习率0.01、weight decay 0.001。', '',
        f'本地有效标签{int(local.training_labels.min())}–{int(local.training_labels.max())}；来源{int(source.training_labels.min())}–{int(source.training_labels.max())}。共同epoch不意味着共同训练充分程度；本地每个样本被访问40次，来源40次但每次全数据有26次参数更新，不能简单把信息与优化步数影响完全分离，也不应机械强制同一步数。', '',
        f'本地末10轮平均训练MSE相对前10轮下降中位数{100 * local.late_relative_training_mse_decrease.median():.2f}%，{100 * local.late_relative_training_mse_decrease.gt(.05).mean():.1f}%拟合下降超过5%；来源相同末段中位下降{100 * source.late_relative_training_mse_decrease.median():.2f}%；适配末5轮相对前5轮中位下降{100 * adaptation.late_relative_training_mse_decrease.median():.2f}%。这提示需要合法验证下的轮数诊断，不能单据训练曲线断言欠拟合/收敛/泛化改善。', '',
        f'Ridge名义42维：7体积+7掩码+28星期编码。固定horizon下全部星期编码只含两个主要周期自由度；float32舍入可产生微小数值秩。实际centered有效rank（相对最大奇异值1e-6）为{int(local_ridge.centered_effective_rank_relative_1e6.min())}–{int(local_ridge.centered_effective_rank_relative_1e6.max())}，所以“42维超过30天标签”不能等同于42个独立特征。实际秩/常数列/近共线对/奇异值见完整CSV。', '',
        f'权重SUM=1，alpha约束的是平均平方误差目标，h1=0.0001、h3=0.01。本地有效惩罚自由度范围{local_ridge.effective_df_penalized.min():.2f}–{local_ridge.effective_df_penalized.max():.2f}，另加未惩罚截距1。没有另做StandardScaler；体积按预算内正值中位数缩放，掩码/星期自然尺度，正则作用随本地波动和缺失模式改变。来源选参未模拟各本地预算，不可称本地最优。', '',
        '边界核查：各本地训练输入张量SHA、标签数、尺度匹配原diagnostics；预算起点及末标签边界重新检查，来源末标签≤2021-12-31。所有已存适配encoder冻结、optimizer步数、参数及checkpoint哈希重新核验；已有完整真实预测日期/指标检查保存在Stage 2 validation，另以SHA引用。', '',
        'MSE训练目标与MAE主评价目标并不一致；MSE强调较大误差，MAE强调条件中位而非均值，不能仅用训练MSE低断言主目标更优。MAE损失若要诊断必须提前限定为敏感性，并保留MSE主要训练对照与MAE主要指标。', '',
        '本审计采用公开发布后QA历史回顾，实时QA可用性和物理设施身份仍未知；不作部署或独立厂泛化保证。', '']
    (output / 'AUDIT_ZH.md').write_text('\n'.join(text))
    print(json.dumps({'status': 'passed', 'checkpoint_count': len(checkpoints),
                      'ridge_conditions': len(ridges), 'output': args.output,
                      'family_statistics': family_statistics}, indent=2))


if __name__ == '__main__':
    main()
