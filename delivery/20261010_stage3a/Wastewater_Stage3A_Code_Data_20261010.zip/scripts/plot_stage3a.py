"""Stage 3A figures from saved, checked development outputs only."""
import json
import os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.cache/matplotlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
import numpy as np
import pandas as pd
from wastewater.common import sha256,write_json

REPORT=ROOT/'reports/stage3a_20261010/results';OUT=ROOT/'figures/stage3a_20261010'
LABELS={'local_ridge':'Stage 2 local 42-column Ridge','local_ridge42_tuned':'Tuned local 42-column Ridge',
 'local_ridge_lags_tuned':'Tuned local compact Ridge','shared_ridge_lags':'Shared compact Ridge',
 'shared_ridge_lags_bias':'Shared compact Ridge + bias','local_gru':'Stage 2 local GRU (40 epochs)',
 'local_gru_selected':'Validated local GRU','shared_gru_selected':'Validated shared GRU','shared_gru_head_selected':'Validated head adaptation (source 40)',
 'shared_ridge_bias':'Stage 2 shared Ridge + bias'}
COLORS=['#777777','#0072B2','#009E73','#56B4E9','#D55E00']


def save(fig,name):
    for ext in ['pdf','svg','png']:fig.savefig(OUT/f'{name}.{ext}',dpi=170,bbox_inches='tight',facecolor='white')
    plt.close(fig)


def main():
    OUT.mkdir(parents=True,exist_ok=True);v=json.loads((REPORT/'validation.json').read_text())
    if v['status']!='passed':raise ValueError('Unvalidated results')
    for f,h in v['outputs_sha256'].items():
        if sha256(REPORT/f)!=h:raise ValueError('Result changed after validation')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42})
    summary=pd.read_csv(REPORT/'summary.csv');s=summary[summary.constraint.eq('raw')]
    groups=[['local_ridge','local_ridge42_tuned','local_ridge_lags_tuned','shared_ridge_lags','shared_ridge_lags_bias'],['local_gru','local_gru_selected','shared_gru_selected','shared_gru_head_selected']]
    fig,axes=plt.subplots(2,2,figsize=(11.5,8.1))
    for row,models in enumerate(groups):
        for col,h in enumerate([1,3]):
            ax=axes[row,col]
            for m,c in zip(models,COLORS):
                g=s[s.model.eq(m)&s.horizon.eq(h)].set_index('budget').loc[[30,90,180]]
                ax.plot([30,90,180],100*g.mean_skill,'o-',color=c,label=LABELS[m],linewidth=1.6,markersize=4)
            ax.axhline(0,color='black',linestyle='--',lw=.8);ax.set_xticks([30,90,180]);ax.set_xlabel('Initial local history (calendar days)');ax.set_title(f'{h}-day horizon — '+('Ridge' if row==0 else 'GRU'))
            ax.set_ylabel('Equal-SiteID MAE skill vs Persistence (%)');ax.legend(fontsize=7.1,loc='best',frameon=False)
    fig.tight_layout();save(fig,'baseline_fairness_budget_skill')
    metric=pd.read_csv(REPORT/'metrics_by_station.csv',dtype={'site_id':str});metric=metric[metric.constraint.eq('raw')]
    models=['local_ridge_lags_tuned','shared_ridge_lags_bias','local_gru_selected','shared_gru_selected','shared_gru_head_selected'];sites=sorted(metric.site_id.unique())
    mats=[100*metric[metric.budget.eq(90)&metric.horizon.eq(h)].pivot(index='site_id',columns='model',values='skill_vs_persistence').loc[sites,models].to_numpy() for h in [1,3]]
    limit=max(1.,float(np.max(np.abs(mats))));norm=TwoSlopeNorm(vmin=-limit,vcenter=0,vmax=limit)
    fig,axes=plt.subplots(1,2,figsize=(11.3,5.3),sharey=True)
    short=['Local Ridge\n(6 columns)','Shared Ridge\n(6) + bias','Local GRU','Shared GRU','Head adapt.']
    for ax,h,mat in zip(axes,[1,3],mats):
        im=ax.imshow(mat,cmap='RdBu',norm=norm,aspect='auto')
        for i in range(10):
            for j in range(5):ax.text(j,i,f'{mat[i,j]:+.1f}',ha='center',va='center',fontsize=7.3,color='white' if abs(mat[i,j])>.6*limit else 'black')
        ax.set_xticks(range(5),short,fontsize=8);ax.set_yticks(range(10),sites);ax.set_title(f'{h}-day horizon; 90-day budget');ax.set_ylabel('Development SiteID')
    fig.subplots_adjust(left=.07,right=.89,bottom=.17,top=.91,wspace=.2);cax=fig.add_axes([.93,.22,.015,.6]);fig.colorbar(im,cax=cax,label='MAE skill vs Persistence (%)');save(fig,'station_persistence_skill')
    ci=pd.read_csv(REPORT/'paired_block_intervals.csv');ci=ci[ci.block_days.eq(14)]
    selected=['shared_ridge_bias','shared_ridge_lags_bias','shared_gru_selected','shared_gru_head_selected']
    fig,axes=plt.subplots(1,2,figsize=(11.2,5.2))
    for ax,kind,b,rb in [(axes[0],'same_budget_transfer',90,90),(axes[1],'history_budget_comparison',30,90)]:
        tick=[]
        for i,m in enumerate(selected):
            tick.append(LABELS[m])
            for h,color,shift in [(1,'#0072B2',-.13),(3,'#D55E00',.13)]:
                r=ci[ci.kind.eq(kind)&ci.model.eq(m)&ci.budget.eq(b)&ci.reference_budget.eq(rb)&ci.horizon.eq(h)].iloc[0]
                x=100*r.mean_station_skill;lo=100*r.lower_95;hi=100*r.upper_95
                ax.plot([lo,hi],[i+shift]*2,color=color,lw=1.5);ax.plot(x,i+shift,'o',color=color,label=f'{h}-day horizon' if i==0 else None)
        ax.axvline(0,color='black',linestyle='--',lw=.8);ax.set_yticks(range(4),tick,fontsize=8);ax.invert_yaxis();ax.set_xlabel('Equal-SiteID MAE skill vs strengthened local (%)');ax.set_title(f'Shared B{b} vs matched local B{rb}');ax.legend(frameon=False,fontsize=8)
    fig.tight_layout();save(fig,'transfer_and_history_intervals')
    selections=pd.read_csv(REPORT/'validation_selections.csv');curves=pd.read_csv(REPORT/'target_training_curves.csv');curves['budget']=curves.task.str.extract(r'_B(\d+)_')[0].astype(int)
    fig,axes=plt.subplots(1,3,figsize=(11.4,3.8))
    for ax,b in zip(axes,[30,90,180]):
        f=curves[curves.budget.eq(b)&curves.trajectory.str.startswith('local_seed')]
        q=f.groupby('epoch').post_epoch_train_mse.quantile([.25,.5,.75]).unstack()
        ax.plot(q.index,q[.5],color='#0072B2');ax.fill_between(q.index,q[.25],q[.75],color='#0072B2',alpha=.18)
        for e in [40,120,300]:ax.axvline(e,color='#555555',linestyle=':',lw=.7)
        counts=selections[selections.budget.eq(b)].local_epoch.value_counts().sort_index();ax.set_title(f'B{b}; selected E: '+', '.join(f'{e}={n}' for e,n in counts.items()),fontsize=9)
        ax.set_xlabel('Training epoch');ax.set_ylabel('Post-epoch normalized training MSE');ax.set_yscale('log')
    fig.tight_layout();save(fig,'local_training_sufficiency')
    high=pd.read_csv(REPORT/'high_volume_summary.csv');high=high[high.constraint.eq('raw')];models=['local_ridge_lags_tuned','shared_ridge_lags_bias','local_gru_selected','shared_gru_selected','shared_gru_head_selected']
    fig,axes=plt.subplots(1,2,figsize=(10.8,4.3))
    for ax,h in zip(axes,[1,3]):
        allv=s[s.budget.eq(90)&s.horizon.eq(h)].set_index('model').loc[models];hv=high[high.budget.eq(90)&high.horizon.eq(h)].set_index('model').loc[models];x=np.arange(len(models))
        ax.bar(x-.18,100*allv.mean_skill,.36,color='#0072B2',label='All matched dates');ax.bar(x+.18,100*hv.mean_skill,.36,color='#E69F00',label='High-volume dates (exploratory)')
        ax.axhline(0,color='black',lw=.8);ax.set_xticks(x,['Local compact\nRidge','Shared compact\nRidge + bias','Local GRU','Shared GRU','Head adapt.'],rotation=20,ha='right',fontsize=8);ax.set_title(f'{h}-day horizon; B90');ax.set_ylabel('Equal-SiteID MAE skill vs Persistence (%)');ax.legend(fontsize=8,frameon=False)
    fig.tight_layout();save(fig,'high_volume_exploratory')
    text='''# Stage 3A figure evidence and English captions

All numerical figures use saved actual development outputs, raw forecasts and matched dates. SiteID identity/independence and historical QA arrival remain unverified. Three-seed losses are averaged; no seed is an independent plant. PDF/SVG are vector exports with embedded/text fonts.

1. **Baseline fairness and history budgets.** Question: does improved local training/regularization change apparent transfer benefits? Source: `summary.csv`. Caption: Equal-SiteID mean MAE skill relative to Persistence across initial local-history budgets. The original Stage 2 local comparators and legally validated Stage 3A policies are shown. Negative skill indicates worse prediction than Persistence; third-day forecasts represent that day's volume.
2. **SiteID skill at B90.** Question: which fixed development sites benefit or fail? Source: `metrics_by_station.csv`. Caption: Per-SiteID MAE skill relative to Persistence for the 90-day history budget, averaged as losses across the three GRU seeds. Rows retain numerical SiteID order; physical independence is unverified.
3. **Transfer and history intervals.** Question: do matched-structure transfer and history savings remain after strengthening local baselines? Source: `paired_block_intervals.csv`, primary block14. Caption: Equal-SiteID paired MAE improvements against strengthened local comparators at equal budgets and shared B30 versus local B90. Whiskers are pointwise 95% exploratory intervals from synchronous calendar blocks and SiteID resampling, conditional on this nonrandom development cohort; they are not prediction intervals or multiplicity-adjusted guarantees.
4. **Local training sufficiency.** Question: does the original epoch cap constrain optimization, and what does legal validation select? Source: `target_training_curves.csv`, `validation_selections.csv`. Caption: Median and interquartile range of normalized post-epoch local fitting MSE, with candidate epochs 40/120/300 marked. Counts summarize legally selected epochs across site/episode/horizon conditions. Descriptive training curves do not establish deployment generalization.
5. **High-volume subgroup.** Question: do conditional high-volume patterns differ from all-date performance? Source: `high_volume_summary.csv`, `summary.csv`. Caption: Exploratory skill on dates whose observed target exceeds the initial 30-day-history Q90, compared with all matched dates. Future realized targets define this reporting subgroup only; the threshold is not capacity, permit or overflow information, and this subgroup does not select models.

This round does not execute interval forecasts, residual models, source expansion or a software prototype.
'''
    (OUT/'FIGURE_EVIDENCE.md').write_text(text)
    write_json(OUT/'manifest.json',dict(status='exported',source_validation_sha256=sha256(REPORT/'validation.json'),source_files={n:sha256(REPORT/n) for n in ['summary.csv','metrics_by_station.csv','paired_block_intervals.csv','validation_selections.csv','target_training_curves.csv','high_volume_summary.csv']},figures={f.name:sha256(f) for f in OUT.iterdir() if f.suffix in ['.pdf','.svg','.png']}))


if __name__=='__main__':main()
