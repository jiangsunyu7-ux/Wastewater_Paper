"""Independent arithmetic, information-boundary and artifact checks; no fitting."""
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from wastewater.common import sha256,write_json
from wastewater.shared_data import load_series
from wastewater.shared_experiment import target_data
from wastewater.stage3a_training import state_hash

ROOT=Path(__file__).resolve().parents[1]


def main():
    report=ROOT/'reports/stage3a_20261010/results';p=pd.read_csv(report/'predictions_all.csv',dtype={'site_id':str});m=pd.read_csv(report/'metrics_by_station.csv',dtype={'site_id':str})
    cfg=json.loads((ROOT/'configs/stage3a_20261010/full.json').read_text());series=load_series(ROOT/cfg['canonical_csv'],cfg['development_ids'])
    completion=json.loads((ROOT/cfg['output']/'completion.json').read_text());checked=0;encoders=0
    for c in completion:
        folder=ROOT/c['folder'];d=json.loads((folder/'diagnostics.json').read_text());tr,te,expected=target_data(series,cfg,d['site_id'],d['episode'],d['budget'],d['horizon'])
        assert expected['training_X_sha256']==d['training_X_sha256'] and expected['evaluation_X_sha256']==d['evaluation_X_sha256']
        assert tr.targets.max()<=pd.Timestamp(d['fit_end']) and tr.origins.min()>=pd.Timestamp(d['budget_start'])
        f=d['selection']['fold']
        if not f['source_assisted']:
            assert pd.Timestamp(f['last_fit_target'])<pd.Timestamp(f['validation_start'])
            assert pd.Timestamp(f['last_validation_target'])<=pd.Timestamp(d['fit_end'])
            assert pd.Timestamp(f['first_validation_origin'])>pd.Timestamp('2020-12-31')
        else:assert f['fallback_key'] in json.loads((ROOT/cfg['source_output']/'selection.json').read_text())['fallback_settings']
        for seed in cfg['seeds']:
            original=torch.load(ROOT/f"runs/shared_v3_20261009/source/final_h{d['horizon']}_seed{seed}.pt",map_location='cpu',weights_only=False)['model']
            for epoch in [10,40,120]:
                state=torch.load(folder/f'head_seed{seed}/epoch{epoch}.pt',map_location='cpu',weights_only=False)['model']
                assert all(torch.equal(v,state[k]) for k,v in original.items() if k.startswith('gru.'));encoders+=1
        checked+=1
    common=p[p.common_evaluation];keys=['site_id','budget','horizon','model']
    metric_checks=0
    for condition,g in common.groupby(keys):
        for constraint,col in [('raw','prediction_m3'),('all_models_nonnegative','prediction_nonnegative_m3')]:
            error=g[col].to_numpy()-g.truth_m3.to_numpy();v=g.assign(ae=np.abs(error),se=error**2).groupby(['episode','origin']).agg(ae=('ae','mean'),se=('se','mean'))
            row=m[(m.constraint==constraint)&(m.site_id==condition[0])&(m.budget==condition[1])&(m.horizon==condition[2])&(m.model==condition[3])].iloc[0]
            np.testing.assert_allclose(row.mae_m3,v.ae.mean(),rtol=1e-12,atol=1e-9);np.testing.assert_allclose(row.rmse_m3,np.sqrt(v.se.mean()),rtol=1e-12,atol=1e-9);assert row.n_dates==len(v)
            metric_checks+=1
    assert len(common)==4713*81
    assert set(p.seed.unique())=={0,20261009,20261010,20261011}
    assert not p[p.model.str.contains('gru')].groupby(['site_id','episode','budget','horizon','origin','model']).seed.nunique().ne(3).any()
    assert (pd.to_datetime(p.target_date).max().year==2023)
    result=dict(status='passed',conditions_verified=checked,frozen_encoder_checkpoint_checks=encoders,independent_station_metric_checks=metric_checks,common_date_groups=4713,negative_raw_predictions=int(p.prediction_m3.lt(0).sum()),final_period_performance_calculated=False,report_validation_sha256=sha256(report/'validation.json'),checker_sha256=sha256(Path(__file__)))
    write_json(ROOT/'validation/stage3a_independent_results.json',result);print(json.dumps(result,indent=2))


if __name__=='__main__':main()
