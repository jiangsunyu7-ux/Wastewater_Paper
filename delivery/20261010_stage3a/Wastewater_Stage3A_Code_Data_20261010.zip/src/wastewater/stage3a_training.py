"""Finite CPU trajectories; validation cannot change optimizer state or RNG."""
import copy
import hashlib
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch import nn

from .shared_models import CompactGRU, predict_gru
from .common import write_json


def array_hash(a):
    a=np.ascontiguousarray(a)
    return hashlib.sha256(str((a.shape,str(a.dtype))).encode()+a.tobytes()).hexdigest()


def state_hash(state):
    if state is None:return None
    return hashlib.sha256(''.join(k+array_hash(v.detach().cpu().numpy()) for k,v in sorted(state.items())).encode()).hexdigest()


def model_from_state(state,hidden=8):
    model=CompactGRU(hidden);model.load_state_dict(state);return model


def fit_trajectory(X,y,hidden,seed,epochs_grid,learning_rate,folder,weights=None,
                   initial=None,head_only=False,batch_size=256,signature='',
                   validation=None,checkpoint_every=20,stop_after_epoch=None):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True);torch.manual_seed(int(seed))
    model=CompactGRU(int(hidden))
    if initial is not None:model.load_state_dict(copy.deepcopy(initial))
    if head_only:
        for p in model.gru.parameters():p.requires_grad=False
    optimizer=torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],lr=learning_rate,weight_decay=.001)
    w=np.ones(len(y))/len(y) if weights is None else np.asarray(weights,dtype=float)
    if not len(y) or not np.isclose(w.sum(),1) or not np.all(w>0):raise ValueError('Invalid fitting weights')
    metadata=dict(signature=signature,hidden=hidden,seed=seed,epochs_grid=list(epochs_grid),lr=learning_rate,
                  head_only=head_only,batch_size=batch_size,X_sha256=array_hash(X),y_sha256=array_hash(y),
                  weights_sha256=array_hash(w),initial_sha256=state_hash(initial),validation_sha256=None)
    if validation is not None:
        metadata['validation_sha256']={k:array_hash(v) for k,v in validation.items()}
    Xt=torch.as_tensor(X,dtype=torch.float32);yt=torch.as_tensor(y,dtype=torch.float32)
    wt=torch.as_tensor(w*len(y),dtype=torch.float32)
    generator=torch.Generator().manual_seed(int(seed));start=0;curves=[];elapsed=0
    last=folder/'last.pt'
    if last.exists():
        saved=torch.load(last,map_location='cpu',weights_only=False)
        if saved['metadata']!=metadata:raise ValueError('Changed data/config/initialization; new version required')
        model.load_state_dict(saved['model']);optimizer.load_state_dict(saved['optimizer'])
        generator.set_state(saved['generator_state']);start=saved['epoch'];curves=saved['curves'];elapsed=saved['elapsed_seconds']
    t=time.perf_counter();cap=max(epochs_grid) if stop_after_epoch is None else min(max(epochs_grid),stop_after_epoch)
    for epoch in range(start,cap):
        model.train();order=torch.randperm(len(y),generator=generator);total=0.
        for ix in order.split(batch_size):
            optimizer.zero_grad(set_to_none=True);pred=model(Xt[ix]);loss=((pred-yt[ix])**2*wt[ix]).mean()
            if not torch.isfinite(loss):raise FloatingPointError(f'Nonfinite MSE at epoch {epoch+1}')
            loss.backward();nn.utils.clip_grad_norm_(model.parameters(),1.);optimizer.step()
            total+=float(loss.detach())*len(ix)/len(y)
        p=predict_gru(model,X);row=dict(epoch=epoch+1,update_count=(epoch+1)*math.ceil(len(y)/batch_size),
            online_batch_mse=total,post_epoch_train_mse=float(np.sum(w*(p-y)**2)),
            post_epoch_train_mae=float(np.sum(w*np.abs(p-y))),validation_mae=None,validation_mse=None)
        if validation is not None and epoch+1 in epochs_grid:
            vp=predict_gru(model,validation['X']);vw=validation.get('weights',np.ones(len(vp))/len(vp));vy=validation['y']
            row.update(validation_mae=float(np.sum(vw*np.abs(vp-vy))),validation_mse=float(np.sum(vw*(vp-vy)**2)))
        curves.append(row)
        if (epoch+1)%checkpoint_every==0 or epoch+1 in epochs_grid or epoch+1==cap:
            saved=dict(metadata=metadata,model=model.state_dict(),optimizer=optimizer.state_dict(),
                       generator_state=generator.get_state(),epoch=epoch+1,curves=curves,
                       elapsed_seconds=elapsed+time.perf_counter()-t)
            temporary=folder/'last.tmp';torch.save(saved,temporary);temporary.replace(last)
            if epoch+1 in epochs_grid:torch.save(saved,folder/f'epoch{epoch+1}.pt')
    states={e:torch.load(folder/f'epoch{e}.pt',map_location='cpu',weights_only=False)['model'] for e in epochs_grid if (folder/f'epoch{e}.pt').exists()}
    pd.DataFrame(curves).to_csv(folder/'curve.csv',index=False)
    diag=dict(epochs_completed=cap,resumed_from_epoch=start,training_samples=len(y),
        total_parameters=sum(p.numel() for p in model.parameters()),trainable_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),
        head_only=head_only,batches_per_epoch=math.ceil(len(y)/batch_size),optimizer_updates=cap*math.ceil(len(y)/batch_size),
        learning_rate=learning_rate,device='cpu',seed=seed,fit_seconds=elapsed+time.perf_counter()-t,
        stopping_rule='predeclared finite cap, no deployment-window early stopping',metadata=metadata)
    write_json(folder/'diagnostics.json',diag)
    return states,diag
