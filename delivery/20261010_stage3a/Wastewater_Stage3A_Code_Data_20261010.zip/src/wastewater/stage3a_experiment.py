"""Stage 3A finite diagnostics. Never choose settings from forecast-window error."""
import argparse
from concurrent.futures import ProcessPoolExecutor,as_completed
import hashlib
import json
import multiprocessing
from pathlib import Path
import time
import traceback

import numpy as np
import pandas as pd
import torch

from .common import sha256,runtime_manifest,utc_now,write_json
from .shared_data import load_series,scale_from_history,build_samples
from .shared_models import fit_ridge,predict_gru,stable_seed
from .shared_experiment import validate,source_pool,target_data,prediction_frame,run_job
from .stage3a_data import compact,eligible,internal_fold,pseudo_fold
from .stage3a_training import fit_trajectory,model_from_state,state_hash

ROOT=Path(__file__).resolve().parents[2]


def load_cfg(path):return json.loads((ROOT/path).read_text())


def execution_signature(cfg):
    files=['shared_data.py','shared_models.py','shared_experiment.py','stage3a_data.py','stage3a_training.py','stage3a_experiment.py']
    info=dict(core_sha256={f:sha256(ROOT/'src/wastewater'/f) for f in files},
        data_sha256=sha256(ROOT/cfg['canonical_csv']),mapping_sha256=sha256(ROOT/cfg['mapping_csv']),
        config=cfg,protocol_sha256=sha256(ROOT/cfg['protocol']),torch=torch.__version__)
    return hashlib.sha256(json.dumps(info,sort_keys=True).encode()).hexdigest(),info


def features(X,kind):return X if kind=='42' else compact(X)


def scores(states,validation):
    rows=[]
    for epoch,state in states.items():
        p=predict_gru(model_from_state(state),validation['X']);w=validation['weights'];y=validation['y']
        rows.append(dict(epoch=epoch,validation_mae=float(np.sum(w*np.abs(p-y))),validation_mse=float(np.sum(w*(p-y)**2))))
    return rows


def load_state(folder,epoch):return torch.load(Path(folder)/f'epoch{epoch}.pt',map_location='cpu',weights_only=False)['model']


def check_stage2_endpoint(prior,current,X):
    a=predict_gru(model_from_state(prior),X);b=predict_gru(model_from_state(current),X)
    delta=float(np.max(np.abs(a-b)))
    if not np.allclose(a,b,atol=1e-4,rtol=1e-5):raise AssertionError(f'Stage 2 endpoint discrepancy exceeds numeric tolerance: {delta}')
    return dict(bitwise_identical=state_hash(prior)==state_hash(current),max_normalized_prediction_difference=delta,
        max_parameter_difference=max(float((current[k]-v).abs().max()) for k,v in prior.items()),atol=1e-4,rtol=1e-5)


def choose_epoch(rows):
    frame=pd.DataFrame(rows);s=frame.groupby('epoch').validation_mae.mean()
    return int(min(s.index,key=lambda e:(s[e],e)))


def shared_validation(series,cfg,horizon):
    xs=[];ys=[];ws=[]
    for site in cfg['source_ids']:
        scale=scale_from_history(series[site],cfg['source_training_start'],'2020-12-31')
        data=build_samples(series[site],pd.date_range('2021-01-01',pd.Timestamp('2021-12-31')-pd.Timedelta(days=horizon)),horizon,'2016-01-01',scale)
        v,_=eligible(data);xs.append(v['X']);ys.append(v['y']);ws.append(v['weights']/len(cfg['source_ids']))
    return dict(X=np.concatenate(xs),y=np.concatenate(ys),weights=np.concatenate(ws))


def source_worker(config_path,signature,kind,horizon,seed,held=None):
    cfg=load_cfg(config_path);series=load_series(ROOT/cfg['canonical_csv'],cfg['source_ids'])
    fitcfg=dict(cfg)
    if held is not None:fitcfg['source_ids']=[s for s in cfg['source_ids'] if s!=held]
    end='2021-12-31' if kind=='full' else '2020-12-31'
    X,y,w,ds=source_pool(series,fitcfg,horizon,end)
    folder=ROOT/cfg['source_output']/f'{kind}_h{horizon}_seed{seed}'
    if held is not None:folder=ROOT/cfg['source_output']/f'loso{held}_h{horizon}_seed{seed}'
    grid=[40] if held is not None else cfg['gru_epochs_grid']
    validation=shared_validation(series,cfg,horizon) if kind=='select' else None
    states,diag=fit_trajectory(X,y,8,stable_seed(seed,f'source_h{horizon}'),grid,.01,folder,
        weights=w,signature=signature,validation=validation,checkpoint_every=cfg['checkpoint_every'])
    write_json(folder/'data_diagnostics.json',dict(sites=ds,fit_end=end,held_out_source=held))
    if kind=='full':
        old=ROOT/f'runs/shared_v3_20261009/source/final_h{horizon}_seed{seed}.pt'
        prior=torch.load(old,map_location='cpu',weights_only=False)['model']
        diag['stage2_endpoint_check']=check_stage2_endpoint(prior,states[40],X)
    return dict(kind=kind,horizon=horizon,seed=seed,held=held,folder=str(folder.relative_to(ROOT)),diagnostics=diag,
                scores=scores(states,validation) if validation is not None else [])


def fallback_worker(config_path,signature,budget,horizon,site,date):
    cfg=load_cfg(config_path);s=load_series(ROOT/cfg['canonical_csv'],[site])[site]
    tr,val,diag=pseudo_fold(s,date,budget,horizon,cfg);folder=ROOT/cfg['source_output']/f'fallback_{site}_{date}_B{budget}_H{horizon}'
    folder.mkdir(parents=True,exist_ok=True);ridge=[];local=[];head=[]
    for kind in ['42','lags']:
        for alpha in cfg['ridge_alphas']:
            m=fit_ridge(features(tr.X,kind),tr.y,alpha);p=m.predict(features(val['X'],kind).reshape(len(val['y']),-1))
            ridge.append(dict(features=kind,alpha=alpha,validation_mae=float(np.mean(np.abs(p-val['y'])))))
    task=f'{site}_{date}_B{budget}_H{horizon}'
    for seed in cfg['seeds']:
        states,ld=fit_trajectory(tr.X,tr.y,8,stable_seed(seed,'local_'+task),cfg['gru_epochs_grid'],.01,
            folder/f'local_seed{seed}',validation=val,signature=signature)
        local.extend(dict(r,seed=seed) for r in scores(states,val))
        proxy=load_state(ROOT/cfg['source_output']/f'loso{site}_h{horizon}_seed{seed}',40)
        states,ad=fit_trajectory(tr.X,tr.y,8,stable_seed(seed,'adapt_'+task),cfg['adapt_epochs_grid'],.01,
            folder/f'head_seed{seed}',initial=proxy,head_only=True,validation=val,signature=signature)
        head.extend(dict(r,seed=seed) for r in scores(states,val))
    result=dict(site_id=site,date=date,budget=budget,horizon=horizon,fold=diag,ridge=ridge,local_gru=local,head_gru=head)
    write_json(folder/'selection_scores.json',result);return result


def parallel_jobs(fn,jobs,workers,label):
    results=[]
    with ProcessPoolExecutor(max_workers=workers,mp_context=multiprocessing.get_context('spawn')) as pool:
        futures={pool.submit(fn,*job):job for job in jobs}
        for n,f in enumerate(as_completed(futures),1):
            result=f.result();results.append(result)
            print(f'{label} {n}/{len(jobs)} completed',flush=True)
    return results


def prepare_sources(config_path,cfg,signature,workers):
    folder=ROOT/cfg['source_output'];folder.mkdir(parents=True,exist_ok=True);saved=folder/'selection.json'
    if saved.exists():
        result=json.loads(saved.read_text())
        if result['signature']!=signature:raise ValueError('Source selection specification changed')
        return result
    jobs=[(config_path,signature,kind,h,seed,None) for kind in ['select','full'] for h in cfg['horizons'] for seed in cfg['seeds']]
    jobs.extend((config_path,signature,'loso',h,seed,held) for held in cfg['source_ids'] for h in cfg['horizons'] for seed in cfg['seeds'])
    source=parallel_jobs(source_worker,jobs,workers,'source trajectories')
    s=load_series(ROOT/cfg['canonical_csv'],cfg['development_ids']);fallback_budgets={30}
    for site in cfg['development_ids']:
        for date in cfg['origins']:
            for b in cfg['budgets']:
                for h in cfg['horizons']:
                    _,_,diag=internal_fold(s[site],date,b,h,cfg)
                    if not diag['valid']:fallback_budgets.add(b)
    fallback_jobs=[(config_path,signature,b,h,site,date) for b in sorted(fallback_budgets) for h in cfg['horizons'] for site in cfg['source_ids'] for date in cfg['source_pseudo_origins']]
    fallback=parallel_jobs(fallback_worker,fallback_jobs,workers,'source-budget validation')
    settings={};source_series=load_series(ROOT/cfg['canonical_csv'],cfg['source_ids'])
    for h in cfg['horizons']:
        candidates=[dict(r,seed=t['seed']) for t in source if t['kind']=='select' and t['horizon']==h for r in t['scores']]
        X,y,w,_=source_pool(source_series,cfg,h,'2020-12-31');v=shared_validation(source_series,cfg,h);ridge_scores=[]
        for alpha in cfg['ridge_alphas']:
            model=fit_ridge(compact(X),y,alpha,w);p=model.predict(compact(v['X']))
            ridge_scores.append(dict(alpha=alpha,validation_mae=float(np.sum(v['weights']*np.abs(p-v['y'])))))
        settings[str(h)]=dict(shared_epoch=choose_epoch(candidates),shared_lags_alpha=min(ridge_scores,key=lambda r:(r['validation_mae'],r['alpha']))['alpha'],shared_epoch_scores=candidates,shared_ridge_scores=ridge_scores)
    fallback_settings={}
    for b in sorted(fallback_budgets):
        for h in cfg['horizons']:
            relevant=[x for x in fallback if x['budget']==b and x['horizon']==h]
            rs=pd.DataFrame([r for x in relevant for r in x['ridge']]).groupby(['features','alpha']).validation_mae.mean()
            alphas={kind:float(min(rs[kind].index,key=lambda a:(rs[kind][a],a))) for kind in ['42','lags']}
            fallback_settings[f'B{b}_H{h}']=dict(ridge_alphas=alphas,local_epoch=choose_epoch([r for x in relevant for r in x['local_gru']]),head_epoch=choose_epoch([r for x in relevant for r in x['head_gru']]),source_assisted=True)
    result=dict(signature=signature,settings=settings,fallback_settings=fallback_settings,source_trajectories=source,source_budget_folds=fallback,
        selection_boundaries='source fitting<=2020; validation<=2021; no deployment-window scores',completed_utc=utc_now())
    write_json(saved,result);return result


def target_worker(config_path,signature,site,date,budget,horizon,seeds):
    cfg=load_cfg(config_path);selection=json.loads((ROOT/cfg['source_output']/'selection.json').read_text())
    series=load_series(ROOT/cfg['canonical_csv'],[site]);train,test,diag=target_data(series,cfg,site,date,budget,horizon)
    cv,val,fold=internal_fold(series[site],date,budget,horizon,cfg)
    folder=ROOT/cfg['output']/'jobs'/f'{site}_{date}_B{budget}_H{horizon}';task=f'{site}_{date}_B{budget}_H{horizon}'
    # Seed subset is an explicit scientific smoke operation, independently cached.
    folder=folder/('seeds_'+'_'.join(str(s) for s in seeds))
    fingerprint=hashlib.sha256((signature+task+str(seeds)).encode()).hexdigest()
    def operation(job):
        ridge_rows=[];gru_local_scores=[];gru_head_scores=[]
        if fold['valid']:
            alpha_choices={}
            for kind in ['42','lags']:
                for a in cfg['ridge_alphas']:
                    m=fit_ridge(features(cv.X,kind),cv.y,a);p=m.predict(features(val['X'],kind).reshape(len(val['y']),-1))
                    ridge_rows.append(dict(features=kind,alpha=a,validation_mae=float(np.mean(np.abs(p-val['y'])))))
                alpha_choices[kind]=min((r for r in ridge_rows if r['features']==kind),key=lambda r:(r['validation_mae'],r['alpha']))['alpha']
            # Selection always averages the existing three seeds, even during a one-seed prediction smoke check.
            for seed in cfg['seeds']:
                states,_=fit_trajectory(cv.X,cv.y,8,stable_seed(seed,'local_'+task),cfg['gru_epochs_grid'],.01,job/f'validation_local_seed{seed}',validation=val,signature=fingerprint)
                gru_local_scores.extend(dict(r,seed=seed) for r in scores(states,val))
                proxy_folder=ROOT/cfg['source_output']/f'select_h{horizon}_seed{seed}'
                proxy=load_state(proxy_folder,40)
                if pd.Timestamp(fold['first_validation_origin'])<=pd.Timestamp('2020-12-31'):raise AssertionError('Proxy source includes future validation information')
                states,_=fit_trajectory(cv.X,cv.y,8,stable_seed(seed,'adapt_'+task),cfg['adapt_epochs_grid'],.01,job/f'validation_head_seed{seed}',validation=val,initial=proxy,head_only=True,signature=fingerprint)
                gru_head_scores.extend(dict(r,seed=seed) for r in scores(states,val))
            local_epoch=choose_epoch(gru_local_scores);head_epoch=choose_epoch(gru_head_scores)
        else:
            fallback=selection['fallback_settings'][f'B{budget}_H{horizon}'];alpha_choices=fallback['ridge_alphas'];local_epoch=fallback['local_epoch'];head_epoch=fallback['head_epoch']
            fold.update(source_assisted=True,fallback_reason='insufficient internal fitting/validation labels',fallback_key=f'B{budget}_H{horizon}')
        decision=dict(fold=fold,ridge_alphas=alpha_choices,local_epoch=local_epoch,head_epoch=head_epoch,ridge_validation=ridge_rows,local_gru_validation=gru_local_scores,head_gru_validation=gru_head_scores)
        # Decision is serialized before reading any deployment prediction errors.
        write_json(job/'selection.json',decision)
        source_series=load_series(ROOT/cfg['canonical_csv'],cfg['source_ids']);X,y,w,_=source_pool(source_series,cfg,horizon,'2021-12-31')
        ss=selection['settings'][str(horizon)];shared=fit_ridge(compact(X),y,ss['shared_lags_alpha'],w)
        l42=fit_ridge(train.X,train.y,alpha_choices['42']);llag=fit_ridge(compact(train.X),train.y,alpha_choices['lags'])
        sp=shared.predict(compact(test.X));bias=float(np.mean(train.y-shared.predict(compact(train.X))))
        outputs=dict(local_ridge42_tuned=l42.predict(test.X.reshape(len(test.X),-1))*test.scale,
                     local_ridge_lags_tuned=llag.predict(compact(test.X))*test.scale,
                     shared_ridge_lags=sp*test.scale,shared_ridge_lags_bias=(sp+bias)*test.scale)
        frames=[prediction_frame(test,diag,outputs,0)];training=[]
        np.savez(job/'ridge_parameters.npz',local42_coef=l42.coef_,local42_intercept=l42.intercept_,local_lags_coef=llag.coef_,local_lags_intercept=llag.intercept_,shared_lags_coef=shared.coef_,shared_lags_intercept=shared.intercept_,bias=bias)
        for seed in seeds:
            states,ld=fit_trajectory(train.X,train.y,8,stable_seed(seed,'local_'+task),cfg['gru_epochs_grid'],.01,job/f'local_seed{seed}',signature=fingerprint)
            source_folder=ROOT/cfg['source_output']/f'full_h{horizon}_seed{seed}'
            # Use the actual archived backbone for head-only diagnostics, isolating adaptation length exactly.
            source40=torch.load(ROOT/f'runs/shared_v3_20261009/source/final_h{horizon}_seed{seed}.pt',map_location='cpu',weights_only=False)['model']
            astates,ad=fit_trajectory(train.X,train.y,8,stable_seed(seed,'adapt_'+task),cfg['adapt_epochs_grid'],.01,job/f'head_seed{seed}',initial=source40,head_only=True,signature=fingerprint)
            old_folder=ROOT/cfg.get('stage2_output','runs/shared_v3_20261009/full')/'jobs'/f'gru_seed{seed}_{task}'
            endpoint_checks={}
            for name,state,oldfile in [('local40',states[40],'local.pt'),('head10',astates[10],'adapt.pt')]:
                prior=torch.load(old_folder/oldfile,map_location='cpu',weights_only=False)['model']
                endpoint_checks[name]=check_stage2_endpoint(prior,state,train.X)
            for state in astates.values():
                if any(not torch.equal(state[k],v) for k,v in source40.items() if k.startswith('gru.')):raise AssertionError('Frozen encoder changed')
            grus=dict(local_gru_selected=predict_gru(model_from_state(states[local_epoch]),test.X)*test.scale,
                      shared_gru_selected=predict_gru(model_from_state(load_state(source_folder,ss['shared_epoch'])),test.X)*test.scale,
                      shared_gru_head_selected=predict_gru(model_from_state(astates[head_epoch]),test.X)*test.scale)
            frames.append(prediction_frame(test,diag,grus,seed))
            endpoint={f'local_gru_E{e}':predict_gru(model_from_state(s),test.X)*test.scale for e,s in states.items()}
            endpoint.update({f'head_gru_E{e}':predict_gru(model_from_state(s),test.X)*test.scale for e,s in astates.items()})
            endpoint.update({f'shared_gru_E{e}':predict_gru(model_from_state(load_state(source_folder,e)),test.X)*test.scale for e in cfg['gru_epochs_grid']})
            ep=prediction_frame(test,diag,endpoint,seed);ep.to_csv(job/f'endpoint_predictions_seed{seed}.csv',index=False)
            training.append(dict(seed=seed,local=ld,head=ad,local_epoch_selected=local_epoch,head_epoch_selected=head_epoch,source_epoch_selected=ss['shared_epoch'],stage2_endpoint_checks=endpoint_checks))
        return pd.concat(frames,ignore_index=True),dict(diag,selection=decision,training=training,source_shared_epoch=ss['shared_epoch'],bias_m3=bias*test.scale)
    status=run_job(folder,fingerprint,operation)
    return dict(task=task,status=status,folder=str(folder.relative_to(ROOT)))


def main():
    p=argparse.ArgumentParser();p.add_argument('--config',default='configs/stage3a_20261010/full.json');p.add_argument('--workers',type=int,default=4);p.add_argument('--smoke',action='store_true');p.add_argument('--source-only',action='store_true')
    args=p.parse_args();cfg=load_cfg(args.config);validate(cfg,ROOT)
    signature,info=execution_signature(cfg);out=ROOT/cfg['output'];out.mkdir(parents=True,exist_ok=True)
    manifest_path=out/'manifest.json'
    if manifest_path.exists() and json.loads(manifest_path.read_text())['signature']!=signature:raise ValueError('Changed stage specification; new output version required')
    manifest=dict(status='running',signature=signature,provenance=info,config=cfg,runtime=runtime_manifest(ROOT),started_utc=utc_now(),execution_command=' '.join(__import__('sys').argv),physical_facility_independence_verified=False,online_QA_availability_verified=False)
    write_json(manifest_path,manifest)
    prepare_sources(args.config,cfg,signature,args.workers)
    if args.source_only:print('source phase completed');return
    if args.smoke:
        tasks=[(args.config,signature,site,cfg['origins'][0],b,h,[cfg['seeds'][0]]) for site in ['13013','13015'] for b in cfg['budgets'] for h in cfg['horizons']]
    else:
        tasks=[(args.config,signature,site,date,b,h,cfg['seeds']) for site in cfg['development_ids'] for date in cfg['origins'] for b in cfg['budgets'] for h in cfg['horizons']]
    results=parallel_jobs(target_worker,tasks,args.workers,'target conditions');write_json(out/('smoke_completion.json' if args.smoke else 'completion.json'),results)
    manifest.update(status='smoke_completed' if args.smoke else 'completed',finished_utc=utc_now(),completed_conditions=len(results),failed_conditions=sum(r['status']=='failed' for r in results),selection_sha256=sha256(ROOT/cfg['source_output']/'selection.json'))
    if manifest['failed_conditions']:manifest['status']='failed'
    write_json(manifest_path,manifest);print(json.dumps({k:manifest[k] for k in ['status','completed_conditions','failed_conditions']},indent=2))
    if manifest['failed_conditions']:raise SystemExit(2)


if __name__=='__main__':main()
