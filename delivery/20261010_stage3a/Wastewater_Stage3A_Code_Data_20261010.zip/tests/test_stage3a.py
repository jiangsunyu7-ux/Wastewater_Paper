import json
import tempfile
import unittest
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from wastewater.shared_data import load_series
from wastewater.shared_models import fit_gru,CompactGRU
from wastewater.stage3a_data import internal_fold,compact
from wastewater.stage3a_training import fit_trajectory,state_hash
from wastewater.stage3a_experiment import validate

ROOT=Path(__file__).resolve().parents[1]


class Stage3ATests(unittest.TestCase):
    def setUp(self):
        self.cfg=json.loads((ROOT/'configs/stage3a_20261010/full.json').read_text())

    def test_real_budget_folds_and_future_perturbation(self):
        series=load_series(ROOT/self.cfg['canonical_csv'],['13013','13015'])
        for site,s in series.items():
            for date in self.cfg['origins']:
                for b in self.cfg['budgets']:
                    for h in [1,3]:
                        train,val,diag=internal_fold(s,date,b,h,self.cfg)
                        self.assertLessEqual(train.targets.max(),pd.Timestamp(diag['fit_end']))
                        self.assertLess(train.targets.max(),pd.Timestamp(diag['first_validation_origin']))
                        self.assertLessEqual(pd.Timestamp(diag['last_validation_target']),pd.Timestamp(date)-pd.Timedelta(days=1))
                        changed=s.copy();changed.loc[pd.Timestamp(date):]=1e9
                        tr2,v2,d2=internal_fold(changed,date,b,h,self.cfg)
                        np.testing.assert_array_equal(train.X,tr2.X);np.testing.assert_array_equal(train.y,tr2.y)
                        np.testing.assert_array_equal(val['X'],v2['X']);np.testing.assert_array_equal(val['y'],v2['y'])
                        self.assertEqual(diag,d2)
                        json.dumps(diag)

    def test_scaling_ignores_validation_and_compact_indices(self):
        s=pd.Series(np.arange(1.,367),index=pd.date_range('2021-01-01',periods=366))
        tr,v,d=internal_fold(s,'2022-01-01',90,3,self.cfg)
        modified=s.copy();modified.loc[d['validation_start']:d['budget_end']]=1e6
        tr2,_,d2=internal_fold(modified,'2022-01-01',90,3,self.cfg)
        self.assertEqual(d['scale_m3'],d2['scale_m3']);np.testing.assert_array_equal(tr.X,tr2.X)
        c=compact(tr.X);np.testing.assert_array_equal(c[:,:3],tr.X[:,[6,5,0],0]);self.assertEqual(c.shape[1],6)

    def test_resume_exact_original_endpoints_and_encoder_freeze(self):
        rng=np.random.default_rng(7);X=rng.normal(size=(29,7,6)).astype('float32');y=rng.normal(size=29).astype('float32')
        with tempfile.TemporaryDirectory() as temp:
            folder=Path(temp)
            old,_=fit_gru(X,y,8,19,2,.01,folder/'old.pt')
            states,_=fit_trajectory(X,y,8,19,[2,4,6],.01,folder/'continuous')
            self.assertEqual(state_hash(old.state_dict()),state_hash(states[2]))
            fit_trajectory(X,y,8,19,[2,4,6],.01,folder/'resume',stop_after_epoch=3)
            resumed,diag=fit_trajectory(X,y,8,19,[2,4,6],.01,folder/'resume')
            self.assertEqual(diag['resumed_from_epoch'],3);self.assertEqual(state_hash(resumed[6]),state_hash(states[6]))
            with self.assertRaises(ValueError):fit_trajectory(X,y+1,8,19,[2,4,6],.01,folder/'resume')
            adapted,_=fit_trajectory(X,y,8,21,[2,4],.01,folder/'head',initial=states[6],head_only=True)
            for k,v in states[6].items():
                if k.startswith('gru.'):self.assertTrue(torch.equal(adapted[4][k],v))

    def test_final_window_and_cohort_rejected(self):
        validate(self.cfg,ROOT)
        cfg=dict(self.cfg,origins=['2024-01-01'])
        with self.assertRaises(ValueError):validate(cfg,ROOT)


if __name__=='__main__':unittest.main()
