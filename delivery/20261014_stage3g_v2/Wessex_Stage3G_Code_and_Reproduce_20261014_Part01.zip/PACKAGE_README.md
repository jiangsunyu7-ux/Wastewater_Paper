# Wessex Stage3G — Code_and_Reproduce

Version: stage3g_transfer_reliability_v1
This is a new bounded development experiment, not an independent final test.
Extract all parts into one new directory, preserving the repository-relative paths.
Old Stage3C2/3D scientific archives are not renamed or regenerated.
The per-member manifest excludes its own digest; the external index hashes the complete ZIP.
For CPU reproduction see reports/stage3g_transfer_reliability_v1/REPRODUCE.md.
