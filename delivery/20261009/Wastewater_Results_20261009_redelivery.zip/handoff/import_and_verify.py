#!/usr/bin/env python3
"""Import the two known data ZIPs without overwriting existing content; stdlib only."""
import argparse
import hashlib
import json
import shutil
import sys
import zipfile
from pathlib import Path, PurePosixPath


def digest_stream(stream):
    h = hashlib.sha256()
    for chunk in iter(lambda: stream.read(1024 * 1024), b''):
        h.update(chunk)
    return h.hexdigest()


def digest_file(path):
    with path.open('rb') as f:
        return digest_stream(f)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--project-root', required=True, type=Path)
    ap.add_argument('--zip', action='append', default=[], type=Path)
    args = ap.parse_args()
    here = Path(__file__).resolve().parent
    manifest = json.loads((here / 'manifest_original_58.json').read_text(encoding='utf-8'))
    expected = {x['relative_path']: x for x in manifest['files']}
    root = args.project_root.resolve()
    if len(expected) != 58:
        raise ValueError('Manifest must contain exactly 58 original files')
    destinations = {}
    for name in expected:
        rel = PurePosixPath(name)
        if rel.is_absolute() or '..' in rel.parts or '.git' in rel.parts:
            raise ValueError('Unsafe manifest path: ' + name)
        target = root.joinpath(*rel.parts)
        if not target.resolve().is_relative_to(root):
            raise ValueError('Destination escapes project root: ' + name)
        # Refuse symlink ancestors even when they resolve inside the project.
        if any(p.is_symlink() for p in [target, *target.parents] if p != root):
            raise ValueError('Symlink in destination path: ' + name)
        destinations[name] = target

    sources = {}
    if args.zip:
        archive_manifest = json.loads((here / 'manifest_archives.json').read_text(encoding='utf-8'))
        known_hashes = {a['sha256'] for a in archive_manifest['data_archives']}
        for path in args.zip:
            if not path.is_file() or digest_file(path) not in known_hashes:
                raise ValueError('ZIP does not match supplied data archives: ' + str(path))
            with zipfile.ZipFile(path) as z:
                for info in z.infolist():
                    if info.is_dir():
                        continue
                    rel = PurePosixPath(info.filename)
                    if not rel.parts or rel.parts[0] != 'Wastewater_Paper' or '..' in rel.parts:
                        raise ValueError('Unexpected archive member: ' + info.filename)
                    name = PurePosixPath(*rel.parts[1:]).as_posix()
                    if name not in expected or name in sources:
                        raise ValueError('Unknown or repeated member: ' + name)
                    with z.open(info) as f:
                        checksum = digest_stream(f)
                    if checksum != expected[name]['sha256'] or info.file_size != expected[name]['size_bytes']:
                        raise ValueError('Member hash/size mismatch: ' + name)
                    sources[name] = (path, info.filename)
        if set(sources) != set(expected):
            raise ValueError('Provide both ZIPs; missing: ' + ', '.join(sorted(set(expected) - set(sources))))

    conflicts = []
    for name, target in destinations.items():
        if target.exists() and (not target.is_file() or digest_file(target) != expected[name]['sha256']):
            conflicts.append(name)
    if conflicts:
        raise ValueError('Existing contents differ; nothing imported. Preserve and inspect: ' + ', '.join(conflicts))

    imported = 0
    if sources:
        # Preflight completed before any project write. Re-running after interruption is safe.
        for name, (path, member) in sources.items():
            target = destinations[name]
            if target.exists():
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(path) as z, z.open(member) as src, target.open('xb') as dst:
                shutil.copyfileobj(src, dst)
            imported += 1

    missing = [name for name, target in destinations.items() if not target.is_file()]
    if missing:
        raise ValueError('Missing files: ' + ', '.join(missing))
    for name, target in destinations.items():
        if target.stat().st_size != expected[name]['size_bytes'] or digest_file(target) != expected[name]['sha256']:
            raise ValueError('Final verification failed: ' + name)
    print(json.dumps({'status': 'passed', 'project_root': str(root), 'verified_files': len(expected),
                      'imported_files': imported, 'existing_identical_files': len(expected) - imported,
                      'overwrite_performed': False}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, zipfile.BadZipFile) as exc:
        print(json.dumps({'status': 'failed', 'reason': str(exc)}, ensure_ascii=False), file=sys.stderr)
        sys.exit(1)
