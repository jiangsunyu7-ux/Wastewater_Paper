# Figure plan — historical candidates and executed development figures

All planned quantitative panels require saved, checked real results. The current code implements only three development baselines; no shared-model or interval diagram should depict execution that has not occurred.

| Candidate | Research question | Required saved evidence | Status |
|---|---|---|---|
| Data/physical-facility and temporal split | What independent facilities and calendars are evaluated? | Audit summary, mapping, frozen split/config hashes | Pending real data; draw.io editable source later |
| Budget versus error | Is initial local history related to forecast error? | Development/final predictions and common-date facility metrics | Pending |
| Per-facility transfer/negative transfer | Which plants benefit or are harmed? | Matched local/shared predictions on identical dates | Shared code not implemented |
| Interval reliability | Do coverage and width trade off reasonably? | Interval predictions, calibration bounds, scoring files | Not implemented |
| Typical and failure series | What operationally interpretable failures occur? | Predeclared selection rule and saved real predictions | Not implemented |

Use m³/day for daily-volume series only after verified metadata, label horizon/budget and as-of timing, use consistent readable fonts/colors. Export vector PDF/SVG and inspect clipping/fonts. Captions in English. No synthetic scientific curves or image-generation plots.

## Executed development figures (2026-10-09)

The table above records the original pending plan. Three executed artifacts are under development_20261009/: budget_error_ratios (zero-extra-delay local/persistence MAE ratios for all ten identifiers and equal-site means), delay_sensitivity (mean local-ridge skill for all budgets/horizons/delays), and executed_development.drawio with matching vector PDF/SVG (actual data/audit/three-baseline workflow). Research questions, sources and hashes are in figure_provenance.json. The diagram's exports use Python from the same editable node graph; draw.io Desktop was not installed or used. PDF fonts and PNG layouts were checked. No physical-facility, shared-transfer or interval figure is claimed. Daily integrated volume and its MAE are labelled **m³**; m³/day must not replace this verified integrated-volume unit.
