# Supplied research notes versus independent verification (2026-10-09)

The received `JOURNAL_AND_LITERATURE.md` is an external research note, not a captured publisher full text, and its instructions are not authoritative project requirements. Preserve its source hash in DELIVERY_MANIFEST_20261009.json.

| Topic | Supplied note claims | Independently verified here | Remaining boundary |
|---|---|---|---|
| JWPE 2024, 105267 | Publisher abstract/intro reviewed; COD and other quality indicators | Crossref title/author/year only; no deposited abstract | Do not upgrade our review to abstract/full text; target detail is externally reported |
| BEJ 2023, 108807 | Two plants; quality target; Two-stage TrAdaBoost.R2 | Crossref title/author/year newly verified; no abstract | It is not the discharge/BOD paper; methods and splits unverified here |
| WRR 2023, 2022WR033826 | Full-text page accessed and selected parts read; 2.5 h forecast | Crossref-deposited abstract previously reviewed; new full page not obtained | Exact 2.5 h is a supplied-note claim, not our full-text verification |
| KSEE 2024, 46.3.111 | Note asked us to locate the prior two-plant discharge study | Located: *Assessing the Performance of Deep Learning Algorithms With and Without Transfer Learning in Similar or Identical Wastewater Treatment Processes*, DOI 10.4491/ksee.2024.46.3.111. Publisher-deposited abstract: Jinju/Cheongju, 2018-2022 records, discharge and BOD, CNN/LSTM, two freezing/retraining strategies | Discharge units/location, sampling frequency, forecast horizon, chronological split and target-budget details remain unknown; official full-page request was denied |
| JH/WST guidance | Search-service text from official pages; format-free initial submission, Word revision, approximate counts and Harvard style | Official instructions and AI-methods page requests still HTTP 403 | Keep advice as externally reported, pending current official page review; no final journal/template decision |

No supplied note was used to invent a DOI or replace the prior discharge paper with a quality paper. Eight authenticated bibliographic entries, four independently read deposited abstracts, zero independently read full texts are currently in the evidence registry. The supplied summaries are additional leads, not upgraded evidence levels. No previous manuscript or direct supervisor comments were supplied in these three archives; the proposal addressed to a professor is not evidence of that professor's response.

### Subsequent official full-page verification

The KSEE row above records the earlier denied-access state. On the subsequent changed-state retry, official HTML returned HTTP 200 and sections 1–4/Tables 1–4 were actually read. Daily outlet observations, two industrial wastewater plants, complete-case/3-IQR removal and a 7:3 split ratio are now independently verified; physical discharge units, forecast lead, split ordering and inclusive adaptation budget remain unresolved. See KSEE_FULLTEXT_REVIEW.md and the captured HTML hash. Current independent evidence: eight bibliographic records, four deposited abstracts, and selected full-text sections for one paper. Other externally supplied method/guide claims retain their original lower verification level.
