# Literature and journal verification log

2026-10-09: the three titles/DOIs in EVIDENCE_TABLE.csv were supplied by the user, not independently authenticated. Requests to Crossref failed at the network tunnel (403). No abstract or full text was read, so even title-derived target descriptions have not been entered as verified evidence. Do not generate BibTeX or novelty claims from these rows until authenticated.

For each paper, record the version/URL/hash of retrieved evidence, then mark `metadata_verified`, `abstract_verified` or `full_text_verified`. Extract target and units; number of physical plants; resolution and horizon; input availability; source/target split; local data budget (including adaptation/calibration); exact baselines; interval method; quantitative findings with page/table and limits. Unknown is distinct from absent.

The likely overlap to investigate is transfer for limited-data effluent forecasting; do not presume this project is first. Distinguish water quality vs daily treated-effluent volume, seen plants vs held-out physical plants, temporal vs plant isolation, and full-history adaptation vs inclusive small-history budgets. The inflow paper must be assessed for interval methodology and input timing rather than treated as direct evidence for treated effluent volume.

Supplementary literature search (pending): recent original research on cross-plant/domain forecasting, low-history hydrological regression, temporal conformal calibration, and wastewater flow data quality. Use official publisher/Crossref records; record search strings/dates and negative searches. Third-party promotional claims are not scientific evidence.

Official candidate pages attempted and not read:

- https://iwaponline.com/jh/pages/About
- https://iwaponline.com/jh/pages/Author_Guidelines
- https://iwaponline.com/wst/pages/About
- https://iwaponline.com/wst/pages/Author_Guidelines

All four returned tunnel 403. These are attempted URLs, not verified current links or current policy. Once accessible, resolve any redirects and inspect current official article types, scope, manuscript/reference structure, editable figures and resolution, data/code availability, templates, and fees. Do not invent numeric formatting requirements. Conditional journal positioning is in RESEARCH_PLAN.md; no final journal recommendation is established yet.

## 2026-10-09 follow-up: actual evidence recovered

After the network draft save and a new diagnostic request, Crossref and OpenAlex returned HTTP 200. This observation establishes access to those requests, not that all saved network/script settings have been applied or published. The earlier 403 observations remain part of the chronological log.

- The three user-specified title/DOI/year records are authenticated in Crossref. Both 2024 Elsevier records contain no deposited abstract; OpenAlex also has no abstract for them. Their methods, cohorts, inputs, data budgets, and findings remain **unverified**. Publisher requests are blocked (see access logs), not evidence that the papers do not exist.
- Sonnenschein and Ziel (2023), DOI 10.1029/2022WR033826: publisher-deposited abstract reviewed via Crossref. It models intraday **inflow**, using sewer sensor and rain forecast information, benchmarks AR and LSTM, and stresses real-time rain forecasts. Exact sampling/horizon, split, calibration details and low-history transfer are not authenticated from a full text.
- Supplementary original research was located by OpenAlex and individually authenticated in Crossref. **Most relevant novelty warning:** DOI 10.4491/ksee.2024.46.3.111 (2024) already examines transfer between two WWTPs for **discharge and BOD**. Its publisher-deposited abstract says improvement for discharge was slight under frozen hidden layers; the other transfer strategy gave no measurable prediction change. Do not claim first cross-plant discharge transfer. Exact measurement location, horizon, and inclusive local budgets need full text. This makes the project's potential contribution a stricter held-out-facility/budget/data-integrity evaluation, conditional on actually executing it and demonstrating a useful finding.
- DOI 10.3390/w17162357 (2025): GPR sewer inflow/water-level probabilistic forecasting; abstract-reviewed. Earlier preprint explicitly describes hydraulic simulations, so the final article's real-vs-simulated data must be checked rather than claiming it used measured effluent data.
- DOI 10.1145/3744350 (2025): context-driven forecasting at two full-scale utilities, but different targets (tunnel level and nitrate). Abstract-reviewed. Different utilities/targets do not establish unseen-plant daily-volume transfer. Reported abstract numbers are literature claims, never our experiment results.
- DOI 10.1016/j.seppur.2026.138807: Crossref verifies a September 2026 publication on reverse-osmosis forecasting/transfer in wastewater reuse; metadata only. OpenAlex gives an earlier date, retained in its record; use publisher/Crossref date with provenance and do not infer methods from title.

Evidence table now separates metadata-only and abstract-reviewed records; `reviewed_abstracts.json` preserves the deposited abstract text and source path; `verified_metadata.bib` contains only authenticated bibliographic fields. No full text has been reviewed. Full source responses and SHA256 access logs are under `access_attempts/`.

Searches: Crossref generic query `wastewater treatment plant transfer learning forecasting effluent`, 2024-01-01 through 2026-10-09, six results (several irrelevant, not all included); second Crossref interval query returned 429 and was not retried in a loop. OpenAlex queries `wastewater transfer learning forecasting` and `wastewater probabilistic flow forecast`, same date interval, six results each. Search results include reviews, preprints, conference abstracts and unrelated disease surveillance; these were not promoted to original WWTP effluent evidence. This is a targeted initial search, not a systematic or exhaustive review.

IWA main journal pages now return HTTP 403 after tunnel access; additional publisher-site and Wiley/Elsevier requests still encounter policy denial. Scope and author-guide content remains unverified. Added publisher destinations are saved in the draft for review, not proof of available access.

## Publisher full-text access update (after received-data experiments)

The KSEE publisher request now succeeds after the required domain addition. Main text sections 1–4 and Tables 1–4 have been read, upgrading this record to **full-text selected-sections verified**. Eight metadata records remain authenticated; four deposited abstracts were read earlier, with one of those papers now additionally reviewed in publisher full text. Detailed daily sampling, outlet location, 7:3 split statement, missing/outlier deletion, normalized MSE tables and remaining timing/unit uncertainties are in KSEE_FULLTEXT_REVIEW.md. Prior no-full-text statements above are historical. No final journal guidance or Elsevier full text has been upgraded.
