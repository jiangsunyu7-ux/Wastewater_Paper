# 本次真实开发阶段交付（2026-10-09）

先读 reports/development_20261009/RESULTS.md、STATUS.md、EXPERIMENT_PROTOCOL.md。
这是10个未核实物理身份SiteID的离线开发结果，不是最终跨厂实验。
全部12次主运行及独立冒烟保留，负结果和687负预测均未裁剪。
论文6页开发稿只写实测基线，共享/区间/最终仍待完成。

阶段包包含原审计daily_candidates、异常记录、规则及提供方元数据，可直接重跑基线。原始CSV/API/HK数据不重复打包，保留在用户Part1/Part2及云目录。完整row_audit另见审计伴随ZIP。若要重跑原数据审计，先导入原件：
将本包解压到新项目目录，再从原Part1/Part2导入（脚本先核验、拒绝覆盖冲突）：
python3 handoff/import_and_verify.py --project-root . --zip /path/Wastewater_Part1_Plan_and_Raw.zip --zip /path/Wastewater_Part2_Derived.zip
原文件存在时可运行 python3 handoff/import_and_verify.py --project-root . 只做逐文件核验。
bash scripts/refresh_environment.sh
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
export MPLCONFIGDIR="$PWD/.cache/matplotlib"
export XDG_CACHE_HOME="$PWD/.cache"

已打包原版本daily_candidates，无需重建即可跑smoke和batch；如重做原数据审计，用新目录避免覆盖：
python3 -m wastewater.audit --raw wastewater_data/raw/wessex_all_2016_2025.csv --config configs/audit.wessex_20261009.json --output data/derived/REPLAY_AUDIT
新输出需与原manifest.outputs_sha256逐文件比对；如需补齐row_audit，只复制缺少文件，不覆写已有原版本。
或者写新版本配置指向REPLAY_AUDIT，不把新版本输出伪称原运行。
按WORKFLOW.md执行smoke→batch→新summary→新figures。
完整原逐记录审计在云目录保留，旧审计参考表随原Part2保留。

Overleaf另用源项目ZIP；本结果包不是Overleaf上传包。
SHA256SUMS.txt覆盖其他每个包内文件。日期和图形/PDF生成元数据可能不同，不承诺重新渲染字节相同。
数据是提供方年度快照，历史观测可用性未验证；延迟情景不能恢复历史修订。
