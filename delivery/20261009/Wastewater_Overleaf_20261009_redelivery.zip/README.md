# Manuscript status

Initial state: no manuscript existed before the split data archives arrived. That historical limitation has been resolved for the three executed development baselines only.

Current `main.tex` is an English **development work draft**, with verified local baseline results and explicit pending items, not a complete shared-learning/final-test paper. Unknown authors/affiliations and final journal are marked pending. No official journal template is claimed. Numbers and table source are generated from checked artifacts using `scripts/prepare_development_manuscript.py`, and bibliography entries use authenticated metadata with reading levels logged in literature/.

Build from this directory:

```bash
mkdir -p build
pdflatex -halt-on-error -interaction=nonstopmode -output-directory=build main.tex
bibtex build/main
pdflatex -halt-on-error -interaction=nonstopmode -output-directory=build main.tex
pdflatex -halt-on-error -interaction=nonstopmode -output-directory=build main.tex
```

On Overleaf, select `main.tex` as the root document and pdfLaTeX. The package requires standard LaTeX packages only and contains no raw dataset. `build/main.pdf` is the local compiled development draft; actual validation and ZIP checks are recorded in STATUS.md. No account sync, public release or submission was performed. IWA Word-revision advice is externally reported and awaits official-page verification; no Word deliverable or finalized journal claim is made here.
