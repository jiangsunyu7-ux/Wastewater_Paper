# Stage3E Diagnostics

New evidence-review version: stage3e_evidence_review_v1, client date 20261013.
Read reports/stage3e_evidence_review_v1/REPRODUCE.md, ANALYSIS_ZH.md and NEXT_STAGE_DECISION.md.
This is reliability repair and post-hoc diagnosis, not a new forecasting model.
All original D frozen scientific files retain their old hashes. Original D
intervals/source banks are SHA-linked; source caches and twelve original
smoke conditions here enable the limited software/science check. Full
diagnostic replay requires the separately identified original D prediction
inputs. It is not a cold rerun of 300 interval conditions.
Extract all NEW E packages to one new root; different-SHA collisions fail.
C2 original Part01/02 remain old original bytes and are separate archives.
All statistical diagnostics are exploratory. Physical mapping and real-time
publication are unverified. Stop: no final2024-2025, new fitting or source search.
