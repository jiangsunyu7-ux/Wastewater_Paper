# Stage3E 运行可靠性核验

本轮使用新的 `stage3e_evidence_review_v1` 输出树，未修改 Stage3D 的科学模块、冻结配置、原任务状态或结果。此工作是运行持久化防护与数学回归检查，**不是新的预测模型训练或新的源侧 gamma 选择**。

## 已确认与未确认

- 原 Stage3D 的 `common.write_json` 采用直接 `write_text`，任务科学 CSV 使用直接 `to_csv`。原 `run_task` 返回前没有对最终完成状态做写后读回核验。原总运行收尾仍检查磁盘证据，不完整时能正确返回 `PARTIAL`。这些是代码结构事实，不等于已确定外部9个 RUNNING 状态的根因。
- 本仓库原300任务的状态、配置指纹、3个科学成员 SHA、实际 CSV 行数和校准日期边界均只读核验通过。本轮未重算这300任务。
- 外部冷启动“函数返回300成功，9个状态仍RUNNING”的异常没有在本轮小规模重构中自然复现；根因仍未确认。用户报告的9个任务前后SHA相同，不应被改写为原提交实验未完成。本轮没有该外部运行原始附件，不能替代对其文件的独立核验。

## 新防护

`src/wastewater/stage3e_runtime.py` 在单进程、串行作用域中封装冻结的 Stage3D `run_task`，只拦截新E输出树中的必要CSV和JSON持久化。序列化仍由原pandas/JSON规则执行。

1. 同目录临时文件写入，`flush`、文件 `fsync`、原子 `os.replace`、目录 `fsync`、SHA256读回。
2. 三个科学文件不是跨文件事务。只有全部文件存在、原科学配置指纹一致、成员SHA一致、CSV实际行数和计划任务/日期边界一致，才写入独立、原子、读回验证的 `runtime_status.json` 完成收据。
3. 函数返回成功数与磁盘验证完成数分别报告；最终运行状态只取后者。缺文件或损坏缓存不会静默复用，不同配置指纹直接拒绝且不覆写。
4. 每次运行每任务至多2次尝试（初次加1次修复）。恢复前保存当前新E任务目录至 `recovery_evidence`；失败/恢复事件追加到fsync后的 `failure_events.jsonl`。没有自动无限重试或手工改COMPLETED。
5. 可直接加载的源缓存由原 `GAMMA_FREEZE.json` 的21个状态/成员SHA以及源provenance指纹、签名、设施列表、规则和既定gamma独立验证；没有重新选择gamma。

当前环境支持文件和目录fsync；故障被抛出时不会以返回成功代替磁盘证据。未认证网络文件系统或多进程同时修改同一新任务目录的持久化语义，封装仅支持本轮单CPU串行用途。

## 实际执行

| 检查 | 真实结果 |
|---|---|
| 原D300任务只读核验 | 300/300通过，无原任务补算 |
| E初次仅1个任务 | 函数成功1、磁盘完成1/12、failed=0；正确PARTIAL，退出码3 |
| E原两测点首窗口全部预算/时距 | 12/12、12,960条区间；12任务总共重构，非新模型训练 |
| 与原D同12任务的科学成员比对 | calibration.csv / intervals.csv / diagnostics.json 共36成员SHA完全相同 |
| E完整resume | 12个经验证缓存，函数重算0；全部科学成员SHA不变 |
| 必要新测试 | 14项通过 |
| 受控软件故障 | 每批8项，两批保留；第二批增加原源冻结链核查后执行 |

受控故障包括陈旧RUNNING、输出缺失、损坏缓存、错误指纹、最终状态写入中断、replace前/后中断、函数成功但磁盘证据缺失。各正常可修复情景恢复后的3科学成员仍与原D/已验证E完全相同，重复resume不重算；错误指纹保持拒绝；函数虚报成功的2次尝试均不生成COMPLETED。受控注入不是对原9状态自然根因的复现。

记录路径：`runs/stage3e_evidence_review_v1/runtime/smoke/`、`runtime/controlled_fault_trials/batch_*`。两批故障保留来自软件防护校验，未增设科学模型/参数/源设施/评价窗口。报告在 `reports/stage3e_evidence_review_v1/runtime/`。

真实耗时：首1任务调用2.50秒，接续原12任务调用5.56秒（复用1、重构11），纯缓存resume2.23秒；只读300审计加8项故障核验的两次脚本调用分别6.63和6.74秒。没有采样峰值内存或GPU验证，不据此报告完整进程树内存。

## 运行和复核命令

仓库环境已存在 `.venv-stage2`；设置单CPU库线程并保持依赖版本与原D一致：

```bash
export PYTHONPATH=src
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
.venv-stage2/bin/python -m unittest tests.test_stage3e_runtime -v
.venv-stage2/bin/python -m wastewater.stage3e_runtime --mode smoke
.venv-stage2/bin/python -m wastewater.stage3e_runtime --mode resume
.venv-stage2/bin/python scripts/check_stage3e_runtime.py
```

最小复核包不包含原D全部300任务时，使用明确的smoke范围；不将它写成全量冷启动复现：

```bash
.venv-stage2/bin/python scripts/check_stage3e_runtime.py --scope smoke --run-smoke
```

最小依赖：原D冻结文件清单中的25个文件、FREEZE.json、GAMMA_FREEZE.json、原三个源缓存的21状态/成员、原D12smoke任务的36科学文件（比对输入），以及本轮三个新代码/测试文件。数据包括原canonical、共同评价日期、Persistence参考及质量表。不需要重新生成源误差库、不需要原D324,000逐条区间大文件；如执行默认full只读审计，才需原D300任务的状态和3科学成员。
