"""Independently verify saved Stage3D task artifacts, then recompute interval metrics.

No fitting, gamma selection, or target prediction occurs. Completed status
requires every registered task and artifact checksum, not merely failed=0.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from wastewater.common import sha256
from wastewater.stage3d_evaluation import summarize_intervals


def verify_run(root,config_path,run,frame,prediction_path):
    from wastewater.stage3d_experiment import (expected_tasks,job_fingerprint,load_config,task_key,validate_job)
    cfg,signature,_=load_config(config_path)
    manifest=json.loads((run/'manifest.json').read_text())
    if manifest.get('mode')!='full' or manifest.get('status')!='COMPLETED':
        raise ValueError('Full scientific evaluation requires a verified COMPLETED full run')
    if manifest.get('signature')!=signature or manifest.get('config_sha256')!=sha256(root/config_path):
        raise ValueError('Run/configuration fingerprint mismatch')
    if manifest.get('predictions_sha256')!=sha256(prediction_path):
        raise ValueError('Saved aggregate prediction checksum mismatch')
    gamma_path=root/cfg['gamma_freeze']
    gamma=json.loads(gamma_path.read_text())
    if manifest.get('gamma_freeze_sha256')!=sha256(gamma_path) or gamma.get('signature')!=signature:
        raise ValueError('Source-only gamma-freeze fingerprint/checksum mismatch')
    if gamma.get('status')!='FROZEN_SOURCE_ONLY_GAMMA_BEFORE_TARGET_INTERVALS' or gamma.get('target_deployment_scores_used') is not False:
        raise ValueError('Gamma is not explicitly frozen from source-only data')
    for name,expected in gamma['files_sha256'].items():
        if not (root/name).is_file() or sha256(root/name)!=expected:
            raise ValueError('Frozen source library/validation output changed: '+name)
    tasks=expected_tasks(cfg,'full');rows_per=cfg['evaluation_days']*len(cfg['pools'])*len(cfg['methods'])*len(cfg['nominal_coverages'])
    if manifest.get('expected_conditions')!=len(tasks) or manifest.get('completed_conditions')!=len(tasks):
        raise ValueError('Partial run cannot be promoted by evaluation')
    if manifest.get('failed_conditions')!=0 or manifest.get('not_completed_conditions')!=0:
        raise ValueError('Manifest contains failed/incomplete tasks')
    frames=[];hashes={};start_times=[]
    for task in tasks:
        job=run/'jobs'/task_key(task)
        if not validate_job(job,job_fingerprint(signature,task,cfg),rows_per):
            raise ValueError('Missing/incomplete registered task: '+task_key(task))
        status=json.loads((job/'status.json').read_text())
        start_times.append(status['started_utc'])
        hashes[str((job/'status.json').relative_to(root))]=sha256(job/'status.json')
        for name,expected in status['outputs_sha256'].items():
            hashes[str((job/name).relative_to(root))]=expected
        piece=pd.read_csv(job/'intervals.csv',dtype={'site_id':str,'pool_id':str,'order_label':str},low_memory=False)
        if len(piece)!=rows_per:raise ValueError('Incorrect task row count: '+task_key(task))
        frames.append(piece)
    if pd.Timestamp(gamma['created_utc'])>min(pd.Timestamp(t) for t in start_times):
        raise ValueError('Source gamma freeze was created after a target task started')
    if len(frame)!=len(tasks)*rows_per or manifest.get('expected_prediction_rows')!=len(frame):
        raise ValueError('Incomplete/unregistered aggregate row count')
    saved=pd.concat(frames,ignore_index=True)
    keys=['site_id','episode','budget','horizon','origin','target_date','pool_id','method','nominal_coverage']
    columns=['truth_m3','persistence_m3','lower_m3','upper_m3','lower_nonnegative_m3','gamma','selected_mixture_gamma',
             'scale_m3','normalized_quantile','calibration_samples','high_threshold_m3']
    compared=frame[keys+columns].merge(saved[keys+columns],on=keys,how='outer',suffixes=('','_job'),
                                      indicator=True,validate='one_to_one')
    if not compared._merge.eq('both').all():
        raise ValueError('Aggregate does not contain exactly the saved original task intervals')
    tol=cfg['tolerances'];checks=[]
    for column in columns:
        a=compared[column].to_numpy(float);b=compared[column+'_job'].to_numpy(float)
        exact=column in ['gamma','selected_mixture_gamma','calibration_samples']
        passed=np.array_equal(a,b,equal_nan=True) if exact else np.allclose(a,b,atol=tol['m3_atol'],rtol=tol['m3_rtol'],equal_nan=True)
        if not passed:raise ValueError('Aggregate differs from saved job values: '+column)
        finite=np.isfinite(a)&np.isfinite(b)
        checks.append(dict(column=column,passed=True,finite_rows=int(finite.sum()),
          maximum_absolute_difference=float(np.max(np.abs(a[finite]-b[finite]))) if finite.any() else 0.,
          bitwise_parsed_csv_values=bool(np.array_equal(a,b,equal_nan=True))))
    for pool in cfg['pools']:
        for b in cfg['budgets']:
            for h in cfg['horizons']:
                chosen=gamma['selected_gamma'][pool['pool_id']][f'B{b}_H{h}']
                condition=frame.pool_id.eq(pool['pool_id'])&frame.budget.eq(b)&frame.horizon.eq(h)
                if not frame.loc[condition,'selected_mixture_gamma'].eq(chosen).all():
                    raise ValueError('Target metadata differs from frozen source gamma')
                mix=condition&frame.method.eq('MIXTURE')
                if not frame.loc[mix,'gamma'].eq(chosen).all():
                    raise ValueError('MIXTURE target gamma differs from source-only frozen selection')
    return cfg,dict(status='VERIFIED',all_expected_tasks_verified=True,expected_conditions=len(tasks),
        completed_conditions=len(tasks),expected_interval_rows=len(frame),config_sha256=sha256(root/config_path),
        predictions_sha256=sha256(prediction_path),manifest_sha256=sha256(run/'manifest.json'),
        gamma_freeze_sha256=sha256(gamma_path),gamma_frozen_before_target_tasks=True,
        aggregate_checks=checks,numeric_tolerance=tol,tolerance_not_bitwise_reproduction_claim=True,
        verified_original_task_artifacts_sha256=hashes)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',required=True)
    parser.add_argument('--run',required=True)
    parser.add_argument('--predictions')
    parser.add_argument('--output',required=True)
    args=parser.parse_args();root=Path(__file__).resolve().parents[1]
    resolve=lambda path:Path(path) if Path(path).is_absolute() else root/path
    run=resolve(args.run);prediction=resolve(args.predictions) if args.predictions else run/'predictions_all.csv.gz'
    frame=pd.read_csv(prediction,dtype={'site_id':str,'pool_id':str,'order_label':str},low_memory=False)
    config_path=str(resolve(args.config).resolve().relative_to(root.resolve()))
    cfg,integrity=verify_run(root,config_path,run,frame,prediction)
    _,_,_,ci=summarize_intervals(frame,cfg,resolve(args.output),integrity)
    print(ci[ci.co_primary&ci.block_days.eq(14)][['horizon','mean_station_skill','lower_ci','upper_ci',
                                               'confidence_level']].to_string(index=False))


if __name__=='__main__':main()
