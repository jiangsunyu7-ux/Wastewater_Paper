"""Independent arithmetic/primitive-bootstrap audit of saved Stage3E evidence.

No Stage3E diagnostic/runtime algorithm is imported and no forecast is trained.
Old Stage3D endpoints remain the sole scientific observations.
"""
from pathlib import Path
import hashlib,json,math,time
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
VERSION='stage3e_evidence_review_v1'

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    started=time.perf_counter();report=ROOT/'reports'/VERSION;out=report/'results'
    cfg=json.loads((ROOT/'configs/stage3d_interval_v1/full.json').read_text())
    freeze=json.loads((ROOT/cfg['frozen_manifest']).read_text())
    for name,h in freeze['files_sha256'].items():assert sha(ROOT/name)==h,name
    status=json.loads((out/'DIAGNOSTIC_STATUS.json').read_text())
    for name,h in status['files_sha256'].items():assert sha(out/name)==h,name
    daily=pd.read_csv(ROOT/cfg['report_output']/'daily_losses.csv.gz',dtype={'site_id':str},low_memory=False)
    primary=daily[daily.constraint.eq('raw')&daily.pool_id.eq(cfg['primary_pool_id'])&daily.budget.eq(30)
                  &daily.nominal_coverage.eq(.9)&daily.method.isin(['MIXTURE','LOCAL'])].copy()
    # Formula independently evaluated in original m3, inclusive endpoints.
    lower=primary.lower_m3.to_numpy();upper=primary.upper_m3.to_numpy();truth=primary.truth_m3.to_numpy()
    score=upper-lower+20*np.maximum(lower-truth,0)+20*np.maximum(truth-upper,0)
    np.testing.assert_allclose(score,primary.interval_score_m3,atol=1e-8,rtol=1e-12)
    primary['own_score']=score
    metrics=primary.groupby(['site_id','horizon','method']).own_score.mean().unstack('method')
    metrics['skill']=1-metrics.MIXTURE/metrics.LOCAL.where(metrics.LOCAL.gt(0))
    metrics['contribution']=(metrics.MIXTURE-metrics.LOCAL)/len(cfg['development_ids'])
    contributions=pd.read_csv(out/'primary_site_contributions.csv',dtype={'site_id':str})
    pairs=contributions.set_index(['site_id','horizon'])
    np.testing.assert_allclose(pairs.skill_vs_local.sort_index(),metrics.skill.sort_index(),atol=1e-12,rtol=1e-12)
    np.testing.assert_allclose(pairs.equal_site_score_change_contribution_m3.sort_index(),metrics.contribution.sort_index(),atol=1e-8,rtol=1e-12)
    loo=pd.read_csv(out/'leave_one_site_out_sensitivity.csv',dtype={'omitted_site_id':str})
    for row in loo.itertuples(index=False):
        q=metrics.xs(row.horizon,level='horizon').drop(row.omitted_site_id)
        np.testing.assert_allclose([row.mean_skill_without_site,row.raw_local_score_without_site_m3,
            row.raw_mixture_score_without_site_m3,row.raw_score_skill_without_site],
            [q.skill.mean(),q.LOCAL.mean(),q.MIXTURE.mean(),1-q.MIXTURE.mean()/q.LOCAL.mean()],atol=1e-8,rtol=1e-12)
        assert row.excluded_from_formal_evaluation is False
    segments=pd.read_csv(out/'deployment_segment_metrics_by_site_window.csv',dtype={'site_id':str})
    filtered=segments[segments.constraint.eq('raw')&segments.pool_id.eq(cfg['primary_pool_id'])
        &segments.budget.eq(30)&segments.nominal_coverage.eq(.9)&segments.method.eq('MIXTURE')]
    for row in filtered.itertuples(index=False):
        start,end=map(int,row.segment.split('-'))
        d=primary[primary.site_id.eq(row.site_id)&primary.episode.eq(row.episode)&primary.horizon.eq(row.horizon)&primary.method.eq('MIXTURE')]
        day=(pd.to_datetime(d.origin)-pd.Timestamp(row.episode)).dt.days+1;d=d[day.between(start,end)]
        np.testing.assert_allclose([row.interval_score_m3,row.coverage,row.mean_width_m3],
            [d.own_score.mean(),d.covered.mean(),(d.upper_m3-d.lower_m3).mean()],atol=1e-8,rtol=1e-12)
        assert row.n_dates==len(d)
    cal=pd.read_csv(out/'calibration_actual_samples.csv',dtype={'site_id':str})
    # Every new calibration count/date is read independently from saved D CSV.
    for row in cal.itertuples(index=False):
        job=ROOT/cfg['output']/'jobs'/f'{row.site_id}_{row.episode}_B{row.budget}_H{row.horizon}'
        frame=pd.read_csv(job/'calibration.csv')
        assert int(frame.valid_score.sum())==row.actual_calibration_errors
        kept=frame[frame.valid_score]
        assert kept.target_date.max()<=str((pd.Timestamp(row.episode)-pd.Timedelta(days=1)).date())
    table=pd.read_csv(out/'primary_comparison_recomputed.csv')
    sites=cfg['development_ids'];episodes=cfg['evaluation_origins'];length=cfg['evaluation_days']
    index=pd.MultiIndex.from_tuples([(s,e,str(o.date())) for s in sites for e in episodes for o in pd.date_range(e,periods=length)],names=['site_id','episode','origin'])
    bootstrap=[]
    for h in cfg['horizons']:
        arrays=[]
        for method in ['MIXTURE','LOCAL']:
            q=primary[primary.horizon.eq(h)&primary.method.eq(method)].set_index(['site_id','episode','origin']).own_score
            arrays.append(q.reindex(index).to_numpy().reshape(len(sites),len(episodes)*length))
        dense=np.stack(arrays,axis=2)
        for block in cfg['bootstrap']['blocks']:
            rng=np.random.default_rng(cfg['bootstrap']['seed']+h*100+block);draws=[]
            for _ in range(cfg['bootstrap']['replicates']):
                times=[]
                for e in range(len(episodes)):
                    starts=rng.integers(0,length-block+1,size=math.ceil(length/block))
                    times.extend((e*length+(starts[:,None]+np.arange(block)).ravel()[:length]).tolist())
                chosen=rng.integers(0,len(sites),size=len(sites))
                temporal=np.nanmean(dense[:,times,:],axis=1)[chosen]
                draws.append(np.nanmean(np.where(temporal[:,1]>0,1-temporal[:,0]/temporal[:,1],np.nan)))
            mean=metrics.xs(h,level='horizon').skill.mean();bounds=np.quantile(draws,[.0125,.9875])
            row=table[table.horizon.eq(h)&table.block_days.eq(block)].iloc[0]
            np.testing.assert_allclose([row.mean_station_skill,row.lower_ci,row.upper_ci],[mean,*bounds],atol=1e-10,rtol=1e-10)
            assert row.replicates==5000
            bootstrap.append({'horizon':h,'block_days':block,'replicates':5000,'max_absolute_difference':float(np.max(np.abs(np.array([row.mean_station_skill,row.lower_ci,row.upper_ci])-np.array([mean,*bounds]))))})
    runtime=ROOT/'runs'/VERSION/'runtime/smoke';old=ROOT/'runs/stage3d_interval_v1/smoke'
    files=0
    for job in sorted((runtime/'jobs').iterdir()):
        s=json.loads((job/'runtime_status.json').read_text());assert s['status']=='COMPLETED'
        for name,h in s['outputs_sha256'].items():assert sha(job/name)==h==sha(old/'jobs'/job.name/name);files+=1
    result={'status':'PASSED','version':VERSION,'scientific_models_trained':0,
        'old_D_freeze_files_checked':len(freeze['files_sha256']),'primary_loss_rows_checked':len(primary),
        'site_contributions_checked':len(pairs),'leave_one_out_rows_checked':len(loo),
        'main_site_window_segment_rows_checked':len(filtered),'calibration_rows_checked':len(cal),
        'primitive_bootstrap_checks':bootstrap,'runtime_scientific_files_byte_identical':files,
        'checker_sha256':sha(__file__),'elapsed_seconds':time.perf_counter()-started,'old_inputs_modified':False}
    (report/'INDEPENDENT_EVIDENCE_CHECK.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
