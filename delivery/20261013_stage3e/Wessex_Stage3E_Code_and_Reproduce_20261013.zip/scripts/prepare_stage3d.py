"""Extract immutable C2 references and prepare the bounded Stage3D configuration.

No point prediction is regenerated: reference rows are copied from verified
original job files. This script does not compute interval performance.
"""
from pathlib import Path
import json
import shutil
import subprocess

import numpy as np
import pandas as pd
from wastewater.common import sha256, utc_now, write_json

ROOT = Path(__file__).resolve().parents[1]
VERSION = 'stage3d_interval_v1'


def main():
    cfg_folder = ROOT / 'configs' / VERSION
    data_folder = ROOT / 'data/derived' / VERSION
    report = ROOT / 'reports' / VERSION
    for p in [cfg_folder, data_folder, report]:
        p.mkdir(parents=True, exist_ok=True)
    if (cfg_folder/'full.json').exists():
        raise ValueError('Preparation is one-time; do not overwrite a configured version')
    old = json.loads((ROOT/'configs/stage3c2_source_scale_v1/full.json').read_text())
    old_freeze = json.loads((ROOT/old['frozen_manifest']).read_text())
    for name, expected in old_freeze['files_sha256'].items():
        if sha256(ROOT/name) != expected:
            raise ValueError('Old frozen file changed: ' + name)
    original_manifest = json.loads((ROOT/old['output']/'manifest.json').read_text())
    assert original_manifest['status'] == 'COMPLETED'
    assert original_manifest['completed_conditions'] == 300
    assert sha256(ROOT/old['output']/'predictions_all.csv.gz') == original_manifest['predictions_sha256']
    references = []
    members = {}
    for p in sorted((ROOT/old['output']/'jobs').glob('*/predictions.csv')):
        frame = pd.read_csv(p, dtype={'site_id': str})
        reference = frame[frame.pool_id.eq('baseline') & frame.model.eq('persistence')].copy()
        assert len(reference) == 60
        references.append(reference)
        members[str(p.relative_to(ROOT))] = sha256(p)
    assert len(references) == 300
    pd.concat(references, ignore_index=True).to_csv(data_folder/'c2_persistence_reference.csv.gz', index=False,
                                                  compression={'method':'gzip', 'mtime':0})
    idx_path = 'reports/stage3c2_source_scale_v1/results/paired_evaluation_index.csv.gz'
    shutil.copyfile(ROOT/idx_path, data_folder/'c2_common_dates.csv.gz')
    canonical = pd.read_csv(ROOT/old['canonical_csv'], dtype={'site_id':str})
    targets = canonical[canonical.site_id.isin(old['development_ids'])].copy()
    raw_path = 'data/provenance/stage3c2_source_scale_v1/selected_model_raw_records.csv.gz'
    raw = pd.read_csv(ROOT/raw_path, dtype={'SiteID':str}, usecols=['SiteID','Date','QualityFlag'])
    raw = raw[raw.SiteID.isin(old['development_ids'])].rename(columns={'SiteID':'site_id','Date':'date'})
    flags = raw.groupby(['site_id','date']).QualityFlag.apply(
        lambda x:'|'.join(sorted(set(x.dropna().astype(str))))).rename('quality_flag').reset_index()
    targets = targets.merge(flags, on=['site_id','date'], how='left', validate='one_to_one')
    targets['quality_flag'] = targets.quality_flag.fillna('No_record')
    targets[['site_id','date','quality_flag','target_quality_valid','conflict','source_records']].to_csv(
        data_folder/'development_quality.csv', index=False)
    cfg = {k:old[k] for k in ['development_ids','source_training_start','source_training_end',
        'source_selection_train_end','source_pseudo_origins','source_pseudo_validation_days',
        'evaluation_days','budgets','horizons','smoke_ids','evaluation_origins','canonical_csv',
        'source_pool_definition','high_volume_quantile','high_volume_history_days']}
    cfg.update(version=VERSION, stage='development', analysis_unit='station_exploratory',
        physical_mapping_verified=False, verified_real_time=False,
        qa_mode='published_good_only_retrospective', all_windows_already_used_development=True,
        interval_protocol_after_observing_stage3c2=True,
        pools=[p for p in old['pools'] if p['k']==30], gammas=[0,.25,.5,.75,1],
        nominal_coverages=[.8,.9], min_calibration_scores=14, gamma_tie_tolerance=1e-12,
        quantile_cdf_tolerance=float(8*np.finfo(float).eps),
        methods=['LOCAL','SHARED','MIXTURE'],
        scale='median_positive_Good_in_allowed_history; no_positive=NO_VALID_SCALE',
        center='unchanged Stage3C2 Persistence: latest finite origin..origin-7 within budget left',
        source_weights='each included source SiteID equal total mass',
        loss='90% interval score divided by held-site allowed-history scale; held SiteID/window equal',
        calibration_insufficient_rule='all three methods retained but jointly excluded for that condition',
        quantile='observed-value left inverse weighted empirical CDF; no interpolation',
        interval_constraint='raw primary; all methods lower=max(0,lower) sensitivity',
        high_volume_rule='same first-origin preceding30day Good Q90 shared across budgets',
        initial_budget_definition='T-B..T-1 calendar days; no left warm-up; all interval parameters frozen60origins',
        source_output=f'runs/{VERSION}/source', output=f'runs/{VERSION}/full',
        report_output=f'reports/{VERSION}/results', protocol='STAGE3D_PROTOCOL.md',
        frozen_manifest=f'configs/{VERSION}/FREEZE.json',
        gamma_freeze=f'reports/{VERSION}/GAMMA_FREEZE.json',
        c2_persistence_reference=f'data/derived/{VERSION}/c2_persistence_reference.csv.gz',
        c2_common_dates=f'data/derived/{VERSION}/c2_common_dates.csv.gz',
        development_quality=f'data/derived/{VERSION}/development_quality.csv',
        primary_pool_id='order20261012_K30', primary_method='MIXTURE', primary_budget=30,
        primary_nominal_coverage=.9, workers=2,
        bootstrap={'replicates':5000,'blocks':[7,14,28],'primary_block':14,
          'seed':20261012,'seed_formula':'20261012+h*100+L',
          'primary_comparison_interval_level':.975,'primary_comparison_interval_percentiles':[1.25,98.75],
          'design':'within-window synchronized noncircular calendar blocks then whole SiteID resampling'},
        tolerances={'m3_atol':1e-8,'m3_rtol':1e-12,'normalized_atol':1e-10,'normalized_rtol':1e-10})
    assert len(cfg['pools']) == 3
    write_json(cfg_folder/'full.json', cfg)
    outputs = ['c2_persistence_reference.csv.gz','c2_common_dates.csv.gz','development_quality.csv']
    write_json(data_folder/'manifest.json', dict(status='PREPARED_NO_INTERVAL_PERFORMANCE',utc=utc_now(),
        origin='Rows extracted from original preserved C2 files; no prediction regeneration',
        original_c2_aggregate_sha256=original_manifest['predictions_sha256'],
        original_c2_reference_files_sha256=members,
        input_sha256={name:sha256(ROOT/name) for name in [old['canonical_csv'],idx_path,raw_path]},
        outputs_sha256={name:sha256(data_folder/name) for name in outputs},reference_rows=18000))
    before = report/'long_term_documents_before'
    before.mkdir(exist_ok=True)
    for name in ['AGENTS.md','STATUS.md','RESEARCH_PLAN.md','EXPERIMENT_PROTOCOL.md','WORKFLOW.md']:
        shutil.copyfile(ROOT/name, before/name)
    (ROOT/'requirements-stage3d.txt').write_text((ROOT/'requirements-stage3c2.txt').read_text())
    print(json.dumps(dict(status='PREPARED',config_sha256=sha256(cfg_folder/'full.json'),
                         pools=3,expected_conditions=300,interval_rows=324000)))


if __name__=='__main__':main()
