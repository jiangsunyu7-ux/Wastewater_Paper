"""Package new Stage3E evidence, never rename Stage3D as a new experiment.

Original scientific files remain unchanged. The new code package contains only
small replay dependencies (including original source caches); the large original
D prediction packages are SHA-linked external inputs for full diagnostics.
"""
from __future__ import annotations
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import time
import zipfile

ROOT=Path(__file__).resolve().parents[1]
VERSION='stage3e_evidence_review_v1'
D_VERSION='stage3d_interval_v1'
DAY='20261013'
LIMIT=24*1024**2
spec=importlib.util.spec_from_file_location('_stage3d_package_helpers',ROOT/'scripts/package_stage3d.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
helper.VERSION=VERSION;helper.DAY=DAY
sha=helper.sha
save_json=helper.save_json
add_path=helper.add_path


def start_text(category):
    return (f'# Stage3E {category}\n\n'
      f'New evidence-review version: {VERSION}, client date {DAY}.\n'
      'Read reports/'+VERSION+'/REPRODUCE.md, ANALYSIS_ZH.md and NEXT_STAGE_DECISION.md.\n'
      'This is reliability repair and post-hoc diagnosis, not a new forecasting model.\n'
      'All original D frozen scientific files retain their old hashes. Original D\n'
      'intervals/source banks are SHA-linked; source caches and twelve original\n'
      'smoke conditions here enable the limited software/science check. Full\n'
      'diagnostic replay requires the separately identified original D prediction\n'
      'inputs. It is not a cold rerun of 300 interval conditions.\n'
      'Extract all NEW E packages to one new root; different-SHA collisions fail.\n'
      'C2 original Part01/02 remain old original bytes and are separate archives.\n'
      'All statistical diagnostics are exploratory. Physical mapping and real-time\n'
      'publication are unverified. Stop: no final2024-2025, new fitting or source search.\n').encode()
helper.start_text=start_text


def make_packages(output,category,payload):
    base=f'Wessex_Stage3E_{category}_{DAY}'
    force_parts=category=='Diagnostics'
    first=output/(base+('_Part01' if force_parts else '')+'.zip')
    if first.exists() or list(output.glob(base+'_Part*.zip')):
        raise FileExistsError('Never overwrite earlier E archives')
    print(f'packaging {category}: {len(payload)} files',flush=True)
    item=helper.write_archive(first,payload,category,1 if force_parts else None)
    if item['bytes']<LIMIT:return [item]
    first.unlink(); weights=[]
    with tempfile.NamedTemporaryFile(suffix='.zip',dir=output) as scratch:
        with zipfile.ZipFile(scratch.name,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for name,p in sorted(payload.items()):
                z.write(p,name);weights.append((name,z.getinfo(name).compress_size+len(name)*2+200))
    chunks=[];chunk={};size=0;target=22*1024**2
    for name,weight in weights:
        if weight>target:raise ValueError('A member exceeds safe independent ZIP size: '+name)
        if chunk and size+weight>target:chunks.append(chunk);chunk={};size=0
        chunk[name]=payload[name];size+=weight
    if chunk:chunks.append(chunk)
    packages=[]
    for i,payload_part in enumerate(chunks,1):
        item=helper.write_archive(output/(base+f'_Part{i:02d}.zip'),payload_part,category,i)
        if item['bytes']>=LIMIT:raise ValueError('Actual new archive exceeds 24MiB')
        packages.append(item)
    return packages


def collect(root):
    quick,code,diagnostics={},{},{}
    report=root/f'reports/{VERSION}'
    required=['ANALYSIS_ZH.md','DELTA_FROM_STAGE3D.md','REPRODUCE.md','NEXT_STAGE_DECISION.md',
              'CLAIM_EVIDENCE_MATRIX.csv','RUN_STATUS.json','CODE_VERSION.json']
    for name in required:
        if not (report/name).is_file():raise FileNotFoundError('Stage3E key file missing: '+name)
    for name in ['STAGE3E_PROTOCOL.md',f'configs/{VERSION}',f'figures/{VERSION}']:
        add_path(root,quick,name)
    for name in ['AGENTS.md','STATUS.md','RESEARCH_PLAN.md','EXPERIMENT_PROTOCOL.md','WORKFLOW.md']:
        add_path(root,quick,name)
        add_path(root,code,name)
    for p in sorted(report.rglob('*')):
        if not p.is_file() or any(part in {'__pycache__','.git'} for part in p.parts):continue
        rel=p.relative_to(report)
        if rel.parts[0] in {'diagnostics','runtime'} and p.suffix in {'.csv','.gz'}:
            continue
        add_path(root,quick,str(p.relative_to(root)))
    for name in ['STAGE3E_PROTOCOL.md',f'configs/{VERSION}',f'reports/{VERSION}',f'runs/{VERSION}']:
        add_path(root,diagnostics,name)
    for p in sorted((root/'validation').glob('stage3e*')):
        if p.is_file():
            add_path(root,quick,str(p.relative_to(root)))
            add_path(root,diagnostics,str(p.relative_to(root)))
    # Immutable D scientific inputs ensure load_config validates the OLD freeze,
    # rather than creating a new hash to bypass old integrity checks.
    freeze=json.loads((root/f'configs/{D_VERSION}/FREEZE.json').read_text())
    for name,digest in freeze['files_sha256'].items():
        if sha(root/name)!=digest:raise ValueError('Old D scientific file changed: '+name)
        add_path(root,code,name)
    for name in [f'configs/{D_VERSION}/FREEZE.json',
      'src/wastewater/__init__.py','requirements-stage3d.txt','scripts/package_stage3d.py',
      'scripts/package_stage3e.py','STAGE3E_PROTOCOL.md',f'configs/{VERSION}',
      f'reports/{VERSION}/REPRODUCE.md',f'reports/{VERSION}/RUN_STATUS.json',
      f'reports/{VERSION}/CODE_VERSION.json',f'runs/{D_VERSION}/source',f'runs/{D_VERSION}/smoke',
      f'reports/{D_VERSION}/GAMMA_FREEZE.json',
      'materials/received_stage2_20261009/paper idea.docx']:
        add_path(root,code,name)
    for parent,pattern in [('src/wastewater','stage3e*.py'),('scripts','*stage3e*.py'),('tests','test_stage3e*.py')]:
        matches=sorted((root/parent).glob(pattern))
        if not matches:raise FileNotFoundError('Missing actual E code/tests: '+parent+'/'+pattern)
        for p in matches:add_path(root,code,str(p.relative_to(root)))
    for name in ['ANALYSIS_ZH.md','DELTA_FROM_STAGE3D.md','NEXT_STAGE_DECISION.md','CLAIM_EVIDENCE_MATRIX.csv']:
        add_path(root,code,f'reports/{VERSION}/{name}')
    # Reused official responses are evidence, not new network queries. Preserve
    # original bytes so a reviewer can inspect every excerpt without an API.
    with (report/'OFFICIAL_QUERY_LEDGER.csv').open(newline='') as handle:
        official=list(csv.DictReader(handle))
    for item in official:
        name=item['evidence_file']
        if sha(root/name)!=item['evidence_sha256']:
            raise ValueError('Existing official evidence response changed: '+name)
        add_path(root,quick,name)
        add_path(root,code,name)
    for name in ['LITERATURE_EVIDENCE.csv','LITERATURE_REVIEW_ZH.md','OFFICIAL_QUERY_LEDGER.csv',
      'FACILITY_MAPPING_STATUS.csv','FIELD_EVIDENCE.csv','PROVIDER_REQUEST_ZH.md',
      'PROVIDER_REQUEST_EN.md','PROVIDER_METADATA_TEMPLATE.csv','literature']:
        add_path(root,code,f'reports/{VERSION}/{name}')
    # Source caches here are old, immutable software dependencies, not E fits.
    if any(n.startswith(f'runs/{D_VERSION}/full') for n in code):raise AssertionError('Do not repackage big D full forecasts')
    if not any(VERSION in n for n in code) or not any(VERSION in n for n in diagnostics):
        raise AssertionError('New E payload absent')
    return [('Quick_Review',quick),('Code_and_Reproduce',code),('Diagnostics',diagnostics)]


def reissue_c2_original_parts(root,output):
    old=root/'delivery/20261012_stage3c2'
    receipt=json.loads((old/'PACKAGE_CHECKS.json').read_text())
    entries=[]
    for number in [1,2]:
        original=f'Wastewater_Stage3C2_Predictions_and_Diagnostics_20261012_Part{number:02d}.zip'
        record=next(x for x in receipt['packages'] if x['file']==original)
        source=old/original
        if source.stat().st_size!=record['bytes'] or sha(source)!=record['sha256']:
            raise ValueError('Original C2 archive absent/changed: '+original)
        name=f'Wessex_Stage3C2_Original_Predictions_and_Diagnostics_Part{number:02d}_Reissued_{DAY}.zip'
        target=output/name
        if target.exists():raise FileExistsError(target)
        shutil.copyfile(source,target)
        if sha(target)!=record['sha256'] or target.stat().st_size>=LIMIT:raise ValueError('C2 original copy differs')
        members=[]
        with zipfile.ZipFile(target) as z:
            if z.testzip() or len(z.namelist())!=len(set(z.namelist())):raise ValueError('Original C2 CRC/duplicate error')
            for info in z.infolist():
                if not info.is_dir():members.append(dict(path=info.filename,bytes=info.file_size,sha256=hashlib.sha256(z.read(info.filename)).hexdigest()))
        sums=''.join(x['sha256']+'  '+x['path']+'\n' for x in members)
        (output/(name+'.members.SHA256SUMS')).write_text(sums)
        entries.append(dict(stage='Stage3C2 ORIGINAL',original_file=original,file=name,bytes=target.stat().st_size,
           MiB=target.stat().st_size/1024**2,sha256=sha(target),members=members,
           copied_original_bytes=True,predictions_regenerated=False,not_a_stage3e_result=True))
    save_json(output/'C2_ORIGINAL_PART01_PART02.json',dict(status='PASSED',files=entries))
    return entries


def run_clean_checks(root,packages,python,output):
    logs=output/'clean_replay_logs';calls=[]
    code=[p['path'] for p in packages if p['category']=='Code_and_Reproduce']
    with tempfile.TemporaryDirectory(prefix='stage3e_clean_code_',dir='/tmp') as folder:
        clean=Path(folder); extracted=helper.safe_extract(code,clean)
        if (clean/f'runs/{VERSION}').exists():raise AssertionError('Code replay must start with no E runtime cache')
        calls.append(helper.run_checked(python,['-m','unittest','discover','-s','tests','-p','test_stage3e*.py','-v'],clean,logs,'new_E_software_tests'))
        calls.append(helper.run_checked(python,['-m','wastewater.stage3e_runtime','--mode','smoke'],clean,logs,'cold_twelve_frozen_D_interval_software_reconstructions'))
        calls.append(helper.run_checked(python,['scripts/check_stage3e_runtime.py','--scope','smoke'],clean,logs,'frozen_scientific_files_and_atomic_recovery_checks'))
        calls.append(helper.run_checked(python,['-m','wastewater.stage3e_runtime','--mode','resume'],clean,logs,'repeated_verified_twelve_cache_resume'))
        runtime=json.loads((clean/f'runs/{VERSION}/runtime/smoke/manifest.json').read_text())
        if runtime.get('status')!='COMPLETED':raise AssertionError('Clean E disk completion failed')
    with tempfile.TemporaryDirectory(prefix='stage3e_clean_merged_',dir='/tmp') as folder:
        clean=Path(folder);merged=helper.safe_extract([p['path'] for p in packages],clean)
        # No new model calculation: verify all archived CSV member hashes and new
        # critical delivery identity. Full diagnostics require linked D losses.
        expected=[]
        for item in packages:
            for name,digest in item['members'].items():
                p=clean/name
                if not p.is_file() or sha(p)!=digest:raise AssertionError('Extracted E member mismatch: '+name)
                expected.append(name)
        keys=[f'reports/{VERSION}/{x}' for x in ['ANALYSIS_ZH.md','RUN_STATUS.json','NEXT_STAGE_DECISION.md','CLAIM_EVIDENCE_MATRIX.csv']]
        if any(not (clean/p).is_file() for p in keys):raise AssertionError('New E critical files absent')
    return dict(status='PASSED',code_only_extraction=extracted,merged_extraction=merged,
       cold_interval_calibration_reconstructions=12,new_predictive_models_trained=0,
       original_D_source_banks_loaded_read_only=True,full_D_300_cold_rerun=False,
       full_diagnostic_replay='Separate original D large prediction/loss inputs are SHA-linked; not bundled or replayed here',
       all_new_archive_members_verified_after_extraction=True,commands=calls,
       tolerance_not_bitwise_claim=True)


def build(output,python,skip_replay=False):
    started=time.perf_counter();root=ROOT;output=Path(output).resolve()
    if output.exists() and any(output.iterdir()):raise FileExistsError('Use a new empty delivery directory')
    output.mkdir(parents=True,exist_ok=True)
    status=json.loads((root/f'reports/{VERSION}/RUN_STATUS.json').read_text())
    if status.get('status')!='COMPLETED':raise ValueError('Stage3E is not complete')
    packages=[]
    for category,payload in collect(root):packages.extend(make_packages(output,category,payload))
    old_d_hashes={sha(p) for p in (root/'delivery/20261012_stage3d').glob('Wessex_Stage3D_*.zip')}
    for package in packages:
        if package['sha256'] in old_d_hashes:raise AssertionError('Stage3E container equals old D archive')
        if 'Stage3E' not in Path(package['path']).name:raise AssertionError('New E archive naming failure')
    originals=reissue_c2_original_parts(root,output)
    replay=run_clean_checks(root,packages,python,output) if not skip_replay else dict(status='NOT_EXECUTED')
    code_version=json.loads((root/f'reports/{VERSION}/CODE_VERSION.json').read_text())
    config=root/f'configs/{VERSION}/full.json'
    index=dict(stage='Stage3E',version=VERSION,generated_utc=datetime.now(timezone.utc).isoformat(),
       client_timezone='Asia/Shanghai',client_date='2026-10-13',actual_completion_status=status['status'],
       code_version=code_version,config_path=str(config.relative_to(root)),config_sha256=sha(config),
       result_directory=f'reports/{VERSION}',run_directory=f'runs/{VERSION}',
       old_D_prediction_container_reused_as_new_E=False,original_D_scientific_results_unchanged=True,
       packages=[dict(file=Path(p['path']).name,stage='Stage3E',category=p['category'],part=p['part'],
          bytes=p['bytes'],MiB=p['MiB'],sha256=p['sha256'],members=p['members'],actual_status='COMPLETED') for p in packages],
       original_C2_parts=originals,
       separate_large_D_dependency='See reports/'+VERSION+'/REPRODUCE.md; original files verified, never regenerated')
    save_json(output/'ARTIFACT_INDEX.json',index)
    save_json(output/'PACKAGE_CHECKS.json',dict(status='PASSED' if replay['status']=='PASSED' else 'ARCHIVES_CHECKED_REPLAY_NOT_EXECUTED',
       stage='Stage3E',version=VERSION,created_utc=datetime.now(timezone.utc).isoformat(),
       packages=index['packages'],original_C2_parts=originals,clean_replay=replay,
       all_new_packages_different_from_all_original_D_archives=True,
       actual_new_E_files_present=True,all_archives_under_24MiB=True,
       all_CRC_and_member_SHA256_passed=True,total_seconds=time.perf_counter()-started))
    for name in ['ANALYSIS_ZH.md','DELTA_FROM_STAGE3D.md','NEXT_STAGE_DECISION.md','REPRODUCE.md','RUN_STATUS.json','CODE_VERSION.json','CLAIM_EVIDENCE_MATRIX.csv']:
        shutil.copyfile(root/f'reports/{VERSION}/{name}',output/name)
    shutil.copyfile(root/'STAGE3E_PROTOCOL.md',output/'STAGE3E_PROTOCOL.md')
    lines=['# Wessex Stage3E — 2026-10-13', '',
      '**本目录是新增 Stage3E 可靠性与证据审查，不是旧 Stage3D ZIP 改名。**', '',
      '版本：`'+VERSION+'`。所有新包通过 CRC、成员 SHA 和干净目录软件复现；',
      '旧 D 科学结果、源池、gamma 与原始区间不变。完整大 D 预测只按原 SHA 关联，不重复打包。', '',
      '[中文分析](ANALYSIS_ZH.md) · [唯一下一行动](NEXT_STAGE_DECISION.md) · '
      '[相对 D 的变化](DELTA_FROM_STAGE3D.md) · [复现命令](REPRODUCE.md)', '',
      '| 新 Stage3E 包 | MiB |', '|---|---:|']
    for item in packages:
        name=Path(item['path']).name
        lines.append('| ['+name+']('+name+'?raw=true) | '+format(item['MiB'],'.2f')+' |')
    lines += ['', '将所有新 E 包解压到同一新目录。Code 包可独立执行有限软件修复检查；',
      '完整新诊断重算另需原 D 逐条输入，路径和 SHA 见 INPUT_MANIFEST 与 REPRODUCE。', '',
      '**另附旧 C2 原件，以下两包不是新 E 结果：**', '']
    for item in originals:
        lines.append('- ['+item['file']+']('+item['file']+'?raw=true) — 原字节、'+format(item['MiB'],'.2f')+' MiB')
    lines += ['', '[ARTIFACT_INDEX.json](ARTIFACT_INDEX.json) 保存阶段/配置/代码/每包及成员 SHA；',
      '[PACKAGE_CHECKS.json](PACKAGE_CHECKS.json) 保存实际复现范围；',
      '[SHA256SUMS](SHA256SUMS) 包含其余交付文件的校验值。', '',
      '自然九 RUNNING 异常未复现、根因未知；受控故障防护不冒充自然复现。',
      '结论仍为未证明稳定共享获益；物理设施独立性和实时时点未知。',
      '本轮完成后停止，唯一下一行动为 NEEDS_DATA，未自动开最终测试或新训练。', '']
    (output/'README.md').write_text('\n'.join(lines))
    # Self-reference is excluded: SHA256SUMS hashes all other delivery files,
    # while ARTIFACT_INDEX references zip containers and their payload members.
    members=[]
    for p in sorted(output.rglob('*')):
        if p.is_file() and p.name!='SHA256SUMS':members.append((p.relative_to(output).as_posix(),sha(p)))
    (output/'SHA256SUMS').write_text(''.join(d+'  '+n+'\n' for n,d in members))
    print(json.dumps(dict(status='PASSED' if replay['status']=='PASSED' else 'PARTIAL',output=str(output),
       new_E_packages=[dict(file=Path(p['path']).name,MiB=p['MiB'],sha256=p['sha256']) for p in packages],
       original_C2_parts=[dict(file=p['file'],sha256=p['sha256']) for p in originals],seconds=time.perf_counter()-started),indent=2),flush=True)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',default='delivery/20261013_stage3e')
    ap.add_argument('--python',default=sys.executable)
    ap.add_argument('--skip-replay',action='store_true')
    ap.add_argument('--extract',nargs='+')
    ap.add_argument('--destination')
    a=ap.parse_args()
    if a.extract:
        if not a.destination:ap.error('--destination required for extraction')
        print(json.dumps(helper.safe_extract(a.extract,a.destination),indent=2));return
    build(a.output,a.python,a.skip_replay)

if __name__=='__main__':main()
