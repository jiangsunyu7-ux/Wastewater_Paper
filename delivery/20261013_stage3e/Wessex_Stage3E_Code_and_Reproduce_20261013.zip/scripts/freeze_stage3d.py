"""Freeze the post-C2 development protocol before any Stage3D target scores."""
from pathlib import Path
import json
from wastewater.common import sha256,utc_now,write_json

ROOT=Path(__file__).resolve().parents[1]
VERSION='stage3d_interval_v1'

names=['STAGE3D_PROTOCOL.md',f'configs/{VERSION}/full.json',
    'data/provenance/stage3c2_source_scale_v1/source_pool_definition.json',
    'data/provenance/stage3c2_source_scale_v1/association_edges.csv',
    'data/provenance/stage3c2_source_scale_v1/partition_group_ledger.csv',
    'data/provenance/stage3c2_source_scale_v1/temporary_and_registered_protection.csv',
    'data/derived/stage3c2_source_scale_v1/daily_candidates.csv']
names += [str(p.relative_to(ROOT)) for p in sorted((ROOT/f'data/derived/{VERSION}').glob('*')) if p.is_file()]
names += ['src/wastewater/'+n for n in ['common.py','shared_data.py','stage3c2_evaluation.py',
          'stage3d_intervals.py','stage3d_experiment.py','stage3d_evaluation.py']]
names += ['scripts/'+n for n in ['prepare_stage3d.py','freeze_stage3d.py','check_stage3d_smoke.py','summarize_stage3d.py']]
names += [str(p.relative_to(ROOT)) for p in sorted((ROOT/'tests').glob('test_stage3d*.py'))]
freeze=ROOT/f'configs/{VERSION}/FREEZE.json'
if freeze.exists():raise ValueError('Freeze already exists: use a new version for scientific changes')
if list((ROOT/f'runs/{VERSION}').glob('*/jobs/*/intervals.csv')):
    raise ValueError('Cannot claim a before-target-results freeze after interval rows exist')
value=dict(status='FROZEN_POST_C2_DEVELOPMENT_PROTOCOL_BEFORE_STAGE3D_TARGET_INTERVALS',
    created_utc=utc_now(),files_sha256={name:sha256(ROOT/name) for name in names},
    expected_conditions=300,expected_interval_rows=324000,source_pools=3,source_gamma_choices=18,
    source_validation_folds=1080,primary_comparisons=2,physical_mapping_verified=False,
    independent_preregistration=False,stage3c2_results_already_observed=True,
    all_windows_used_development=True,no_final_period_performance=True)
write_json(freeze,value)
print(json.dumps(dict(status=value['status'],frozen_files=len(names),freeze_sha256=sha256(freeze))))
