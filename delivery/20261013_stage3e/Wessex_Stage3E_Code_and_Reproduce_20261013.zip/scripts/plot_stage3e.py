#!/usr/bin/env python3
"""Plot saved Stage3D evidence and Stage3E post hoc diagnostics, without fitting.

All original SiteIDs, source compositions, budgets and deployment windows are
retained in the plotting tables. Displayed B30/main-order subsets are fixed by
the Stage3E review protocol, rather than selected by performance. No 2024--2025
record, model fit, recalibration or new source selection enters this script.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import xml.etree.ElementTree as ET

os.environ.setdefault("MPLCONFIGDIR", "/tmp/wastewater-stage3e-matplotlib")
os.environ.setdefault("XDG_CACHE_HOME", "/tmp/wastewater-stage3e-fontconfig")
Path(os.environ["XDG_CACHE_HOME"]).mkdir(parents=True, exist_ok=True)
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
VERSION = "stage3e_evidence_review_v1"
SITES = ["13013", "13015", "13016", "13017", "13022", "13024", "13025", "13028", "13029", "13031"]
WINDOWS = ["2022-01-01", "2022-07-01", "2023-01-01", "2023-07-01", "2023-10-01"]
POOLS = [f"order{x}_K30" for x in (20261012, 20261013, 20261014)]
METHODS = ["LOCAL", "SHARED", "MIXTURE"]
COLORS = {"LOCAL": "#666666", "SHARED": "#009E73", "MIXTURE": "#0072B2"}
POOL_COLORS = {p: c for p, c in zip(POOLS, ("#0072B2", "#D55E00", "#009E73"))}
NOTE = "Post hoc diagnostics of reused development history; SiteID grouping and real-time availability unverified."


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1048576), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, dtype={"site_id": str, "pool_id": str, "order_label": str}, low_memory=False)


def select(frame, **conditions):
    selected = frame
    for column, value in conditions.items():
        if isinstance(value, float):
            selected = selected[np.isclose(selected[column].astype(float), value, rtol=0, atol=1e-12)]
        else:
            selected = selected[selected[column].eq(value)]
    return selected


def single(frame, **conditions):
    selected = select(frame, **conditions)
    if len(selected) != 1:
        raise ValueError(f"Expected one saved row for {conditions}, found {len(selected)}")
    return selected.iloc[0]


def style(ax, zero=False):
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color="#DDDDDD", linewidth=.5, zorder=0)
    if zero:
        ax.axhline(0, color="#777777", linewidth=.8, zorder=1)


def save(fig, output, name):
    for suffix in ("pdf", "svg", "png"):
        fig.savefig(output / f"{name}.{suffix}", bbox_inches="tight", dpi=170)
    plt.close(fig)


def save_data(frame, output, name):
    frame.to_csv(output / f"{name}_plotting.csv", index=False)


def primary_and_composition(ci, summary, gamma, output):
    """Reproduce the two original primary estimates; never reselect a pool."""
    data = select(ci, constraint="raw", subset="all_dates", block_days=14,
                  method="MIXTURE", budget=30, reference_method="LOCAL",
                  reference_budget=30, nominal_coverage=.9).copy()
    if len(data) != 6 or set(data.pool_id) != set(POOLS):
        raise ValueError("All three source compositions and both horizons are required")
    if not data.finite_replicates.eq(5000).all():
        raise ValueError("Incomplete paired resampling cannot be plotted as completed")
    data = data.merge(gamma, on=["pool_id", "budget", "horizon"], how="left", validate="one_to_one")
    save_data(data, output, "primary_and_composition")
    save_data(gamma, output, "all_source_gamma")
    save_data(summary, output, "all_score_coverage_width")
    fig, axes = plt.subplots(1, 2, figsize=(11.8, 4.5), sharex=False)
    for ax, horizon in zip(axes, (1, 3)):
        q = data[data.horizon.eq(horizon)].set_index("pool_id").loc[POOLS]
        for index, (pool, row) in enumerate(q.iterrows()):
            main = pool == POOLS[0]
            ax.hlines(index, row.lower_ci * 100, row.upper_ci * 100,
                      color=POOL_COLORS[pool], lw=2 if main else 1.5)
            ax.scatter(row.mean_station_skill * 100, index, color=POOL_COLORS[pool], s=40, zorder=3)
        ax.set_yticks(np.arange(3), [f"{p[5:13]} ({'main' if p == POOLS[0] else 'sensitivity'}), γ={q.loc[p, 'gamma']:g}"
                                     for p in POOLS])
        ax.invert_yaxis(); ax.axvline(0, color="#777777", lw=.9)
        ax.grid(axis="x", color="#DDDDDD", lw=.5); ax.spines[["top", "right"]].set_visible(False)
        ax.set_title(f"h={horizon}: B30, 90% raw intervals")
        ax.set_xlabel("Equal-SiteID interval-score skill vs LOCAL (%)")
    fig.suptitle("Original primary evidence and all fixed source compositions", y=.97)
    fig.text(.5, .071, "Main: Bonferroni-adjusted 97.5% CI; sensitivities: exploratory 95% CI. 5000 paired 14-day-block/SiteID resamples.",
             ha="center", fontsize=8)
    fig.text(.5, .026, NOTE, ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .15, 1, .9))
    save(fig, output, "primary_and_composition")


def site_scale_contributions(metrics, output):
    """Display all ten official evaluation sites, including adverse influence."""
    all_data = select(metrics, constraint="raw", method="MIXTURE", nominal_coverage=.9).copy()
    all_data["raw_score_change_m3"] = all_data.interval_score_m3 - all_data.local_interval_score_m3
    all_data["contribution_to_mean_change_m3"] = all_data.raw_score_change_m3 / len(SITES)
    leave_rows = []
    for key, group in all_data.groupby(["pool_id", "budget", "horizon"], sort=True):
        if len(group) != 10 or set(group.site_id) != set(SITES):
            raise ValueError("All SiteIDs must remain in the official metric table")
        for site in SITES:
            remainder = group[group.site_id.ne(site)]
            leave_rows.append(dict(pool_id=key[0], budget=key[1], horizon=key[2], omitted_site_id=site,
                                   sensitivity_only=True, remaining_sites=9,
                                   mean_relative_skill=remainder.skill_vs_local.mean(),
                                   equal_siteid_raw_score_change_m3=remainder.raw_score_change_m3.mean()))
    leave = pd.DataFrame(leave_rows)
    save_data(all_data, output, "site_scale_contributions")
    save_data(leave, output, "leave_one_out_influence")
    main = select(all_data, pool_id=POOLS[0], budget=30, horizon=3).set_index("site_id").loc[SITES]
    influence = select(leave, pool_id=POOLS[0], budget=30, horizon=3).set_index("omitted_site_id").loc[SITES]
    fig, axes = plt.subplots(1, 3, figsize=(13.8, 5.8), sharey=True)
    y = np.arange(10)
    axes[0].barh(y, main.skill_vs_local.to_numpy(float) * 100,
                 color=["#0072B2" if x >= 0 else "#D55E00" for x in main.skill_vs_local], zorder=3)
    axes[0].set_xlabel("Per-SiteID score skill (%)")
    axes[1].barh(y, main.contribution_to_mean_change_m3,
                 color=["#D55E00" if x > 0 else "#0072B2" for x in main.raw_score_change_m3], zorder=3)
    axes[1].set_xlabel("Contribution to raw-unit mean\nscore change (MIXTURE − LOCAL, m³)")
    axes[2].scatter(influence.equal_siteid_raw_score_change_m3, y, color="#666666", s=32, zorder=3)
    original_change = main.raw_score_change_m3.mean()
    axes[2].axvline(original_change, color="#0072B2", ls="--", lw=1, label="All ten SiteIDs retained")
    axes[2].set_xlabel("Raw-unit mean change after omitting\nlabelled SiteID (m³; sensitivity only)")
    for ax in axes:
        ax.axvline(0, color="#777777", lw=.8); ax.grid(axis="x", color="#DDDDDD", lw=.5)
        ax.spines[["top", "right"]].set_visible(False)
        ax.set_yticks(y, SITES)
    axes[0].invert_yaxis(); axes[0].set_ylabel("Development SiteID")
    axes[2].legend(loc="best", fontsize=8, frameon=False)
    fig.suptitle("Relative gains and raw-volume penalties answer different questions: B30, h=3", y=.98)
    fig.text(.5, .055, "Order 20261012; 90% raw bounds. Positive raw-unit change means deterioration. Leave-one-out does not alter official evaluation.",
             ha="center", fontsize=8)
    fig.text(.5, .016, NOTE, ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .12, 1, .92))
    save(fig, output, "site_scale_contributions")


def window_heterogeneity(metrics, output):
    data = select(metrics, constraint="raw", method="MIXTURE", nominal_coverage=.9).copy()
    save_data(data, output, "window_heterogeneity")
    displayed = select(data, pool_id=POOLS[0], budget=30)
    fig, axes = plt.subplots(1, 2, figsize=(12.8, 5.1), sharey=True)
    all_values = displayed.skill_vs_local.to_numpy(float) * 100
    max_value = float(np.nanmax(np.abs(all_values)))
    max_value = max(max_value, .01)
    normalizer = TwoSlopeNorm(vmin=-max_value, vcenter=0, vmax=max_value)
    for ax, horizon in zip(axes, (1, 3)):
        q = displayed[displayed.horizon.eq(horizon)]
        pivot = q.pivot(index="episode", columns="site_id", values="skill_vs_local").reindex(index=WINDOWS, columns=SITES) * 100
        if pivot.isna().any().any():
            raise ValueError("Window heatmap must retain all five windows and ten SiteIDs")
        # Native rectangle mesh avoids embedding a bitmap in SVG/PDF exports.
        mesh = ax.pcolormesh(np.arange(11), np.arange(6), pivot.to_numpy(float), norm=normalizer,
                             cmap="RdBu", shading="flat", edgecolors="white", linewidth=.6, rasterized=False)
        ax.set_xticks(np.arange(10)+.5, SITES, rotation=55, ha="right")
        ax.set_yticks(np.arange(5)+.5, WINDOWS); ax.set_ylim(5, 0)
        ax.set_xlabel("Development SiteID"); ax.set_title(f"h={horizon}; main order, B30, 90% raw")
    axes[0].set_ylabel("First deployment origin")
    fig.subplots_adjust(left=.12, right=.84, bottom=.24, top=.84, wspace=.15)
    colorbar_axis = fig.add_axes((.89, .29, .018, .52))
    cb = fig.colorbar(mesh, cax=colorbar_axis)
    cb.solids.set_rasterized(False)
    cb.set_label("Per-SiteID / window score skill vs LOCAL (%)")
    fig.suptitle("All fixed sites and windows: gains are not uniform", y=.99)
    fig.text(.5, .025, NOTE, ha="center", fontsize=8)
    save(fig, output, "window_heterogeneity")


def validate_exports(output):
    svg_records = []
    for path in sorted(output.glob("*.svg")):
        root = ET.parse(path).getroot()
        images = sum(e.tag.rsplit("}", 1)[-1] == "image" for e in root.iter())
        texts = sum(e.tag.rsplit("}", 1)[-1] == "text" for e in root.iter())
        if images or not texts:
            raise ValueError(f"Vector figure {path.name} has embedded raster images or no editable text")
        svg_records.append(dict(file=path.name, raster_images=images, editable_text_nodes=texts))
    return svg_records


def error_distribution_comparison(distributions, distances, output):
    save_data(distributions, output, "error_distribution_comparison")
    save_data(distances, output, "weighted_KS_descriptive")
    selected = select(distributions, budget=30)
    selected = selected[selected.pool_id.isin([POOLS[0], "local_only"])]
    phases = ["local_initial_calibration", "source_equal_site_errors_in_target_scale", "deployment_posthoc"]
    phase_labels = {phases[0]: "Initial local calibration", phases[1]: "Source (equal-SiteID weights)",
                    phases[2]: "Deployment (post hoc only)"}
    phase_colors = {phases[0]: "#666666", phases[1]: "#009E73", phases[2]: "#D55E00"}
    averages = selected.groupby(["phase", "site_id", "horizon"])[["abs_q50_normalized", "abs_q90_normalized"]].mean().reset_index()
    ks = select(distances, pool_id=POOLS[0], budget=30)
    ks_averages = ks.groupby(["comparison", "site_id", "horizon"]).weighted_KS.mean().reset_index()
    pair_labels = {"source_vs_initial": "Source vs initial", "source_vs_deployment": "Source vs deployment",
                   "initial_vs_deployment": "Initial vs deployment"}
    pair_colors = {"source_vs_initial": "#0072B2", "source_vs_deployment": "#D55E00", "initial_vs_deployment": "#666666"}
    save_data(averages, output, "error_distribution_equal_window_quantiles")
    save_data(ks_averages, output, "weighted_KS_equal_window")
    fig, axes = plt.subplots(3, 2, figsize=(12.8, 10), sharex=True)
    x = np.arange(10)
    for column, horizon in enumerate((1, 3)):
        for row, (field, quantile_label) in enumerate((("abs_q50_normalized", "50th"), ("abs_q90_normalized", "90th"))):
            ax = axes[row, column]
            for phase in phases:
                q = select(averages, phase=phase, horizon=horizon).set_index("site_id").reindex(SITES)
                if q[field].isna().any():
                    raise ValueError("Error-distribution display requires every SiteID")
                ax.plot(x, q[field], marker="o", ms=3.5, lw=1.3, color=phase_colors[phase], label=phase_labels[phase])
            ax.set_ylabel(f"Mean within-window {quantile_label}\nquantile of standardized |error|")
            style(ax); ax.set_ylim(bottom=0)
            if row == 0:
                ax.set_title(f"Main source order, B30, h={horizon}")
        ax = axes[2, column]
        for pair in pair_labels:
            q = select(ks_averages, comparison=pair, horizon=horizon).set_index("site_id").reindex(SITES)
            if q.weighted_KS.isna().any():
                raise ValueError("Weighted KS display requires every SiteID")
            ax.plot(x, q.weighted_KS, marker="s", ms=3.5, lw=1.3, color=pair_colors[pair], label=pair_labels[pair])
        ax.set_ylabel("Mean within-window weighted KS\n(descriptive distance; no p-value)")
        ax.set_ylim(0, 1); style(ax)
        ax.set_xticks(x, SITES, rotation=50, ha="right"); ax.set_xlabel("Development SiteID")
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", bbox_to_anchor=(.5, .067), ncol=3, fontsize=8, frameon=False)
    handles, labels = axes[2, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", bbox_to_anchor=(.5, .037), ncol=3, fontsize=8, frameon=False)
    fig.suptitle("Permissible calibration distributions and deployment errors need not agree", y=.987)
    fig.text(.5, .01, NOTE, ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .12, 1, .955))
    save(fig, output, "error_distribution_comparison")


def deployment_segments(summary, detail, output):
    save_data(summary, output, "deployment_segments")
    save_data(detail, output, "deployment_segments_all_site_windows")
    data = select(summary, pool_id=POOLS[0], budget=30, nominal_coverage=.9, constraint="raw")
    segments = ["01-14", "15-30", "31-60"]
    fields = [("equal_site_equal_window_coverage", "Empirical coverage (%)", 100),
              ("equal_site_equal_window_interval_score_m3", "Mean interval score (m³)", 1),
              ("equal_site_equal_window_mean_width_m3", "Mean interval width (m³)", 1)]
    fig, axes = plt.subplots(3, 2, figsize=(11.8, 9.5), sharex=True)
    for column, horizon in enumerate((1, 3)):
        for row, (field, label, multiplier) in enumerate(fields):
            ax = axes[row, column]
            for method in METHODS:
                q = select(data, method=method, horizon=horizon).set_index("segment").reindex(segments)
                if len(q) != 3 or q[field].isna().any():
                    raise ValueError("All fixed deployment segments must be present for each method")
                ax.plot(np.arange(3), q[field] * multiplier, color=COLORS[method], lw=1.4,
                        marker="o", ms=4, label=method)
            if row == 0:
                ax.axhline(90, color="#999999", lw=.8, ls="--", label="90% nominal coverage")
                ax.set_title(f"Main source order, B30, h={horizon}")
            ax.set_ylabel(label); style(ax)
            ax.set_xticks(np.arange(3), segments)
            if row == 2:
                ax.set_xlabel("Deployment day (origin offset + 1)")
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", bbox_to_anchor=(.5, .041), ncol=4, fontsize=8, frameon=False)
    fig.suptitle("Fixed deployment segments: no monotonic deterioration is assumed", y=.986)
    fig.text(.5, .011, NOTE, ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .105, 1, .954))
    save(fig, output, "deployment_segments")


def check_diagnostic_table_hashes(folder, names):
    receipt_path = folder / "DIAGNOSTIC_STATUS.json"
    receipt = json.loads(receipt_path.read_text())
    if receipt.get("status") != "COMPLETED" or not receipt.get("original_inputs_unchanged"):
        raise ValueError("Stage3E diagnostic completion evidence must be verified before plotting")
    for name in names:
        recorded = receipt.get("files_sha256", {}).get(name)
        if not recorded or sha256(folder / name) != recorded:
            raise ValueError("Stage3E saved-table SHA mismatch: " + name)
    return receipt_path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", default=f"reports/{VERSION}/results")
    parser.add_argument("--stage3d-results", default="reports/stage3d_interval_v1/results")
    parser.add_argument("--output", default=f"figures/{VERSION}")
    args = parser.parse_args()
    folder = args.root / args.results
    old = args.root / args.stage3d_results
    output = args.root / args.output
    names = ["metrics_by_station.csv", "metrics_by_station_window.csv", "summary.csv",
             "primary_comparison_recomputed.csv", "primary_site_contributions.csv",
             "leave_one_site_out_sensitivity.csv", "initial_source_deployment_error_distribution.csv",
             "distribution_weighted_KS.csv", "deployment_segment_metrics_by_site_window.csv",
             "deployment_segment_equal_site_window_summary.csv"]
    receipt_path = check_diagnostic_table_hashes(folder, names)
    old_receipt_path = old / "evaluation_validation.json"
    old_receipt = json.loads(old_receipt_path.read_text())
    paths = {name: folder / name for name in names}
    old_names = ["paired_block_intervals.csv", "gamma_distribution.csv"]
    for name in old_names:
        path = old / name
        if sha256(path) != old_receipt.get("files_sha256", {}).get(name):
            raise ValueError("Original Stage3D result SHA mismatch: " + name)
        paths["stage3d/" + name] = path
    output.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.titlesize": 10,
                         "axes.labelsize": 9, "figure.titlesize": 12, "pdf.fonttype": 42,
                         "ps.fonttype": 42, "svg.fonttype": "none"})
    metrics = read(folder / "metrics_by_station.csv")
    windows = read(folder / "metrics_by_station_window.csv")
    if set(metrics.site_id) != set(SITES) or set(windows.episode) != set(WINDOWS):
        raise ValueError("All original SiteIDs and development windows must be retained")
    if set(metrics.pool_id) != set(POOLS) or set(metrics.budget) != {30, 90, 180} or set(metrics.horizon) != {1, 3}:
        raise ValueError("Unexpected source pool, budget or forecast horizon")
    ci = read(old / "paired_block_intervals.csv")
    recheck = read(folder / "primary_comparison_recomputed.csv")
    for _, row in recheck.iterrows():
        saved = single(ci, pool_id=row.pool_id, budget=30, horizon=row.horizon, nominal_coverage=.9,
                       method="MIXTURE", reference_method="LOCAL", reference_budget=30,
                       constraint="raw", subset="all_dates", block_days=row.block_days)
        if not np.allclose([row.mean_station_skill, row.lower_ci, row.upper_ci],
                           [saved.mean_station_skill, saved.lower_ci, saved.upper_ci], atol=1e-12, rtol=1e-10):
            raise ValueError("Original primary interval comparison differs from independent Stage3E recomputation")
    primary_and_composition(ci, read(folder / "summary.csv"), read(old / "gamma_distribution.csv"), output)
    site_scale_contributions(metrics, output)
    # Plot-derived linear contributions must agree with the independent
    # diagnostic output; the leave-one-out view never changes official cohorts.
    contribution = read(output / "site_scale_contributions_plotting.csv")
    independent = read(folder / "primary_site_contributions.csv")
    merged = contribution.merge(independent[["site_id", "horizon", "equal_site_score_change_contribution_m3"]],
                                on=["site_id", "horizon"], validate="many_to_one")
    merged = select(merged, pool_id=POOLS[0], budget=30)
    if not np.allclose(merged.contribution_to_mean_change_m3,
                       merged.equal_site_score_change_contribution_m3, rtol=1e-10, atol=1e-8):
        raise ValueError("Per-SiteID raw-unit contribution differs from saved Stage3E diagnosis")
    window_heterogeneity(windows, output)
    error_distribution_comparison(read(folder / "initial_source_deployment_error_distribution.csv"),
                                  read(folder / "distribution_weighted_KS.csv"), output)
    deployment_segments(read(folder / "deployment_segment_equal_site_window_summary.csv"),
                        read(folder / "deployment_segment_metrics_by_site_window.csv"), output)
    captions = [
        ("primary_and_composition", "Does the original primary evidence show stable interval-score improvement, and does it depend on source composition?",
         "Stage3D paired_block_intervals.csv / gamma_distribution.csv; Stage3E primary_comparison_recomputed.csv",
         "Original B30/90% MIXTURE versus LOCAL evidence on matched calendars, with all three fixed K30 source compositions. Main-order lines are Bonferroni-adjusted 97.5% intervals; other orders are exploratory 95% intervals, all using 5000 synchronous within-window 14-day-calendar-block and whole-SiteID resamples. Original primary estimates were independently recomputed; gamma zero returns LOCAL and cannot establish a sharing benefit."),
        ("site_scale_contributions", "Why can mean relative skill improve while raw-unit mean interval score worsens?",
         "Stage3E metrics_by_station.csv / primary_site_contributions.csv / leave_one_site_out_sensitivity.csv",
         "All ten SiteIDs for the main-order B30, h=3, 90% raw interval comparison. Left: per-SiteID relative score skill. Middle: one tenth of the raw-unit score change for each SiteID, summing to the equal-SiteID mean score change. Right: leave-one-out raw-unit mean change, used solely as a sensitivity diagnostic. No SiteID is removed from formal evaluation. Positive raw-unit change means deterioration; relative and absolute averaging answer different questions."),
        ("window_heterogeneity", "Are apparent gains consistent across the five fixed windows and ten target SiteIDs?",
         "Stage3E metrics_by_station_window.csv",
         "Post hoc per-SiteID/window 90% interval-score skill versus LOCAL for the fixed main source order and B30. All five reused development windows and all ten original SiteIDs are shown for both horizons. The symmetric colour scale retains adverse values; complete plotting tables include all budgets and source compositions. This exploratory heterogeneity view does not authorize selecting sites or windows."),
        ("error_distribution_comparison", "How do permissible source and initial local error distributions differ from observed deployment errors?",
         "Stage3E initial_source_deployment_error_distribution.csv / distribution_weighted_KS.csv",
         "B30/main-order standardized absolute Persistence-error quantiles and the sole distribution-distance descriptor, weighted empirical KS. Quantiles and distances are calculated within each fixed deployment window and then averaged equally across five windows for display. Source errors use each source SiteID's permitted-history scale and equal total SiteID weights; local/deployment errors use the target's frozen initial-history positive-volume median. Target scale converts source quantiles to m³ in the full table. KS is descriptive, with no iid p-value or exchangeability claim. Deployment errors are post hoc and do not enter selection or calibration."),
        ("deployment_segments", "Does interval behaviour change across the fixed deployment segments?",
         "Stage3E deployment_segment_equal_site_window_summary.csv / deployment_segment_metrics_by_site_window.csv",
         "The fixed day 1–14, 15–30 and 31–60 origin segments for the main source order, B30 and 90% raw intervals. Scores, coverage and widths are first averaged within each SiteID/window/segment, then across windows equally within each SiteID and across SiteIDs equally. Complete tables retain all source pools, budgets, horizons, constraints and nominal levels. Lines only join the fixed descriptive segments; no monotonic decline or rolling recalibration is assumed.")]
    pd.DataFrame(captions, columns=["figure", "research_question", "result_source", "caption_english"]).to_csv(output / "FIGURE_SOURCES.csv", index=False)
    exports = validate_exports(output)
    plotted_files = {f.name: sha256(f) for f in sorted(output.iterdir()) if f.is_file() and f.suffix in {".pdf", ".svg", ".png", ".csv"}}
    provenance = dict(stage=VERSION, status="PLOTTED_FROM_VERIFIED_SAVED_EVIDENCE",
                      script_sha256=sha256(Path(__file__)), diagnostic_completion_sha256=sha256(receipt_path),
                      original_evaluation_completion_sha256=sha256(old_receipt_path),
                      sources_sha256={n: sha256(p) for n, p in paths.items()}, files_sha256=plotted_files,
                      posthoc_exploratory=True, new_models_trained=False, new_gamma_selected=False,
                      physical_mapping_verified=False, verified_real_time=False,
                      final_2024_2025_performance_used=False, svg_checks=exports,
                      visual_checks="Separate manual PNG inspection recorded in FIGURE_CHECK.json")
    (output / "FIGURE_PROVENANCE.json").write_text(json.dumps(provenance, indent=2)+"\n")
    print(json.dumps(dict(status="PLOTTED", figure_groups=len(captions), svg_checks=exports), indent=2))


if __name__ == "__main__":
    main()
