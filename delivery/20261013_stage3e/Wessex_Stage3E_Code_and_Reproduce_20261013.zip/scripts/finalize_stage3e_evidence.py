"""Seal completed Stage3E evidence; preserve all preexisting scientific bytes.

This completion-time seal is not preregistration. It never trains a model or
changes any old frozen receipt. Packaging/replay and Git delivery are separate.
"""
from pathlib import Path
from datetime import datetime, timezone
import csv
import difflib
import hashlib
import importlib.metadata
import json
import os
import platform
import subprocess

ROOT = Path(__file__).resolve().parents[1]
VERSION = 'stage3e_evidence_review_v1'
REPORT = ROOT/'reports'/VERSION

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda:handle.read(1024**2),b''):h.update(chunk)
    return h.hexdigest()

def read(path):return json.loads(Path(path).read_text())

def save(path,value):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def main():
    now=datetime.now(timezone.utc).isoformat()
    assert not (REPORT/'RUN_STATUS.json').exists(),'Do not overwrite an earlier completion receipt'
    before=read(REPORT/'PRESERVATION_BEFORE.json');changes=[]
    for item in before['files']:
        p=ROOT/item['path']
        if not p.is_file() or p.stat().st_size!=item['bytes'] or digest(p)!=item['sha256']:
            changes.append(item['path'])
    save(REPORT/'PRESERVATION_AFTER.json',dict(status='PASSED' if not changes else 'FAILED',
        generated_utc=now,files_checked=len(before['files']),bytes_checked=before['bytes'],
        changes=changes,all_original_scientific_bytes_unchanged=not changes,
        scope=before['scope'],before_manifest_sha256=digest(REPORT/'PRESERVATION_BEFORE.json')))
    assert not changes,changes
    diag=read(REPORT/'results/DIAGNOSTIC_STATUS.json')
    for name,h in diag['files_sha256'].items():assert digest(REPORT/'results'/name)==h,name
    runtime=read(REPORT/'runtime/RUNTIME_CHECK.json')
    independent=read(REPORT/'INDEPENDENT_EVIDENCE_CHECK.json')
    figure=read(ROOT/'figures'/VERSION/'FIGURE_CHECK.json')
    literature=read(REPORT/'literature/LITERATURE_VERIFY.json')
    assert diag['status']=='COMPLETED' and all(x['status']=='PASSED' for x in [runtime,independent,figure,literature])
    tests=(ROOT/'validation/stage3e_combined_tests.log').read_text()
    assert 'Ran 20 tests' in tests and tests.rstrip().endswith('OK')
    configD=read(ROOT/'configs/stage3d_interval_v1/full.json')
    config=dict(version=VERSION,phase='posthoc_evidence_review',protocol='STAGE3E_PROTOCOL.md',
        protocol_sha256=digest(ROOT/'STAGE3E_PROTOCOL.md'),
        diagnostics_config=f'configs/{VERSION}/diagnostics.json',
        diagnostics_config_sha256=digest(ROOT/'configs'/VERSION/'diagnostics.json'),
        immutable_science_config='configs/stage3d_interval_v1/full.json',
        immutable_science_config_sha256=digest(ROOT/'configs/stage3d_interval_v1/full.json'),
        immutable_science_freeze='configs/stage3d_interval_v1/FREEZE.json',
        immutable_science_freeze_sha256=digest(ROOT/'configs/stage3d_interval_v1/FREEZE.json'),
        immutable_gamma_freeze='reports/stage3d_interval_v1/GAMMA_FREEZE.json',
        immutable_gamma_freeze_sha256=digest(ROOT/'reports/stage3d_interval_v1/GAMMA_FREEZE.json'),
        development_ids=configD['development_ids'],evaluation_origins=configD['evaluation_origins'],
        evaluation_days=configD['evaluation_days'],budgets=configD['budgets'],horizons=configD['horizons'],
        frozen_source_pools=configD['pools'],bootstrap=configD['bootstrap'],
        runtime_scope=dict(sites=['13013','13015'],episode='2022-01-01',tasks=12,
            max_attempts_per_invocation=2,original_science_reconstruction_only=True,
            code='src/wastewater/stage3e_runtime.py'),
        fixed_segments=[[1,14],[15,30],[31,60]],
        distribution_difference='weighted_KS_descriptive_only',
        source_gamma_selection_recomputed=False,new_predictive_models_trained=0,
        source_final_label_cutoff='2021-12-31',source_selection_cutoff='2020-12-31',
        analysis_unit='station_exploratory',physical_mapping_verified=False,verified_real_time=False,
        published_QA_retrospective=True,initial_history_parameters_frozen_for_60_origins=True,
        deploy_persistence_updates_legal_observations=True,rolling_recalibration_allowed=False,
        final_2024_2025_performance_allowed=False,protected_target_performance_allowed=False,
        new_model_training_allowed=False,new_source_search_allowed=False,next_experiment_execute_allowed=False,
        posthoc_diagnostics=True,completion_seal_not_preregistration=True,
        original_unit_tolerance=dict(atol=1e-8,rtol=1e-12),bootstrap_tolerance=dict(atol=1e-10,rtol=1e-10),
        output=f'reports/{VERSION}',run_output=f'runs/{VERSION}')
    save(ROOT/'configs'/VERSION/'full.json',config)
    with (REPORT/'CODE_CHANGES.diff').open('w') as handle:
        for name in ['AGENTS.md','STATUS.md','RESEARCH_PLAN.md','EXPERIMENT_PROTOCOL.md','WORKFLOW.md']:
            old=(REPORT/'long_term_documents_before'/name).read_text().splitlines(True)
            new=(ROOT/name).read_text().splitlines(True)
            handle.writelines(difflib.unified_diff(old,new,fromfile='before/'+name,tofile='after/'+name))
        newcode=sorted(set((ROOT/'src/wastewater').glob('stage3e*.py'))|set((ROOT/'tests').glob('test_stage3e*.py'))|set((ROOT/'scripts').glob('*stage3e*.py')))
        for p in newcode:
            handle.writelines(difflib.unified_diff([],p.read_text().splitlines(True),fromfile='/dev/null',tofile=p.relative_to(ROOT).as_posix()))
    heads={name:subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
        for name,args in [('checkout_HEAD',['rev-parse','HEAD']),('checkout_branch',['branch','--show-current'])]}
    paths=sorted(set(newcode)|set((REPORT/'literature').glob('*.py'))|{ROOT/'STAGE3E_PROTOCOL.md',ROOT/'configs'/VERSION/'full.json',ROOT/'configs'/VERSION/'diagnostics.json'})
    hashes={p.relative_to(ROOT).as_posix():digest(p) for p in paths}
    save(REPORT/'CODE_VERSION.json',dict(version=VERSION,generated_utc=now,**heads,
        scientific_files_are_untracked_in_base_HEAD=True,authoritative_version='content SHA256 plus immutable D freeze',
        files_sha256=hashes,code_changes_diff_sha256=digest(REPORT/'CODE_CHANGES.diff'),
        all_old_C2_D_scientific_code_unchanged=True,
        old_D_freeze_sha256=digest(ROOT/'configs/stage3d_interval_v1/FREEZE.json'),
        delivery_commit_recorded_separately=True))
    cpu=[]
    if Path('/proc/cpuinfo').is_file():
        cpu=sorted({line.split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')})
    save(REPORT/'ENVIRONMENT.json',dict(generated_utc=now,python=platform.python_version(),executable=os.sys.executable,
        platform=platform.platform(),logical_cpus=os.cpu_count(),cpu_models=cpu,device='CPU',GPU_used=False,
        package_versions={name:importlib.metadata.version(name) for name in ['numpy','pandas','matplotlib']},
        dependencies='requirements-stage3d.txt',dependencies_sha256=digest(ROOT/'requirements-stage3d.txt'),
        threads=dict(OMP_NUM_THREADS=os.environ.get('OMP_NUM_THREADS'),OPENBLAS_NUM_THREADS=os.environ.get('OPENBLAS_NUM_THREADS'),MKL_NUM_THREADS=os.environ.get('MKL_NUM_THREADS')),
        new_dependencies_installed_for_Stage3E=False,paid_resources_used=False,
        compute_seconds=dict(existing_prediction_diagnostics=diag['elapsed_seconds'],
            small_runtime_check=runtime['elapsed_seconds'],independent_primitive_audit=independent['elapsed_seconds']),
        complete_stage_peak_memory_measurement='Not recorded; no inferred peak claim'))
    sealpaths=sorted(p for p in REPORT.rglob('*') if p.is_file() and p.name not in {'RUN_STATUS.json','EVIDENCE_SEAL.json'})
    files={p.relative_to(ROOT).as_posix():digest(p) for p in sealpaths}
    save(REPORT/'EVIDENCE_SEAL.json',dict(version=VERSION,sealed_utc=now,
        meaning='Completion-time content seal; not pre-outcome protocol registration',
        config_sha256=digest(ROOT/'configs'/VERSION/'full.json'),files_sha256=files))
    save(REPORT/'RUN_STATUS.json',dict(version=VERSION,stage='Stage3E',status='COMPLETED',
        completed_utc=now,completion_basis='Actual new code/tests, verified disk evidence, independent arithmetic/bootstrap and preserved old bytes',
        evidence_seal_sha256=digest(REPORT/'EVIDENCE_SEAL.json'),config_sha256=digest(ROOT/'configs'/VERSION/'full.json'),
        code_version_sha256=digest(REPORT/'CODE_VERSION.json'),
        original_D_disk_tasks_verified=runtime['original_full_tasks_read_only_verified'],
        runtime_smoke_expected=12,runtime_smoke_disk_verified_completed=12,
        function_return_successes=dict(first_partial_invocation=1,cold_clean_subset=11,repeat_resume=0),
        function_return_count_basis='Original runtime/smoke.log and PARTIAL_FIRST_INVOCATION.json; clean-package rerun logged separately',
        runtime_scientific_files_byte_identical=runtime['scientific_files_byte_identical'],
        controlled_fault_scenarios=runtime['controlled_fault_scenarios'],max_attempts_per_invocation=2,
        natural_external_anomaly='NOT_REPRODUCED; root cause unconfirmed',
        software_tests_passed=20,existing_daily_loss_rows_recomputed=diag['independent_score_check']['row_counts']['daily_rows'],
        original_scientific_models_retrained=0,new_predictive_models_trained=0,
        independent_primary_primitive_bootstrap_checks=6,bootstrap_replicates_per_check=5000,
        preservation_files_checked=before['files_count'],preservation_changed_files=0,
        literature_records=7,literature_evidence_levels=dict(selected_publisher_fulltext=1,publisher_deposited_abstract=3,metadata_only=3),
        reused_official_responses=20,new_official_mapping_queries=0,
        figures=5,posthoc_diagnostics=True,scientific_primary_conclusions_changed=False,
        executed=['initial old-artifact/300-disk-condition audit','12 small frozen-science runtime reconstruction conditions',
            '8 controlled recovery fault scenarios and repeated cache resume','20 meaningful software tests',
            '636444 saved daily-loss formula checks; all sites/windows/pools/budgets/constraints retained',
            '6 independent 5000-replicate primitive paired calendar-block/SiteID bootstrap checks',
            'heterogeneity/contribution/leave-one-site-out/distribution/fixed-segment/high-volume/history comparisons',
            '7-paper graded literature and reused official engineering-evidence review','5 saved-result figure groups'],
        failed_and_preserved=['first diagnostics attempt: same-budget CI selection omitted reference budget; new selector corrected, old science unchanged',
            'independent checker attempt01: new diagnostic CSV field alias wrong; corrected checker only; original failed log retained',
            'bounded controlled software fault attempts retained as fixtures, not natural root-cause proof',
            'initial finalization helper syntax error before execution; corrected helper only, failed log retained',
            '4 new literature access requests tunnel403; no repeated known failure request'],
        missing_materials=['external five (1) repeated attachments not received here',
            'Wessex_Stage3D_Reviewer_Evidence_and_Stage3E_Prompt_20261012.zip'],
        not_executed=['new model training','full 300-condition cold D recalibration','new gamma/source/window search',
            '2024-2025 or protected-target performance','provider/mentor messages','paper/App/paid compute',
            'independent physical-facility confirmation'],
        physical_mapping_verified=False,verified_real_time=False,final_2024_2025_performance_used=False,
        next_stage_decision='C: NEEDS_DATA',next_experiment_execute_allowed=False,STOP=True,
        packaging_validation='Pending separate PACKAGE_CHECKS.json; not scientific training'))
    print(json.dumps(dict(status='COMPLETED',version=VERSION,preserved_files=before['files_count'],new_models=0),indent=2))

if __name__=='__main__':main()
