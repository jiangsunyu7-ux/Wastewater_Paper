#!/usr/bin/env python3
"""Verify reliability guards in a new tree; never retrain Stage3D full tasks.

Default includes a READ-ONLY audit of the 300 saved D tasks. --scope smoke
supports the minimal reproduction bundle (12 saved D tasks and three source
caches). All deliberately damaged artifacts are controlled SOFTWARE FIXTURES,
not evidence of the external reviewer's natural nine RUNNING states.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from wastewater import stage3d_experiment as science
from wastewater.common import sha256, utc_now
from wastewater.stage3e_runtime import (VERSION, FingerprintMismatch, atomic_bytes,
    atomic_json, atomic_science_writes, collect_manifest, load_science_inputs,
    run_reliably, verify_outputs)


def compare_science(new, original):
    result={}
    for name in science.REQUIRED:
        if sha256(new/name) != sha256(original/name):
            raise AssertionError('Scientific file bytes differ: '+str(new/name))
        result[name]=sha256(new/name)
    return result


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--scope',choices=['full','smoke'],default='full')
    ap.add_argument('--output',default=f'reports/{VERSION}/runtime')
    ap.add_argument('--run-smoke',action='store_true',help='Run bounded 12-calibration wrapper and verified cached resume')
    a=ap.parse_args();started=time.perf_counter();report=ROOT/a.output;report.mkdir(parents=True,exist_ok=True)
    cfg,signature,banks,series,common,reference,quality=load_science_inputs('configs/stage3d_interval_v1/full.json')
    # Anchor source caches to the ORIGINAL pre-target gamma freeze, rather
    # than accepting a cache's self-declared fingerprint as independent proof.
    gamma_freeze=json.loads((ROOT/cfg['gamma_freeze']).read_text())
    if gamma_freeze['signature'] != signature or gamma_freeze['configuration_sha256'] != sha256(ROOT/'configs/stage3d_interval_v1/full.json'):
        raise AssertionError('Original gamma freeze signature/config mismatch')
    for name,digest in gamma_freeze['files_sha256'].items():
        if not (ROOT/name).is_file() or sha256(ROOT/name) != digest:
            raise AssertionError('Frozen original source artifact changed: '+name)
    for pool in cfg['pools']:
        bank=banks[pool['pool_id']];state=bank['status'];provenance=state['provenance']
        if state['fingerprint'] != science.hash_value(provenance) or provenance['run_signature'] != signature:
            raise AssertionError('Source-cache provenance fingerprint/signature mismatch')
        if provenance['source_ids'] != pool['site_ids'] or provenance['pool_id'] != pool['pool_id']:
            raise AssertionError('Source composition changed')
        if bank['selected_gamma'] != gamma_freeze['selected_gamma'][pool['pool_id']]:
            raise AssertionError('Frozen source gamma changed')
        if any(cfg[key] != value for key,value in provenance['rules'].items()):
            raise AssertionError('Source-cache scientific rules changed')
    runtime=ROOT/f'runs/{VERSION}/runtime/smoke'
    runtime_signature=science.hash_value(dict(version=VERSION,science_signature=signature,
        runtime_code_sha256=sha256(ROOT/'src/wastewater/stage3e_runtime.py'),max_attempts=2))
    if a.run_smoke:
        for mode in ['smoke','resume']:
            command=[sys.executable,'-m','wastewater.stage3e_runtime','--mode',mode]
            result=subprocess.run(command,cwd=ROOT,capture_output=True,text=True)
            (report/f'check_invocation_{mode}.log').write_text(result.stdout+result.stderr)
            if result.returncode:raise AssertionError(f'Runtime {mode} failed: '+result.stderr)
    tasks=science.expected_tasks(cfg,'smoke')
    immutable=[]; disk=[]
    for task in tasks:
        key=science.task_key(task);folder=runtime/'jobs'/key
        evidence=verify_outputs(folder,science.job_fingerprint(signature,task,cfg),task,cfg,True,runtime_signature)
        if not evidence['valid']:raise AssertionError('New smoke disk evidence failed: '+key)
        disk.append(evidence)
        immutable.append(dict(task=key,hashes=compare_science(folder,ROOT/'runs/stage3d_interval_v1/smoke/jobs'/key)))
    old_full=[]
    if a.scope=='full':
        for task in science.expected_tasks(cfg,'full'):
            evidence=verify_outputs(ROOT/'runs/stage3d_interval_v1/full/jobs'/science.task_key(task),
                science.job_fingerprint(signature,task,cfg),task,cfg)
            if not evidence['valid']:raise AssertionError('Original full evidence invalid: '+science.task_key(task))
            old_full.append(dict(task=science.task_key(task),**evidence))
        atomic_json(report/'ORIGINAL_STAGE3D_FULL_DISK_AUDIT.json',dict(status='PASSED',
            work='Read-only verification of previously saved outputs; zero recalculated tasks',tasks=old_full,
            original_status_files_modified=False,generated_utc=utc_now()))
    scenarios=[]
    base=ROOT/f'runs/{VERSION}/runtime/controlled_fault_trials'
    # Repeated invocation validates already produced fixtures; never silently
    # discard failure evidence by rerunning into the same scenario directory.
    batch=base/('batch_'+str(time.time_ns()));batch.mkdir(parents=True)
    first=tasks[0];second=tasks[-1]
    def trial(name,task,mutate=None,fault=None):
        output=batch/name;key=science.task_key(task);folder=output/'jobs'/key
        if mutate:
            shutil.copytree(runtime/'jobs'/key,folder)
            original_hashes={n:sha256(folder/n) for n in science.REQUIRED}
            mutate(folder)
            atomic_json(output/'SOFTWARE_FIXTURE.json',dict(purpose=name,controlled=True,
                not_external_natural_root_cause=True,initial_scientific_hashes=original_hashes))
        def execute():
            with atomic_science_writes(output,injected_status_fault=fault):
                return science.run_task(task,cfg,signature,banks,series,common,reference,quality,output)
        try:
            result=run_reliably(task,cfg,signature,runtime_signature,output,execute)
        except FingerprintMismatch as exc:
            if name!='wrong_fingerprint':raise
            result=dict(status='REJECTED_FINGERPRINT_MISMATCH',error=str(exc),disk_verified_completed=False)
        if name!='wrong_fingerprint':
            if not result['disk_verified_completed']:raise AssertionError('Controlled recovery failed: '+name)
            compare_science(folder,runtime/'jobs'/key)
            repeated=run_reliably(task,cfg,signature,runtime_signature,output,execute)
            if repeated['status']!='CACHED_VERIFIED' or repeated['function_returns']:
                raise AssertionError('Repeated resume performed calculation: '+name)
            result['repeated_resume']=repeated['status']
        atomic_json(output/'TRIAL_RESULT.json',result)
        scenarios.append(dict(scenario=name,output=str(output.relative_to(ROOT)),**result))
    def stale(folder):
        state=json.loads((folder/'status.json').read_text());state['status']='RUNNING';atomic_json(folder/'status.json',state)
    def wrong(folder):
        state=json.loads((folder/'status.json').read_text());state['fingerprint']='CONTROLLED_WRONG_FINGERPRINT';atomic_json(folder/'status.json',state)
    trial('stale_RUNNING',first,stale)
    trial('missing_output',second,lambda folder:(folder/'calibration.csv').unlink())
    trial('corrupt_cache',first,lambda folder:(folder/'intervals.csv').write_bytes(b'CONTROLLED_CORRUPT_BYTES\n'))
    trial('wrong_fingerprint',second,wrong)
    fault_calls=[0]
    def interrupted(path,state):
        fault_calls[0]+=1
        if fault_calls[0]==1:raise OSError('CONTROLLED_FINAL_STATUS_COMMIT_INTERRUPTION; not natural anomaly diagnosis')
    trial('interrupted_status_commit',second,fault=interrupted)
    for phase in ['before_replace','after_replace']:
        output=batch/phase;path=output/'atomic_file.bin';atomic_bytes(path,b'prior committed bytes\n')
        def injected(current,p,phase=phase):
            if current==phase:raise OSError('CONTROLLED_ATOMIC_WRITE_INTERRUPTION '+phase)
        caught=False
        try:atomic_bytes(path,b'new bytes\n',injected)
        except OSError:caught=True
        if not caught:raise AssertionError('Fault did not interrupt atomic writer')
        expected=b'prior committed bytes\n' if phase=='before_replace' else b'new bytes\n'
        if path.read_bytes()!=expected:raise AssertionError('Atomic file outcome wrong')
        result=dict(scenario=phase,output=str(output.relative_to(ROOT)),controlled=True,
            call_returned_success=False,actual_file_sha256=sha256(path),exact_expected_bytes=True)
        atomic_json(output/'TRIAL_RESULT.json',result);scenarios.append(result)
    # Software success returns cannot counterfeit evidence completeness.
    output=batch/'successful_return_missing_evidence'
    result=run_reliably(first,cfg,signature,runtime_signature,output,
        lambda:dict(status='COMPLETED',task=science.task_key(first)))
    if result['function_return_success_count']!=2 or result['disk_verified_completed']:
        raise AssertionError('Function-success/disk-evidence separation failed')
    atomic_json(output/'TRIAL_RESULT.json',result)
    scenarios.append(dict(scenario='successful_return_missing_evidence',output=str(output.relative_to(ROOT)),**result))
    partial=collect_manifest(tasks,cfg,signature,runtime_signature,output,[result])
    if partial['status']!='PARTIAL':raise AssertionError('Incomplete outputs falsely completed')
    atomic_json(output/'manifest.json',partial)
    # The original natural review anomaly is not reproduced by these injected
    # software faults. Preserve that distinction in every summary.
    summary=dict(version=VERSION,status='PASSED',generated_utc=utc_now(),scope=a.scope,
        elapsed_seconds=time.perf_counter()-started,original_full_tasks_read_only_verified=len(old_full),
        smoke_tasks_reconstructed_or_cached=12,scientific_files_byte_identical=36,
        smoke_prediction_rows=12*1080,original_frozen_scientific_code_unmodified=True,
        original_natural_anomaly='NOT_REPRODUCED; root cause unconfirmed',
        controlled_fault_scenarios=len(scenarios),max_attempts=2,
        scientific_replay_kind='Historical interval-calibration reconstruction, not new model training',
        source_gamma_selection_recomputed=False,source_banks_only_read_verified_cache=True,
        original_gamma_freeze_sha256=sha256(ROOT/cfg['gamma_freeze']),
        source_cache_artifact_hashes_verified=len(gamma_freeze['files_sha256']),
        scientific_equality=immutable,controlled_scenarios=scenarios,
        code_sha256={name:sha256(ROOT/name) for name in ['src/wastewater/stage3e_runtime.py','tests/test_stage3e_runtime.py','scripts/check_stage3e_runtime.py']})
    atomic_json(report/'RUNTIME_CHECK.json',summary)
    print(json.dumps({k:v for k,v in summary.items() if k not in ['scientific_equality','controlled_scenarios']},indent=2))


if __name__=='__main__':main()
