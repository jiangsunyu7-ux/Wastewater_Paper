"""Package verified Stage3D empirical-interval evidence and replay in clean roots.

Original C2 packages are copied byte-for-byte under unique reissue names.
No old forecasts are regenerated. Cold interval-source/smoke computation
and cached full-result re-evaluation are recorded as separate scopes.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
VERSION = "stage3d_interval_v1"
C2_VERSION = "stage3c2_source_scale_v1"
DAY = "20261012"
LIMIT = 24 * 1024**2
SKIP = {"__pycache__", ".git", ".cache", ".ipynb_checkpoints"}
RAW = "wastewater_data/raw/wessex_all_2016_2025.csv"
RAW_SHA = "22f494e2b96fe6fa9550c68971d50c752ddd291793fdc60334d64b2ef089f518"

def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024**2), b""):
            h.update(block)
    return h.hexdigest()


def save_json(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False)+"\n")


def add_path(root, payload, name, required=True):
    path = root/name
    if not path.exists():
        if required:
            raise FileNotFoundError(path)
        return
    for p in ([path] if path.is_file() else sorted(path.rglob("*"))):
        relative = p.relative_to(root)
        if not p.is_file() or any(part in SKIP for part in relative.parts) or p.suffix in {".pyc", ".pyo"}:
            continue
        if p.is_symlink() or not p.resolve().is_relative_to(root):
            raise ValueError("Unsafe payload source: "+str(p))
        key = relative.as_posix()
        if key in payload and sha(payload[key]) != sha(p):
            raise ValueError("Conflicting payload source: "+key)
        payload[key] = p


def write_archive(path, payload, category, part):
    token = category+(f"_Part{part:02d}" if part else "")
    records = [dict(path=name, bytes=p.stat().st_size, sha256=sha(p)) for name, p in sorted(payload.items())]
    start = start_text(category)
    members = {r["path"]: r["sha256"] for r in records}
    members[f"START_HERE_{token}.md"] = hashlib.sha256(start).hexdigest()
    manifest = dict(version=VERSION, category=category, part=part,
                    created_utc=datetime.now(timezone.utc).isoformat(), files=records,
                    excluded_original_raw=dict(path=RAW, sha256=RAW_SHA,
                        retrieval="User Wastewater_Part1_Plan_and_Raw.zip or existing original checkout"),
                    eligibility_full_rebuild_external=True,
                    physical_mapping_verified=False, all_windows_used_development=True)
    manifest_name = f"PACKAGE_{token}_MANIFEST.json"
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2)+"\n").encode()
    members[manifest_name] = hashlib.sha256(manifest_bytes).hexdigest()
    sums = "".join(f"{digest}  {name}\n" for name, digest in sorted(members.items())).encode()
    sums_name = f"PACKAGE_{token}_SHA256SUMS"
    members[sums_name] = hashlib.sha256(sums).hexdigest()
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, p in sorted(payload.items()):
            z.write(p, name)
        z.writestr(f"START_HERE_{token}.md", start)
        z.writestr(manifest_name, manifest_bytes)
        z.writestr(sums_name, sums)
    with zipfile.ZipFile(path) as z:
        bad = z.testzip()
        if bad:
            raise ValueError("ZIP CRC failure: "+bad)
        if set(z.namelist()) != set(members) or len(z.namelist()) != len(members):
            raise ValueError("ZIP duplicate/missing members")
        for name, digest in members.items():
            if hashlib.sha256(z.read(name)).hexdigest() != digest:
                raise ValueError("ZIP member SHA mismatch: "+name)
    return dict(path=str(path), category=category, part=part, bytes=path.stat().st_size,
                MiB=path.stat().st_size/1024**2, sha256=sha(path), members=members,
                CRC_and_all_member_SHA256_passed=True)


def make_packages(output, category, payload):
    base = f"Wessex_Stage3D_{category}_{DAY}"
    first = output/(base+".zip")
    if first.exists() or list(output.glob(base+"_Part*.zip")):
        raise FileExistsError("Delivery already exists; use a NEW output/version")
    print(f"packaging {category}: {len(payload)} files", flush=True)
    candidate = write_archive(first, payload, category, None)
    if candidate["bytes"] < LIMIT:
        return [candidate]
    first.unlink()
    # Split according to actual per-file deflated sizes, then check real archives.
    weights = []
    with tempfile.NamedTemporaryFile(suffix=".zip", dir=output) as scratch:
        with zipfile.ZipFile(scratch.name, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            for name, p in sorted(payload.items()):
                z.write(p, name)
                weights.append((name, z.getinfo(name).compress_size+len(name)*2+200))
    limit = 22*1024**2; chunks = []; chunk = {}; size = 0
    for name, weight in weights:
        if weight > limit:
            raise ValueError("Single file too large for a safe independent ZIP: "+name)
        if chunk and size+weight > limit:
            chunks.append(chunk); chunk = {}; size = 0
        chunk[name] = payload[name]; size += weight
    if chunk:
        chunks.append(chunk)
    result = []
    for i, part in enumerate(chunks, 1):
        item = write_archive(output/(base+f"_Part{i:02d}.zip"), part, category, i)
        if item["bytes"] >= LIMIT:
            raise ValueError("Actual split ZIP still exceeds strict 24 MiB limit")
        result.append(item)
    return result


def safe_extract(packages, destination):
    """Validate declared members and reject nonidentical overlay collisions."""
    root = Path(destination).resolve(); root.mkdir(parents=True, exist_ok=True)
    files = 0
    for package in packages:
        with zipfile.ZipFile(package) as z:
            if len(z.namelist()) != len(set(z.namelist())) or z.testzip():
                raise ValueError("Invalid ZIP CRC or duplicate members: "+str(package))
            manifests = [n for n in z.namelist() if n.startswith("PACKAGE_") and n.endswith("_MANIFEST.json")]
            if len(manifests) != 1:
                raise ValueError("Exactly one package manifest expected")
            manifest = json.loads(z.read(manifests[0]))
            if manifest["version"] != VERSION:
                raise ValueError("Mixed scientific versions")
            expected = {r["path"]: r["sha256"] for r in manifest["files"]}
            sums = [n for n in z.namelist() if n.startswith("PACKAGE_") and n.endswith("_SHA256SUMS")]
            if len(sums) != 1:
                raise ValueError("Package SHA file missing")
            for line in z.read(sums[0]).decode().splitlines():
                digest, name = line.split("  ", 1); expected[name] = digest
            for name in z.namelist():
                parsed = PurePosixPath(name)
                if parsed.is_absolute() or ".." in parsed.parts or "\\" in name or parsed.parts[0].endswith(":"):
                    raise ValueError("Unsafe ZIP path: "+name)
                data = z.read(name)
                digest = hashlib.sha256(data).hexdigest()
                if name not in sums and expected.get(name) != digest:
                    raise ValueError("Member not validated: "+name)
                target = root.joinpath(*parsed.parts)
                if target.is_symlink() or not target.resolve().is_relative_to(root):
                    raise ValueError("Unsafe existing symlink path: "+str(target))
                if target.exists():
                    if not target.is_file() or sha(target) != digest:
                        raise ValueError("Refusing differing existing file: "+str(target))
                else:
                    target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(data)
                files += 1
    return dict(packages=len(packages), validated_file_instances=files,
                differing_existing_members_rejected=True)


def run_checked(python, arguments, root, logs, label, timeout=1800):
    path = logs/(label+".log"); path.parent.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env.update(PYTHONPATH=str(root/"src"), OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1",
               MKL_NUM_THREADS="1", MPLCONFIGDIR=str(root/".mpl-cache"))
    started = time.perf_counter()
    print("clean replay "+label, flush=True)
    with path.open("w") as handle:
        process = subprocess.Popen([python, *arguments], cwd=root, env=env,
                                   stdout=handle, stderr=subprocess.STDOUT)
        while True:
            try:
                code = process.wait(timeout=45)
                break
            except subprocess.TimeoutExpired:
                elapsed = time.perf_counter()-started
                if elapsed > timeout:
                    process.kill(); process.wait()
                    raise TimeoutError(f"Clean replay timeout: {label}; see {path}")
                with path.open("rb") as reader:
                    reader.seek(max(0,path.stat().st_size-1000))
                    tail = reader.read().decode(errors="replace").splitlines()
                last = tail[-1] if tail else "no buffered child progress yet"
                print(f"clean replay {label}: {elapsed:.1f}s; {last}",flush=True)
    if code:
        raise RuntimeError(f"Clean replay {label} failed ({code}); see {path}")
    return dict(command=[python,*arguments], cwd="clean temporary root", exit_code=code,
                seconds=time.perf_counter()-started, log_path=str(path), log_sha256=sha(path))


def compare_tables(reference, rebuilt):
    import numpy as np
    import pandas as pd
    checked = []
    for path in sorted(reference.glob("*.csv*")):
        if path.name == "predictions_all.csv.gz":
            continue
        a = pd.read_csv(path, low_memory=False); b = pd.read_csv(rebuilt/path.name, low_memory=False)
        if list(a.columns) != list(b.columns) or len(a) != len(b):
            raise ValueError("Recomputed table schema/length changed: "+path.name)
        max_relative = 0.
        for column in a:
            if pd.api.types.is_numeric_dtype(a[column]) and pd.api.types.is_numeric_dtype(b[column]):
                aa = a[column].to_numpy(float); bb = b[column].to_numpy(float)
                np.testing.assert_allclose(aa, bb, atol=1e-10, rtol=1e-10, equal_nan=True,
                                           err_msg=path.name+":"+column)
                finite = np.isfinite(aa)&np.isfinite(bb)
                if finite.any():
                    max_relative = max(max_relative, float(np.max(np.abs(aa[finite]-bb[finite])/(1+np.abs(aa[finite])))))
            elif not a[column].fillna("<NA>").astype(str).equals(b[column].fillna("<NA>").astype(str)):
                raise ValueError("Recomputed table nonnumeric field changed: "+path.name+":"+column)
        checked.append(dict(table=path.name, rows=len(a), numeric_atol=1e-10, numeric_rtol=1e-10,
                            maximum_scaled_absolute_difference=max_relative))
    if not checked:
        raise ValueError("No saved evaluation tables")
    return checked



def start_text(category):
    return (f"# Stage3D {category}\n\n"
        f"Read reports/{VERSION}/REPRODUCE.md and ANALYSIS_ZH.md.\n"
        "Extract every new Stage3D part into one NEW root; overlays require identical SHA.\n"
        "All intervals use the same frozen Persistence centre. Empirical interval\n"
        "quantiles have no finite-sample, conditional or conformal guarantee.\n"
        "Code-only cold source/gamma and smoke reproduction is separate from merged\n"
        "full-cache verification and saved-interval evaluation. Actual scope is\n"
        "recorded in the external PACKAGE_CHECKS.json receipt.\n"
        "The original Stage3C2 reissue files are byte-identical archives, not new\n"
        "forecasts; keep their five parts separate from the new Stage3D packages.\n"
        "All five windows are already-used development. physical_mapping_verified=false.\n"
        "Historical QA publication and daily observation arrival are unverified.\n"
        "Stop after this finite CPU round; no final-period performance or new models.\n").encode()


def reissue_original_c2(root, output):
    """Copy previously existing five archives, preserving their exact bytes."""
    old = root / "delivery/20261012_stage3c2"
    original_receipt = json.loads((old/"PACKAGE_CHECKS.json").read_text())
    prior = json.loads((root/f"reports/{VERSION}/STAGE3C2_ORIGINAL_DELIVERY_CHECK.json").read_text())
    prior_check = {Path(item["file"]).name: item for item in prior["checks"]}
    entries = []
    packages = original_receipt["packages"]
    if len(packages) != 5:
        raise ValueError("All FIVE original Stage3C2 archives are required")
    for record in packages:
        name = record["file"]
        source = old/name
        if not source.is_file() or source.stat().st_size != record["bytes"] or sha(source) != record["sha256"]:
            raise ValueError("Original Stage3C2 archive has changed: "+name)
        previous = prior_check.get(name)
        if not previous or previous["sha256"] != record["sha256"] or not previous["is_original_existing_package"]:
            raise ValueError("Original-byte inspection receipt is missing: "+name)
        tail = name.removeprefix("Wastewater_Stage3C2_").removesuffix(".zip").replace("_20261012", "", 1)
        new_name = "Wessex_Stage3C2_Original_"+tail+"_Reissued_20261012.zip"
        destination = output/new_name
        if destination.exists():
            raise FileExistsError("Never overwrite a prior reissue: "+new_name)
        shutil.copyfile(source, destination)
        if sha(destination) != record["sha256"] or destination.stat().st_size >= LIMIT:
            raise ValueError("Reissued bytes/strict size gate differ: "+new_name)
        members = []
        with zipfile.ZipFile(destination) as archive:
            if archive.testzip() or len(archive.namelist()) != len(set(archive.namelist())):
                raise ValueError("Original ZIP is corrupt: "+name)
            for item in archive.infolist():
                if item.is_dir():
                    continue
                members.append(dict(path=item.filename,bytes=item.file_size,
                                    sha256=hashlib.sha256(archive.read(item.filename)).hexdigest()))
        entries.append(dict(original_file=name,reissued_file=new_name,bytes=destination.stat().st_size,
                            MiB=destination.stat().st_size/1024**2,sha256=record["sha256"],
                            is_exact_original_container=True, C2_predictions_regenerated=False,
                            CRC_and_all_member_SHA256_passed=True,members=members))
        (output/(new_name+".members.SHA256SUMS")).write_text("".join(
            f"{item['sha256']}  {item['path']}\n" for item in members))
    manifest = dict(status="PASSED",created_utc=datetime.now(timezone.utc).isoformat(),
                    original_package_count=5, client_missing_Part01_Part02_found_original=True,
                    content_regenerated=False, original_bytes_preserved=True,files=entries)
    save_json(output/"C2_ORIGINAL_REISSUE_MANIFEST.json",manifest)
    return manifest

def collect(root):
    freeze = json.loads((root/f"configs/{VERSION}/FREEZE.json").read_text())
    code, quick, predictions = {}, {}, {}
    for name in freeze["files_sha256"]:
        add_path(root, code, name)
    for name in [f"configs/{VERSION}/FREEZE.json", "src/wastewater/__init__.py",
                 "requirements-stage3d.txt", "scripts/package_stage3d.py",
                 "scripts/check_stage3d_results.py", "scripts/plot_stage3d.py",
                 "scripts/check_stage3d_smoke_v2.py", "scripts/check_stage3d_smoke_v3.py",
                 "scripts/monitor_stage3c2.py", "tests/test_stage3d_audit_helpers.py",
                 "scripts/verify_stage3c2_data.py", f"reports/{VERSION}/REPRODUCE.md",
                 "configs/stage3c2_source_scale_v1/full.json",
                 f"data/derived/{C2_VERSION}", f"data/provenance/{C2_VERSION}",
                 f"data/derived/{VERSION}",
                 "data/provenance/stage3c1_20261011_v1/facilities",
                 "materials/received_stage2_20261009/paper idea.docx"]:
        add_path(root, code, name)
    # C2 data QA has its own frozen provenance definition; neither old Ridge
    # models nor old GRU weights are needed for Stage3D construction/evaluation.
    for path in sorted((root/f"reports/{VERSION}").rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts:
            continue
        name = str(path.relative_to(root))
        if "results" not in path.relative_to(root/f"reports/{VERSION}").parts or path.suffix != ".gz":
            add_path(root, quick, name)
    for name in ["STAGE3D_PROTOCOL.md", f"configs/{VERSION}", f"figures/{VERSION}",
                 f"data/provenance/{C2_VERSION}/source_pool_definition.json",
                 f"data/provenance/{C2_VERSION}/partition_group_ledger.csv",
                 f"data/provenance/{C2_VERSION}/temporary_and_registered_protection.csv",
                 "data/provenance/stage3c1_20261011_v1/facilities"]:
        add_path(root, quick, name)
    for name in [f"runs/{VERSION}", f"reports/{VERSION}/results", "STAGE3D_PROTOCOL.md",
                 f"configs/{VERSION}", f"reports/{VERSION}/REPRODUCE.md",
                 f"reports/{VERSION}/GAMMA_FREEZE.json"]:
        add_path(root, predictions, name)
    for payload in [code, quick, predictions]:
        if RAW in payload:
            raise ValueError("Protected/final-year full raw container must not be packaged")
        for name,path in payload.items():
            if path.stat().st_size == 0 and path.name != "__init__.py":
                raise ValueError("Unexpected empty payload: "+name)
            if name.startswith("runs/") and VERSION not in name:
                raise ValueError("Old training cache is not required by new interval experiment")
    if (root/f"runs/{VERSION}").exists() and any(name.startswith(f"runs/{VERSION}/") for name in code):
        raise ValueError("Code-only cold reproduction must contain no source/target caches")
    return [("Quick_Review",quick),("Code_and_Reproduce",code),("Predictions_and_Diagnostics",predictions)]


def compare_intervals(reference, rebuilt):
    import numpy as np
    import pandas as pd
    keys = ["site_id", "episode", "budget", "horizon", "origin", "target_date", "pool_id", "method", "nominal_coverage"]
    dtype = dict(site_id=str, pool_id=str, order_label=str)
    a = pd.read_csv(reference,dtype=dtype,low_memory=False).set_index(keys).sort_index()
    b = pd.read_csv(rebuilt,dtype=dtype,low_memory=False).set_index(keys).sort_index()
    if not a.index.equals(b.index) or list(a.columns) != list(b.columns):
        raise ValueError("Interval forecast keys/schema differ")
    fields = []
    for column in a:
        if column in {"run_id"}:
            # All target rows still require the same scientific run identity.
            if not a[column].fillna("<NA>").astype(str).equals(b[column].fillna("<NA>").astype(str)):
                raise ValueError("Scientific run identity differs")
        elif pd.api.types.is_numeric_dtype(a[column]) and pd.api.types.is_numeric_dtype(b[column]):
            aa,bb = a[column].to_numpy(float),b[column].to_numpy(float)
            tol = 1e-8 if column.endswith("m3") else 1e-10
            np.testing.assert_allclose(aa,bb,atol=tol,rtol=1e-12 if tol==1e-8 else 1e-10,equal_nan=True,
                                       err_msg=column)
            valid = np.isfinite(aa)&np.isfinite(bb)
            fields.append(dict(column=column, maximum_absolute_difference=float(np.max(np.abs(aa[valid]-bb[valid]))) if valid.any() else 0.))
        elif not a[column].fillna("<NA>").astype(str).equals(b[column].fillna("<NA>").astype(str)):
            raise ValueError("Interval metadata field differs: "+column)
    return dict(rows=len(a),matched_calendar_method_keys=True,m3_atol=1e-8,m3_rtol=1e-12,
                normalized_atol=1e-10,normalized_rtol=1e-10,tolerance_not_bitwise_replication=True,columns=fields)

def validate_completion(root):
    """Verify frozen inputs and all outputs; no failed=0 completion shortcut."""
    sys.path.insert(0,str(root/"src"))
    from wastewater.stage3d_experiment import load_config, expected_tasks, task_key, job_fingerprint, validate_job
    cfg,signature,_ = load_config(f"configs/{VERSION}/full.json")
    full = root/f"runs/{VERSION}/full"
    manifest = json.loads((full/"manifest.json").read_text())
    tasks = expected_tasks(cfg,"full")
    rows_per = cfg["evaluation_days"]*len(cfg["pools"])*len(cfg["methods"])*len(cfg["nominal_coverages"])
    if len(tasks)!=300 or rows_per!=1080 or manifest.get("status")!="COMPLETED":
        raise ValueError("Expected 300 fully completed interval conditions")
    if manifest.get("signature")!=signature or manifest.get("completed_conditions")!=300 or manifest.get("expected_prediction_rows")!=324000:
        raise ValueError("Interval config/fingerprint/count mismatch")
    for task in tasks:
        if not validate_job(full/"jobs"/task_key(task),job_fingerprint(signature,task,cfg),rows_per):
            raise ValueError("Expected interval task incomplete: "+task_key(task))
    if sha(full/"predictions_all.csv.gz")!=manifest.get("predictions_sha256"):
        raise ValueError("Full original interval aggregate changed")
    source_records=[]
    for pool in cfg["pools"]:
        folder=root/cfg["source_output"]/pool["pool_id"]
        state=json.loads((folder/"status.json").read_text())
        if state.get("status")!="COMPLETED" or state.get("expected_folds")!=360 or state.get("completed_folds")!=360 or state.get("completed_choices")!=6:
            raise ValueError("Source validation incomplete: "+pool["pool_id"])
        for name,digest in state["outputs_sha256"].items():
            if not (folder/name).is_file() or sha(folder/name)!=digest:
                raise ValueError("Source error/validation/selection checksum differs")
        source_records.append(dict(pool_id=pool["pool_id"],folds=360,gamma_choices=6,all_output_SHA256_verified=True))
    report=root/f"reports/{VERSION}"
    gamma=json.loads((report/"GAMMA_FREEZE.json").read_text())
    if gamma.get("signature")!=signature or gamma.get("target_deployment_scores_used") is not False:
        raise ValueError("Gamma freeze provenance is not source-only")
    for name,digest in gamma["files_sha256"].items():
        if sha(root/name)!=digest:
            raise ValueError("Gamma freeze output checksum changed")
    if json.loads((report/"RUN_STATUS.json").read_text()).get("status")!="COMPLETED":
        raise ValueError("Scientific RUN_STATUS is not complete")
    evaluation=json.loads((report/"results/evaluation_validation.json").read_text())
    if evaluation.get("status")!="COMPLETED":
        raise ValueError("All saved interval metrics have not completed")
    integrity=evaluation.get("experiment_integrity",{})
    if not integrity.get("all_expected_tasks_verified"):
        raise ValueError("Evaluation lacks full expected task verification")
    for name,digest in evaluation["files_sha256"].items():
        if sha(report/"results"/name)!=digest:
            raise ValueError("Evaluated interval table checksum changed: "+name)
    independent=json.loads((report/"INDEPENDENT_CHECK.json").read_text())
    if independent.get("status")!="PASSED" or independent.get("checker_sha256")!=sha(root/"scripts/check_stage3d_results.py"):
        raise ValueError("Independent interval reconstruction absent or stale")
    gate=json.loads((report/"SMOKE_CHECK.json").read_text())
    if gate.get("status")!="PASSED" or gate.get("signature")!=signature:
        raise ValueError("Actual original-two-site smoke gate absent/stale")
    return dict(signature=signature,completed_conditions=300,interval_rows=324000,
                pools=3,methods=3,coverages=2,source_validation=source_records,
                gamma_choices_frozen_before_target_intervals=True,
                all_expected_job_and_source_SHA256_verified=True,
                saved_evaluation_table_SHA256_verified=True,
                independent_reconstruction_PASSED=True,
                physical_mapping_verified=False,final_period_performance_used=False)

def extraction_collision_checks(output):
    """Check delivery overlays using small software fixtures, not research data."""
    with tempfile.TemporaryDirectory(prefix="stage3d_packaging_fixture_",dir="/tmp") as directory:
        base=Path(directory);sample=base/"fixture.txt";sample.write_text("software fixture, not measured data\n")
        package=base/"fixture.zip"
        record=write_archive(package,{"example/fixture.txt":sample},"Fixture",None)
        clean=base/"clean"
        first=safe_extract([package],clean);second=safe_extract([package],clean)
        (clean/"example/fixture.txt").write_text("different existing content\n")
        refused=False
        try:safe_extract([package],clean)
        except ValueError as exc:
            refused="Refusing differing existing file" in str(exc)
        if not refused:raise AssertionError("Differing existing member was not refused")
        result=dict(status="PASSED",software_fixtures_only=True,
                    original_extraction=first,identical_overlay=second,
                    differing_SHA_overlay_refused=True,CRC_member_SHA_checked=True)
    save_json(output/"EXTRACTION_SAFETY_CHECK.json",result)
    return result

def compare_source_selection(reference_root, rebuilt_root):
    import numpy as np
    records=[]
    cfg=json.loads((reference_root/f"configs/{VERSION}/full.json").read_text())
    for pool in cfg["pools"]:
        a=json.loads((reference_root/cfg["source_output"]/pool["pool_id"]/"selected_gamma.json").read_text())
        b=json.loads((rebuilt_root/cfg["source_output"]/pool["pool_id"]/"selected_gamma.json").read_text())
        if a["source_ids"]!=b["source_ids"] or set(a["choices"])!=set(b["choices"]):
            raise ValueError("Source composition/gamma registry differs")
        for key,choice in a["choices"].items():
            other=b["choices"][key]
            if choice["gamma"]!=other["gamma"]:
                raise ValueError("Source-selected gamma differs: "+pool["pool_id"]+key)
            for g,obj in choice["normalized_objectives"].items():
                np.testing.assert_allclose(obj,other["normalized_objectives"][g],atol=1e-10,rtol=1e-10)
            records.append(dict(pool_id=pool["pool_id"],condition=key,gamma=choice["gamma"],
                                all_five_validation_objectives_match=True))
    return dict(source_pools=3,gamma_choices=18,all_selected_gamma_values_exact=True,
                objective_atol=1e-10,objective_rtol=1e-10,choices=records)


def clean_replay(root,packages,python,output):
    logs=output/"clean_replay_logs";commands=[]
    cfg=f"configs/{VERSION}/full.json"
    code_packages=[p["path"] for p in packages if p["category"]=="Code_and_Reproduce"]
    with tempfile.TemporaryDirectory(prefix="stage3d_cold_code_",dir="/tmp") as directory:
        clean=Path(directory);extraction=safe_extract(code_packages,clean)
        if (clean/f"runs/{VERSION}").exists() or (clean/f"reports/{VERSION}/GAMMA_FREEZE.json").exists():
            raise ValueError("Cold code package unexpectedly includes interval caches")
        commands.append(run_checked(python,["-m","unittest","discover","-s","tests","-p","test_stage3d*.py","-v"],clean,logs,"unit_tests"))
        commands.append(run_checked(python,["scripts/verify_stage3c2_data.py","--root",str(clean),"--output","verification/data_qa.json"],clean,logs,"original_C2_canonical_raw_excerpt_QA"))
        commands.append(run_checked(python,["-m","wastewater.stage3d_experiment","--config",cfg,"--mode","sources","--workers","1"],clean,logs,"cold_three_source_libraries_and_1080_pseudo_folds"))
        source_selection=compare_source_selection(root,clean)
        commands.append(run_checked(python,["-m","wastewater.stage3d_experiment","--config",cfg,"--mode","smoke","--workers","1"],clean,logs,"cold_original_two_site_smoke"))
        commands.append(run_checked(python,["scripts/check_stage3d_smoke_v3.py"],clean,logs,"independent_cold_smoke_calibration_interval_gate"))
        smoke=compare_intervals(root/f"runs/{VERSION}/smoke/predictions_all.csv.gz",clean/f"runs/{VERSION}/smoke/predictions_all.csv.gz")
        gate=json.loads((clean/f"reports/{VERSION}/SMOKE_CHECK.json").read_text())
        if gate.get("status")!="PASSED" or gate.get("interval_rows_checked")!=12960:
            raise ValueError("Actual cold smoke gate incomplete")
        commands.append(run_checked(python,["-m","wastewater.stage3d_experiment","--config",cfg,"--mode","smoke","--workers","1"],clean,logs,"validated_twelve_task_smoke_cache_resume"))
        manifest=json.loads((clean/f"runs/{VERSION}/smoke/manifest.json").read_text())
        if manifest.get("counts_this_call")!=dict(COMPLETED=0,CACHED=12,FAILED=0):
            raise ValueError("Cached smoke did not skip exactly twelve verified tasks")
        cached_smoke=compare_intervals(root/f"runs/{VERSION}/smoke/predictions_all.csv.gz",clean/f"runs/{VERSION}/smoke/predictions_all.csv.gz")
    with tempfile.TemporaryDirectory(prefix="stage3d_merged_evaluate_",dir="/tmp") as directory:
        clean=Path(directory);merged=safe_extract([p["path"] for p in packages],clean)
        commands.append(run_checked(python,["-m","wastewater.stage3d_experiment","--config",cfg,"--mode","resume","--workers","1"],clean,logs,"validated_full_300_task_cache_resume"))
        manifest=json.loads((clean/f"runs/{VERSION}/full/manifest.json").read_text())
        if manifest.get("counts_this_call")!=dict(COMPLETED=0,CACHED=300,FAILED=0):
            raise ValueError("Full cached interval task verification incomplete")
        full=compare_intervals(root/f"runs/{VERSION}/full/predictions_all.csv.gz",clean/f"runs/{VERSION}/full/predictions_all.csv.gz")
        commands.append(run_checked(python,["scripts/summarize_stage3d.py","--config",cfg,"--run",f"runs/{VERSION}/full","--output","verification/results"],clean,logs,"saved_interval_all_table_evaluation_5000_resamples"))
        tables=compare_tables(root/f"reports/{VERSION}/results",clean/"verification/results")
        check=json.loads((clean/"verification/results/evaluation_validation.json").read_text())
        if check.get("status")!="COMPLETED":raise ValueError("Clean saved-interval evaluation incomplete")
        commands.append(run_checked(python,["scripts/check_stage3d_results.py","--root",str(clean),"--output","verification/independent_interval_check.json","--skip-original-c2-packages"],clean,logs,"independent_full_D_CDF_selection_metric_bootstrap_reconstruction"))
        independent=json.loads((clean/"verification/independent_interval_check.json").read_text())
        if independent.get("status")!="PASSED" or independent.get("mode")!="full_independent_interval_evidence_audit":
            raise ValueError("Clean independent empirical-interval reconstruction failed")
    return dict(status="PASSED",code_only_clean_extraction=extraction,merged_clean_extraction=merged,
                no_network_calls=True,cold_computation_executed=dict(source_pools=3,source_validation_folds=1080,
                source_gamma_choices=18,smoke_conditions=12,smoke_interval_rows=12960),
                source_selection_reproduction=source_selection,independent_cold_smoke_gate=gate,
                smoke_interval_comparison=smoke,cached_smoke_comparison=cached_smoke,
                full_verified_cached_conditions=300,full_saved_interval_comparison=full,
                full_cold_interval_rerun="NOT_REPEATED_IN_PACKAGE_REPLAY; actual original full run preserved, source/gamma and smoke rerun cold",
                original_C2_bundle_checks="NOT_REPEATED_IN_D_ONLY_REPLAY; five original ZIPs independently byte-audited and reissued outside new D archives",
                recomputed_interval_evaluation_tables=tables,resamples_per_block=5000,
                independent_D_evidence_audit=independent,commands=commands,tolerance_not_bitwise_claim=True,
                external_dependencies_scope="Full original raw/candidate eligibility/historical project usage scan excluded; not needed for cold D intervals or metric reconstruction")



def write_readme(output, packages, originals):
    lines=["# Wessex Stage3D verified delivery", "", "本交付包含**新Stage3D**与**原Stage3C2字节重交**两组文件，外层名称不同。", "",
        "Stage3D已完成300条件、324,000条经验区间；三套原K30源组合、三预算、两时距、80%/90%均保留。所有中心为原Persistence，不是新的点预测模型。", "",
        "B30主MIXTURE相对LOCAL技能为h1 +2.64%（调整97.5%区间−2.23%至+7.35%）、h3 +2.12%（−4.65%至+9.36%）。两项区间均跨零；覆盖改善伴随宽度成本，不支持稳定区间创新或普遍历史节省。详见[中文分析](ANALYSIS_ZH.md)。", "",
        "## 新Stage3D下载", "", "| 文件 | MiB | SHA256 |", "|---|---:|---|"]
    for item in packages:
        name=Path(item["path"]).name
        lines.append(f"| [{name}]({name}?raw=true) | {item['MiB']:.2f} | `{item['sha256']}` |")
    lines.extend(["", "完整复核需将**所有新D包（包括全部预测诊断分包）**解压到同一个新目录。Quick仅便于阅读，不能替代逐条预测。每卷是独立ZIP，不是需额外解卷工具的字节切片。每包内均有成员SHA清单；不同SHA的同名文件会被拒绝覆盖。", "",
        "## 原Stage3C2重交", "", "以下五个文件只改外层名称，容器SHA与旧包完全相同。原Part01、Part02在仓库中存在且已核验，**没有重新生成原预测**。原预测诊断仍需Part01、Part02、Part03三个包。", "", "| 原文件的唯一重交名称 | MiB | 原容器SHA256 |", "|---|---:|---|"])
    for item in originals["files"]:
        name=item["reissued_file"]
        lines.append(f"| [{name}]({name}?raw=true) | {item['MiB']:.2f} | `{item['sha256']}` |")
    lines.extend(["", "原/新名称、完整ZIP成员SHA在[C2_ORIGINAL_REISSUE_MANIFEST.json](C2_ORIGINAL_REISSUE_MANIFEST.json)；每个原包另附`.members.SHA256SUMS`。这些是旧C2内容，与新D包分开解压。", "",
        "## 核验及复现", "", "[SHA256SUMS](SHA256SUMS)列所有外层文件；[PACKAGE_CHECKS.json](PACKAGE_CHECKS.json)记录实际CRC、成员SHA、干净目录命令和范围。", "",
        "Code-only已冷建三源库/1,080伪部署折/18gamma，再冷跑原两个smoke测点12条件；合并D完整包后核验300缓存任务并重算全部指标及独立CDF/区间/评分/主要Bootstrap。冷smoke与缓存全量复算是不同范围，没有声称打包阶段冷跑全部300条件。", "",
        "安装与入口见[REPRODUCE.md](REPRODUCE.md)。已完成根目录可校验续跑：", "", "```bash", "OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONPATH=src \\",
        ".venv/bin/python -m wastewater.stage3d_experiment \\",
        "  --config configs/stage3d_interval_v1/full.json --mode resume --workers 1", "```", "",
        "所有五窗是已使用开发历史；physical_mapping_verified=false，观测/QA实时到达未核实。经验区间无conformal、有限样本或条件覆盖保证。原全raw和旧186候选历史资格的完整重建属于外部依赖，SHA及范围已列明；新区间冷源/smoke和指标重算输入自包含。", "",
        "2024—2025预测性能及临时保护组未启用；没有雨量、GRU扩展、模型组合、App、论文或付费GPU。本轮结束并停止，等待审查。", ""])
    (output/"README.md").write_text("\n".join(lines))


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root",type=Path,default=ROOT)
    ap.add_argument("--output",default=f"delivery/{DAY}_stage3d")
    ap.add_argument("--python",default=sys.executable)
    ap.add_argument("--extract",nargs="+")
    ap.add_argument("--destination",type=Path)
    a=ap.parse_args()
    if a.extract:
        if not a.destination:ap.error("--extract requires --destination")
        print(json.dumps(safe_extract(a.extract,a.destination),indent=2));return
    root=a.root.resolve()
    if root!=ROOT:raise ValueError("Build only from intended checkout; extraction accepts other destinations")
    output=root/a.output;output.mkdir(parents=True,exist_ok=True)
    if (output/"PACKAGE_CHECKS.json").exists():raise FileExistsError("Do not overwrite completed delivery receipts")
    started=time.perf_counter();completion=validate_completion(root)
    safety=extraction_collision_checks(output)
    originals=reissue_original_c2(root,output)
    packages=[]
    for category,payload in collect(root):packages.extend(make_packages(output,category,payload))
    packing_seconds=time.perf_counter()-started
    print("Original C2 reissues are byte-identical. All D ZIPs passed CRC/member SHA; cold replay starts.",flush=True)
    replay=clean_replay(root,packages,a.python,output)
    public=[{k:v for k,v in p.items() if k not in {"members","path"}}|dict(file=Path(p["path"]).name) for p in packages]
    receipt=dict(status="PASSED",version=VERSION,created_utc=datetime.now(timezone.utc).isoformat(),
                 package_script_sha256=sha(Path(__file__)),strict_ZIP_limit_bytes=LIMIT,
                 scientific_completion_checked=completion,packages=public,clean_replay=replay,
                 original_C2_reissued_packages=[{k:v for k,v in p.items() if k!="members"} for p in originals["files"]],
                 original_C2_predictions_regenerated=False,extraction_collision_checks=safety,
                 timings_seconds=dict(creation_and_member_SHA=packing_seconds,total=time.perf_counter()-started))
    save_json(output/"PACKAGE_CHECKS.json",receipt)
    save_json(output/"MANIFEST.json",dict(version=VERSION,new_stageD_files=[dict(file=p["file"],bytes=p["bytes"],sha256=p["sha256"]) for p in public],
                                        exact_original_C2_reissues=[dict(file=p["reissued_file"],bytes=p["bytes"],sha256=p["sha256"]) for p in originals["files"]]))
    for name in ["ANALYSIS_ZH.md","CLAIM_EVIDENCE.csv","CODE_VERSION.json","REPRODUCE.md","RUN_STATUS.json", "INDEPENDENT_CHECK.json", "GAMMA_FREEZE.json"]:
        source=root/f"reports/{VERSION}"/name
        shutil.copyfile(source,output/name)
    shutil.copyfile(root/"STAGE3D_PROTOCOL.md",output/"STAGE3D_PROTOCOL.md")
    shutil.copyfile(root/f"configs/{VERSION}/full.json",output/"full.json")
    shutil.copyfile(root/f"configs/{VERSION}/FREEZE.json",output/"FREEZE.json")
    write_readme(output,packages,originals)
    sums="".join(f"{sha(p)}  {p.name}\n" for p in sorted(output.iterdir()) if p.is_file() and p.name!="SHA256SUMS")
    (output/"SHA256SUMS").write_text(sums)
    print(json.dumps(dict(status="PASSED",newD_packages=public,
        original_C2_reissued=[p["reissued_file"] for p in originals["files"]],
        package_checks=str(output/"PACKAGE_CHECKS.json")),indent=2))


if __name__=="__main__":main()
