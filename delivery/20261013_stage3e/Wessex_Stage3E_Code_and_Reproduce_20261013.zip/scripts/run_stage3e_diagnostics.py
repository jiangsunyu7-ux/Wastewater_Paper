#!/usr/bin/env python3
"""Read frozen Stage3D endpoints and produce finite Stage3E post-hoc evidence."""
import argparse
import json
from pathlib import Path

from wastewater.stage3e_diagnostics import run_diagnostics

ROOT=Path(__file__).resolve().parents[1]

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config",default="configs/stage3e_evidence_review_v1/diagnostics.json")
    parser.add_argument("--stage3d-config")
    parser.add_argument("--output")
    parser.add_argument("--force",action="store_true",help="Explicitly replace ONLY new Stage3E diagnostics after inspecting failed/cache status")
    args=parser.parse_args()
    path=ROOT/args.config
    cfg=json.loads(path.read_text()) if path.is_file() else {"version":"stage3e_evidence_review_v1"}
    if args.stage3d_config:cfg["stage3d_config"]=args.stage3d_config
    if args.output:cfg["output"]=args.output
    result=run_diagnostics(ROOT,cfg,force=args.force)
    print(json.dumps({k:result[k] for k in ["status","version","fingerprint"]},ensure_ascii=False),flush=True)

if __name__=="__main__":main()
