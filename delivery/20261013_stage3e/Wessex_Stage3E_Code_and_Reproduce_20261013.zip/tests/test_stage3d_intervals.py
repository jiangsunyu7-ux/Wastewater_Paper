"""Synthetic calendars validate Stage3D algebra and legal information only."""
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
import pandas as pd

from wastewater.shared_data import build_samples
from wastewater.stage3d_intervals import (GAMMAS, QUANTILE_CDF_TOLERANCE,
    calibrate_history, choose_gamma, construct_intervals, interval_score,
    linked_sites, local_distribution, mixture_quantiles, persistence_with_dates,
    prepare_source_bank, source_distribution, validate_completed_source_cache,
    weighted_empirical_quantile)


def fixture():
    cfg = dict(source_training_start="2016-01-01", source_training_end="2021-12-31",
        source_selection_train_end="2020-12-31", source_pseudo_origins=["2021-01-01","2021-07-01"],
        source_pseudo_validation_days=14, budgets=[30,90,180], horizons=[1,3],
        gammas=list(GAMMAS), min_calibration_scores=14, gamma_tie_tolerance=1e-12,
        quantile_cdf_tolerance=QUANTILE_CDF_TOLERANCE)
    dates = pd.date_range("2016-01-01", "2023-12-31")
    series = {str(site): pd.Series(multiplier*(100.+25.*np.sin(np.arange(len(dates))/17.)), index=dates)
              for site,multiplier in [("A",1.),("B",7.),("C",19.)]}
    return cfg, series


class EmpiricalQuantileTests(unittest.TestCase):
    def test_quantile_no_interpolation_and_zero_retained(self):
        values = np.array([9.,0.,1.,0.])
        weights = np.array([.1,.3,.3,.3])
        self.assertEqual(weighted_empirical_quantile(values,weights,.5),0.)
        self.assertEqual(weighted_empirical_quantile(values,weights,.8),1.)
        self.assertEqual(weighted_empirical_quantile(values,weights,1.),9.)

    def test_decimal_cdf_boundary_uses_order_statistic(self):
        values=np.arange(1.,11.)
        weights=np.full(10,.1)
        self.assertEqual(weighted_empirical_quantile(values,weights,.8),8.)
        self.assertEqual(weighted_empirical_quantile(values,weights,.9),9.)
        self.assertEqual(weighted_empirical_quantile(values,weights,.900001),10.)
        self.assertEqual(weighted_empirical_quantile([0.,10.],[1.,1e-16],1.),10.)

    def test_equal_total_source_weight_with_unequal_record_counts(self):
        errors=pd.DataFrame(dict(site_id=["A"]+["B"]*9,score=[0.]+[10.]*9))
        distribution=source_distribution(errors,["A","B"])
        self.assertEqual(distribution.sample_counts,(1,9))
        self.assertAlmostEqual(distribution.weights[0],.5)
        self.assertAlmostEqual(distribution.weights[1:].sum(),.5)
        self.assertEqual(weighted_empirical_quantile(distribution.values,distribution.weights,.5),0.)
        self.assertEqual(weighted_empirical_quantile(distribution.values,distribution.weights,.8),10.)

    def test_mixture_endpoints_literal_and_intervals_nested(self):
        local=local_distribution([0.,1.,2.,3.,4.,5.,6.,7.,8.,9.])
        shared=source_distribution(pd.DataFrame(dict(site_id=["A"]*4+["B"]*6,
            score=[.1,.2,.3,.4,10.,11.,12.,13.,14.,15.])))
        for gamma in GAMMAS:
            q=mixture_quantiles(local,shared,gamma)
            self.assertLessEqual(q[.8],q[.9])
            l80,u80,_=construct_intervals([5.,20.],10.,q[.8])
            l90,u90,_=construct_intervals([5.,20.],10.,q[.9])
            self.assertTrue(np.all(l90<=l80))
            self.assertTrue(np.all(u80<=u90))
        self.assertEqual(mixture_quantiles(local,shared,0.),
            {c:weighted_empirical_quantile(local.values,local.weights,c) for c in [.8,.9]})
        self.assertEqual(mixture_quantiles(local,shared,1.),
            {c:weighted_empirical_quantile(shared.values,shared.weights,c) for c in [.8,.9]})

    def test_invalid_quantile_inputs_fail_explicitly(self):
        for values,weights,p in [([],[],.9),([np.nan],[1.],.9),([0.],[-1.],.9),([0.],[0.],.9),([0.],[1.],0)]:
            with self.assertRaises(ValueError):
                weighted_empirical_quantile(values,weights,p)


class HistoryCalibrationTests(unittest.TestCase):
    def test_h3_target_boundary_and_left_budget_preserved(self):
        dates=pd.date_range("2020-12-01","2021-01-31")
        series=pd.Series(np.arange(len(dates),dtype=float)+10.,index=dates)
        calibration=calibrate_history(series,"2021-01-01","2021-01-30",3)
        self.assertTrue(calibration.valid)
        self.assertEqual(len(calibration.scores),27)
        self.assertEqual(calibration.frame.origin.max(),pd.Timestamp("2021-01-27"))
        self.assertEqual(calibration.frame.target_date.max(),pd.Timestamp("2021-01-30"))
        self.assertTrue((calibration.frame.target_date-calibration.frame.origin).eq(pd.Timedelta(days=3)).all())
        self.assertTrue((calibration.frame.latest_input_date>=pd.Timestamp("2021-01-01")).all())

    def test_persistence_exact_legacy_and_dates_include_current_day(self):
        dates=pd.date_range("2020-12-20","2021-02-10")
        series=pd.Series(np.arange(len(dates),dtype=float)+10.,index=dates)
        series.loc["2021-01-02":"2021-01-04"]=np.nan
        origins=pd.date_range("2021-01-01",periods=6)
        expected=build_samples(series,origins,3,"2021-01-01",50.).persistence
        actual,inputs=persistence_with_dates(series,origins,3,"2021-01-01",50.)
        np.testing.assert_array_equal(actual,expected)
        self.assertEqual(inputs[0],pd.Timestamp("2021-01-01"))
        self.assertEqual(inputs[3],pd.Timestamp("2021-01-01"))
        self.assertEqual(inputs[5],pd.Timestamp("2021-01-06"))

    def test_eight_day_gap_and_no_before_left_history(self):
        dates=pd.date_range("2020-12-31","2021-01-30")
        series=pd.Series(10.,index=dates)
        series.loc["2021-01-01":"2021-01-09"]=np.nan
        p,inputs=persistence_with_dates(series,pd.to_datetime(["2021-01-01","2021-01-09","2021-01-10"]),
            1,"2021-01-01",10.)
        self.assertTrue(np.isnan(p[:2]).all())
        self.assertTrue(pd.isna(inputs[:2]).all())
        self.assertEqual(p[2],10.)

    def test_zero_values_are_labels_and_zero_errors_retained(self):
        dates=pd.date_range("2021-01-01",periods=30)
        series=pd.Series(10.,index=dates)
        series.loc["2021-01-10":"2021-01-12"]=0.
        calibration=calibrate_history(series,dates.min(),dates.max(),1)
        self.assertTrue(calibration.valid)
        self.assertEqual(calibration.scale,10.)
        self.assertEqual(int(calibration.frame.truth.eq(0).sum()),3)
        self.assertTrue((calibration.scores==0).any())
        self.assertEqual(len(calibration.scores),29)

    def test_no_positive_scale_and_insufficient_counts_are_distinct(self):
        dates=pd.date_range("2021-01-01",periods=30)
        zero=pd.Series(0.,index=dates)
        calibration=calibrate_history(zero,dates.min(),dates.max(),1)
        self.assertFalse(calibration.valid)
        self.assertIsNone(calibration.scale)
        self.assertEqual(calibration.reason,"NO_VALID_SCALE")
        sparse=pd.Series(np.nan,index=dates)
        sparse.iloc[:12]=10.
        calibration=calibrate_history(sparse,dates.min(),dates.max(),1)
        self.assertFalse(calibration.valid)
        self.assertEqual(calibration.reason,"INSUFFICIENT_CALIBRATION_ERRORS")
        self.assertEqual(len(calibration.scores),11)

    def test_future_and_before_left_values_do_not_change_calibration(self):
        _,series=fixture()
        before=calibrate_history(series["A"],"2020-12-02","2020-12-31",3)
        changed=series["A"].copy()
        changed.loc[:"2020-12-01"]=99999999.
        changed.loc["2021-01-01":]=88888888.
        after=calibrate_history(changed,"2020-12-02","2020-12-31",3)
        self.assertEqual(before.diagnostic,after.diagnostic)
        pd.testing.assert_frame_equal(before.frame,after.frame)


class IntervalScoreAndSelectionTests(unittest.TestCase):
    def test_relation_closure_undirected_transitive_and_unknown_not_independence(self):
        self.assertEqual(linked_sites("C",{"A":["B"],"C":["B"]}),{"A","B","C"})
        self.assertEqual(linked_sites("unknown",{}),{"unknown"})
        with self.assertRaises(TypeError):
            linked_sites("A",{"A":"facility-name"})

    def test_score_formula_and_uniform_nonnegative_sensitivity(self):
        score,width,lp,up=interval_score([-2.,5.,12.],[0.,0.,0.],[10.,10.,10.],.1,True)
        np.testing.assert_array_equal(width,[10.,10.,10.])
        np.testing.assert_array_equal(lp,[40.,0.,0.])
        np.testing.assert_array_equal(up,[0.,0.,40.])
        np.testing.assert_array_equal(score,[50.,10.,50.])
        lower,upper,clipped=construct_intervals([1.,20.],5.,1.)
        np.testing.assert_array_equal(lower,[-4.,15.])
        np.testing.assert_array_equal(upper,[6.,25.])
        np.testing.assert_array_equal(clipped,[0.,15.])

    def test_gamma_equal_site_window_selection_and_smaller_tie(self):
        rows=[]
        for gamma in GAMMAS:
            for site in ["A","B"]:
                for origin in ["2021-01-01","2021-07-01"]:
                    loss=1. if gamma in [0.,.25] else 2.
                    rows.append(dict(site_id=site,pseudo_origin=origin,gamma=gamma,
                        normalized_interval_score=loss))
        selected,objectives=choose_gamma(rows)
        self.assertEqual(selected,0.)
        self.assertEqual(objectives["0.0"],1.)
        with self.assertRaises(ValueError):
            choose_gamma(rows[:-1])

    def test_partial_zero_failures_never_complete_and_missing_members_rejected(self):
        cfg,_=fixture()
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)
            (path/"status.json").write_text(json.dumps(dict(status="PARTIAL",failed=0,fingerprint="fixture")))
            self.assertFalse(validate_completed_source_cache(path,"fixture",cfg,["A","B","C"]))
            (path/"status.json").write_text(json.dumps(dict(status="COMPLETED",fingerprint="fixture",
                completed_folds=36,expected_folds=36,completed_choices=6,outputs_sha256={})))
            with self.assertRaises(ValueError):
                validate_completed_source_cache(path,"fixture",cfg,["A","B","C"])

    def test_source_selection_boundaries_group_exclusion_cache_and_future_invariance(self):
        cfg,series=fixture()
        relations={"A":["A-linked"]}
        with tempfile.TemporaryDirectory() as folder:
            first=prepare_source_bank(cfg,series,["A","B","C"],folder,relations,"fixture","synthetic")
            self.assertFalse(first["cache_reused"])
            self.assertEqual(len(first["selected_gamma"]),6)
            rows=pd.read_csv(Path(folder)/"source_validation.csv")
            self.assertEqual(len(rows),180)
            self.assertTrue(rows.loc[rows.site_id.eq("A"),"excluded_related_ids"].eq("A|A-linked").all())
            proxy=pd.read_csv(Path(folder)/"source_errors_proxy.csv.gz")
            self.assertTrue(proxy.target_date.le("2020-12-31").all())
            final=pd.read_csv(Path(folder)/"source_errors_final.csv.gz")
            self.assertTrue(final.target_date.le("2021-12-31").all())
            changed={k:v.copy() for k,v in series.items()}
            for values in changed.values():
                values.loc["2022-01-01":]=99999999.
            cached=prepare_source_bank(cfg,changed,["A","B","C"],folder,relations,"fixture","synthetic")
            self.assertTrue(cached["cache_reused"])
            self.assertEqual(first["selected_gamma"],cached["selected_gamma"])
            (Path(folder)/"source_validation.csv").write_text("tampered\n")
            with self.assertRaises(ValueError):
                prepare_source_bank(cfg,series,["A","B","C"],folder,relations,"fixture","synthetic")

    def test_source_selection_excludes_all_in_pool_related_members(self):
        cfg,series=fixture()
        relations={"A":["B"], "B":["external-linked"]}
        with tempfile.TemporaryDirectory() as folder:
            bank=prepare_source_bank(cfg,series,["A","B","C"],folder,relations,"fixture","related-fixture")
            rows=pd.read_csv(Path(folder)/"source_validation_diagnostics.csv")
            selected=rows.loc[rows.site_id.isin(["A","B"])]
            self.assertTrue(selected.retained_source_count.eq(1).all())
            self.assertTrue(selected.excluded_related_ids.eq("A|B|external-linked").all())
            self.assertEqual(bank["status"]["completed_folds"],36)


if __name__=="__main__":
    unittest.main()
