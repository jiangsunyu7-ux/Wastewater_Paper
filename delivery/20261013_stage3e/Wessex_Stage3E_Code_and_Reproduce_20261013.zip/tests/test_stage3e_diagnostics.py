import numpy as np
import pandas as pd
import unittest

from wastewater.stage3e_diagnostics import (interval_components, left_quantiles,
    weighted_distribution, weighted_ks, distribution_summary, station_metrics,
    influence, equal_site_window_segment_summary)


def test_interval_score_independent_components():
    score,width,lower,upper=interval_components([0,2,4],[1,1,1],[3,3,3],.9)
    np.testing.assert_allclose(score,[22,2,22]);np.testing.assert_allclose(width,[2,2,2])
    np.testing.assert_allclose(lower,[20,0,0]);np.testing.assert_allclose(upper,[0,0,20])


def test_left_quantiles_zero_and_noninterpolation():
    np.testing.assert_array_equal(left_quantiles([0,0,2,9],[0,.5,.8,1]),[0,0,9,9])
    assert left_quantiles([0,3], [.5], [1,1])[0]==0
    with unittest.TestCase().assertRaises(ValueError):left_quantiles([], [.9])


def test_weighted_ks_is_single_descriptive_distance():
    a=weighted_distribution([0,1],[3,1]);b=weighted_distribution([0,1],[1,3])
    assert weighted_ks(a,a)==0
    np.testing.assert_allclose(weighted_ks(a,b),.5)
    assert weighted_ks(a,b)==weighted_ks(b,a)


def test_signed_source_mean_keeps_zero_errors():
    d=distribution_summary([-1,0,3],[.25,.5,.25])
    assert d['n_errors']==3 and d['zero_error_count']==1
    np.testing.assert_allclose(d['mean_signed_error_normalized'],.5)
    np.testing.assert_allclose(d['mean_absolute_error_normalized'],1)


def test_influence_can_reverse_relative_and_raw_averages():
    m=pd.DataFrame([dict(site_id='large',constraint='raw',pool_id='P',budget=30,horizon=3,nominal_coverage=.9,method='MIXTURE',interval_score_m3=110,local_interval_score_m3=100,skill_vs_local=-.1),dict(site_id='small',constraint='raw',pool_id='P',budget=30,horizon=3,nominal_coverage=.9,method='MIXTURE',interval_score_m3=.5,local_interval_score_m3=1,skill_vs_local=.5)])
    contributions,leave=influence(m,{'primary_pool_id':'P'})
    np.testing.assert_allclose(contributions.equal_site_skill_contribution.sum(),.2)
    assert contributions.equal_site_score_change_contribution_m3.sum()>0
    assert not leave.excluded_from_formal_evaluation.any()


def test_equal_window_segment_summary_does_not_pool_longer_cells():
    rows=[]
    for site,episode,n,score in [('a','one',1,2),('a','two',10,4),('b','one',1,10),('b','two',10,10)]:
        r=dict(site_id=site,episode=episode,n_dates=n,segment='01-14',constraint='raw',pool_id='P',method='MIXTURE',budget=30,horizon=1,nominal_coverage=.9,skill_vs_local=0.)
        for col in ['interval_score_m3','mean_width_m3','median_width_m3','coverage','lower_miss_rate','upper_miss_rate','lower_penalty_m3','upper_penalty_m3']:r[col]=score
        rows.append(r)
    q=equal_site_window_segment_summary(pd.DataFrame(rows))
    np.testing.assert_allclose(q.iloc[0].equal_site_equal_window_interval_score_m3,6.5)


def load_tests(loader, tests, pattern):
    suite=unittest.TestSuite()
    for name,value in globals().items():
        if name.startswith('test_') and callable(value):suite.addTest(unittest.FunctionTestCase(value))
    return suite


if __name__=='__main__':unittest.main()
