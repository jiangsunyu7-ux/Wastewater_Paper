"""Cache integrity, explicit data exclusions and deterministic resumed tasks."""
import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
import pandas as pd
from wastewater.common import sha256
from wastewater.stage3d_intervals import local_distribution, persistence_with_dates
from wastewater.stage3d_experiment import (REQUIRED, expected_tasks, job_fingerprint,
    run_task, task_key, validate_job)


class Stage3DExperimentTests(unittest.TestCase):
    def test_partial_failed_zero_is_not_complete(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'status.json';p.write_text(json.dumps(dict(status='PARTIAL',failed=0,fingerprint='x')))
            self.assertFalse(validate_job(d,'x',1080))
            with self.assertRaises(ValueError):validate_job(d,'different',1080)

    def test_completed_checks_members_rows_and_hash(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            for name in REQUIRED:(p/name).write_text('actual fixture\n')
            state=dict(status='COMPLETED',fingerprint='x',prediction_rows=1080,
                       outputs_sha256={name:sha256(p/name) for name in REQUIRED})
            (p/'status.json').write_text(json.dumps(state))
            self.assertTrue(validate_job(p,'x',1080))
            with self.assertRaises(ValueError):validate_job(p,'x',1079)
            (p/'calibration.csv').write_text('modified')
            with self.assertRaises(ValueError):validate_job(p,'x',1080)

    def test_expected_registry_uses_planned_conditions(self):
        cfg=dict(smoke_ids=['13013','13015'],development_ids=[str(i) for i in range(10)],
            evaluation_origins=['2022-01-01','2022-07-01','2023-01-01','2023-07-01','2023-10-01'],
            budgets=[30,90,180],horizons=[1,3])
        self.assertEqual(len(expected_tasks(cfg,'smoke')),12)
        self.assertEqual(len(expected_tasks(cfg,'full')),300)

    def _run_fixture(self, zero=False):
        date='2022-01-01';site='fixture';h=3;budget=30
        index=pd.date_range('2021-12-02',periods=100)
        values=np.zeros(len(index)) if zero else 100+np.arange(len(index),dtype=float)%7
        s=pd.Series(values,index=index);origins=pd.date_range(date,periods=60);targets=origins+pd.Timedelta(days=h)
        persistence,_=persistence_with_dates(s,origins,h,pd.Timestamp('2021-12-02'),1.)
        cfg=dict(evaluation_days=60,pools=[dict(pool_id='pool',order_label=1)],
            methods=['LOCAL','SHARED','MIXTURE'],nominal_coverages=[.8,.9],min_calibration_scores=14,
            high_volume_history_days=30,high_volume_quantile=.9,qa_mode='published_good_only_retrospective',
            tolerances=dict(m3_atol=1e-8,m3_rtol=1e-12))
        bank=dict(final={h:local_distribution(np.arange(30)/100)},selected_gamma={'B30_H3':.5})
        reference=pd.DataFrame(dict(site_id=site,episode=date,budget=budget,horizon=h,
            origin=origins.strftime('%Y-%m-%d'),target_date=targets.strftime('%Y-%m-%d'),prediction_m3=persistence))
        common=pd.DataFrame(dict(site_id=site,episode=date,horizon=h,origin=origins.strftime('%Y-%m-%d'),
            target_date=targets.strftime('%Y-%m-%d'),common_evaluation=True)).set_index(['site_id','episode','horizon','origin','target_date'])
        quality=pd.DataFrame(dict(site_id=site,date=targets.strftime('%Y-%m-%d'),quality_flag='Good',
            target_quality_valid=1,conflict=0)).set_index(['site_id','date'])
        task=(site,date,budget,h)
        # Use an isolated temporary folder below the permitted execution root
        # so the task records retain valid repository-relative paths.
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1],prefix='.d-test-') as d:
            result=run_task(task,cfg,'fixture-signature',{'pool':bank},{site:s},common,reference,quality,Path(d))
            self.assertEqual(result['status'],'COMPLETED',result)
            folder=Path(d)/'jobs'/task_key(task)
            data=pd.read_csv(folder/'intervals.csv')
            self.assertEqual(len(data),360)
            self.assertEqual(data.calibration_status.unique().tolist(),['NO_VALID_SCALE'] if zero else ['VALID'])
            if zero:
                self.assertTrue(data.lower_m3.isna().all())
                self.assertFalse(data.evaluation_mask.any())
            before={name:sha256(folder/name) for name in REQUIRED}
            cached=run_task(task,cfg,'fixture-signature',{'pool':bank},{site:s},common,reference,quality,Path(d))
            self.assertEqual(cached['status'],'CACHED')
            self.assertEqual(before,{name:sha256(folder/name) for name in REQUIRED})
            with self.assertRaises(ValueError):
                validate_job(folder,job_fingerprint('changed',task,cfg),360)

    def test_real_task_fixture_and_validated_resume(self):self._run_fixture()

    def test_no_scale_records_explicit_exclusion_not_software_failure(self):self._run_fixture(zero=True)


if __name__=='__main__':unittest.main()
