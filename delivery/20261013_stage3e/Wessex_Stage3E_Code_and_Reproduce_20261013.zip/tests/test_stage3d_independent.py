"""Independent audit primitives: deliberately do not import Stage3D models."""
import importlib.util
from pathlib import Path
import unittest

import numpy as np
import pandas as pd

CHECKER = Path(__file__).resolve().parents[1] / "scripts/check_stage3d_results.py"
spec = importlib.util.spec_from_file_location("independent_stage3d_check", CHECKER)
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


class IndependentAuditPrimitives(unittest.TestCase):
    def test_step_quantile_retains_zero_and_exact_decimal_boundary(self):
        self.assertEqual(audit.weighted_quantile(np.arange(10), np.ones(10), .9), 8.)
        self.assertEqual(audit.weighted_quantile([0, 0, 1], [1, 1, 1], .5), 0.)

    def test_probability_weights_not_record_counts(self):
        # Two sites with one and nine observations still carry half each.
        v = np.r_[0., np.ones(9)]
        w = np.r_[.5, np.full(9, .5 / 9)]
        self.assertEqual(audit.weighted_quantile(v, w, .5), 0.)

    def test_gamma_endpoints_are_literal_baselines(self):
        local, shared, weights = np.array([0., 1., 5.]), np.array([2., 4., 9.]), np.array([.2, .4, .4])
        for c in [.8, .9]:
            self.assertEqual(audit.mixture_quantile(local, shared, weights, 0., c),
                             audit.weighted_quantile(local, np.ones(3), c))
            self.assertEqual(audit.mixture_quantile(local, shared, weights, 1., c),
                             audit.weighted_quantile(shared, weights, c))
        self.assertLessEqual(audit.mixture_quantile(local, shared, weights, .5, .8),
                             audit.mixture_quantile(local, shared, weights, .5, .9))

    def test_interval_score_components(self):
        q = audit.interval_score([-2., 0., 4.], [-1., -1., -1.], [2., 2., 2.], .9)
        np.testing.assert_allclose(q["score"], [23., 3., 43.])
        np.testing.assert_array_equal(q["covered"], [False, True, False])

    def test_no_valid_positive_scale_is_failure(self):
        s = pd.Series([0., 0., np.nan], index=pd.date_range("2021-01-01", periods=3))
        self.assertTrue(np.isnan(audit.legal_scale(s, s.index.min(), s.index.max())))
        self.assertEqual(len(audit.allowed_errors(s, s.index.min(), s.index.max(), 1)["values"]), 0)

    def test_h3_labels_and_budget_left_boundary(self):
        s = pd.Series(np.arange(1., 31.), index=pd.date_range("2021-01-01", periods=30))
        q = audit.allowed_errors(s, "2021-01-10", "2021-01-20", 3)
        self.assertEqual(len(q["values"]), 8)
        self.assertEqual(q["origins"].min(), pd.Timestamp("2021-01-10"))
        self.assertEqual(q["targets"].max(), pd.Timestamp("2021-01-20"))
        np.testing.assert_array_equal((q["targets"] - q["origins"]).days, np.repeat(3, 8))

    def test_future_and_left_warmup_mutations_do_not_change_calibration(self):
        s = pd.Series(np.arange(1., 51.), index=pd.date_range("2021-01-01", periods=50))
        a = audit.allowed_errors(s, "2021-01-10", "2021-01-30", 3)
        modified = s.copy()
        modified.loc[:"2021-01-09"] = 1e10
        modified.loc["2021-01-31":] = -1e10
        b = audit.allowed_errors(modified, "2021-01-10", "2021-01-30", 3)
        np.testing.assert_array_equal(a["values"], b["values"])
        self.assertEqual(a["scale"], b["scale"])

    def test_missing_current_persistence_uses_only_legal_lookback(self):
        s = pd.Series(np.arange(1., 20.), index=pd.date_range("2021-01-01", periods=19))
        s.loc["2021-01-10":"2021-01-18"] = np.nan
        p, dates = audit.persistence(s, ["2021-01-10", "2021-01-18"], "2021-01-10")
        self.assertTrue(np.isnan(p).all())
        self.assertTrue(dates.isna().all())


if __name__ == "__main__":
    unittest.main()
