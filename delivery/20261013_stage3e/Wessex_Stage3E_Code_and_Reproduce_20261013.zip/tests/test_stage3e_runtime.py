"""Controlled persistence faults, bounded resume and unchanged Stage3D science."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import pandas as pd

from wastewater.common import sha256
from wastewater import stage3d_experiment as science
from wastewater.stage3d_intervals import local_distribution, persistence_with_dates
from wastewater.stage3e_runtime import (FingerprintMismatch, atomic_bytes, atomic_json,
    atomic_science_writes, collect_manifest, run_reliably, verify_outputs)


class Stage3ERuntimeTests(unittest.TestCase):
    def fixture(self, root, task=('13013','2022-01-01',30,3)):
        site,date,budget,h=task
        index=pd.date_range('2021-07-01','2022-04-30')
        values=100+np.arange(len(index),dtype=float)%7
        series={site:pd.Series(values,index=index)}
        origins=pd.date_range(date,periods=60);targets=origins+pd.Timedelta(days=h)
        p,_=persistence_with_dates(series[site],origins,h,pd.Timestamp(date)-pd.Timedelta(days=budget),1.)
        cfg=dict(evaluation_days=60,pools=[dict(pool_id='pool',order_label=1)],methods=['LOCAL','SHARED','MIXTURE'],
            nominal_coverages=[.8,.9],min_calibration_scores=14,high_volume_history_days=30,high_volume_quantile=.9,
            qa_mode='published_good_only_retrospective',tolerances=dict(m3_atol=1e-8,m3_rtol=1e-12))
        banks={'pool':dict(final={h:local_distribution(np.arange(30)/100)},selected_gamma={f'B{budget}_H{h}':.5})}
        ref=pd.DataFrame(dict(site_id=site,episode=date,budget=budget,horizon=h,origin=origins.strftime('%Y-%m-%d'),
            target_date=targets.strftime('%Y-%m-%d'),prediction_m3=p))
        common=pd.DataFrame(dict(site_id=site,episode=date,horizon=h,origin=origins.strftime('%Y-%m-%d'),
            target_date=targets.strftime('%Y-%m-%d'),common_evaluation=True)).set_index(['site_id','episode','horizon','origin','target_date'])
        quality=pd.DataFrame(dict(site_id=site,date=targets.strftime('%Y-%m-%d'),quality_flag='Good',target_quality_valid=1,conflict=0)).set_index(['site_id','date'])
        signature='fixture-original-D-signature';runtime='fixture-E-signature'
        def execute():
            with atomic_science_writes(root):
                return science.run_task(task,cfg,signature,banks,series,common,ref,quality,Path(root))
        return task,cfg,signature,runtime,execute

    def run_fixture(self, root):
        args=self.fixture(root)
        result=run_reliably(*args[:4],root,args[4])
        self.assertTrue(result['disk_verified_completed'])
        return args,result,Path(root)/'jobs'/science.task_key(args[0])

    def test_atomic_exact_bytes_flush_fsync_readback(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'value.csv'
            with patch('wastewater.stage3e_runtime.os.fsync', wraps=__import__('os').fsync) as spy:
                digest=atomic_bytes(p,b'actual\nbytes\n')
            self.assertEqual(digest,sha256(p));self.assertGreaterEqual(spy.call_count,2)
            self.assertEqual(p.read_bytes(),b'actual\nbytes\n')

    def test_interrupted_before_replace_preserves_old_bytes(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'status.json';atomic_bytes(p,b'old')
            def fault(stage,path):
                if stage=='before_replace':raise OSError('controlled interruption')
            with self.assertRaises(OSError):atomic_bytes(p,b'new',fault)
            self.assertEqual(p.read_bytes(),b'old');self.assertEqual(list(Path(d).glob('*.tmp')),[])

    def test_interrupted_after_replace_is_not_returned_as_success(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'status.json'
            def fault(stage,path):
                if stage=='after_replace':raise OSError('controlled post-replace interruption')
            with self.assertRaises(OSError):atomic_bytes(p,b'new',fault)
            self.assertEqual(p.read_bytes(),b'new')

    def test_real_frozen_science_adapter_and_repeat_resume(self):
        with tempfile.TemporaryDirectory() as d:
            args,result,folder=self.run_fixture(d)
            before={n:sha256(folder/n) for n in science.REQUIRED}
            repeated=run_reliably(*args[:4],d,args[4])
            self.assertEqual(repeated['status'],'CACHED_VERIFIED');self.assertEqual(repeated['function_returns'],[])
            self.assertEqual(before,{n:sha256(folder/n) for n in science.REQUIRED})

    def test_stale_running_recomputes_and_preserves_recovery_evidence(self):
        with tempfile.TemporaryDirectory() as d:
            args,_,folder=self.run_fixture(d)
            before={n:sha256(folder/n) for n in science.REQUIRED}
            state=json.loads((folder/'status.json').read_text());state['status']='RUNNING';atomic_json(folder/'status.json',state)
            result=run_reliably(*args[:4],d,args[4])
            self.assertEqual(result['status'],'COMPLETED_VERIFIED')
            self.assertEqual(before,{n:sha256(folder/n) for n in science.REQUIRED})
            self.assertTrue(list((Path(d)/'recovery_evidence').rglob('status.json')))
            self.assertIn('RECOVERY_REQUIRED',(Path(d)/'failure_events.jsonl').read_text())

    def test_missing_output_never_reuses_cache(self):
        with tempfile.TemporaryDirectory() as d:
            args,_,folder=self.run_fixture(d);(folder/'calibration.csv').unlink()
            result=run_reliably(*args[:4],d,args[4]);self.assertTrue(result['disk_verified_completed'])
            self.assertEqual(result['status'],'COMPLETED_VERIFIED')
            self.assertIn('MISSING_OUTPUT',(Path(d)/'failure_events.jsonl').read_text())

    def test_corrupt_output_never_reuses_cache(self):
        with tempfile.TemporaryDirectory() as d:
            args,_,folder=self.run_fixture(d);(folder/'intervals.csv').write_bytes(b'corrupted')
            result=run_reliably(*args[:4],d,args[4]);self.assertTrue(result['disk_verified_completed'])
            self.assertIn('OUTPUT_SHA_MISMATCH',(Path(d)/'failure_events.jsonl').read_text())

    def test_wrong_fingerprint_refused_without_overwrite(self):
        with tempfile.TemporaryDirectory() as d:
            args,_,folder=self.run_fixture(d)
            state=json.loads((folder/'status.json').read_text());state['fingerprint']='different';atomic_json(folder/'status.json',state)
            before=sha256(folder/'status.json')
            with self.assertRaises(FingerprintMismatch):run_reliably(*args[:4],d,args[4])
            self.assertEqual(before,sha256(folder/'status.json'))

    def test_actual_row_counts_not_only_hash_receipt(self):
        with tempfile.TemporaryDirectory() as d:
            args,_,folder=self.run_fixture(d)
            frame=pd.read_csv(folder/'intervals.csv');frame.iloc[:-1].to_csv(folder/'intervals.csv',index=False)
            state=json.loads((folder/'status.json').read_text());state['outputs_sha256']['intervals.csv']=sha256(folder/'intervals.csv')
            atomic_json(folder/'status.json',state)
            evidence=verify_outputs(folder,science.job_fingerprint(args[2],args[0],args[1]),args[0],args[1])
            self.assertFalse(evidence['valid']);self.assertEqual(evidence['reason'],'OUTPUT_CONTENT_INVALID')

    def test_controlled_status_commit_fault_bounded_resume(self):
        with tempfile.TemporaryDirectory() as d:
            args=self.fixture(d);count=[0]
            def injected(path,state):
                count[0]+=1
                if count[0]==1:raise OSError('controlled final status failure; not observed natural root cause')
            def execute():
                with atomic_science_writes(d,injected_status_fault=injected):
                    return args[4]()
            # Nested adapters restore in order; inner adapter would mask fault.
            # Inject by patching the final atomic primitive instead.
            original=atomic_json
            def fail_once(path,value,*a,**kw):
                if Path(path).name=='status.json' and value.get('status')=='COMPLETED':injected(path,value)
                return original(path,value,*a,**kw)
            with patch('wastewater.stage3e_runtime.atomic_json',fail_once):
                result=run_reliably(*args[:4],d,args[4])
            self.assertEqual(result['attempts'],2);self.assertEqual(len(result['failures']),1)
            self.assertTrue(result['disk_verified_completed'])

    def test_function_success_with_missing_disk_is_failed_and_bounded(self):
        with tempfile.TemporaryDirectory() as d:
            args=self.fixture(d);count=[0]
            def fake_success():count[0]+=1;return dict(status='COMPLETED',task=science.task_key(args[0]))
            result=run_reliably(*args[:4],d,fake_success)
            self.assertEqual(count[0],2);self.assertEqual(result['function_return_success_count'],2)
            self.assertFalse(result['disk_verified_completed'])
            self.assertEqual(json.loads((Path(d)/'jobs'/science.task_key(args[0])/'runtime_status.json').read_text())['status'],'FAILED')

    def test_partial_failed_zero_is_not_completed(self):
        with tempfile.TemporaryDirectory() as d:
            args,result,_=self.run_fixture(d)
            absent=('13015','2022-01-01',30,3)
            m=collect_manifest([args[0],absent],args[1],args[2],args[3],d,[result])
            self.assertEqual(m['status'],'PARTIAL');self.assertEqual(m['failed_this_call'],0)
            self.assertEqual(m['disk_verified_completed'],1);self.assertEqual(m['expected_tasks'],2)

    def test_attempt_limit_cannot_expand(self):
        with tempfile.TemporaryDirectory() as d:
            args=self.fixture(d)
            with self.assertRaises(ValueError):run_reliably(*args[:4],d,args[4],max_attempts=3)

    def test_adapter_does_not_touch_original_science_code(self):
        code=Path(science.__file__);before=sha256(code)
        with tempfile.TemporaryDirectory() as d:self.run_fixture(d)
        self.assertEqual(before,sha256(code))


if __name__=='__main__':unittest.main()
