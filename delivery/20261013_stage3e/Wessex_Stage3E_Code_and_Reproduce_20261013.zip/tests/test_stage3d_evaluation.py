"""Small synthetic software fixtures, not scientific experiment results."""
import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

from wastewater.stage3d_evaluation import (aggregate_station_metrics,interval_score,
    paired_block_intervals,prepare_intervals,station_metrics,summarize_intervals)


class Stage3DEvaluationTests(unittest.TestCase):
    def config(self):
        return dict(development_ids=['a','b'],origins=['2022-01-01','2023-10-01'],
           budgets=[30,90,180],horizons=[1,3],evaluation_days=4,
           pools=[dict(pool_id='order20261012_K30',order_label=20261012,k=30),
                  dict(pool_id='order20261013_K30',order_label=20261013,k=30)],
           nominal_coverages=[.8,.9],min_calibration_scores=14,gammas=[0,.25,.5,.75,1],
           bootstrap=dict(blocks=[2],replicates=30,seed=20261012))

    def intervals(self):
        cfg=self.config();rows=[]
        for site,volume,scale,improvement in [('a',10.,1.,.5),('b',1000.,100.,1.5)]:
            for episode in cfg['origins']:
                for budget in cfg['budgets']:
                    for horizon in cfg['horizons']:
                        for day in pd.date_range(episode,periods=cfg['evaluation_days']):
                            for pool in cfg['pools']:
                                for coverage in cfg['nominal_coverages']:
                                    for method in ['LOCAL','SHARED','MIXTURE']:
                                        radius=scale*(.75 if coverage==.8 else 1)*(1 if method=='LOCAL' else improvement)
                                        rows.append(dict(site_id=site,episode=episode,budget=budget,horizon=horizon,
                                           origin=str(day.date()),target_date=str((day+pd.Timedelta(days=horizon)).date()),
                                           pool_id=pool['pool_id'],method=method,nominal_coverage=coverage,
                                           truth_m3=volume,persistence_m3=volume,lower_m3=volume-radius,upper_m3=volume+radius,
                                           gamma=0 if method=='LOCAL' else 1 if method=='SHARED' else .5,
                                           scale_m3=scale,calibration_samples=25,calibration_status='VALID',
                                           calibration_start=str((pd.Timestamp(episode)-pd.Timedelta(days=budget)).date()),
                                           calibration_end=str((pd.Timestamp(episode)-pd.Timedelta(days=1)).date()),
                                           calibration_latest_target=str((pd.Timestamp(episode)-pd.Timedelta(days=1)).date()),
                                           calibration_latest_input_date=str((pd.Timestamp(episode)-pd.Timedelta(days=1+horizon)).date()),
                                           latest_input_date=str(day.date()),high_threshold_m3=volume,evaluation_mask_c2=True))
        return pd.DataFrame(rows)

    def daily(self,p):
        p=p[p.common_evaluation].copy();p['constraint']='raw';p['evaluation_set']='five_used_development_windows'
        score,width,lp,up=interval_score(p.truth_m3,p.lower_m3,p.upper_m3,p.nominal_coverage)
        p['interval_score_m3']=score;p['width_m3']=width;p['lower_penalty_m3']=lp;p['upper_penalty_m3']=up
        p['covered']=(p.truth_m3>=p.lower_m3)&(p.truth_m3<=p.upper_m3)
        p['lower_miss']=p.truth_m3<p.lower_m3;p['upper_miss']=p.truth_m3>p.upper_m3
        return p

    def test_interval_score_formula_and_boundary_inclusion(self):
        score,width,lp,up=interval_score([0,5,12],[2,2,2],[8,8,8],.9)
        np.testing.assert_allclose(score,[46,6,86]);np.testing.assert_allclose(width,6)
        np.testing.assert_allclose(lp,[40,0,0]);np.testing.assert_allclose(up,[0,0,80])
        self.assertEqual(float(interval_score(2,2,8,.8)[0]),6.)
        with self.assertRaises(ValueError):interval_score(2,8,2,.9)

    def test_expected_calendar_and_missing_software_rows_are_not_silently_removed(self):
        frame=self.intervals();prepared=prepare_intervals(frame,self.config())
        self.assertEqual(len(prepared),len(frame));self.assertTrue(prepared.common_evaluation.all())
        with self.assertRaisesRegex(ValueError,'Missing/unregistered'):prepare_intervals(frame.iloc[1:],self.config())

    def test_gamma_endpoints_nesting_and_uniform_clipping(self):
        p=self.intervals();mix=p.method.eq('MIXTURE');p.loc[mix,'gamma']=0
        p.loc[mix,'lower_m3']=p.loc[mix,'persistence_m3']-p.loc[mix,'scale_m3']*np.where(p.loc[mix,'nominal_coverage'].eq(.8),.75,1)
        p.loc[mix,'upper_m3']=2*p.loc[mix,'persistence_m3']-p.loc[mix,'lower_m3']
        prepare_intervals(p,self.config())
        p.loc[p[mix].index[0],'lower_m3']+=.01
        with self.assertRaises(ValueError):prepare_intervals(p,self.config())
        p=self.intervals();p.loc[0,'lower_nonnegative_m3']=0.
        p['lower_nonnegative_m3']=np.maximum(0,p.lower_m3);p.loc[0,'lower_nonnegative_m3']+=1.
        with self.assertRaisesRegex(ValueError,'clipping'):prepare_intervals(p,self.config())
        p=self.intervals();n=p.nominal_coverage.eq(.8)
        p.loc[n,'lower_m3']-=200;p.loc[n,'upper_m3']+=200
        with self.assertRaisesRegex(ValueError,'contained'):prepare_intervals(p,self.config())

    def test_labels_input_budget_and_final_year_guards(self):
        for column,value in [('calibration_latest_target','2022-01-01'),
                             ('calibration_start','2021-11-01'),('latest_input_date','2022-01-02')]:
            p=self.intervals();p.loc[0,column]=value
            with self.assertRaises(ValueError):prepare_intervals(p,self.config())
        cfg=self.config();cfg['origins']=['2024-01-01']
        with self.assertRaisesRegex(ValueError,'2024'):prepare_intervals(self.intervals(),cfg)

    def test_insufficient_calibration_excludes_only_condition_and_explicit_cross_budget_pair(self):
        p=self.intervals();q=p.site_id.eq('a')&p.episode.eq('2022-01-01')&p.budget.eq(30)&p.horizon.eq(1)
        p.loc[q,'calibration_samples']=5;p.loc[q,'calibration_status']='INSUFFICIENT_CALIBRATION'
        p.loc[q,['lower_m3','upper_m3']]=np.nan
        prepared=prepare_intervals(p,self.config())
        excluded=prepared.site_id.eq('a')&prepared.episode.eq('2022-01-01')&prepared.budget.eq(30)&prepared.horizon.eq(1)
        self.assertFalse(prepared[excluded].common_evaluation.any())
        legal=prepared.site_id.eq('a')&prepared.budget.eq(90)&prepared.horizon.eq(1)
        self.assertTrue(prepared[legal].common_evaluation.all())
        ci,pairs,index=paired_block_intervals(self.daily(prepared),self.config(),progress=lambda *a,**k:None)
        cross=pairs[pairs.site_id.eq('a')&pairs.budget.eq(30)&pairs.reference_budget.eq(90)&pairs.horizon.eq(1)]
        self.assertTrue(cross.n_dates.eq(4).all())
        self.assertTrue((~index[index.site_id.eq('a')&index.episode.eq('2022-01-01')&index.horizon.eq(1)&index.comparison_id.str.contains('MIXTURE_B30')].paired_evaluation).all())

    def test_site_skill_is_equal_weight_not_pooled_volume_ratio(self):
        cfg=self.config();metric=station_metrics(self.daily(prepare_intervals(self.intervals(),cfg)),cfg)
        summary=aggregate_station_metrics(metric)
        row=summary[summary.constraint.eq('raw')&summary.pool_id.eq('order20261012_K30')&summary.budget.eq(30)&summary.horizon.eq(1)&summary.method.eq('MIXTURE')&summary.nominal_coverage.eq(.9)].iloc[0]
        self.assertAlmostEqual(row.mean_skill,0.)
        self.assertEqual(row.winning_stations,1);self.assertEqual(row.negative_transfer_stations,1)
        self.assertNotAlmostEqual(row.mean_skill,1-151/101)

    def test_zero_reference_is_explicitly_undefined_without_epsilon(self):
        p=self.intervals();q=p.site_id.eq('a')&p.method.eq('LOCAL')
        p.loc[q,'lower_m3']=p.loc[q,'persistence_m3'];p.loc[q,'upper_m3']=p.loc[q,'persistence_m3']
        metric=station_metrics(self.daily(prepare_intervals(p,self.config())),self.config())
        q=metric[metric.site_id.eq('a')&metric.constraint.eq('raw')]
        self.assertTrue(q.zero_reference_score.all());self.assertTrue(q.skill_vs_local.isna().all())
        self.assertTrue(q.absolute_score_improvement_m3.notna().all())

    def test_two_primary_comparisons_bonferroni_and_partial_not_completed(self):
        cfg=self.config();p=prepare_intervals(self.intervals(),cfg)
        ci,_,_=paired_block_intervals(self.daily(p),cfg,progress=lambda *a,**k:None)
        primary=ci[ci.co_primary];self.assertEqual(len(primary),2)
        np.testing.assert_allclose(primary.confidence_level,.975)
        np.testing.assert_allclose(primary.mean_station_skill,0.)
        self.assertTrue((primary.lower_ci<=primary.lower_95).all());self.assertTrue((primary.upper_ci>=primary.upper_95).all())
        with tempfile.TemporaryDirectory() as tmp:
            summarize_intervals(self.intervals(),cfg,tmp,progress=lambda *a,**k:None)
            state=json.loads((Path(tmp)/'evaluation_validation.json').read_text())
            self.assertEqual(state['status'],'PARTIAL');self.assertTrue(state['evaluation_outputs_complete'])


if __name__=='__main__':unittest.main()
