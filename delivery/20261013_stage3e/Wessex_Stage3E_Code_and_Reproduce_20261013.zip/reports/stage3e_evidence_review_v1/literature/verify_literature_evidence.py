"""Verify captured bibliographic/quote evidence, not scientific completeness."""
import csv
import hashlib
import html
import json
import re
from pathlib import Path


def main():
    directory = Path(__file__).resolve().parent
    report = directory.parent
    manifest = json.loads((directory / 'EVIDENCE_MANIFEST.json').read_text())
    rows = list(csv.DictReader((report / 'LITERATURE_EVIDENCE.csv').open(newline='', encoding='utf-8')))
    assert len(rows) == manifest['papers_reviewed'] == 7
    for item in manifest['sources']:
        local = report / item['delivery_relative_path']
        assert local.stat().st_size == item['bytes'], local
        assert hashlib.sha256(local.read_bytes()).hexdigest() == item['sha256'], local
    abstracts = {x['doi'].lower(): x['abstract'] for x in json.loads((directory / 'publisher_deposited_abstracts_original.json').read_text())}
    for row in rows:
        crossref = json.loads((directory / (row['record_id'] + '_crossref_metadata.json')).read_text())['message']
        assert row['doi'].lower() == crossref['DOI'].lower()
        assert row['title'] == crossref['title'][0]
        evidence = report / row['captured_evidence_file']
        assert hashlib.sha256(evidence.read_bytes()).hexdigest() == row['captured_evidence_sha256']
        if row['quote_location'] == 'Crossref title field':
            assert row['verification_level'] == 'metadata_verified_only'
            text = crossref['title'][0]
        else:
            text = abstracts[row['doi'].lower()]
            captured = ' '.join(html.unescape(re.sub('<[^>]*>', '', crossref['abstract'])).split())
            assert captured == ' '.join(text.split()), row['record_id']
        assert row['evidence_quote'] in text
        assert row['future_fulltext_needed']
    receipt = {'stage': 'stage3e_evidence_review_v1', 'status': 'PASSED', 'rows': len(rows), 'source_files': len(manifest['sources']), 'titles_and_dois_verified': len(rows), 'quotes_match_actual_source': len(rows), 'publisher_deposited_abstracts_match_crossref': 4, 'not_a_claim_that_all_fulltexts_were_read': True, 'old_scientific_files_modified': False}
    (directory / 'LITERATURE_VERIFY.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__':
    main()
