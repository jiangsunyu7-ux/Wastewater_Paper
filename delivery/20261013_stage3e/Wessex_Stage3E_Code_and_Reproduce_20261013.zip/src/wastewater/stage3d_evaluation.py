"""Evaluate fixed-centre empirical intervals on the frozen C2 development calendar.

No model or quantile fitting occurs here. LOCAL references repeated across source
pools are checked for identity, never treated as extra independent facilities.
The old, verified C2 calendar/SiteID resampling primitive is reused unchanged.
"""
from __future__ import annotations

import itertools
import json
import time
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

from .common import sha256, utc_now, write_json
from .stage3c2_evaluation import bootstrap_station_means, calendar_draw_indices

METHODS = ('LOCAL', 'SHARED', 'MIXTURE')
KEYS = ['site_id', 'episode', 'horizon', 'origin', 'target_date']
CONDITION_KEYS = ['site_id', 'episode', 'budget', 'horizon']
ROW_KEYS = KEYS + ['budget', 'pool_id', 'method', 'nominal_coverage']
TIE_TOLERANCE = 1e-12
NUMERIC_ATOL_M3 = 1e-8
NUMERIC_RTOL = 1e-12


def _mean(values, axis=None):
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', RuntimeWarning)
        return np.nanmean(values, axis=axis)


def interval_score(truth, lower, upper, nominal_coverage):
    """Return proper interval score and its separately auditable components."""
    y, l, u = np.broadcast_arrays(np.asarray(truth, float), np.asarray(lower, float), np.asarray(upper, float))
    c = np.asarray(nominal_coverage, float)
    if np.any((c <= 0) | (c >= 1)):
        raise ValueError('Nominal coverage must be strictly between zero and one')
    if np.any(np.isfinite(l) & np.isfinite(u) & (l > u)):
        raise ValueError('Interval lower bound exceeds upper bound')
    width = u-l
    lower_penalty = 2/(1-c)*np.maximum(l-y, 0)
    upper_penalty = 2/(1-c)*np.maximum(y-u, 0)
    return width+lower_penalty+upper_penalty, width, lower_penalty, upper_penalty


def pools(cfg):
    result = []
    for p in cfg.get('pools', cfg.get('source_pools', [])):
        result.append(dict(pool_id=str(p['pool_id']), order_label=str(p['order_label']),
                           k=int(p.get('k', 30))))
    if not result or len({p['pool_id'] for p in result}) != len(result):
        raise ValueError('Explicit, distinct frozen source-pool registry required')
    return result


def coverages(cfg):
    return list(map(float, cfg.get('nominal_coverages', cfg.get('coverages', [.8, .9]))))


def episodes(cfg):
    result = cfg.get('evaluation_origins', cfg.get('origins', []))
    if not result or len(set(result)) != len(result):
        raise ValueError('Explicit unique development episodes required')
    for t in result:
        last = pd.Timestamp(t)+pd.Timedelta(days=int(cfg['evaluation_days'])-1+max(cfg['horizons']))
        if last > pd.Timestamp('2023-12-31'):
            raise ValueError('2024--2025 performance is forbidden')
    return list(result)


def _resolve(path):
    p = Path(path)
    return p if p.is_absolute() else Path(__file__).resolve().parents[2]/p


def load_c2_calendar(cfg):
    path = cfg.get('c2_common_dates',cfg.get('c2_paired_index', cfg.get('c2_paired_evaluation_index')))
    if not path:
        return None
    table = pd.read_csv(_resolve(path), dtype={'site_id': str}, low_memory=False)
    required = KEYS+['common_evaluation', 'truth_m3', 'high_threshold_m3']
    if not set(required) <= set(table):
        raise ValueError('C2 calendar is missing mandatory fields')
    if table.duplicated(KEYS).any():
        raise ValueError('Duplicate date in frozen C2 calendar')
    return table[required].rename(columns={'common_evaluation': 'evaluation_mask_c2',
                                           'truth_m3': 'c2_truth_m3',
                                           'high_threshold_m3': 'c2_high_threshold_m3'})


def _bool(series):
    if pd.api.types.is_bool_dtype(series):
        return series
    if series.isna().any():
        raise ValueError('Missing boolean status field')
    mapping = {'true': True, 'false': False, '1': True, '0': False}
    converted = series.astype(str).str.lower().map(mapping)
    if converted.isna().any():
        raise ValueError('Unrecognised boolean status field')
    return converted.astype(bool)


def prepare_intervals(frame, cfg):
    """Validate all expected rows; software failures cannot disappear in a join.

    Permitted calibration exclusions apply to the entire SiteID-window-budget-h
    condition. Other budgets remain evaluable. Cross-budget comparisons later
    use their explicitly saved pair-specific calendar intersections.
    """
    aliases = {'prediction_m3': 'persistence_m3', 'point_prediction_m3': 'persistence_m3',
               'coverage': 'nominal_coverage', 'lower_raw_m3': 'lower_m3', 'upper_raw_m3': 'upper_m3',
               'lower_clipped_m3': 'lower_nonnegative_m3', 'local_calibration_samples': 'calibration_samples',
               'calibration_n': 'calibration_samples', 'latest_calibration_target': 'calibration_latest_target',
               'latest_calibration_input': 'calibration_latest_input_date'}
    p = frame.rename(columns={a:b for a,b in aliases.items() if a in frame and b not in frame}).copy()
    required = ROW_KEYS+['truth_m3', 'persistence_m3', 'lower_m3', 'upper_m3', 'gamma',
                        'scale_m3', 'calibration_samples', 'calibration_status', 'high_threshold_m3']
    if not set(required) <= set(p):
        raise ValueError('Missing interval fields: '+', '.join(sorted(set(required)-set(p))))
    p['site_id'] = p.site_id.astype(str); p['pool_id'] = p.pool_id.astype(str)
    p['method'] = p.method.astype(str).str.upper()
    for c in ['episode', 'origin', 'target_date']:
        p[c] = pd.to_datetime(p[c]).dt.strftime('%Y-%m-%d')
    for c in ['budget', 'horizon', 'calibration_samples']:
        p[c] = p[c].astype(int)
    p['nominal_coverage'] = p.nominal_coverage.astype(float)
    if p.duplicated(ROW_KEYS).any():
        raise ValueError('Duplicate interval row')
    registry = pd.DataFrame(pools(cfg))
    expected = pd.MultiIndex.from_product([list(map(str,cfg['development_ids'])), episodes(cfg), cfg['budgets'],
                cfg['horizons'], registry.pool_id, METHODS, coverages(cfg)],
                names=CONDITION_KEYS+['pool_id','method','nominal_coverage']).to_frame(index=False)
    length = int(cfg['evaluation_days'])
    expected = expected.loc[expected.index.repeat(length)].reset_index(drop=True)
    offsets = np.tile(np.arange(length), len(expected)//length)
    expected['origin'] = (pd.to_datetime(expected.episode)+pd.to_timedelta(offsets,unit='D')).dt.strftime('%Y-%m-%d')
    expected['target_date'] = (pd.to_datetime(expected.origin)+pd.to_timedelta(expected.horizon,unit='D')).dt.strftime('%Y-%m-%d')
    checked = expected[ROW_KEYS].merge(p, on=ROW_KEYS, how='outer', indicator=True, validate='one_to_one')
    if not checked._merge.eq('both').all():
        counts = checked._merge.value_counts().to_dict()
        raise ValueError('Missing/unregistered interval rows: '+str(counts))
    p = checked.drop(columns='_merge')
    if not (pd.to_datetime(p.target_date)-pd.to_datetime(p.origin)).dt.days.eq(p.horizon).all():
        raise ValueError('h=3 must be origin+3 single-day volume')
    if 'latest_input_date' in p and (pd.to_datetime(p.latest_input_date)>pd.to_datetime(p.origin)).any():
        raise ValueError('Deployment input later than origin')
    cutoff = pd.to_datetime(p.episode)-pd.Timedelta(days=1)
    left = pd.to_datetime(p.episode)-pd.to_timedelta(p.budget,unit='D')
    for col in ['calibration_latest_target', 'calibration_end']:
        if col in p and (pd.to_datetime(p[col])>cutoff).any():
            raise ValueError('Calibration label/end exceeds initial-history cutoff')
    for col in ['calibration_start', 'calibration_latest_input_date']:
        if col in p:
            dates = pd.to_datetime(p[col])
            if ((dates<left)|(dates>cutoff)).any():
                raise ValueError('Calibration input outside budget')
    for col in ['truth_m3','persistence_m3','high_threshold_m3']:
        bounds=p.groupby(KEYS)[col].agg(['min','max'])
        if ((bounds['max']-bounds['min']) > NUMERIC_ATOL_M3+NUMERIC_RTOL*bounds['min'].abs()).any():
            raise ValueError('Inconsistent common '+col)
    if not set(p.method) <= set(METHODS):
        raise ValueError('Unregistered interval method')
    for col in ['scale_m3','calibration_samples','calibration_status']:
        if p.groupby(CONDITION_KEYS)[col].nunique(dropna=False).gt(1).any():
            raise ValueError('Condition calibration differs across interval methods/pools: '+col)
    taskkeys = CONDITION_KEYS+['pool_id','method']
    for col in ['gamma','scale_m3','calibration_samples','calibration_status']:
        if p.groupby(taskkeys)[col].nunique(dropna=False).gt(1).any():
            raise ValueError('Deployment calibration/selection changed within 60 origins: '+col)
    nmin = int(cfg.get('min_calibration_scores',cfg.get('min_calibration_errors',cfg.get('min_calibration_samples',14))))
    valid = p.calibration_status.astype(str).str.upper().isin(['VALID','OK','COMPLETED'])
    permitted = ['VALID','OK','COMPLETED','INSUFFICIENT','INSUFFICIENT_CALIBRATION',
                 'INSUFFICIENT_CALIBRATION_ERRORS','NO_VALID_SCALE','INVALID_SCALE','NO_SCALE']
    if not p.calibration_status.astype(str).str.upper().isin(permitted).all():
        raise ValueError('Unexpected calibration status; software failures must be resolved/reported')
    if (valid & (p.calibration_samples.lt(nmin)|~np.isfinite(p.scale_m3)|p.scale_m3.le(0))).any():
        raise ValueError('Valid calibration has insufficient errors or invalid scale')
    p['calibration_valid'] = valid
    finitecentre=np.isfinite(p.persistence_m3)
    finitebounds=np.isfinite(p.lower_m3)&np.isfinite(p.upper_m3)
    if (valid & finitecentre & ~finitebounds).any():
        raise ValueError('Finite centre and valid calibration produced missing bounds')
    if (finitebounds & (p.lower_m3>p.upper_m3)).any():
        raise ValueError('Negative interval width')
    if not np.allclose((p.lower_m3+p.upper_m3)/2,p.persistence_m3,
                       atol=NUMERIC_ATOL_M3,rtol=NUMERIC_RTOL,equal_nan=True):
        # Legal insufficient calibration has no interval despite a finite centre.
        q=p[valid&finitecentre]
        if not np.allclose((q.lower_m3+q.upper_m3)/2,q.persistence_m3,atol=NUMERIC_ATOL_M3,rtol=NUMERIC_RTOL):
            raise ValueError('Interval centre is not fixed Persistence')
    clip=np.maximum(0.,p.lower_m3.to_numpy(float))
    if 'lower_nonnegative_m3' in p and not np.array_equal(p.lower_nonnegative_m3.to_numpy(float),clip,equal_nan=True):
        raise ValueError('Lower clipping is not uniformly max(0,lower)')
    p['lower_nonnegative_m3']=clip
    if not p.loc[p.method.eq('LOCAL'),'gamma'].eq(0).all() or not p.loc[p.method.eq('SHARED'),'gamma'].eq(1).all():
        raise ValueError('LOCAL/SHARED gamma endpoint declaration incorrect')
    if not p.loc[valid,'gamma'].isin(cfg.get('gammas',[0,.25,.5,.75,1])).all():
        raise ValueError('Gamma outside frozen grid')
    qkeys=CONDITION_KEYS+['origin','target_date','pool_id','nominal_coverage']
    for g,method in [(0.,'LOCAL'),(1.,'SHARED')]:
        a=p[p.method.eq('MIXTURE')&p.gamma.eq(g)]
        b=p[p.method.eq(method)]
        pair=a.merge(b[qkeys+['lower_m3','upper_m3']],on=qkeys,suffixes=('','_reference'),validate='one_to_one')
        for col in ['lower_m3','upper_m3']:
            if not np.array_equal(pair[col].to_numpy(float),pair[col+'_reference'].to_numpy(float),equal_nan=True):
                raise ValueError('Gamma endpoint is not exactly identical to '+method)
    # LOCAL is repeated for source-pool-matched references only.
    for col in ['lower_m3','upper_m3','gamma']:
        local=p[p.method.eq('LOCAL')].groupby(CONDITION_KEYS+['origin','target_date','nominal_coverage'])[col]
        if local.nunique(dropna=False).gt(1).any():
            raise ValueError('LOCAL reference differs across source pools')
    nested=p.pivot(index=CONDITION_KEYS+['origin','target_date','pool_id','method'],columns='nominal_coverage',values=['lower_m3','upper_m3'])
    if .8 in coverages(cfg) and .9 in coverages(cfg):
        if (nested['lower_m3'][.8]<nested['lower_m3'][.9]).any() or (nested['upper_m3'][.8]>nested['upper_m3'][.9]).any():
            raise ValueError('80% interval is not contained within 90% interval')
    calendar=load_c2_calendar(cfg)
    if calendar is not None:
        declared=p.pop('evaluation_mask_c2') if 'evaluation_mask_c2' in p else None
        p=p.merge(calendar,on=KEYS,how='left',validate='many_to_one')
        if p.evaluation_mask_c2.isna().any():
            raise ValueError('Interval origin not present in frozen C2 calendar')
        if declared is not None and not np.array_equal(_bool(declared).to_numpy(),_bool(p.evaluation_mask_c2).to_numpy()):
            raise ValueError('Declared C2 mask differs from saved original calendar')
        for col in ['truth_m3','high_threshold_m3']:
            old='c2_'+col
            if not np.allclose(p[col],p[old],atol=NUMERIC_ATOL_M3,rtol=NUMERIC_RTOL,equal_nan=True):
                raise ValueError('Interval truth/high threshold differs from C2: '+col)
    elif 'evaluation_mask_c2' not in p:
        raise ValueError('Frozen C2 mask must be supplied; no inferred intersection')
    p['evaluation_mask_c2']=_bool(p.evaluation_mask_c2)
    if cfg.get('c2_persistence_reference'):
        reference=pd.read_csv(_resolve(cfg['c2_persistence_reference']),dtype={'site_id':str},low_memory=False)
        refkeys=KEYS+['budget']
        reference=reference[refkeys+['prediction_m3']].rename(columns={'prediction_m3':'c2_persistence_m3'})
        p=p.merge(reference,on=refkeys,how='left',validate='many_to_one')
        if not np.allclose(p.persistence_m3,p.c2_persistence_m3,atol=NUMERIC_ATOL_M3,rtol=NUMERIC_RTOL,equal_nan=True):
            raise ValueError('Interval centre differs from original frozen Stage3C2 Persistence')
    if (p.evaluation_mask_c2 & (~np.isfinite(p.truth_m3)|~finitecentre)).any():
        raise ValueError('C2 evaluable day has missing truth or fixed centre')
    p['common_evaluation']=p.evaluation_mask_c2&p.calibration_valid
    p['exclusion_reason']=np.select([~p.evaluation_mask_c2,~p.calibration_valid],
       ['excluded_by_frozen_stage3c2_common_calendar','initial_calibration_'+p.calibration_status.astype(str)],default='')
    if p.groupby(KEYS+['budget']).common_evaluation.nunique().gt(1).any():
        raise ValueError('Methods/source pools do not have a common condition-specific evaluation mask')
    p['evaluation_set']='five_used_development_windows'
    p=p.drop(columns=[c for c in ['order_label','k'] if c in p]).merge(registry,on='pool_id',validate='many_to_one')
    return p


def _metric_registry(cfg,per_window):
    dimensions=[['five_used_development_windows'],['raw','all_methods_lower_nonnegative'],
                map(str,cfg['development_ids']),cfg['budgets'],cfg['horizons'],
                [p['pool_id'] for p in pools(cfg)],METHODS,coverages(cfg)]
    names=['evaluation_set','constraint','site_id','budget','horizon','pool_id','method','nominal_coverage']
    result=pd.MultiIndex.from_product(dimensions,names=names).to_frame(index=False)
    if per_window:
        result=result.merge(pd.DataFrame({'episode':episodes(cfg)}),how='cross')
    return result


def station_metrics(daily,cfg,per_window=False):
    keys=['evaluation_set','constraint','site_id','pool_id','method','budget','horizon','nominal_coverage']
    if per_window: keys.insert(2,'episode')
    metric=daily.groupby(keys).agg(n_dates=('interval_score_m3','size'),
      interval_score_m3=('interval_score_m3','mean'),mean_width_m3=('width_m3','mean'),
      median_width_m3=('width_m3','median'),coverage=('covered','mean'),
      lower_miss_rate=('lower_miss','mean'),upper_miss_rate=('upper_miss','mean'),
      width_term_m3=('width_m3','mean'),lower_penalty_m3=('lower_penalty_m3','mean'),
      upper_penalty_m3=('upper_penalty_m3','mean')).reset_index()
    metric=_metric_registry(cfg,per_window).merge(metric,on=keys,how='left',validate='one_to_one')
    metric['n_dates']=metric.n_dates.fillna(0).astype(int)
    metric['coverage_minus_nominal']=metric.coverage-metric.nominal_coverage
    metric['miss_penalty_m3']=metric.lower_penalty_m3+metric.upper_penalty_m3
    refkeys=[c for c in keys if c!='method']
    ref=metric[metric.method.eq('LOCAL')][refkeys+['interval_score_m3']].rename(columns={'interval_score_m3':'local_interval_score_m3'})
    metric=metric.merge(ref,on=refkeys,validate='many_to_one')
    metric['zero_reference_score']=metric.local_interval_score_m3.eq(0)
    metric['skill_vs_local']=1-metric.interval_score_m3/metric.local_interval_score_m3.where(metric.local_interval_score_m3.gt(0))
    metric['absolute_score_improvement_m3']=metric.local_interval_score_m3-metric.interval_score_m3
    return metric.merge(pd.DataFrame(pools(cfg)),on='pool_id',validate='many_to_one')


def aggregate_station_metrics(metric,per_window=False):
    keys=['evaluation_set','constraint','pool_id','order_label','k','method','budget','horizon','nominal_coverage']
    if per_window: keys.insert(2,'episode')
    rows=[]
    for values,g in metric.groupby(keys,sort=True):
        skill=g.skill_vs_local.dropna(); n=len(skill)
        wins=int(skill.gt(TIE_TOLERANCE).sum());loss=int(skill.lt(-TIE_TOLERANCE).sum());ties=n-wins-loss
        row=dict(zip(keys,values),stations=len(g),stations_with_dates=int(g.n_dates.gt(0).sum()),
             defined_skill_stations=n,mean_skill=float(skill.mean()),median_skill=float(skill.median()),
             winning_stations=wins,tied_stations=ties,negative_transfer_stations=loss,
             win_fraction=wins/n if n else np.nan,tie_fraction=ties/n if n else np.nan,
             negative_transfer_fraction=loss/n if n else np.nan,zero_reference_stations=int(g.zero_reference_score.sum()),
             min_dates=int(g.n_dates.min()),max_dates=int(g.n_dates.max()))
        for col in ['interval_score_m3','mean_width_m3','median_width_m3','coverage','coverage_minus_nominal',
                    'lower_miss_rate','upper_miss_rate','width_term_m3','lower_penalty_m3','upper_penalty_m3',
                    'miss_penalty_m3','absolute_score_improvement_m3']:
            row['equal_station_'+col]=float(g[col].mean())
        rows.append(row)
    return pd.DataFrame(rows)


def comparisons(cfg):
    result=[]
    main=cfg.get('primary_pool_id','order20261012_K30')
    for p,b,h,c in itertools.product(pools(cfg),cfg['budgets'],cfg['horizons'],coverages(cfg)):
        pool=p['pool_id']
        for method,ref in [('SHARED','LOCAL'),('MIXTURE','LOCAL'),('MIXTURE','SHARED')]:
            result.append(dict(pool_id=pool,method=method,budget=b,reference_method=ref,reference_budget=b,
                horizon=h,nominal_coverage=c,kind='same_budget_vs_'+ref.lower(),
                prespecified_primary=pool==main and b==30 and c==.9 and method=='MIXTURE' and ref=='LOCAL'))
    for p,(b,rb),h,c in itertools.product(pools(cfg),[(30,90),(30,180),(90,180)],cfg['horizons'],coverages(cfg)):
        if b in cfg['budgets'] and rb in cfg['budgets']:
            result.append(dict(pool_id=p['pool_id'],method='MIXTURE',budget=b,reference_method='LOCAL',
                 reference_budget=rb,horizon=h,nominal_coverage=c,kind='history_budget_comparison',prespecified_primary=False))
    for r in result:
        r['comparison_id']=f"{r['pool_id']}_{r['method']}_B{r['budget']}_vs_{r['reference_method']}_B{r['reference_budget']}_H{r['horizon']}_C{r['nominal_coverage']:g}"
    return result


def _dense_daily(daily,cfg,horizon,coverage,constraint,subset):
    siteids=list(map(str,cfg['development_ids']));e=episodes(cfg);length=cfg['evaluation_days']
    labels=[(b,p['pool_id'],m) for b in cfg['budgets'] for p in pools(cfg) for m in METHODS]
    lookup={v:i for i,v in enumerate(labels)}
    q=daily[daily.horizon.eq(horizon)&daily.nominal_coverage.eq(coverage)&daily.constraint.eq(constraint)]
    if subset=='historical_high_volume':q=q[q.truth_m3.ge(q.high_threshold_m3)&q.high_threshold_m3.notna()]
    columns=['interval_score_m3','covered','width_m3','lower_miss','upper_miss']
    result={c:np.full((len(siteids),len(e)*length,len(labels)),np.nan) for c in columns}
    if len(q):
        s=q.site_id.map({s:i for i,s in enumerate(siteids)}).to_numpy()
        d=q.episode.map({v:i for i,v in enumerate(e)}).to_numpy()*length+(pd.to_datetime(q.origin)-pd.to_datetime(q.episode)).dt.days.to_numpy()
        l=np.fromiter((lookup[v] for v in zip(q.budget,q.pool_id,q.method)),int,count=len(q))
        for c in columns:result[c][s,d,l]=q[c].to_numpy(float)
    return result,labels


def paired_block_intervals(daily,cfg,constraint='raw',subset='all_dates',progress=print):
    """Pair-specific masks retain calendar gaps and condition calibration exclusions."""
    rows=[];site_rows=[];index_frames=[]
    sites=list(map(str,cfg['development_ids']));e=episodes(cfg);length=int(cfg['evaluation_days'])
    comp=comparisons(cfg)
    for h,c in itertools.product(cfg['horizons'],coverages(cfg)):
        dense,labels=_dense_daily(daily,cfg,h,c,constraint,subset)
        errors=dense['interval_score_m3'];lookup={v:i for i,v in enumerate(labels)}
        active=[r for r in comp if r['horizon']==h and r['nominal_coverage']==c]
        # Pack distinct pair masks into an error cube. Reuse identical masked
        # policies (including duplicated LOCAL references) within this cube.
        arrays=[];packed={};pairindices=[]
        for r in active:
            ai=lookup[(r['budget'],r['pool_id'],r['method'])]
            bi=lookup[(r['reference_budget'],r['pool_id'],r['reference_method'])]
            valid=np.isfinite(errors[:,:,ai])&np.isfinite(errors[:,:,bi])
            maskid=np.packbits(valid).tobytes()
            indices=[]
            for pi in [ai,bi]:
                key=(pi,maskid)
                if key not in packed:
                    packed[key]=len(arrays);arrays.append(np.where(valid,errors[:,:,pi],np.nan))
                indices.append(packed[key])
            pairindices.append((r,*indices))
            a0=_mean(np.where(valid,errors[:,:,ai],np.nan),axis=1)
            b0=_mean(np.where(valid,errors[:,:,bi],np.nan),axis=1)
            with np.errstate(divide='ignore',invalid='ignore'):skill=np.where(b0>0,1-a0/b0,np.nan)
            for si,site in enumerate(sites):
                count=int(valid[si].sum())
                site_rows.append(dict(r,constraint=constraint,subset=subset,site_id=site,n_dates=count,
                    interval_score_m3=float(a0[si]),reference_interval_score_m3=float(b0[si]),
                    absolute_score_improvement_m3=float(b0[si]-a0[si]),skill=float(skill[si]),
                    zero_reference_score=bool(b0[si]==0),negative_transfer=bool(skill[si]<-TIE_TOLERANCE),
                    win=bool(skill[si]>TIE_TOLERANCE),tie=bool(abs(skill[si])<=TIE_TOLERANCE)))
            # Explicit comparison calendar, including exclusions. A compact
            # origin string registry is separate from the dense bootstrap cube.
            origins_flat=np.concatenate([pd.date_range(t,periods=length).strftime('%Y-%m-%d').to_numpy() for t in e])
            index_frames.append(pd.DataFrame(dict(comparison_id=r['comparison_id'],constraint=constraint,subset=subset,
                site_id=np.repeat(sites,len(e)*length),episode=np.tile(np.repeat(e,length),len(sites)),
                horizon=h,nominal_coverage=c,origin=np.tile(origins_flat,len(sites)),paired_evaluation=valid.ravel())))
        cube=np.stack(arrays,axis=2)
        means=_mean(cube,axis=1);counts=np.isfinite(cube).sum(axis=1)
        for block in cfg['bootstrap']['blocks']:
            started=time.monotonic();seed=int(cfg['bootstrap']['seed'])+int(h)*100+int(block)
            reps=int(cfg['bootstrap']['replicates'])
            draws=bootstrap_station_means(cube,len(e),length,int(block),reps,seed)
            for r,ai,bi in pairindices:
                a,b=draws[:,:,ai],draws[:,:,bi];a0,b0=means[:,ai],means[:,bi]
                with np.errstate(divide='ignore',invalid='ignore'):
                    samples=_mean(np.where(b>0,1-a/b,np.nan),axis=1)
                    skill0=np.where(b0>0,1-a0/b0,np.nan)
                usable=samples[np.isfinite(samples)]
                primary=bool(r['prespecified_primary'] and constraint=='raw' and subset=='all_dates')
                alpha=.025 if primary else .05
                q=np.quantile(usable,[.025,.975,alpha/2,1-alpha/2]) if len(usable) else [np.nan]*4
                differences=_mean(b-a,axis=1);diff= differences[np.isfinite(differences)]
                dq=np.quantile(diff,[alpha/2,1-alpha/2]) if len(diff) else [np.nan,np.nan]
                rows.append(dict(r,constraint=constraint,subset=subset,block_days=int(block),replicates=reps,
                    bootstrap_seed=seed,finite_replicates=len(usable),mean_station_skill=float(_mean(skill0)),
                    lower_95=float(q[0]),upper_95=float(q[1]),lower_ci=float(q[2]),upper_ci=float(q[3]),
                    confidence_level=1-alpha,co_primary=primary,
                    multiplicity_family='two primary comparisons; Bonferroni' if primary else 'exploratory pointwise',
                    absolute_score_improvement_m3=float(_mean(b0-a0)),absolute_difference_lower_ci_m3=float(dq[0]),
                    absolute_difference_upper_ci_m3=float(dq[1]),defined_skill_stations=int(np.isfinite(skill0).sum()),
                    zero_reference_stations=int(np.sum(b0==0)),winning_stations=int(np.sum(skill0>TIE_TOLERANCE)),
                    negative_transfer_stations=int(np.sum(skill0<-TIE_TOLERANCE)),minimum_paired_dates=int(counts[:,ai].min())))
            progress(f'Interval statistics: {constraint}/{subset}, h={h}, c={c:g}, block={block}; {reps} paired draws, {time.monotonic()-started:.2f}s',flush=True)
    return pd.DataFrame(rows),pd.DataFrame(site_rows),pd.concat(index_frames,ignore_index=True)


def coverage_block_intervals(daily,cfg,progress=print):
    """Exploratory coverage/width intervals; nominal-in-CI is not calibration proof."""
    rows=[]
    for constraint,h,c in itertools.product(['raw','all_methods_lower_nonnegative'],cfg['horizons'],coverages(cfg)):
        dense,labels=_dense_daily(daily,cfg,h,c,constraint,'all_dates')
        metricnames=['covered','width_m3','lower_miss','upper_miss']
        cube=np.concatenate([dense[name] for name in metricnames],axis=2)
        point=_mean(_mean(cube,axis=1),axis=0)
        for block in cfg['bootstrap']['blocks']:
            seed=int(cfg['bootstrap']['seed'])+int(h)*100+int(block)
            draws=bootstrap_station_means(cube,len(episodes(cfg)),cfg['evaluation_days'],int(block),
                                          int(cfg['bootstrap']['replicates']),seed)
            estimands=_mean(draws,axis=1)
            for mi,name in enumerate(metricnames):
                for pi,(b,p,m) in enumerate(labels):
                    j=mi*len(labels)+pi;usable=estimands[:,j][np.isfinite(estimands[:,j])]
                    q=np.quantile(usable,[.025,.975]) if len(usable) else [np.nan,np.nan]
                    rows.append(dict(constraint=constraint,horizon=h,nominal_coverage=c,pool_id=p,method=m,budget=b,
                      metric=name,block_days=int(block),estimate=float(point[j]),lower_95=float(q[0]),upper_95=float(q[1]),
                      confidence_level=.95,bootstrap_seed=seed,replicates=cfg['bootstrap']['replicates'],
                      finite_replicates=len(usable),interpretation='Exploratory; containing nominal coverage does not prove calibration'))
        progress(f'Coverage/width exploratory intervals: {constraint}, h={h}, c={c:g}',flush=True)
    return pd.DataFrame(rows)


def save_resampling_indices(cfg,output):
    """Record time and facility layers separately with the original RNG order."""
    folder=Path(output)/'resampling';folder.mkdir(parents=True,exist_ok=True);files=[]
    for h,block in itertools.product(cfg['horizons'],cfg['bootstrap']['blocks']):
        seed=int(cfg['bootstrap']['seed'])+int(h)*100+int(block)
        draws=list(calendar_draw_indices(len(cfg['development_ids']),len(episodes(cfg)),int(cfg['evaluation_days']),
                                          int(block),int(cfg['bootstrap']['replicates']),seed))
        path=folder/f'h{h}_block{block}.npz'
        np.savez_compressed(path,site_indices=np.stack([d[0] for d in draws]).astype(np.int16),
           calendar_indices=np.stack([d[1] for d in draws]).astype(np.int16),site_ids=np.asarray(cfg['development_ids']),
           episode_start_dates=np.asarray(episodes(cfg)),days_per_episode=cfg['evaluation_days'],seed=seed)
        files.append(dict(path=str(path.relative_to(output)),sha256=sha256(path),seed=seed,horizon=h,block_days=block))
    write_json(Path(output)/'RESAMPLING.json',dict(files=files,
        time_layer='Each noncircular calendar moving block sampled inside its own 60-origin episode; missing calendar dates preserved',
        facility_layer='After time draws, sample whole SiteIDs with replacement; synchronize sampled dates across all SiteIDs and methods',
        random_order='Exact Stage3C2 time-then-SiteID random number sequence',
        independent_units='Only 10 development SiteIDs; source composition/budget/horizon/window/dates are not additional facilities'))


def _save(frame,output,name):
    frame.to_csv(Path(output)/name,index=False,compression={'method':'gzip','mtime':0} if name.endswith('.gz') else None)


def summarize_intervals(frame,cfg,output,experiment_integrity=None,progress=print):
    """Recompute scores from saved endpoints. Do not fit or choose anything."""
    output=Path(output);output.mkdir(parents=True,exist_ok=True);started=time.monotonic()
    p=prepare_intervals(frame,cfg);_save(p,output,'predictions_all.csv.gz')
    condition=p.groupby(CONDITION_KEYS).agg(planned_interval_rows=('origin','size'),
        c2_evaluable_rows=('evaluation_mask_c2','sum'),evaluated_rows=('common_evaluation','sum'),
        calibration_samples=('calibration_samples','first'),scale_m3=('scale_m3','first'),
        calibration_status=('calibration_status','first')).reset_index()
    _save(condition,output,'calibration_availability.csv')
    _save(p[p.exclusion_reason.ne('')][ROW_KEYS+['calibration_samples','calibration_status','exclusion_reason']],
          output,'excluded_interval_rows.csv.gz')
    paired=p.groupby(KEYS+['budget']).agg(interval_rows=('method','size'),
          evaluation_mask_c2=('evaluation_mask_c2','first'),common_evaluation=('common_evaluation','first'),
          calibration_valid=('calibration_valid','first'),truth_m3=('truth_m3','first'),
          high_threshold_m3=('high_threshold_m3','first')).reset_index()
    _save(paired,output,'paired_evaluation_index.csv.gz')
    eligible=p[p.common_evaluation].copy();frames=[]
    keep=ROW_KEYS+['order_label','k','truth_m3','persistence_m3','high_threshold_m3','gamma','scale_m3','calibration_samples']
    for constraint,column in [('raw','lower_m3'),('all_methods_lower_nonnegative','lower_nonnegative_m3')]:
        d=eligible[keep].copy();d['lower_m3']=eligible[column];d['upper_m3']=eligible.upper_m3
        d['constraint']=constraint;d['evaluation_set']='five_used_development_windows'
        score,width,lp,up=interval_score(d.truth_m3,d.lower_m3,d.upper_m3,d.nominal_coverage)
        d['interval_score_m3']=score;d['width_m3']=width;d['lower_penalty_m3']=lp;d['upper_penalty_m3']=up
        d['covered']=(d.truth_m3>=d.lower_m3)&(d.truth_m3<=d.upper_m3)
        d['lower_miss']=d.truth_m3<d.lower_m3;d['upper_miss']=d.truth_m3>d.upper_m3
        frames.append(d)
    daily=pd.concat(frames,ignore_index=True);_save(daily,output,'daily_losses.csv.gz')
    metric=station_metrics(daily,cfg);_save(metric,output,'metrics_by_station.csv')
    _save(aggregate_station_metrics(metric),output,'summary.csv')
    windowmetric=station_metrics(daily,cfg,True);_save(windowmetric,output,'metrics_by_station_window.csv')
    _save(aggregate_station_metrics(windowmetric,True),output,'summary_by_window.csv')
    high=daily[daily.truth_m3.ge(daily.high_threshold_m3)&daily.high_threshold_m3.notna()]
    hm=station_metrics(high,cfg);_save(hm,output,'high_volume_metrics_by_station.csv')
    _save(aggregate_station_metrics(hm),output,'high_volume_summary.csv')
    cis=[];pairs=[];indices=[];hc=[];hp=[]
    for constraint in ['raw','all_methods_lower_nonnegative']:
        ci,pair,index=paired_block_intervals(daily,cfg,constraint,progress=progress)
        cis.append(ci);pairs.append(pair);indices.append(index)
        ci,pair,index=paired_block_intervals(daily,cfg,constraint,'historical_high_volume',progress=progress)
        hc.append(ci);hp.append(pair);indices.append(index)
    ci=pd.concat(cis,ignore_index=True);pair=pd.concat(pairs,ignore_index=True)
    _save(ci,output,'paired_block_intervals.csv');_save(pair,output,'paired_comparisons_by_station.csv')
    _save(pd.concat(indices,ignore_index=True),output,'comparison_paired_index.csv.gz')
    _save(pd.concat(hc,ignore_index=True),output,'high_volume_block_intervals.csv')
    _save(pd.concat(hp,ignore_index=True),output,'high_volume_paired_by_station.csv')
    _save(pair[pair.kind.eq('history_budget_comparison')],output,'cross_budget_by_station.csv')
    _save(ci[ci.kind.eq('history_budget_comparison')],output,'cross_budget_intervals.csv')
    negative=pair[pair.kind.eq('same_budget_vs_local')].groupby(
        ['constraint','pool_id','method','budget','horizon','nominal_coverage']).agg(
        stations=('site_id','size'),defined_skill_stations=('skill','count'),mean_skill_vs_local=('skill','mean'),
        median_skill_vs_local=('skill','median'),negative_transfer_stations=('negative_transfer','sum'),
        winning_stations=('win','sum'),tied_stations=('tie','sum')).reset_index()
    negative['negative_transfer_fraction']=negative.negative_transfer_stations/negative.defined_skill_stations.where(negative.defined_skill_stations.gt(0))
    _save(negative,output,'negative_transfer_summary.csv')
    _save(pair[pair.zero_reference_score],output,'zero_reference_comparisons.csv')
    _save(coverage_block_intervals(daily,cfg,progress),output,'coverage_width_intervals.csv')
    choices=p[CONDITION_KEYS+['pool_id','method','gamma','scale_m3','calibration_samples','calibration_status']].drop_duplicates()
    _save(choices,output,'calibration_parameter_choices.csv')
    gamma=choices[choices.method.eq('MIXTURE')].groupby(['pool_id','budget','horizon','gamma']).size().reset_index(name='target_conditions')
    _save(gamma,output,'gamma_distribution.csv')
    fallback=choices[choices.method.eq('MIXTURE')].groupby(['pool_id','budget','horizon']).agg(
        target_conditions=('episode','size'),gamma_zero_conditions=('gamma',lambda s:int(s.eq(0).sum())),
        gamma_one_conditions=('gamma',lambda s:int(s.eq(1).sum()))).reset_index()
    fallback['local_fallback_fraction']=fallback.gamma_zero_conditions/fallback.target_conditions
    _save(fallback,output,'gamma_fallback.csv');save_resampling_indices(cfg,output)
    integrity=experiment_integrity or dict(status='NOT_PROVIDED',all_expected_tasks_verified=False)
    complete=bool(integrity.get('all_expected_tasks_verified',False))
    files={str(f.relative_to(output)):sha256(f) for f in sorted(output.rglob('*')) if f.is_file() and f.name!='evaluation_validation.json'}
    write_json(output/'evaluation_validation.json',dict(status='COMPLETED' if complete else 'PARTIAL',
       evaluation_outputs_complete=True,experiment_integrity=integrity,started_from_saved_endpoints_only=True,
       planned_interval_rows=len(p),planned_condition_calendars=len(paired),evaluated_condition_calendars=int(paired.common_evaluation.sum()),
       excluded_c2_calendar_conditions=int((~paired.evaluation_mask_c2).sum()),
       extra_excluded_calibration_conditions=int((paired.evaluation_mask_c2&~paired.calibration_valid).sum()),
       calibration_insufficient_tasks=int((~condition.calibration_status.astype(str).str.upper().isin(['VALID','OK','COMPLETED'])).sum()),
       point_prediction='Identical Stage3C2 Persistence centre; no Ridge/model reselection',
       date_matching='Frozen C2 common calendar, plus preregistered data-only calibration exclusions per budget; explicit pair-specific cross-budget intersections',
       station_aggregation='Pool dates within each SiteID, compute relative LOCAL interval-score skill per SiteID, then equal SiteID mean',
       high_volume='Frozen C2 Q90 from each initial B30 history reused across budgets',
       multiplicity='Two B30/order20261012/90%-coverage MIXTURE-vs-LOCAL raw comparisons: 97.5% individual CI; other contrasts 95% exploratory',
       empirical_interval='Weighted empirical absolute-error quantiles; no finite-sample, conditional, or conformal coverage guarantee',
       retrospective_published_quality_flags=True,physical_mapping_verified=False,verified_real_time=False,
       final_2024_2025_performance_used=False,tie_skill_tolerance=TIE_TOLERANCE,
       numeric_tolerance=dict(absolute_m3=NUMERIC_ATOL_M3,relative=NUMERIC_RTOL),
       statistics_seconds=time.monotonic()-started,finished_utc=utc_now(),files_sha256=files))
    return p,daily,metric,ci
