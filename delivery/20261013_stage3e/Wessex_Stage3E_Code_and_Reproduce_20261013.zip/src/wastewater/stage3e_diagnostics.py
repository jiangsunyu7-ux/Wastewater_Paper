"""Post-hoc Stage3E diagnostics of frozen Stage3D empirical intervals.

This module fits no predictive model, changes no gamma, and does not update any
Stage3D artifact. Deployment errors are read only for retrospective explanation.
"""
from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

import numpy as np
import pandas as pd

from .common import sha256, utc_now
from .stage3c2_evaluation import bootstrap_station_means

VERSION = "stage3e_evidence_review_v1"
TIE_TOL = 1e-12
ATOL_M3 = 1e-8
RTOL = 1e-12
CONDITION = ["site_id", "episode", "budget", "horizon"]
ROW = CONDITION + ["origin", "target_date", "pool_id", "method", "nominal_coverage"]
METRIC_KEYS = ["constraint", "site_id", "pool_id", "method", "budget", "horizon", "nominal_coverage"]
METRICS = ["interval_score_m3", "mean_width_m3", "median_width_m3", "coverage",
           "lower_miss_rate", "upper_miss_rate", "lower_penalty_m3", "upper_penalty_m3"]
SEGMENTS = [(1, 14), (15, 30), (31, 60)]


def atomic_json(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n"); stream.flush(); os.fsync(stream.fileno())
    os.replace(temporary, path)
    if json.loads(path.read_text()) != value:
        raise IOError("JSON write-back validation failed: " + str(path))


def save_csv(frame, folder, name):
    path = Path(folder) / name; path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    compression = {"method": "gzip", "mtime": 0} if name.endswith(".gz") else None
    with temporary.open("wb") as stream:
        frame.to_csv(stream, index=False, compression=compression)
        stream.flush(); os.fsync(stream.fileno())
    os.replace(temporary, path)
    return path


def bool_values(values):
    if pd.api.types.is_bool_dtype(values):
        return values.to_numpy(bool)
    parsed = values.astype(str).str.lower().map({"true": True, "false": False, "1": True, "0": False})
    if parsed.isna().any():
        raise ValueError("Missing or unrecognized boolean")
    return parsed.to_numpy(bool)


def interval_components(truth, lower, upper, coverage):
    """Independent implementation, including the two separately signed penalties."""
    y, l, u, c = np.broadcast_arrays(np.asarray(truth, float), np.asarray(lower, float),
                                    np.asarray(upper, float), np.asarray(coverage, float))
    if np.any((c <= 0) | (c >= 1)) or np.any(l > u):
        raise ValueError("Invalid coverage or bounds")
    width = u - l
    lp = np.where(y < l, 2 * (l - y) / (1 - c), 0.)
    up = np.where(y > u, 2 * (y - u) / (1 - c), 0.)
    return width + lp + up, width, lp, up


def weighted_distribution(values, weights=None):
    x = np.asarray(values, float)
    w = np.ones(len(x), float) if weights is None else np.asarray(weights, float)
    if x.ndim != 1 or w.shape != x.shape or not len(x) or not np.isfinite(x).all() or not np.isfinite(w).all() or (w <= 0).any():
        raise ValueError("Nonempty finite values and positive weights required")
    order = np.argsort(x, kind="stable"); x = x[order]; w = w[order] / w.sum()
    return x, np.cumsum(w)


def left_quantiles(values, probabilities, weights=None):
    x, cdf = weighted_distribution(values, weights)
    p = np.asarray(probabilities, float)
    if ((p < 0) | (p > 1)).any():
        raise ValueError("Probability outside [0,1]")
    indices = np.searchsorted(cdf, p, side="left").clip(0, len(x) - 1)
    return x[indices]


def weighted_ks(first, second):
    """One descriptive distance only; no iid KS p-value is calculated."""
    x, fx = first; y, fy = second
    grid = np.union1d(x, y)
    ix = np.searchsorted(x, grid, side="right") - 1
    iy = np.searchsorted(y, grid, side="right") - 1
    cx = np.where(ix >= 0, fx[np.maximum(ix, 0)], 0.)
    cy = np.where(iy >= 0, fy[np.maximum(iy, 0)], 0.)
    return float(np.max(np.abs(cx - cy)))


def stage3d_inputs(root, cfg):
    root = Path(root)
    result = root / cfg.get("stage3d_results", "reports/stage3d_interval_v1/results")
    run = root / cfg.get("stage3d_run", "runs/stage3d_interval_v1/full")
    dpath = root / cfg.get("stage3d_config", "configs/stage3d_interval_v1/full.json")
    dcfg = json.loads(dpath.read_text())
    paths = [dpath, result / "predictions_all.csv.gz", result / "daily_losses.csv.gz",
             result / "metrics_by_station.csv", result / "metrics_by_station_window.csv",
             result / "paired_block_intervals.csv", result / "cross_budget_by_station.csv",
             result / "cross_budget_intervals.csv", result / "high_volume_block_intervals.csv",
             result / "high_volume_paired_by_station.csv", result / "gamma_fallback.csv"]
    for site in dcfg["development_ids"]:
        for episode in dcfg["evaluation_origins"]:
            for b in dcfg["budgets"]:
                for h in dcfg["horizons"]:
                    job = run / "jobs" / f"{site}_{episode}_B{b}_H{h}"
                    paths.extend([job / "calibration.csv", job / "diagnostics.json"])
    source = root / dcfg["source_output"]
    for pool in dcfg["pools"]:
        p = source / pool["pool_id"]
        paths.extend(p / f for f in ["source_errors_final.csv.gz", "source_errors_proxy.csv.gz",
                                    "source_validation.csv", "selected_gamma.json"])
    for p in paths:
        if not p.is_file():
            raise FileNotFoundError(p)
    return dcfg, result, run, source, paths


def recompute_daily(predictions, dcfg):
    p = predictions.copy()
    p["site_id"] = p.site_id.astype(str)
    if p.duplicated(ROW).any():
        raise ValueError("Duplicate frozen interval rows")
    if set(p.site_id) != set(map(str, dcfg["development_ids"])) or set(p.episode) != set(dcfg["evaluation_origins"]):
        raise ValueError("Unexpected development registry")
    if (pd.to_datetime(p.target_date) > pd.Timestamp("2023-12-31")).any():
        raise ValueError("Forbidden final-period performance")
    delta = (pd.to_datetime(p.target_date) - pd.to_datetime(p.origin)).dt.days
    if not delta.eq(p.horizon).all():
        raise ValueError("Third-day target alignment changed")
    if (pd.to_datetime(p.latest_input_date) > pd.to_datetime(p.origin)).any():
        raise ValueError("Future input")
    p = p[bool_values(p.common_evaluation)]
    frames = []
    for constraint, lower in [("raw", "lower_m3"), ("all_methods_lower_nonnegative", "lower_nonnegative_m3")]:
        d = p.copy(); d["lower_m3"] = d[lower]; d["constraint"] = constraint
        score, width, lp, up = interval_components(d.truth_m3, d.lower_m3, d.upper_m3, d.nominal_coverage)
        d["interval_score_m3"] = score; d["width_m3"] = width
        d["lower_penalty_m3"] = lp; d["upper_penalty_m3"] = up
        d["covered"] = d.truth_m3.ge(d.lower_m3) & d.truth_m3.le(d.upper_m3)
        d["lower_miss"] = d.truth_m3.lt(d.lower_m3); d["upper_miss"] = d.truth_m3.gt(d.upper_m3)
        d["deployment_day"] = (pd.to_datetime(d.origin) - pd.to_datetime(d.episode)).dt.days + 1
        d["segment"] = pd.cut(d.deployment_day, [0, 14, 30, 60], labels=["01-14", "15-30", "31-60"]).astype(str)
        frames.append(d)
    return pd.concat(frames, ignore_index=True)


def station_metrics(daily, by_window=False, by_segment=False):
    keys = METRIC_KEYS.copy()
    if by_window:
        keys.insert(2, "episode")
    if by_segment:
        keys.insert(2, "segment")
    grouped = daily.groupby(keys, observed=True)
    metric = grouped.agg(n_dates=("origin", "size"), interval_score_m3=("interval_score_m3", "mean"),
         mean_width_m3=("width_m3", "mean"), median_width_m3=("width_m3", "median"), coverage=("covered", "mean"),
         lower_miss_rate=("lower_miss", "mean"), upper_miss_rate=("upper_miss", "mean"),
         lower_penalty_m3=("lower_penalty_m3", "mean"), upper_penalty_m3=("upper_penalty_m3", "mean")) .reset_index()
    refs = [k for k in keys if k != "method"]
    local = metric[metric.method.eq("LOCAL")][refs + ["interval_score_m3"]].rename(columns={"interval_score_m3": "local_interval_score_m3"})
    metric = metric.merge(local, on=refs, how="left", validate="many_to_one")
    metric["skill_vs_local"] = 1 - metric.interval_score_m3 / metric.local_interval_score_m3.where(metric.local_interval_score_m3 > 0)
    metric["absolute_score_improvement_m3"] = metric.local_interval_score_m3 - metric.interval_score_m3
    metric["coverage_minus_nominal"] = metric.coverage - metric.nominal_coverage
    metric["miss_penalty_m3"] = metric.lower_penalty_m3 + metric.upper_penalty_m3
    metric["negative_transfer"] = metric.skill_vs_local.lt(-TIE_TOL)
    metric["posthoc_exploratory"] = True
    return metric


def metric_summary(metric, by_window=False, by_segment=False):
    keys = [k for k in METRIC_KEYS if k != "site_id"]
    if by_window: keys.insert(1, "episode")
    if by_segment: keys.insert(1, "segment")
    rows = []
    for values, g in metric.groupby(keys, observed=True, sort=True):
        s = g.skill_vs_local.dropna(); n = len(s)
        row = dict(zip(keys, values), sites=len(g), defined_skill_sites=n, mean_skill=float(s.mean()),
                   median_skill=float(s.median()), wins=int(s.gt(TIE_TOL).sum()), losses=int(s.lt(-TIE_TOL).sum()),
                   ties=int(s.abs().le(TIE_TOL).sum()), win_fraction=float(s.gt(TIE_TOL).mean()),
                   total_paired_dates=int(g.n_dates.sum()), min_site_dates=int(g.n_dates.min()),
                   max_site_dates=int(g.n_dates.max()), posthoc_exploratory=True)
        for col in METRICS + ["miss_penalty_m3", "absolute_score_improvement_m3"]:
            row["equal_site_" + col] = float(g[col].mean())
        rows.append(row)
    return pd.DataFrame(rows)


def validate_recomputed(daily, metric, windowmetric, result):
    counts = {}; maxima = {}
    old = pd.read_csv(result / "daily_losses.csv.gz", dtype={"site_id": str})
    keys = ROW + ["constraint"]
    checked = daily.merge(old[keys + ["interval_score_m3", "width_m3", "lower_penalty_m3", "upper_penalty_m3"]], on=keys, suffixes=("", "_old"), how="outer", validate="one_to_one", indicator=True)
    if not checked._merge.eq("both").all():
        raise ValueError("Daily-loss rows differ from Stage3D")
    for col in ["interval_score_m3", "width_m3", "lower_penalty_m3", "upper_penalty_m3"]:
        a, b = checked[col].to_numpy(), checked[col + "_old"].to_numpy()
        if not np.allclose(a, b, atol=ATOL_M3, rtol=RTOL, equal_nan=True):
            raise ValueError("Independent score recomputation mismatch: " + col)
        maxima[col] = float(np.nanmax(np.abs(a - b)))
    counts["daily_rows"] = len(checked)
    for m, filename, w in [(metric, "metrics_by_station.csv", False), (windowmetric, "metrics_by_station_window.csv", True)]:
        old = pd.read_csv(result / filename, dtype={"site_id": str})
        keys = METRIC_KEYS + (["episode"] if w else [])
        checked = m.merge(old[keys + METRICS + ["n_dates", "skill_vs_local"]], on=keys, suffixes=("", "_old"), how="outer", validate="one_to_one", indicator=True)
        if not checked._merge.eq("both").all():
            raise ValueError("Metric registry changed: " + filename)
        for col in METRICS + ["n_dates", "skill_vs_local"]:
            if not np.allclose(checked[col], checked[col + "_old"], atol=ATOL_M3 if col.endswith("m3") else 1e-12, rtol=RTOL, equal_nan=True):
                raise ValueError("Recomputed metric differs: " + filename + ":" + col)
        counts[filename] = len(checked)
    return dict(status="PASSED", row_counts=counts, max_absolute_difference_m3=maxima,
                tolerance=dict(absolute_m3=ATOL_M3, relative=RTOL, dimensionless=1e-12),
                wording="Tolerance reproduction, not bitwise identity")


def main_ci(daily, dcfg, result):
    rows = []; sites = list(map(str, dcfg["development_ids"])); episodes = dcfg["evaluation_origins"]
    length = int(dcfg["evaluation_days"]); pool = dcfg["primary_pool_id"]
    for h in dcfg["horizons"]:
        q = daily[daily.constraint.eq("raw") & daily.pool_id.eq(pool) & daily.budget.eq(30) & daily.horizon.eq(h) & daily.nominal_coverage.eq(.9) & daily.method.isin(["LOCAL", "MIXTURE"])]
        cube = np.full((len(sites), len(episodes) * length, 2), np.nan)
        si = q.site_id.map({x:i for i,x in enumerate(sites)}).to_numpy()
        day = q.episode.map({x:i for i,x in enumerate(episodes)}).to_numpy() * length + q.deployment_day.to_numpy() - 1
        mi = q.method.map({"MIXTURE": 0, "LOCAL": 1}).to_numpy()
        cube[si, day, mi] = q.interval_score_m3.to_numpy()
        paired = np.isfinite(cube).all(axis=2)
        cube[~paired] = np.nan
        base = np.nanmean(cube, axis=1); skill = 1 - base[:,0] / np.where(base[:,1] > 0, base[:,1], np.nan)
        for block in dcfg["bootstrap"]["blocks"]:
            seed = int(dcfg["bootstrap"]["seed"]) + int(h) * 100 + int(block)
            draws = bootstrap_station_means(cube, len(episodes), length, int(block), 5000, seed)
            sample = np.nanmean(1 - draws[:,:,0] / np.where(draws[:,:,1] > 0, draws[:,:,1], np.nan), axis=1)
            bounds = np.quantile(sample[np.isfinite(sample)], [.0125, .9875])
            row = dict(pool_id=pool, budget=30, horizon=h, nominal_coverage=.9, method="MIXTURE", reference_method="LOCAL", constraint="raw", block_days=block, replicates=5000, seed=seed, mean_station_skill=float(np.nanmean(skill)), lower_ci=float(bounds[0]), upper_ci=float(bounds[1]), confidence_level=.975, finite_replicates=int(np.isfinite(sample).sum()), original_stage3d_primary=True, new_exploratory_hypothesis=False)
            old = pd.read_csv(result / "paired_block_intervals.csv")
            old = old[old.pool_id.eq(pool) & old.budget.eq(30) & old.reference_budget.eq(30) & old.horizon.eq(h) & old.nominal_coverage.eq(.9) & old.method.eq("MIXTURE") & old.reference_method.eq("LOCAL") & old.constraint.eq("raw") & old.block_days.eq(block)]
            if len(old) != 1:
                raise ValueError("Original primary comparison missing or duplicated")
            for c in ["mean_station_skill", "lower_ci", "upper_ci"]:
                if not np.isclose(row[c], old.iloc[0][c], atol=1e-12, rtol=RTOL):
                    raise ValueError("Primary CI independent recomputation mismatch: " + c)
            row["old_table_tolerance_verified"] = True; rows.append(row)
    return pd.DataFrame(rows)


def influence(metric, dcfg):
    main = metric[metric.constraint.eq("raw") & metric.pool_id.eq(dcfg["primary_pool_id"]) & metric.budget.eq(30) & metric.nominal_coverage.eq(.9) & metric.method.eq("MIXTURE")].copy()
    contributions = []; leave = []
    for h, g in main.groupby("horizon"):
        n = len(g); local_total = g.local_interval_score_m3.sum()
        for _, r in g.iterrows():
            row = r.to_dict(); row.update(equal_site_skill_contribution=r.skill_vs_local / n,
                equal_site_score_change_contribution_m3=(r.interval_score_m3-r.local_interval_score_m3)/n,
                local_score_share=r.local_interval_score_m3/local_total,
                mixture_score_share=r.interval_score_m3/g.interval_score_m3.sum(),
                interpretation="All 10 sites retained in formal results; scale influences absolute-score average")
            contributions.append(row)
            other = g[g.site_id.ne(r.site_id)]
            leave.append(dict(horizon=h, omitted_site_id=r.site_id, remaining_sites=len(other),
                mean_skill_without_site=float(other.skill_vs_local.mean()),
                raw_local_score_without_site_m3=float(other.local_interval_score_m3.mean()),
                raw_mixture_score_without_site_m3=float(other.interval_score_m3.mean()),
                raw_score_skill_without_site=float(1-other.interval_score_m3.mean()/other.local_interval_score_m3.mean()),
                full_mean_skill=float(g.skill_vs_local.mean()),
                full_raw_score_skill=float(1-g.interval_score_m3.mean()/g.local_interval_score_m3.mean()),
                wins_without_site=int(other.skill_vs_local.gt(TIE_TOL).sum()), sensitivity_only=True,
                excluded_from_formal_evaluation=False))
    return pd.DataFrame(contributions), pd.DataFrame(leave)


def distribution_summary(values, weights=None):
    values = np.asarray(values, float)
    weights = np.ones(len(values), float) if weights is None else np.asarray(weights, float)
    weights = weights / weights.sum()
    qs = left_quantiles(np.abs(values), [.5, .8, .9, .95], weights)
    return dict(n_errors=len(values), mean_signed_error_normalized=float(np.sum(values*weights)),
                mean_absolute_error_normalized=float(np.sum(np.abs(values)*weights)), zero_error_count=int(np.sum(values==0)),
                abs_q50_normalized=float(qs[0]), abs_q80_normalized=float(qs[1]),
                abs_q90_normalized=float(qs[2]), abs_q95_normalized=float(qs[3]))


def error_distributions(daily, dcfg, run, source, progress):
    source_rows = []; source_cache = {}; validation_rows = []; gamma_rows = []
    for pool in dcfg["pools"]:
        pid = pool["pool_id"]; folder = source / pid
        selected = json.loads((folder / "selected_gamma.json").read_text())
        # The original gamma JSON schema is recorded without re-selecting gamma.
        gamma_rows.append(dict(pool_id=pid, selected_gamma_json=json.dumps(selected, sort_keys=True)))
        for phase, filename, cutoff in [("final_2016_2021", "source_errors_final.csv.gz", "2021-12-31"), ("selection_through2020", "source_errors_proxy.csv.gz", "2020-12-31")]:
            frame = pd.read_csv(folder / filename, dtype={"site_id": str})
            if (pd.to_datetime(frame.target_date)>pd.Timestamp(cutoff)).any() or (pd.to_datetime(frame.latest_input_date)>pd.to_datetime(frame.origin)).any():
                raise ValueError("Source error information boundary violated")
            for h, g in frame.groupby("horizon"):
                g = g[bool_values(g.valid_score)].copy()
                if set(g.site_id) != set(map(str, pool["site_ids"])):
                    raise ValueError("Source error pool differs from frozen registry")
                signed = (g.truth-g.persistence)/g.scale_m3
                if not np.allclose(np.abs(signed),g.score,atol=1e-12,rtol=RTOL):
                    raise ValueError("Source error score differs from permissible scale")
                counts = g.groupby("site_id").size(); weights = g.site_id.map(1/counts).to_numpy()/len(counts)
                masses = pd.Series(weights,index=g.index).groupby(g.site_id).sum()
                if not np.allclose(masses, 1/len(counts),atol=1e-12,rtol=RTOL):
                    raise ValueError("Unequal source SiteID weights")
                source_rows.append(dict(pool_id=pid,horizon=h,phase=phase,site_id="EQUAL_SITE_POOL",scale_basis="Each source SiteID positive-history median in its permissible library period",**distribution_summary(signed,weights)))
                for site, sg in g.groupby("site_id"):
                    ss=(sg.truth-sg.persistence)/sg.scale_m3
                    source_rows.append(dict(pool_id=pid,horizon=h,phase=phase,site_id=site,scale_basis="Own permitted source-history scale",**distribution_summary(ss)))
                if phase=="final_2016_2021":
                    source_cache[(pid,int(h))]=dict(distribution=weighted_distribution(np.abs(signed),weights),
                         summary=distribution_summary(signed,weights),site_count=len(counts))
        v=pd.read_csv(folder / "source_validation.csv",dtype={"site_id":str})
        for b,h in [(b,h) for b in dcfg["budgets"] for h in dcfg["horizons"]]:
            q=v[v.budget.eq(b)&v.horizon.eq(h)]
            # Read selected gamma from target rows; verify it is identical across
            # all target conditions before using the already-selected source rows.
            target=daily[daily.pool_id.eq(pid)&daily.method.eq("MIXTURE")&daily.budget.eq(b)&daily.horizon.eq(h)]
            gammas=target.gamma.unique()
            if len(gammas)!=1: raise ValueError("Frozen gamma differs across target conditions")
            q=q[q.gamma.eq(float(gammas[0]))]
            per_site=q.groupby("site_id").agg(normalized_interval_score=("normalized_interval_score","mean"),coverage=("coverage","mean"),normalized_width=("normalized_width","mean"),validation_samples=("validation_samples","sum"))
            validation_rows.append(dict(pool_id=pid,budget=b,horizon=h,gamma=float(gammas[0]),
                nominal_coverage=.9,source_validation_days_per_window=14,source_sites=len(per_site),
                source_pseudo_windows=q.pseudo_origin.nunique(),total_paired_validation_dates=int(q.validation_samples.sum()),
                equal_site_equal_window_normalized_score=float(per_site.normalized_interval_score.mean()),
                equal_site_equal_window_coverage=float(per_site.coverage.mean()),
                equal_site_equal_window_normalized_width=float(per_site.normalized_width.mean()),
                interpretation="Selected source-only 14-origin pseudo-validation; no target-side selection"))
        progress(f"Source error descriptions: {pid}; both cutoff libraries checked",flush=True)
    distribution_rows=[];ks_rows=[];calibration_rows=[]
    point=daily[daily.constraint.eq("raw")&daily.method.eq("LOCAL")&daily.nominal_coverage.eq(.9)&daily.pool_id.eq(dcfg["primary_pool_id"])]
    for number,(values,g) in enumerate(point.groupby(CONDITION,sort=True),1):
        site,episode,b,h=values; base=dict(site_id=site,episode=episode,budget=int(b),horizon=int(h))
        folder=run/"jobs"/f"{site}_{episode}_B{b}_H{h}"
        cal=pd.read_csv(folder/"calibration.csv");diag=json.loads((folder/"diagnostics.json").read_text())
        valid=cal[bool_values(cal.valid_score)];scale=float(diag["scale_m3"])
        if len(valid)!=int(diag["calibration_samples"]): raise ValueError("Calibration count mismatch")
        left=pd.Timestamp(episode)-pd.Timedelta(days=int(b));cutoff=pd.Timestamp(episode)-pd.Timedelta(days=1)
        for column in ["origin","target_date","latest_input_date"]:
            dates=pd.to_datetime(valid[column]);
            if ((dates<left)|(dates>cutoff)).any(): raise ValueError("Calibration reads beyond initial budget")
        local=(valid.truth-valid.persistence)/scale;deploy=(g.truth_m3-g.persistence_m3)/scale
        if not np.allclose(np.abs(local),valid.score,atol=1e-12,rtol=RTOL): raise ValueError("Local error scale mismatch")
        local_summary=distribution_summary(local);deploy_summary=distribution_summary(deploy)
        calibration_rows.append(dict(base,scale_m3=scale,calendar_history_days=int(b),
            possible_calibration_origins=int(diag["possible_calibration_origins"]),
            actual_calibration_errors=len(valid),zero_errors=int(diag["zero_errors"]),
            first_calibration_origin=diag["first_calibration_origin"],latest_calibration_target=diag["latest_calibration_target"],
            latest_calibration_input=diag["latest_calibration_input"],missing_target_rows=int(diag["missing_target_rows"]),
            missing_persistence_rows=int(diag["missing_persistence_rows"]),
            deployment_evaluated_dates=len(g),parameters_frozen=True,deployment_error_used_for_selection=False))
        distribution_rows.extend([dict(base,phase="local_initial_calibration",pool_id="local_only",scale_m3=scale,**local_summary),
                                  dict(base,phase="deployment_posthoc",pool_id="local_only",scale_m3=scale,**deploy_summary)])
        ld=weighted_distribution(np.abs(local));dd=weighted_distribution(np.abs(deploy))
        for pool in dcfg["pools"]:
            pid=pool["pool_id"];src=source_cache[(pid,int(h))]
            distribution_rows.append(dict(base,phase="source_equal_site_errors_in_target_scale",pool_id=pid,scale_m3=scale,
                source_sites=src["site_count"],**src["summary"]))
            for pair,a,c in [("source_vs_initial",src["distribution"],ld),("source_vs_deployment",src["distribution"],dd),("initial_vs_deployment",ld,dd)]:
                ks_rows.append(dict(base,pool_id=pid,comparison=pair,weighted_KS=weighted_ks(a,c),
                    descriptive_only=True,p_value_computed=False,deployment_used_for_selection=False))
        if number%60==0: progress(f"Local/deployment error descriptions: {number}/300 conditions",flush=True)
    dist=pd.DataFrame(distribution_rows)
    for col in ["mean_signed_error_normalized","mean_absolute_error_normalized","abs_q50_normalized","abs_q80_normalized","abs_q90_normalized","abs_q95_normalized"]:
        dist[col.replace("_normalized","_m3_target_scale")]=dist[col]*dist.scale_m3
    return pd.DataFrame(source_rows),dist,pd.DataFrame(ks_rows),pd.DataFrame(calibration_rows),pd.DataFrame(validation_rows),pd.DataFrame(gamma_rows)


def equal_site_window_segment_summary(segment_metric):
    """Each SiteID-window is first summarized, then windows/SiteIDs equal weight."""
    keys=[k for k in METRIC_KEYS if k!="site_id"]+["segment"]
    rows=[]
    for values,g in segment_metric.groupby(keys,observed=True,sort=True):
        site=g.groupby("site_id")[METRICS+["skill_vs_local"]].mean()
        row=dict(zip(keys,values),sites=len(site),site_window_cells=len(g),
                 total_evaluated_dates=int(g.n_dates.sum()),aggregation="Within SiteID-window segment mean; then equal windows within SiteID; then equal SiteIDs",
                 posthoc_exploratory=True)
        for col in METRICS+["skill_vs_local"]:row["equal_site_equal_window_"+col]=float(site[col].mean())
        rows.append(row)
    return pd.DataFrame(rows)


def verify_reuse_point_tables(daily, result):
    """Reuse original CIs; independently check their underlying paired scores."""
    tables={};records=[]
    grouped={k:g for k,g in daily.groupby(METRIC_KEYS,observed=True,sort=False)}
    for filename,high in [("cross_budget_by_station.csv",False),("high_volume_paired_by_station.csv",True)]:
        old=pd.read_csv(result/filename,dtype={"site_id":str}); tables[filename]=old
        for _,r in old.iterrows():
            a=grouped[(r.constraint,r.site_id,r.pool_id,r.method,r.budget,r.horizon,r.nominal_coverage)]
            b=grouped[(r.constraint,r.site_id,r.pool_id,r.reference_method,r.reference_budget,r.horizon,r.nominal_coverage)]
            if high:
                a=a[a.truth_m3.ge(a.high_threshold_m3)&a.high_threshold_m3.notna()]
                b=b[b.truth_m3.ge(b.high_threshold_m3)&b.high_threshold_m3.notna()]
            pair=a[["episode","origin","target_date","interval_score_m3"]].merge(b[["episode","origin","target_date","interval_score_m3"]],on=["episode","origin","target_date"],validate="one_to_one",suffixes=("_a","_b"))
            am=float(pair.interval_score_m3_a.mean());bm=float(pair.interval_score_m3_b.mean())
            if len(pair)!=int(r.n_dates) or not np.allclose([am,bm],[r.interval_score_m3,r.reference_interval_score_m3],atol=ATOL_M3,rtol=RTOL,equal_nan=True):
                raise ValueError("Original paired raw-unit score mismatch: "+filename)
        records.append(dict(file=filename,sha256=sha256(result/filename),rows=len(old),point_scores_and_counts_independently_verified=True,
            units="m3 interval score before each SiteID's relative ratio; no cross-budget comparison of normalized scores"))
    for filename in ["cross_budget_intervals.csv","high_volume_block_intervals.csv"]:
        tables[filename]=pd.read_csv(result/filename)
        records.append(dict(file=filename,sha256=sha256(result/filename),rows=len(tables[filename]),
            interval_provenance="Original independently validated Stage3D 5000 synchronized within-window calendar/SiteID draws; reused, not relabeled as new estimates"))
    return tables,records


def run_diagnostics(root, cfg, progress=print, force=False):
    root=Path(root);output=root/cfg.get("output","reports/stage3e_evidence_review_v1/results")
    output.mkdir(parents=True,exist_ok=True);started=time.monotonic()
    dcfg,result,run,source,paths=stage3d_inputs(root,cfg)
    paths.append(Path(__file__))
    inputs={str(p.relative_to(root)):sha256(p) for p in paths}
    fingerprint=hashlib.sha256(json.dumps(dict(config=cfg,inputs=inputs),sort_keys=True).encode()).hexdigest()
    statuspath=output/"DIAGNOSTIC_STATUS.json"
    if statuspath.is_file() and not force:
        old=json.loads(statuspath.read_text())
        if old.get("fingerprint")!=fingerprint:raise ValueError("Config/input/code fingerprint changed; refuse old diagnostics")
        if old.get("status")=="COMPLETED" and all((output/f).is_file() and sha256(output/f)==h for f,h in old.get("files_sha256",{}).items()):
            progress("Stage3E diagnostic cache: all saved member hashes verified; no new analysis",flush=True)
            return old
        raise ValueError("Incomplete/corrupt diagnostic cache; use a new output or explicit --force after inspection")
    atomic_json(statuspath,dict(status="RUNNING",version=VERSION,fingerprint=fingerprint,started_utc=utc_now(),posthoc_exploratory=True))
    try:
        p=pd.read_csv(result/"predictions_all.csv.gz",dtype={"site_id":str},low_memory=False)
        daily=recompute_daily(p,dcfg); metric=station_metrics(daily); window=station_metrics(daily,True)
        checked=validate_recomputed(daily,metric,window,result)
        progress(f"Independent endpoint score verification: {len(daily)} rows; original station/window tables agree",flush=True)
        save_csv(metric,output,"metrics_by_station.csv");save_csv(window,output,"metrics_by_station_window.csv")
        save_csv(metric_summary(metric),output,"summary.csv");save_csv(metric_summary(window,True),output,"summary_by_window.csv")
        save_csv(main_ci(daily,dcfg,result),output,"primary_comparison_recomputed.csv")
        con,leave=influence(metric,dcfg);save_csv(con,output,"primary_site_contributions.csv");save_csv(leave,output,"leave_one_site_out_sensitivity.csv")
        segment=station_metrics(daily,True,True)
        save_csv(segment,output,"deployment_segment_metrics_by_site_window.csv")
        save_csv(equal_site_window_segment_summary(segment),output,"deployment_segment_equal_site_window_summary.csv")
        sf,dist,ks,cal,val,gamma=error_distributions(daily,dcfg,run,source,progress)
        for name,frame in [("source_error_distribution.csv",sf),("initial_source_deployment_error_distribution.csv",dist),
                           ("distribution_weighted_KS.csv",ks),("calibration_actual_samples.csv",cal),
                           ("source_14day_selected_gamma_validation_summary.csv",val),("frozen_gamma_registry.csv",gamma)]:
            save_csv(frame,output,name)
        high=daily[daily.truth_m3.ge(daily.high_threshold_m3)&daily.high_threshold_m3.notna()]
        hm=station_metrics(high); save_csv(hm,output,"high_volume_metrics_by_station.csv")
        save_csv(metric_summary(hm),output,"high_volume_summary.csv")
        reuse,records=verify_reuse_point_tables(daily,result)
        for name,frame in reuse.items():save_csv(frame,output,"stage3d_verified_reuse_"+name)
        atomic_json(output/"STAGE3D_REUSE_PROVENANCE.json",dict(files=records,
           description="Original CI estimates retained; new diagnostic tables and underlying point-score verification are post hoc",
           no_models_trained=True,no_gamma_selected=True,no_deployment_error_feedback=True))
        atomic_json(output/"INDEPENDENT_SCORE_CHECK.json",checked)
        schema={f.name:dict(columns=pd.read_csv(f,nrows=0).columns.tolist(),posthoc_exploratory=f.name!="primary_comparison_recomputed.csv") for f in output.glob("*.csv")}
        atomic_json(output/"TABLE_SCHEMA.json",schema)
        atomic_json(output/"INPUT_MANIFEST.json",dict(version=VERSION,fingerprint=fingerprint,inputs_sha256=inputs,
            initial_budget="T-B..T-1; interval scale/errors/gamma frozen for 60 origins; Persistence updates legitimate observed lags",
            distribution_difference="Weighted empirical KS descriptive distance only; no p-value/second distance",
            segment_definition="Origin offset +1: 1-14,15-30,31-60; windows and SiteIDs equal weights in segment summary",
            retrospective_QA=True,physical_mapping_verified=False,verified_real_time=False,final_period_performance_used=False))
        if any(sha256(root/f)!=h for f,h in inputs.items()):raise ValueError("Read-only Stage3D inputs changed during diagnostic run")
        files={str(f.relative_to(output)):sha256(f) for f in sorted(output.rglob("*")) if f.is_file() and f!=statuspath}
        finished=dict(status="COMPLETED",version=VERSION,fingerprint=fingerprint,finished_utc=utc_now(),
            elapsed_seconds=time.monotonic()-started,files_sha256=files,independent_score_check=checked,
            executed="Saved endpoint recomputation, finite post-hoc explanations and original CI reuse; no new model training",
            posthoc_exploratory=True,original_inputs_unchanged=True,final_2024_2025_performance_used=False,
            physical_mapping_verified=False,verified_real_time=False)
        atomic_json(statuspath,finished)
        if not all(sha256(output/f)==h for f,h in files.items()):raise IOError("Output hashes changed after completion")
        return finished
    except Exception as exc:
        atomic_json(statuspath,dict(status="FAILED",version=VERSION,fingerprint=fingerprint,error_type=type(exc).__name__,error=str(exc),finished_utc=utc_now()))
        raise
