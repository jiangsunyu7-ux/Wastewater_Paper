"""Integration checks on fabricated software fixtures, NOT wastewater experiments."""
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import pandas as pd

from wastewater.common import sha256


class CliTests(unittest.TestCase):
    def test_audit_and_development_cli_with_unit_fixture(self):
        root = Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory(prefix="wastewater-unit-only-") as tmp:
            tmp = Path(tmp)
            evidence = tmp / "UNIT_FIXTURE_NOT_EMPIRICAL.txt"
            evidence.write_text("Artificial monotone series for software testing only. No plant or scientific evidence.")
            dates = pd.date_range("2020-01-01", periods=240)
            raw = pd.DataFrame({"id": ["unit-development"]*240, "name": ["Unit WRC"]*240,
                                "day": dates.strftime("%Y-%m-%d"), "value": [str(x+100) for x in range(240)], "qa": ["Good"]*240})
            # Parsing test: include invalid/missing numeric strings under nullable CSV reader.
            raw.loc[0, "value"] = "bad"
            raw.loc[1, "value"] = ""
            raw_path = tmp / "RAW_UNIT_FIXTURE.csv"
            raw.to_csv(raw_path, index=False)
            raw_hash = sha256(raw_path)
            acfg = {"source_id": "UNIT_ONLY", "columns": {"site": "id", "date": "day", "value": "value", "quality": "qa", "name": "name"},
                    "date_format": "%Y-%m-%d", "value_multiplier_to_m3": 1, "valid_target_quality": ["Good"],
                    "name_filter_literal": "WRC", "encoding": "utf-8", "separator": ","}
            config_path = tmp / "audit.json"
            config_path.write_text(json.dumps(acfg))
            env = dict(os.environ)
            env["PYTHONPATH"] = str(root / "src")
            def run(module, *args):
                return subprocess.run([sys.executable, "-m", module, *args], cwd=root, env=env, text=True, capture_output=True)
            audited = tmp / "AUDIT_UNIT_ONLY"
            p = run("wastewater.audit", "--raw", str(raw_path), "--config", str(config_path), "--output", str(audited))
            self.assertEqual(p.returncode, 0, p.stderr)
            self.assertEqual(sha256(raw_path), raw_hash)
            audit_summary = json.loads((audited / "summary.json").read_text())
            self.assertEqual(audit_summary["rule_counts"]["invalid_value"], 2)
            mapping = tmp / "UNIT_MAPPING.csv"
            pd.DataFrame([{"site_id": "unit-development", "facility_id": "unit-fixture-not-real", "role": "development",
                           "measurement_location": "treated_effluent", "independence_evidence": str(evidence), "mapping_reviewed": "true"}]).to_csv(mapping, index=False)
            cfg = json.loads((root / "configs/development.template.json").read_text())
            cfg.update({"canonical_csv": str(audited / "daily_candidates.csv"), "mapping_csv": str(mapping),
                        "deployment_date": "2020-05-01", "output_root": str(tmp / "RUNS_UNIT_ONLY")})
            for key in ["target_semantics", "availability"]:
                cfg[key].update({"reviewed": True, "evidence_path": str(evidence)})
            dcfg = tmp / "development.json"
            dcfg.write_text(json.dumps(cfg))
            p = run("wastewater.development", "--config", str(dcfg))
            self.assertEqual(p.returncode, 0, p.stderr)
            runs = list((tmp / "RUNS_UNIT_ONLY").iterdir())
            self.assertEqual(len(runs), 1)
            manifest = json.loads((runs[0] / "manifest.json").read_text())
            self.assertEqual(manifest["status"], "completed")
            metrics = pd.read_csv(runs[0] / "metrics_by_facility.csv")
            self.assertEqual(len(metrics), 18)  # 3 budgets x 2 horizons x 3 models
            self.assertEqual(set(metrics.n_evaluation), {60})
            for file, digest in manifest["outputs_sha256"].items():
                self.assertEqual(sha256(runs[0] / file), digest)
            # Run repeatability on persistent raw/audit inputs; no overwrites of first run.
            p = run("wastewater.development", "--config", str(dcfg))
            self.assertEqual(p.returncode, 0, p.stderr)
            runs = sorted((tmp / "RUNS_UNIT_ONLY").iterdir())
            self.assertEqual(len(runs), 2)
            self.assertEqual(sha256(runs[0] / "predictions.csv"), sha256(runs[1] / "predictions.csv"))
            # Tampered derived data must not silently lose the raw->audit->results chain.
            canonical = audited / "daily_candidates.csv"
            original_canonical = canonical.read_bytes()
            with canonical.open("a") as stream:
                stream.write("\n")
            p = run("wastewater.development", "--config", str(dcfg))
            self.assertNotEqual(p.returncode, 0)
            failed = [json.loads((d / "manifest.json").read_text()) for d in (tmp / "RUNS_UNIT_ONLY").iterdir()]
            self.assertTrue(any("completed audit manifest" in m.get("error", "") for m in failed))
            canonical.write_bytes(original_canonical)
            # Confirm a denied final-stage attempt is preserved with failure status.
            cfg["stage"] = "final_test"
            dcfg.write_text(json.dumps(cfg))
            p = run("wastewater.development", "--config", str(dcfg))
            self.assertNotEqual(p.returncode, 0)
            manifests = [json.loads((d / "manifest.json").read_text()) for d in (tmp / "RUNS_UNIT_ONLY").iterdir()]
            self.assertIn("failed", [m["status"] for m in manifests])


if __name__ == "__main__":
    unittest.main()
