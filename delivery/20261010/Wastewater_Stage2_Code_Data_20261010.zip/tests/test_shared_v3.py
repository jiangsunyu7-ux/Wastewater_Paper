"""Leakage, shared-information, QA and checkpoint safeguards for V3."""
import copy
import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from wastewater.shared_data import build_samples, load_series, scale_from_history, train_samples
from wastewater.shared_experiment import validate
from wastewater.shared_models import fit_gru, fit_ridge, predict_gru


class SharedIntegrity(unittest.TestCase):
    def setUp(self):
        self.dates=pd.date_range('2021-01-01',periods=365)
        self.s=pd.Series(np.arange(365,dtype=float)+10,index=self.dates)

    def test_calendar_gap_is_not_compressed(self):
        self.s.loc['2021-01-04']=np.nan
        sample=build_samples(self.s,['2021-01-07'],3,'2021-01-01',10)
        self.assertEqual(sample.X[0,3,1],0)
        self.assertEqual(sample.X[0,4,0],1.4)
        self.assertEqual(str(sample.targets[0].date()),'2021-01-10')

    def test_no_observation_before_budget_or_after_origin(self):
        baseline=build_samples(self.s,['2021-01-05'],3,'2021-01-04',20)
        changed=self.s.copy();changed.loc[:'2021-01-03']=999999;changed.loc['2021-01-06':]=999999
        other=build_samples(changed,['2021-01-05'],3,'2021-01-04',20)
        np.testing.assert_array_equal(baseline.X,other.X)
        self.assertEqual(baseline.X[0,:,1].sum(),2)
        self.assertNotEqual(baseline.y[0],other.y[0])

    def test_horizon_label_budget_boundary(self):
        sample=train_samples(self.s,'2021-02-01','2021-03-02',3,40)
        self.assertEqual(len(sample.y),27)
        self.assertEqual(sample.targets.max(),pd.Timestamp('2021-03-02'))
        self.assertEqual(sample.origins.max(),pd.Timestamp('2021-02-27'))

    def test_missing_target_never_imputed(self):
        self.s.loc['2021-01-10']=np.nan
        sample=train_samples(self.s,'2021-01-01','2021-01-30',1,20)
        self.assertNotIn(pd.Timestamp('2021-01-10'),sample.targets)
        self.assertTrue(np.isfinite(sample.y).all())

    def test_scale_uses_only_budget_and_retains_zero(self):
        self.s.loc['2021-01-02']=0
        self.assertEqual(scale_from_history(self.s,'2021-01-01','2021-01-03'),11)
        before=scale_from_history(self.s,'2021-01-10','2021-01-20')
        self.s.loc['2021-01-21':]=999999
        self.assertEqual(before,scale_from_history(self.s,'2021-01-10','2021-01-20'))

    def test_qa_input_cannot_differ_from_truth_mask(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/'daily.csv'
            pd.DataFrame({'site_id':['1'],'date':['2021-01-01'],'observed_input_m3':[0.],
                          'candidate_value_m3':[np.nan]}).to_csv(p,index=False)
            with self.assertRaises(ValueError):load_series(p,['1'])

    def test_final_data_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/'daily.csv'
            pd.DataFrame({'site_id':['1'],'date':['2024-01-01'],'observed_input_m3':[1.],
                          'candidate_value_m3':[1.]}).to_csv(p,index=False)
            with self.assertRaises(ValueError):load_series(p,['1'])

    def test_weighted_ridge_is_invariant_to_duplication_with_adjusted_weights(self):
        X=np.arange(40,dtype=float).reshape(5,2,4)/40;y=np.array([1,2,1,3,4.])
        a=fit_ridge(X,y,.01,np.ones(5)/5)
        b=fit_ridge(np.repeat(X,2,axis=0),np.repeat(y,2),.01,np.ones(10)/10)
        np.testing.assert_allclose(a.coef_,b.coef_,rtol=1e-10,atol=1e-10)

    def test_gru_checkpoint_and_head_only(self):
        rng=np.random.default_rng(123);X=rng.normal(size=(16,7,6)).astype('float32');y=rng.normal(size=16)
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)
            base,diag=fit_gru(X,y,8,123,3,.01,p/'source.pt',signature='test')
            repeated,rd=fit_gru(X,y,8,123,3,.01,p/'source.pt',signature='test')
            np.testing.assert_array_equal(predict_gru(base,X),predict_gru(repeated,X))
            self.assertEqual(rd['resumed_from_epoch'],3)
            initial=copy.deepcopy(base.state_dict())
            adapted,ad=fit_gru(X,y,8,124,2,.01,p/'adapt.pt',initial=initial,head_only=True,signature='adapt')
            for key,value in adapted.state_dict().items():
                if key.startswith('gru.'):self.assertTrue(torch.equal(value,initial[key]))
            self.assertEqual(ad['trainable_parameters'],9)
            with self.assertRaises(ValueError):fit_gru(X,y,8,123,3,.01,p/'source.pt',signature='different')

    def test_source_target_overlap_rejected(self):
        root=Path(__file__).resolve().parents[1];cfg=json.loads((root/'configs/shared_v3_20261009/full.json').read_text())
        cfg['source_ids']=[cfg['development_ids'][0]]
        with self.assertRaises(ValueError):validate(cfg,root)


if __name__=='__main__':unittest.main()
