"""Small artificial fixtures ONLY test software invariants; never scientific results."""
import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

from wastewater.audit import audit_frame
from wastewater.baselines import (daily_calendar, features_at, paired_metrics, persistence_at,
                                  ridge_pipeline, run_site, training_set, weekly_at)
from wastewater.development import load_development_rows, validate_config, validate_mapping


def fixture_calendar():
    dates = pd.date_range("2020-01-01", periods=240)
    values = np.arange(240, dtype=float) + 100
    frame = pd.DataFrame({"date": dates.strftime("%Y-%m-%d"), "candidate_value_m3": values,
                          "observed_input_m3": values, "target_quality_valid": 1, "conflict": 0})
    return daily_calendar(frame, dates[0], dates[-1])


class IntegrityTests(unittest.TestCase):
    def test_calendar_missing_day_not_compressed(self):
        frame = pd.DataFrame({"date": ["2020-01-01", "2020-01-03"], "candidate_value_m3": [10, 30],
                              "observed_input_m3": [10, 30], "target_quality_valid": [1, 1]})
        c = daily_calendar(frame, "2020-01-01", "2020-01-03")
        x = features_at(c.observed_input_m3, "2020-01-03", 1, pd.Timestamp("2020-01-01"))
        self.assertEqual(len(c), 3)
        self.assertEqual(x[0], 30)
        self.assertTrue(np.isnan(x[1]))
        self.assertEqual(x[2], 10)

    def test_budget_no_warmup_and_label_boundary(self):
        c = fixture_calendar()
        T = pd.Timestamp("2020-05-01")
        left = T - pd.Timedelta(days=30)
        tr = training_set(c, T, 30, 3)
        self.assertEqual(min(tr.origins), left)
        self.assertTrue(np.isnan(tr.X[0, 1]))
        self.assertLessEqual(max(tr.targets), T - pd.Timedelta(days=1))
        self.assertEqual(len(tr.y), 27)

    def test_delay_applies_to_features_and_training_labels(self):
        c = fixture_calendar()
        T = pd.Timestamp("2020-05-01")
        left = T - pd.Timedelta(days=30)
        tr = training_set(c, T, 30, 3, delay_days=2)
        self.assertLessEqual(max(tr.targets), T - pd.Timedelta(days=3))
        x = features_at(c.observed_input_m3, T, 3, left, delay_days=2)
        self.assertEqual(x[0], c.observed_input_m3.loc[T-pd.Timedelta(days=2)])

    def test_future_inputs_and_targets_do_not_change_fit(self):
        c = fixture_calendar()
        T = pd.Timestamp("2020-05-01")
        other = c.copy()
        other.loc[T:, ["candidate_value_m3", "observed_input_m3"]] = 999999
        a, b = training_set(c, T, 30, 3), training_set(other, T, 30, 3)
        np.testing.assert_allclose(a.X, b.X, equal_nan=True)
        np.testing.assert_allclose(a.y, b.y)
        x1 = features_at(c.observed_input_m3, T-pd.Timedelta(days=1), 3, T-pd.Timedelta(days=30))
        x2 = features_at(other.observed_input_m3, T-pd.Timedelta(days=1), 3, T-pd.Timedelta(days=30))
        np.testing.assert_allclose(x1, x2, equal_nan=True)

    def test_train_does_not_use_retrospective_qa(self):
        c = fixture_calendar()
        T = pd.Timestamp("2020-05-01")
        other = c.copy()
        other["candidate_value_m3"] = np.nan
        other["target_quality_valid"] = 0
        a, b = training_set(c, T, 30, 1), training_set(other, T, 30, 1)
        np.testing.assert_allclose(a.y, b.y)

    def test_prediction_target_weekly_alignment(self):
        c = fixture_calendar()
        T = pd.Timestamp("2020-05-01")
        left = T - pd.Timedelta(days=30)
        self.assertEqual(weekly_at(c.observed_input_m3, T, 3, left), c.observed_input_m3.loc[T-pd.Timedelta(days=4)])
        self.assertTrue(np.isnan(weekly_at(c.observed_input_m3, T, 3, left, delay_days=5)))

    def test_missing_target_never_evaluated(self):
        c = fixture_calendar()
        c.loc["2020-05-02", "candidate_value_m3"] = np.nan
        cfg = {"deployment_date": "2020-05-01", "availability": {"delay_days": 0},
               "budgets": [30], "horizons": [1], "min_train_labels": 14, "ridge_alpha": 10, "evaluation_days": 35}
        p, fits = run_site(c, "unit-facility", "unit-site", cfg)
        self.assertFalse(p[p.target_date.eq("2020-05-02")].common_evaluation.any())
        m, _, _ = paired_metrics(p)
        self.assertEqual(set(m.n_evaluation), {34})
        self.assertEqual(set(fits.ridge_status), {"fitted"})

    def test_common_dates_and_metrics_known_errors(self):
        rows = []
        for model, errors in [("persistence", [2, 4]), ("weekly_persistence", [1, 3]), ("local_ridge", [0, 2])]:
            for i, e in enumerate(errors):
                rows.append({"facility_id": "unit-facility", "budget": 30, "horizon": 1, "model": model,
                             "truth_m3": 10, "prediction_m3": 10+e, "common_evaluation": True, "target_date": str(i)})
        m, a, s = paired_metrics(pd.DataFrame(rows))
        ridge = m[m.model.eq("local_ridge")].iloc[0]
        self.assertEqual(ridge.mae_m3, 1)
        self.assertAlmostEqual(ridge.rmse_m3, np.sqrt(2))
        self.assertAlmostEqual(ridge.improvement_vs_weekly_persistence, 0.5)
        self.assertEqual(set(a.common_dates), {2})

    def test_zero_baseline_relative_gain_undefined(self):
        p = pd.DataFrame([{"facility_id": "unit", "budget": 30, "horizon": 1, "model": model,
                           "truth_m3": 10, "prediction_m3": 10, "common_evaluation": True}
                          for model in ["persistence", "weekly_persistence", "local_ridge"]])
        m, _, _ = paired_metrics(p)
        self.assertTrue(m.improvement_vs_persistence.isna().all())

    def test_persistence_staleness_and_budget_left(self):
        c = fixture_calendar()
        T = pd.Timestamp("2020-05-01")
        c.loc[T-pd.Timedelta(days=7):T, "observed_input_m3"] = np.nan
        pred, age = persistence_at(c.observed_input_m3, T, T-pd.Timedelta(days=30))
        self.assertTrue(np.isnan(pred))
        pred, age = persistence_at(c.observed_input_m3, T, T)
        self.assertTrue(np.isnan(pred))

    def test_scaler_is_training_only(self):
        p = ridge_pipeline(10)
        X = np.arange(180, dtype=float).reshape(20, 9)
        p.fit(X, np.arange(20))
        mean = p.named_steps["standardscaler"].mean_.copy()
        p.predict(np.full((1, 9), 1000000.0))
        np.testing.assert_array_equal(mean, p.named_steps["standardscaler"].mean_)

    def test_quality_conflicts_and_duplicate_rules(self):
        cfg = {"columns": {"site": "id", "date": "day", "value": "value", "quality": "qa", "name": "name"},
               "date_format": "%Y-%m-%d", "value_multiplier_to_m3": 1, "valid_target_quality": ["Good"],
               "name_filter_literal": "WATER RECYCLING CENTRE"}
        raw = pd.DataFrame({"id": ["unit"]*6, "day": ["2020-01-01", "2020-01-02", "2020-01-03", "2020-01-03", "2020-01-04", "2020-01-04"],
                            "value": [-1, 20, 30, 31, 40, 40], "qa": ["Good", "Missing", "Good", "Good", "Good", "Good"],
                            "name": ["Unit WATER RECYCLING CENTRE"]*6})
        a, d, s = audit_frame(raw, cfg)
        self.assertEqual(s["good_negative_rows"], 1)
        self.assertEqual(s["missing_nonzero_rows"], 1)
        self.assertEqual(s["rule_counts"]["conflicting_station_days"], 1)
        self.assertEqual(s["rule_counts"]["identical_duplicate_days"], 1)
        self.assertTrue(np.isnan(d.iloc[1].candidate_value_m3))
        self.assertEqual(d.iloc[1].observed_input_m3, 20)
        self.assertTrue(np.isnan(d.iloc[2].observed_input_m3))
        self.assertEqual(len(a), 6)

    def test_invalid_raw_never_becomes_truth(self):
        cfg = {"columns": {"site": "id", "date": "day", "value": "value", "quality": "qa", "name": "name"},
               "date_format": "%Y-%m-%d", "value_multiplier_to_m3": 1000, "valid_target_quality": ["Good"],
               "name_filter_literal": "WRC"}
        raw = pd.DataFrame({"id": ["unit"]*4, "day": ["bad", "2020-01-02", "2020-01-03", "2020-01-04"],
                            "value": [1, float("inf"), "error", 0.05], "qa": ["Good"]*4, "name": ["WRC"]*4})
        a, d, s = audit_frame(raw, cfg)
        self.assertEqual(s["valid_candidate_target_rows"], 1)
        self.assertEqual(d.iloc[-1].candidate_value_m3, 50)

    def test_duplicate_canonical_rejected(self):
        rows = pd.DataFrame({"date": ["2020-01-01"]*2, "candidate_value_m3": [10]*2,
                             "observed_input_m3": [10]*2, "target_quality_valid": [1]*2})
        with self.assertRaises(ValueError):
            daily_calendar(rows, "2020-01-01", "2020-01-02")

    def test_retrospective_qa_truth_violation_rejected(self):
        rows = pd.DataFrame({"date": ["2020-01-01"], "candidate_value_m3": [10],
                             "observed_input_m3": [10], "target_quality_valid": [0]})
        with self.assertRaises(ValueError):
            daily_calendar(rows, "2020-01-01", "2020-01-02")

    def test_final_stage_rejected(self):
        with self.assertRaises(ValueError):
            validate_config({"stage": "final"}, Path("."))

    def test_unreviewed_template_rejected(self):
        root = Path(__file__).resolve().parents[1]
        cfg = json.loads((root / "configs/development.template.json").read_text())
        cfg["deployment_date"] = "2020-05-01"
        with self.assertRaisesRegex(ValueError, "semantics"):
            validate_config(cfg, root)

    def test_final_mapping_rejected(self):
        row = {"site_id": "unit", "facility_id": "unit", "role": "final_test", "measurement_location": "treated_effluent",
               "independence_evidence": "somefile", "mapping_reviewed": "true"}
        with self.assertRaisesRegex(ValueError, "must not contain"):
            validate_mapping(pd.DataFrame([row]), Path("."))

    def test_facility_duplicates_rejected(self):
        rows = [{"site_id": str(i), "facility_id": "unit", "role": "development", "measurement_location": "treated_effluent",
                 "independence_evidence": "somefile", "mapping_reviewed": "true"} for i in [1, 2]]
        with self.assertRaisesRegex(ValueError, "Multi-measurement"):
            validate_mapping(pd.DataFrame(rows), Path("."))

    def test_loader_retains_only_explicit_development(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "canonical.csv"
            pd.DataFrame({"site_id": ["development", "final_test"], "arbitrary_value": [5, 9999]}).to_csv(p, index=False)
            rows = load_development_rows(p, ["development"])
            self.assertEqual(list(rows.arbitrary_value), [5])

    def test_loader_excludes_reserved_years_even_at_development_station(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "canonical.csv"
            pd.DataFrame({"site_id": ["dev", "dev"], "date": ["2023-12-31", "2024-01-01"],
                          "value": [5, 9999]}).to_csv(p, index=False)
            rows = load_development_rows(p, ["dev"], max_date="2023-12-31")
            self.assertEqual(list(rows.value), [5])

    def test_exploration_is_explicit_not_fake_reviewed_facility(self):
        root = Path(__file__).resolve().parents[1]
        cfg = json.loads((root / "configs/development.template.json").read_text())
        cfg.update({"analysis_unit": "station_exploratory", "deployment_date": "2022-01-01"})
        cfg["target_semantics"].update({"reviewed": True, "evidence_path": "AGENTS.md"})
        cfg["availability"] = {"mode": "retrospective_snapshot_delay", "assumption_documented": True,
                               "verified_real_time": False, "delay_days": 0, "evidence_path": "AGENTS.md"}
        validate_config(cfg, root)
        cfg["availability"]["verified_real_time"] = True
        with self.assertRaisesRegex(ValueError, "unverified retrospective"):
            validate_config(cfg, root)

    def test_any_development_unit_rejects_final_label_boundary(self):
        root = Path(__file__).resolve().parents[1]
        cfg = json.loads((root / "configs/development.template.json").read_text())
        cfg.update({"deployment_date": "2023-12-30", "evaluation_days": 1})
        with self.assertRaisesRegex(ValueError, "reserves 2024-2025"):
            validate_config(cfg, root)

    def test_unverified_station_mapping_accepted_but_spoofed_facility_rejected(self):
        root = Path(__file__).resolve().parents[1]
        row = {"site_id": "unit", "facility_id": "station:unit", "role": "development", "measurement_location": "treated_effluent",
               "independence_evidence": "AGENTS.md", "mapping_reviewed": "false"}
        validate_mapping(pd.DataFrame([row]), root, "station_exploratory")
        row["facility_id"] = "verified_plant"
        with self.assertRaisesRegex(ValueError, "unverified station:ID"):
            validate_mapping(pd.DataFrame([row]), root, "station_exploratory")

    def test_good_zero_policy_is_preserved_not_outcome_selected(self):
        cfg = {"columns": {"site": "id", "date": "day", "value": "value", "quality": "qa", "name": "name"},
               "date_format": "%Y-%m-%d", "value_multiplier_to_m3": 1, "valid_target_quality": ["Good"], "name_filter_literal": "WRC"}
        raw = pd.DataFrame({"id": ["unit"], "day": ["2020-01-01"], "value": [0], "qa": ["Good"], "name": ["WRC"]})
        a, d, s = audit_frame(raw, cfg)
        self.assertEqual(d.iloc[0].candidate_value_m3, 0)
        self.assertEqual(s["valid_candidate_target_rows"], 1)
        self.assertEqual(s["old_positive_noduplicate_candidate_count"], 0)

    def test_wrong_units_cannot_enter_inputs_or_truth(self):
        cfg = {"columns": {"site": "id", "date": "day", "value": "value", "quality": "qa", "name": "name", "unit": "unit"},
               "date_format": "%Y-%m-%d", "value_multiplier_to_m3": 1, "valid_target_quality": ["Good"], "name_filter_literal": "WRC", "expected_unit": "m3"}
        raw = pd.DataFrame({"id": ["unit"], "day": ["2020-01-01"], "value": [10], "qa": ["Good"], "name": ["WRC"], "unit": ["L/s"]})
        a, d, s = audit_frame(raw, cfg)
        self.assertTrue(np.isnan(d.iloc[0].observed_input_m3))
        self.assertEqual(s["rule_counts"]["invalid_unit"], 1)


if __name__ == "__main__":
    unittest.main()
