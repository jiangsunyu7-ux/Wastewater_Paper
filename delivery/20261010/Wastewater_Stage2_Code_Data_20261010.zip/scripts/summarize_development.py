"""Check and aggregate real predeclared development runs; no synthetic results."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from wastewater.common import sha256, write_json


def summarize(predictions):
    common = predictions[predictions.common_evaluation].copy()
    common["absolute_error"] = (common.prediction_m3-common.truth_m3).abs()
    common["squared_error"] = (common.prediction_m3-common.truth_m3)**2
    keys = ["site_id", "budget", "horizon", "extra_delay_days", "model"]
    metrics = common.groupby(keys).agg(n_evaluation=("truth_m3", "size"),
                                       mae_m3=("absolute_error", "mean"), mse=("squared_error", "mean")).reset_index()
    metrics["rmse_m3"] = np.sqrt(metrics.pop("mse"))
    for baseline in ["persistence", "weekly_persistence"]:
        refs = metrics[metrics.model.eq(baseline)][keys[:-1]+["mae_m3"]].rename(columns={"mae_m3": baseline+"_mae"})
        metrics = metrics.merge(refs, on=keys[:-1], validate="many_to_one")
        denominator = metrics[baseline+"_mae"]
        metrics["skill_vs_"+baseline] = 1-metrics.mae_m3/denominator.where(denominator.gt(0))
    invalid = predictions.groupby(keys).prediction_m3.apply(lambda s: int(s.lt(0).sum())).reset_index(name="negative_predictions")
    metrics = metrics.merge(invalid, on=keys, validate="one_to_one")
    summary_rows = []
    for keys, group in metrics.groupby(["budget", "horizon", "extra_delay_days", "model"]):
        summary_rows.append(dict(zip(["budget", "horizon", "extra_delay_days", "model"], keys),
                                 stations=len(group), n_evaluation_total=int(group.n_evaluation.sum()),
                                 min_dates_per_station=int(group.n_evaluation.min()),
                                 equal_weight_mae_m3=float(group.mae_m3.mean()),
                                 equal_weight_rmse_m3=float(group.rmse_m3.mean()),
                                 equal_weight_skill_vs_persistence=float(group.skill_vs_persistence.mean()),
                                 equal_weight_skill_vs_weekly=float(group.skill_vs_weekly_persistence.mean()),
                                 stations_worse_than_persistence=int(group.skill_vs_persistence.lt(0).sum()),
                                 defined_persistence_skill=int(group.skill_vs_persistence.notna().sum()),
                                 negative_predictions=int(group.negative_predictions.sum())))
    return metrics, pd.DataFrame(summary_rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch-index", required=True)
    parser.add_argument("--output", required=True, help="New directory")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    output = root / args.output
    output.mkdir(parents=True, exist_ok=False)
    index = json.loads((root / args.batch_index).read_text())
    frames, fit_frames = [], []
    runs = []
    for run in index["runs"]:
        folder = root / run["run_dir"]
        manifest = json.loads((folder/"manifest.json").read_text())
        if manifest["status"] not in {"completed", "incomplete"}:
            raise ValueError("A failed run cannot silently disappear from the planned report")
        for file, digest in manifest["outputs_sha256"].items():
            if sha256(folder/file) != digest:
                raise ValueError(f"Stored result changed: {folder/file}")
        p = pd.read_csv(folder/"predictions.csv", dtype={"site_id":"string"})
        p["episode"] = manifest["config"]["deployment_date"]
        p["run_dir"] = run["run_dir"]
        fits = pd.read_csv(folder/"fit_records.csv", dtype={"site_id":"string"})
        fits["episode"] = p.episode.iloc[0]
        fits["extra_delay_days"] = manifest["config"]["availability"]["delay_days"]
        fit_frames.append(fits)
        frames.append(p)
        runs.append({"run_dir":run["run_dir"],"manifest_sha256":sha256(folder/"manifest.json"),"status":manifest["status"]})
    p = pd.concat(frames, ignore_index=True)
    fits = pd.concat(fit_frames, ignore_index=True)
    duplicate_keys = ["site_id","budget","horizon","extra_delay_days","episode","origin","model"]
    if p.duplicated(duplicate_keys).any():
        raise ValueError("Duplicate episodes/dates; exclude interface smoke runs from primary aggregate")
    origin, target = pd.to_datetime(p.origin), pd.to_datetime(p.target_date)
    latest, left, fit_end = pd.to_datetime(p.latest_input_date), pd.to_datetime(p.budget_start), pd.to_datetime(p.fit_end)
    alignment = (target-origin).dt.days.eq(p.horizon).all()
    input_bound = ((origin-latest).dt.days == p.extra_delay_days).all() and latest.ge(left).all()
    label_bound = pd.to_datetime(p.last_train_target).le(pd.to_datetime(p.latest_allowed_train_label)).all()
    budget_bound = (pd.to_datetime(p.episode)-left).dt.days.eq(p.budget).all()
    final_excluded = target.max() <= pd.Timestamp("2023-12-31")
    same_models = p.groupby(duplicate_keys[:-1]).agg(models=("model","nunique"),common_variants=("common_evaluation","nunique"))
    common_models = same_models.models.eq(3).all() and same_models.common_variants.eq(1).all()
    # Assert budget-curve comparability directly, rather than assuming matching coverage.
    common_sets = []
    for keys,g in p[p.model.eq("local_ridge")].groupby(["site_id","horizon","extra_delay_days","episode"]):
        sets = [set(sub.loc[sub.common_evaluation,"origin"]) for _,sub in g.groupby("budget")]
        common_sets.append(all(s == sets[0] for s in sets))
    checks={"horizon_alignment":bool(alignment),"input_date_bound":bool(input_bound),
            "training_label_bound":bool(label_bound),"inclusive_calendar_budget":bool(budget_bound),
            "final_evaluation_period_excluded":bool(final_excluded),"three_models_on_same_dates":bool(common_models),
            "evaluation_dates_equal_across_budgets":bool(all(common_sets))}
    if not all(checks.values()):
        raise ValueError(f"Real-result validation failed: {checks}")
    # Verify prediction truths against the audited source, including QA validity.
    canonical_path=root/json.loads((root/index['runs'][0]['config']).read_text())["canonical_csv"]
    canonical=pd.read_csv(canonical_path,dtype={"site_id":"string"})
    canonical=canonical[canonical.site_id.isin(p.site_id.unique()) & canonical.date.le("2023-12-31")]
    truths=p[p.truth_m3.notna()][["site_id","target_date","truth_m3"]].drop_duplicates()
    matched=truths.merge(canonical[["site_id","date","candidate_value_m3","target_quality_valid"]],left_on=["site_id","target_date"],right_on=["site_id","date"],how="left",validate="many_to_one")
    np.testing.assert_allclose(matched.truth_m3,matched.candidate_value_m3,rtol=0,atol=1e-7)
    if not matched.target_quality_valid.eq(1).all():raise ValueError("Invalid QA target evaluated")
    checks["evaluation_truth_matches_audited_original"]=True
    # Real-data repeatability: the independently run two-station smoke equals the first full episode.
    smoke_dir=root/"runs/development/20261009T061016Z_04efdd27"
    if smoke_dir.exists():
        smoke=pd.read_csv(smoke_dir/"predictions.csv",dtype={"site_id":"string"})
        repeat=p[p.site_id.isin(smoke.site_id.unique()) & p.episode.eq("2022-01-01") & p.extra_delay_days.eq(0)]
        pd.testing.assert_frame_equal(smoke.reset_index(drop=True),repeat[smoke.columns].reset_index(drop=True))
        checks["real_data_smoke_repeatability"]=True
    metrics,summary=summarize(p)
    p.to_csv(output/"predictions_all.csv",index=False)
    metrics.to_csv(output/"metrics_by_station.csv",index=False)
    summary.to_csv(output/"equal_station_summary.csv",index=False)
    fits.to_csv(output/"fit_records_all.csv",index=False)
    availability=p.groupby(["site_id","budget","horizon","extra_delay_days","model"]).agg(origins=("origin","size"),observed_targets=("truth_m3","count"),common_dates=("common_evaluation","sum"),predictions=("prediction_m3","count")).reset_index()
    availability["common_fraction_of_observed_targets"]=availability.common_dates/availability.observed_targets
    availability.to_csv(output/"availability_by_station.csv",index=False)
    result={"stage":"development","analysis_unit":"station_exploratory","runs":runs,"checks":checks,
            "batch_index_sha256":sha256(root/args.batch_index),"prediction_rows":len(p),"stations":p.site_id.nunique(),
            "episodes":sorted(p.episode.unique()),"target_min":str(target.min().date()),"target_max":str(target.max().date()),
            "negative_ridge_predictions":int((p.model.eq("local_ridge") & p.prediction_m3.lt(0)).sum()),
            "zero_evaluation_truths":int(p[p.common_evaluation & p.model.eq("local_ridge")].truth_m3.eq(0).sum()),
            "common_coverage_min":float(availability.common_fraction_of_observed_targets.min()),
            "physical_facility_independence_verified":False,"online_availability_verified":False,
            "shared_models_run":False,"intervals_run":False,"formal_statistical_inference":False,
            "outputs_sha256":{file.name:sha256(file) for file in output.iterdir() if file.is_file()}}
    write_json(output/"validation.json",result)
    print(json.dumps({k:v for k,v in result.items() if k!='runs'},indent=2))
    print(summary[summary.extra_delay_days.eq(0)][["budget","horizon","model","equal_weight_mae_m3","equal_weight_skill_vs_persistence","stations_worse_than_persistence"]].to_string(index=False))


if __name__ == "__main__":main()
