"""Vector figures from checked saved real results; editable draw.io method source."""
import argparse
import json
import os
from pathlib import Path
import xml.etree.ElementTree as ET

os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parents[1]/".cache/matplotlib"))
os.environ.setdefault("XDG_CACHE_HOME", str(Path(__file__).resolve().parents[1]/".cache"))
Path(os.environ["XDG_CACHE_HOME"]).mkdir(parents=True,exist_ok=True)
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np
import pandas as pd

from wastewater.common import sha256, write_json


def save(fig, output, name):
    fig.savefig(output/(name+".pdf"))
    fig.savefig(output/(name+".svg"))
    fig.savefig(output/(name+".png"),dpi=150)
    plt.close(fig)


def method_diagram(output):
    # One shared graph description for editable draw.io XML and vector exports.
    # No diagram node claims shared models or final tests were executed.
    nodes=[
        ("raw",60,30,780,65,"Received source files: 58 verified originals\nWessex: 968,794 rows; 31 API pages match CSV"),
        ("audit",60,135,780,65,"WRC audit: 936,637 records / 261 SiteIDs\nRetain originals, flags and conflicts; no interpolation"),
        ("select",60,240,780,65,"Development cohort: 10 fixed SiteIDs\nSelection uses 2016-2021 coverage and ascending IDs"),
        ("input",55,365,375,100,"Offline inputs and fitting labels\nFinite nonnegative raw observations\nNo retrospective QA input masking\nExtra delay scenarios: 0 / 1 / 2 days"),
        ("truth",470,365,375,100,"Retrospective evaluation truth\nGood, nonnegative, nonconflicting\nUnobserved/invalid targets excluded\nGood zeros retained in primary rule"),
        ("models",60,520,780,85,"4 fixed 2022-2023 episodes, 60 origins each\n30 / 90 / 180 calendar-day histories; horizons 1 / 3\nPersistence / weekly persistence / local ridge (alpha=10)"),
        ("results",60,660,780,85,"12 full development runs: predictions, MAE/RMSE and coverage\nIdentical comparison dates; equal SiteID summaries\nNo physical-facility or online-deployment claim"),
    ]
    edges=[("raw","audit"),("audit","select"),("select","input"),("select","truth"),("input","models"),("truth","models"),("models","results")]
    graph=ET.Element("mxfile",host="app.diagrams.net",version="24.7.17")
    diagram=ET.SubElement(graph,"diagram",name="Executed development workflow",id="development")
    model=ET.SubElement(diagram,"mxGraphModel",page="1",pageWidth="900",pageHeight="820")
    rt=ET.SubElement(model,"root");ET.SubElement(rt,"mxCell",id="0");ET.SubElement(rt,"mxCell",id="1",parent="0")
    for node,x,y,w,h,label in nodes:
        cell=ET.SubElement(rt,"mxCell",id=node,value=label.replace("\n","<br>"),style="rounded=1;whiteSpace=wrap;html=1;fillColor=#eef5fa;strokeColor=#33566b;fontSize=15;fontFamily=Arial;",vertex="1",parent="1")
        ET.SubElement(cell,"mxGeometry",x=str(x),y=str(y),width=str(w),height=str(h),attrib={"as":"geometry"})
    for i,(a,b) in enumerate(edges):
        cell=ET.SubElement(rt,"mxCell",id=f"edge{i}",style="edgeStyle=orthogonalEdgeStyle;endArrow=block;strokeColor=#33566b;",edge="1",parent="1",source=a,target=b)
        ET.SubElement(cell,"mxGeometry",relative="1",attrib={"as":"geometry"})
    ET.ElementTree(graph).write(output/"executed_development.drawio",encoding="utf-8",xml_declaration=True)
    fig,ax=plt.subplots(figsize=(9,8.2));ax.set_xlim(0,900);ax.set_ylim(820,0);ax.axis("off")
    geometry={n:(x,y,w,h) for n,x,y,w,h,_ in nodes}
    for a,b in edges:
        x,y,w,h=geometry[a];xx,yy,ww,hh=geometry[b]
        ax.add_patch(FancyArrowPatch((x+w/2,y+h+4),(xx+ww/2,yy-5),arrowstyle="-|>",mutation_scale=12,color="#33566b",linewidth=1.1,zorder=1))
    for node,x,y,w,h,label in nodes:
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0,rounding_size=9",facecolor="#eef5fa",edgecolor="#33566b",linewidth=1,zorder=2))
        ax.text(x+w/2,y+h/2,label,ha="center",va="center",fontsize=9.2,linespacing=1.45,zorder=3)
    fig.subplots_adjust(left=.02,right=.98,bottom=.02,top=.98)
    save(fig,output,"executed_development")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report",required=True);parser.add_argument("--output",required=True)
    args=parser.parse_args();root=Path(__file__).resolve().parents[1];report=root/args.report;output=root/args.output
    output.mkdir(parents=True,exist_ok=False)
    validation=json.loads((report/"validation.json").read_text())
    if validation["stage"]!="development" or not all(validation["checks"].values()):raise ValueError("Only checked real development results may be plotted")
    for file,digest in validation['outputs_sha256'].items():
        if sha256(report/file)!=digest:raise ValueError("Results changed after validation")
    m=pd.read_csv(report/"metrics_by_station.csv",dtype={"site_id":"string"})
    summary=pd.read_csv(report/"equal_station_summary.csv")
    plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9,"axes.spines.top":False,"axes.spines.right":False,"svg.fonttype":"none","pdf.fonttype":42,"axes.grid":True,"grid.alpha":.15})
    fig,axes=plt.subplots(1,2,figsize=(8.2,3.4),layout="constrained")
    for h,ax in zip([1,3],axes):
        selected=m[m.model.eq('local_ridge') & m.extra_delay_days.eq(0) & m.horizon.eq(h)]
        for sid,g in selected.groupby('site_id'):
            g=g.sort_values('budget');ratio=1-g.skill_vs_persistence
            ax.plot(g.budget,ratio,color='#78a9bb',alpha=.65,lw=.7,marker='o',ms=3)
        s=summary[summary.model.eq('local_ridge') & summary.extra_delay_days.eq(0) & summary.horizon.eq(h)].sort_values('budget')
        ax.plot(s.budget,1-s.equal_weight_skill_vs_persistence,color='#b34b2f',lw=2,marker='s',label='Equal SiteID mean ratio')
        ax.axhline(1,color='#222222',ls='--',lw=1,label='Persistence')
        ax.set_xticks([30,90,180]);ax.set_xlabel('Initial calendar history (days)');ax.set_ylabel('MAE ratio: local ridge / persistence')
        ax.set_title(f'{h}-day horizon; extra delay = 0');ax.set_ylim(bottom=0)
    axes[0].legend(frameon=False,fontsize=8)
    save(fig,output,'budget_error_ratios')
    fig,axes=plt.subplots(1,2,figsize=(8.2,3.4),layout="constrained")
    for h,ax in zip([1,3],axes):
        for B,color in [(30,'#b34b2f'),(90,'#176d91'),(180,'#398348')]:
            s=summary[summary.model.eq('local_ridge') & summary.budget.eq(B) & summary.horizon.eq(h)].sort_values('extra_delay_days')
            ax.plot(s.extra_delay_days,100*s.equal_weight_skill_vs_persistence,marker='o',lw=1.6,color=color,label=f'{B}-day budget')
        ax.axhline(0,color='#222222',ls='--',lw=1);ax.set_xticks([0,1,2]);ax.set_xlabel('Assumed extra arrival delay (days)')
        ax.set_ylabel('Equal SiteID mean MAE skill (%)');ax.set_title(f'{h}-day horizon; local ridge')
    axes[0].legend(frameon=False,fontsize=8)
    save(fig,output,'delay_sensitivity')
    method_diagram(output)
    provenance={"questions":{"budget_error_ratios":"How does fixed local-ridge error relative to persistence vary with inclusive initial calendar history?","delay_sensitivity":"How do offline assumed arrival delays affect observed local-ridge skill?","executed_development":"Which data/units/model steps were actually executed in this development stage?"},
                "source_report":args.report,"validation_sha256":sha256(report/"validation.json"),
                "source_metrics_sha256":sha256(report/"metrics_by_station.csv"),"source_summary_sha256":sha256(report/"equal_station_summary.csv"),
                "labels":"Exploratory SiteID cohort, fixed alpha=10, not independent physical-facility inference; individual and negative results retained",
                "diagram_export":"Editable draw.io XML; PDF/SVG/PNG rendered from the same node/edge graph in matplotlib, not exported by draw.io Desktop",
                "outputs_sha256":{p.name:sha256(p) for p in output.iterdir()}}
    write_json(output/"figure_provenance.json",provenance)
    print('Saved three figure sets; sources and hashes in '+str(output/"figure_provenance.json"))


if __name__=='__main__':main()
