"""Write a Chinese development analysis from verified saved metrics."""
import json
from pathlib import Path

import pandas as pd

from wastewater.common import sha256, write_json


ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / 'reports/shared_v3_20261009'
MODELS = ['persistence', 'weekly_persistence', 'local_ridge', 'shared_ridge', 'shared_ridge_bias',
          'local_gru', 'shared_gru', 'shared_gru_adapt']
LABELS = dict(zip(MODELS, ['Persistence', 'Weekly persistence', 'Local Ridge', 'Shared Ridge',
    'Shared Ridge + bias', 'Local GRU', 'Shared GRU', 'Shared GRU + head adaptation']))


def table(headers, rows):
    return '\n'.join(['| ' + ' | '.join(headers) + ' |', '| ' + ' | '.join(['---'] * len(headers)) + ' |'] +
                     ['| ' + ' | '.join(map(str, row)) + ' |' for row in rows])


def main():
    validation = json.loads((REPORT / 'validation.json').read_text())
    assert validation['status'] == 'passed' and validation['rows'] == 201600
    # Narrative interpretations below apply to this immutable executed version.
    assert validation['outputs_sha256']['predictions_all.csv'] == 'bdc343aee8da6d380c22a7797f7abc698fd085ea1fa701f761ed97134eb85478'
    checks = json.loads((ROOT / 'validation/stage2_metrics_real_checks.json').read_text())
    assert checks['status'] == 'passed'
    for name, digest in validation['outputs_sha256'].items():
        assert sha256(REPORT / name) == digest
    summary = pd.read_csv(REPORT / 'summary.csv'); summary = summary[summary.constraint.eq('raw')]
    metrics = pd.read_csv(REPORT / 'metrics_by_station.csv', dtype={'site_id': str})
    metrics = metrics[metrics.constraint.eq('raw')]
    contrasts = pd.read_csv(REPORT / 'paired_comparisons_by_station.csv', dtype={'site_id': str})
    intervals = pd.read_csv(REPORT / 'paired_block_intervals.csv')
    high = pd.read_csv(REPORT / 'high_volume_summary.csv'); high = high[high.constraint.eq('raw')]
    seeds = pd.read_csv(REPORT / 'metrics_by_station_seed.csv', dtype={'site_id': str})
    baseline = metrics[metrics.model.eq('persistence')][['site_id','budget','horizon','mae_m3']].rename(columns={'mae_m3':'baseline_mae'})
    seed = seeds[seeds.constraint.eq('raw') & seeds.model.str.contains('gru')].merge(baseline,
        on=['site_id','budget','horizon'], validate='many_to_one')
    seed['skill'] = 1 - seed.mae_m3 / seed.baseline_mae
    sensitivity = seed.groupby(['model','budget','horizon','seed']).agg(mean_skill=('skill','mean'),
        median_skill=('skill','median'), wins=('skill',lambda v:int((v > 0).sum()))).reset_index()
    sensitivity.to_csv(REPORT / 'seed_sensitivity.csv', index=False)
    def select(model, budget, horizon):
        return summary[summary.model.eq(model) & summary.budget.eq(budget) & summary.horizon.eq(horizon)].iloc[0]
    rows=[]
    for model in MODELS:
        row=[LABELS[model]]
        for b in [30,90,180]:
            for h in [1,3]:
                s=select(model,b,h);row.append(f'{s.mean_skill*100:.2f}% ({int(s.winning_stations)}/10)')
        rows.append(row)
    main_table=table(['模型','B30 h1','B30 h3','B90 h1','B90 h3','B180 h1','B180 h3'],rows)
    rows=[]
    for h in [1,3]:
        for model in MODELS:
            s=select(model,90,h)
            rows.append([h,LABELS[model],f'{s.equal_station_mae_m3:.2f}',f'{s.equal_station_rmse_m3:.2f}',
                f'{s.mean_skill*100:.2f}%',f'{s.median_skill*100:.2f}%',f'{int(s.winning_stations)}/10'])
    magnitude_table=table(['h','B90模型','等站MAE (m³)','等站RMSE (m³)','平均skill','中位skill','获胜数'],rows)
    transfer=contrasts[contrasts.kind.eq('same_budget_transfer')]
    rows=[]
    for (model,b,h), group in transfer.groupby(['model','budget','horizon']):
        worse=group[group.negative_transfer]
        rows.append([LABELS[model],b,h,f'{group.skill.mean()*100:.2f}%',f'{len(worse)}/10',
                     ', '.join(worse.site_id) if len(worse) else '无'])
    negative_table=table(['共享方式','预算','h','对同预算本地平均skill','负迁移数','负迁移SiteID'],rows)
    key=intervals[intervals.block_days.eq(14) & intervals.kind.eq('history_budget_comparison') & intervals.budget.eq(30)]
    history_table=table(['共享B30方式','本地预算','h','平均skill vs本地','95%区间','获胜数'],[
        [LABELS[r.model],r.reference_budget,r.horizon,f'{r.mean_station_skill*100:.2f}%',
         f'[{r.lower_95*100:.2f}%, {r.upper_95*100:.2f}%]',f'{r.winning_stations}/10'] for r in key.itertuples()])
    key=intervals[intervals.block_days.eq(14) & intervals.kind.eq('vs_persistence') & intervals.model.eq('shared_ridge_bias')]
    persistence_intervals=table(['Shared Ridge + bias预算','h','平均skill','95%区间'],[
        [r.budget,r.horizon,f'{r.mean_station_skill*100:.2f}%',f'[{r.lower_95*100:.2f}%, {r.upper_95*100:.2f}%]'] for r in key.itertuples()])
    high_rows=[]
    for b in [30,90,180]:
        for h in [1,3]:
            for model in ['shared_ridge','shared_ridge_bias','shared_gru','shared_gru_adapt']:
                r=high[high.model.eq(model)&high.budget.eq(b)&high.horizon.eq(h)].iloc[0]
                high_rows.append([b,h,LABELS[model],f'{r.mean_skill*100:.2f}%',f'{r.median_skill*100:.2f}%',
                    f'{int(r.winning_stations)}/10',f'{int(r.min_dates)}–{int(r.max_dates)}'])
    high_table=table(['预算','h','共享模型','高体积平均skill','中位skill','获胜数','每站评价日数'],high_rows)
    mapping=pd.read_csv(ROOT/'data/provenance/FACILITY_MAPPING_V3_20261009.csv',dtype={'site_id':str})
    map_table=table(['SiteID','分区','提供方名称','物理设施/排口'],[
        [r.site_id,r.partition,r.provider_site_name,'unknown / unknown'] for r in mapping.itertuples()])
    selection=json.loads((ROOT/'runs/shared_v3_20261009/source/selection.json').read_text())
    text=f'''# 有限本地历史下的Wessex跨测点处理后体积预测：第二阶段开发分析

完成日期：2026-10-10。所有下列数值来自保存的QA-v3真实开发预测。本轮没有使用2024–2025预测性能、没有制作App、没有组合多个深度模型、没有重写论文或补造结果。

## 1. 判断

共享学习明显缓解了30天历史下本地模型的不稳定，但本轮所有共享方案、预算和步长的等站平均MAE技能仍低于Persistence。不能写“共享已改善总体实用预测质量”。最接近Persistence的是90天共享Ridge加偏差：h1/h3平均skill分别−3.90%/−3.28%，获胜各4/10测点；探索区间跨零，不能宣称优越或已证明等效。

共享Ridge B30优于本地Ridge B90：h1/h3平均相对改善15.25%/17.75%，10/10测点都改善。它是对本轮匹配本地Ridge的有限历史节省证据，不能推出达到最佳简单基线的质量已节省历史。GRU没有取得总体超越Persistence的证据，负迁移和种子变化必须保留。建议继续一个小规模的开发诊断与对照阶段，暂缓最终测试及模型堆叠。

## 2. 保存、数据规则与实际执行

旧Stage1只运行Persistence、Weekly persistence和固定alpha=10本地Ridge：12完整配置129600预测及单列smoke已保存，旧四个结果/审查/PDF/Overleaf文件未重打包或重算。本轮新增版本`qa_v3_20261009`，输出`runs/shared_v3_20261009/`；共享、GRU为本轮首次实际执行。预测区间、最终测试、集成及软件应用仍未执行。

原始Wessex CSV SHA256：`22f494e2b96fe6fa9550c68971d50c752ddd291793fdc60334d64b2ef089f518`；QA-v3 canonical SHA256：`40f6e6fdb1d09d0afa9c19ba31729b156811ca1cdbb0b317484fdf5fea1d854f`。数据提供方快照报告下载日2026-10-08，收到日2026-10-09，CC BY 4.0，Wessex Water版权2026；并非本轮新下载。目标为许可排口的处理后日积分体积m³，不是污染物排放量、瞬时流量或未来三日累计。

发布方说明Missing整日可编码为零；本轮Missing全部排除，Suspect排除，Good负值/非有限值排除，同日冲突隔离，Good零保留。13个选定ID、允许时段35796记录中：Missing编码零37、Missing非零2、Good负19、Good零14；249条旧输入值被屏蔽，35518有效Good目标。输入、训练标签、评价真值使用同一质量掩码，无未来插值、无目标填补、日历未压缩。全库旧审计的冲突日位于17081，不在此13ID。**本轮明确是使用发布后QA的历史回顾；QA真实预测时的到达/修订时点未验证。**

先对原两个测点13013/13015跑完整单种子96任务、23040预测；再原10测点单种子检查，通过后从缓存续跑另外两个种子。最终960/960任务完成、失败0：240个五基线任务、720个三GRU训练方式任务；201600预测行含全部不可评价记录和38条原始负输出。smoke不重复计入主汇总。4713/4800个站点—episode—步长—起点共同可评价，所有模型/种子/预算共同日期一致；每站每步长220–240个真实日期。

来源仅13006/13008/13012，原先在看误差前按2016–2021逐年有效日≥95%预选，并未扩大或更换。来源选参2016–2020拟合→2021验证，重训2016–2021；h1/h3 Ridge alpha分别0.0001/0.01，GRU hidden均8，搜索alpha五值、hidden两值，实际搜索耗时{selection['total_seconds']:.2f}s。来源归一化与每站1/3权重，源训练样本h1=6527、h3=6521。目标训练实际标签：B30 h1=27–29/h3=25–27；B90=79–89/77–87；B180=165–179/164–177。预算含所有特征、尺度、训练和适应，不额外借历史。

所有学习模型共用7日、6通道信息，Ridge展平相同张量。部署期间可读取新的Good观察更新输入，初始尺度/参数不滚动重训；h3为origin+3当天体积。GRU单层8隐藏元、393总参数；源/本地40epochs，适应冻结编码器只训练9参数线性头10epochs。实际独立检查6源+720本地+720适应checkpoint：720适应编码器均逐张量等于对应源，所有SHA一致。源每次1040优化步，本地40步，适应10步；总保存训练耗时40.49/332.65/45.77s，不含搜索、调度和其他IO。

本地对照采用来源选定的同骨干超参数，属于“预算内本地拟合、来源选参”的匹配对照；不是独立调到最优的纯本地模型。共同epochs不等于共同优化步数，不能把性能差异全归因于共享信息。v3的QA、特征、缩放、正则化也不同于v2，只在v3内部归因；不能把新共享结果与旧未清理输入基线直接比较。

## 3. 全预算点预测

skill=1−MAE_model/MAE_Persistence，先每SiteID合并四窗口算误差、再等站平均。正值为改善。GRU先在同日平均三个种子的绝对/平方损失，不平均预测成集成，不把种子当额外厂。括号为获胜测点数。

{main_table}

以下90天表同时报告原量纲MAE、每站RMSE的等站平均、中位技能及获胜率；全预算逐测点/逐种子数值见CSV。等站m³误差与等站相对技能的权重含义不同：大体积站仍可影响m³均值。因此180天h3偏差Ridge的原量纲平均MAE略低于Persistence，也不能覆盖其平均相对skill为负的事实。

{magnitude_table}

统一裁零是单独次分析：38条负值全部来自本地Ridge，全部方法均max(0,pred)，未选择性处理。它降低部分本地短窗误差，但共享总体仍未超越Persistence；主报告不选择裁零更好的数值替换原输出。

## 4. 对本地模型的共享收益和负迁移

负迁移定义为共享/适应MAE高于相同骨干、相同预算本地MAE；与“不及Persistence”不同。共有10个开发SiteID，不把四窗口/三个种子加成独立设施。以下所有负迁移测点都保留；名称查第7节。

{negative_table}

尤其180天h3，共享Ridge有6/10负迁移，共享GRU有7/10，GRU适应仍4/10；30天h3 GRU适应有6/10负迁移。Ridge偏差修正对本地Ridge六条件均无负迁移，但对Persistence仍全条件平均负技能。简单适应不是必然改善：30天h3偏差修正及GRU适应都不如未经适应的对应共享方案。

## 5. 是否节省历史及相关性区间

下表直接比较共享B30与对应本地B90/B180，不是同预算排行榜。点为等站相对MAE改善；主14日非循环日历移动块、每固定60日episode分层，同日全站同步抽块并整SiteID重采样，1000次。区间是点态95%百分位探索区间，未多重比较校正，也不是未知物理厂总体的保证。

{history_table}

B30共享Ridge对B90本地Ridge两个步长区间均正；B30共享偏差Ridge对B180本地Ridge仅h1区间正，h3跨零。GRU历史节省更不稳定。5%探索不劣界不是经过工程损失核准的容忍度，跨零不等于已证明等效。

接近Persistence的偏差Ridge仍无稳健超过它的证据：

{persistence_intervals}

7/14/28日块敏感性全部保存在`paired_block_intervals.csv`；60日短窗口和长块边界效应、非随机10ID、未知同厂关系均限制区间。该区间仅用于误差比较，不是预测区间，不报告覆盖率或覆盖保证。

## 6. 高体积及种子敏感性

每站每episode阈值仅来自初始最短30日允许历史的Good体积Q90；所有预算用同一阈值。评价按真实目标是否超过该历史阈值分组，这不代表预测时已知未来高体积，不可称容量、许可或溢流阈值。每站高体积评价仅34–75日，是次分析，尚未单独估计其比较区间，不能用它改选主指标。

{high_table}

90天共享GRU在高体积日期h1/h3平均改善4.02%/9.27%（9/10、8/10获胜），但全日期为−21.53%/−22.01%。说明存在值得核查的条件收益，不能替代总体负结果，也不推断降雨因果或实际运行收益。下一阶段应预先规定高体积关键对照与相关性区间，并检验偏差—方差、季节/尺度漂移及低体积损失。

三个种子全部保留，`seed_sensitivity.csv`显示90天共享GRU h1等站skill范围−37.74%至−12.15%，h3−32.30%至−11.55%；不能挑最好种子。没有创建多种子集成预测。`metrics_by_station_seed.csv`保留每站种子的真实MAE/RMSE。

## 7. 设施证据与用途边界

官方提供的TDV为非空间Table，只有SiteID/名称/日期/体积/单位/质量列，relationships为空；未提供许可号、排口ID或坐标。13名称标准化无同名跨分区冲突，同名分组规则已执行；但13映射均`mapping_verified=false`，没有把ID当作独立水厂。官方ArcGIS/EA访问仍403，来源/重试记录已保留，没有伪造可访问元数据。

{map_table}

这些结果只支持固定SiteID开发队列在有限建模历史、发布后QA条件下的treated effluent volume forecasting探索；既有厂短历史不代表新建厂启动。可讨论排水量计划的潜力，尚不能证明许可合规、污染负荷、节能、控制、容量或溢流收益。

## 8. 下一阶段顺序与交付

1. 先补物理设施/许可排口映射及日记录首次到达/修订证据，建立可辩护的分区和在线输入版本。只有三个源，不足以排除更大、事先按覆盖率选择的源队列有不同效果，但不能按当前误差选源。
2. 在同一开发集、全站保留条件下增加小规模的本地调参/优化步数匹配对照和最小输入消融，检查Ridge正则范围、预算边缘padding及GRU初始化/训练稳定性；若修改规则用新版本保存。这些目前均未运行。
3. 对预定高体积次指标补同步块区间，并验证自然缺失/QA到达延迟；人工缺失仅遮输入、保留真实目标。若仍无法超过Persistence，应收缩为有限历史下共享正则化和负迁移研究，而非强实用性能论文。
4. 模型组合只能作为下一次显式开发假设，例如与强Persistence的简单组合，须预定权重选择和对照；当前未构造、未报成绩。预测区间优先以Persistence和简单共享偏差模型B90/180为起点，预算内时间分离训练/校准并处理horizon标签越界；当前没有区间覆盖证据。
5. 软件应用暂缓；先建立可用性、工程损失和外部设施验证。冻结后再考虑2024–2025最终性能，未达到这一步不使用最终期选模型。期刊仍待实际贡献与作者指南核实，不承诺录用。

代码、配置、质量规则/排除表、设施映射、逐条预测、逐测点/种子指标、全部checkpoint/状态/诊断、四张真实PDF/SVG/PNG、英文图注、中文分析及Colab notebook均交付。Colab非Drive核心已在本地隔离实际验证：96缓存任务、输入/配置/预测篡改拒绝、真实预算训练在epoch2中断恢复与连续到epoch4完全一致；最初软件验证目录遗漏及修复日志保留，不能计为科学实验失败。真实Drive挂载与GPU未经认证，本轮CPU已完成，无需把未跑配置包装成成绩。

复现入口见`WORKFLOW.md`与`notebooks/README_STAGE2.md`。新代码和旧Git HEAD需区分：当前应用源码尚未在work分支提交，实际版本由run manifest中三核心SHA、交付包逐文件SHA和配置/data SHA共同标识。旧结果及原四包的最终完整性核对单独保留。
'''
    (REPORT/'ANALYSIS.md').write_text(text,encoding='utf-8')
    # Explicit filters identify every table's quantitative result and its upstream chain.
    raw_hash='22f494e2b96fe6fa9550c68971d50c752ddd291793fdc60334d64b2ef089f518'
    cfg=ROOT/'configs/shared_v3_20261009/full.json'; run=ROOT/'runs/shared_v3_20261009/full/manifest.json'
    chain={'raw_sha256':raw_hash,'rules':'data/derived/wessex_qa_v3_20261009/manifest.json',
           'canonical_sha256':'40f6e6fdb1d09d0afa9c19ba31729b156811ca1cdbb0b317484fdf5fea1d854f',
           'config':str(cfg.relative_to(ROOT)),'config_sha256':sha256(cfg),
           'run_manifest':str(run.relative_to(ROOT)),'run_manifest_sha256':sha256(run),
           'predictions':'reports/shared_v3_20261009/predictions_all.csv','predictions_sha256':sha256(REPORT/'predictions_all.csv'),
           'text':'reports/shared_v3_20261009/ANALYSIS.md'}
    claims=[]
    for frame,source,section,figure in [(summary,'summary.csv','3','budget_skill.pdf'),
        (high,'high_volume_summary.csv','6','high_volume_skill.pdf'),
        (intervals,'paired_block_intervals.csv','5','history_budget_intervals.pdf'),
        (transfer,'paired_comparisons_by_station.csv','4','station_transfer.pdf'),
        (sensitivity,'seed_sensitivity.csv','6','')]:
        for i,row in enumerate(frame.to_dict('records')):
            condition={k:row[k] for k in ['constraint','site_id','model','budget','horizon','seed','id','block_days'] if k in row}
            claims.append({**chain,'claim_id':f'{source}:{i}','result_file':str((REPORT/source).relative_to(ROOT)),
                'result_sha256':sha256(REPORT/source),'row_filter':json.dumps(condition,sort_keys=True),
                'figure':f'figures/shared_v3_20261009/{figure}' if figure else '', 'text_section':section})
    for source,section in [('validation.json','2'),('training_diagnostics.csv','2'),('availability.csv','2')]:
        claims.append({**chain,'claim_id':source,'result_file':str((REPORT/source).relative_to(ROOT)),
            'result_sha256':sha256(REPORT/source),'row_filter':'all','figure':'','text_section':section})
    for name,section in [('data/derived/wessex_qa_v3_20261009/summary.json','2'),
        ('data/provenance/FACILITY_MAPPING_V3_20261009.csv','7'),
        ('runs/shared_v3_20261009/source/selection.json','2'),
        ('validation/stage2_checkpoint_real_checks.json','2'),
        ('validation/notebook_core_validation.json','8')]:
        claims.append({**chain,'claim_id':name,'result_file':name,'result_sha256':sha256(ROOT/name),
            'row_filter':'all','figure':'','text_section':section})
    pd.DataFrame(claims).to_csv(ROOT/'claim_traceability_v3.csv',index=False)
    write_json(ROOT/'validation/stage2_analysis_provenance.json',{'status':'completed',
        'analysis_sha256':sha256(REPORT/'ANALYSIS.md'),'traceability_sha256':sha256(ROOT/'claim_traceability_v3.csv'),
        'source_metrics_verified':True,'manuscript_updated':False,'rows':len(claims)})
    print('Chinese analysis and claim traceability written from verified saved results.')


if __name__ == '__main__':main()
