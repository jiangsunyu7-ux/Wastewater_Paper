"""Matched-date development comparisons, seed loss averaging and calendar-block CIs."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from validate_stage2 import validate_run
from wastewater.common import sha256, write_json


MODELS=['persistence','weekly_persistence','local_ridge','shared_ridge','shared_ridge_bias',
        'local_gru','shared_gru','shared_gru_adapt']
TRANSFER={'shared_ridge':'local_ridge','shared_ridge_bias':'local_ridge',
          'shared_gru':'local_gru','shared_gru_adapt':'local_gru'}


def station_metrics(daily, group_keys):
    metric=daily.groupby(group_keys).agg(n_dates=('absolute_error','size'),mae_m3=('absolute_error','mean'),
                                      mse=('squared_error','mean')).reset_index()
    metric['rmse_m3']=np.sqrt(metric.pop('mse'))
    compare=[k for k in group_keys if k not in ['model','seed']]
    baseline=metric[metric.model.eq('persistence')][compare+['mae_m3']].rename(columns={'mae_m3':'persistence_mae'})
    metric=metric.merge(baseline,on=compare,validate='many_to_one')
    metric['skill_vs_persistence']=1-metric.mae_m3/metric.persistence_mae.where(metric.persistence_mae.gt(0))
    return metric


def aggregate_station_metrics(metric):
    rows=[]
    for keys,g in metric.groupby(['constraint','budget','horizon','model']):
        skill=g.skill_vs_persistence.dropna()
        rows.append(dict(zip(['constraint','budget','horizon','model'],keys),stations=len(g),
            equal_station_mae_m3=float(g.mae_m3.mean()),equal_station_rmse_m3=float(g.rmse_m3.mean()),
            mean_skill=float(skill.mean()),median_skill=float(skill.median()),
            winning_stations=int((skill>0).sum()),worse_stations=int((skill<0).sum()),
            win_fraction=float((skill>0).mean()),defined_skill_stations=len(skill),
            min_dates=int(g.n_dates.min()),max_dates=int(g.n_dates.max())))
    return pd.DataFrame(rows)


def contrasts():
    pairs=[]
    for h in [1,3]:
        for b in [30,90,180]:
            for model,local in TRANSFER.items():
                for ref,kind in [('persistence','vs_persistence'),(local,'same_budget_transfer')]:
                    pairs.append({'id':f'{model}_B{b}_vs_{ref}_B{b}_H{h}','model':model,'budget':b,
                                  'reference':ref,'reference_budget':b,'horizon':h,'kind':kind})
        for b,reference_budget in [(30,90),(30,180),(90,180)]:
            for model,local in TRANSFER.items():
                pairs.append({'id':f'{model}_B{b}_vs_{local}_B{reference_budget}_H{h}','model':model,
                              'budget':b,'reference':local,'reference_budget':reference_budget,'horizon':h,
                              'kind':'history_budget_comparison'})
    return pairs


def block_intervals(daily, cfg):
    """Synchronized noncircular moving blocks within each fixed 60-day episode.

    Resample whole SiteID clusters with replacement, not seeds/conditions/days
    as independent plants. The interval remains conditional on this small,
    nonrandom, incompletely mapped development cohort and these episodes.
    """
    sites=cfg['development_ids'];episodes=cfg['origins'];budgets=cfg['budgets'];length=cfg['evaluation_days']
    comparisons=contrasts();rows=[];station_rows=[]
    for horizon in cfg['horizons']:
        shape=(len(sites),len(episodes)*length,len(budgets),len(MODELS))
        errors=np.full(shape,np.nan)
        for row in daily[daily.horizon.eq(horizon)].itertuples(index=False):
            day=(pd.Timestamp(row.origin)-pd.Timestamp(row.episode)).days
            errors[sites.index(row.site_id),episodes.index(row.episode)*length+day,
                   budgets.index(row.budget),MODELS.index(row.model)]=row.absolute_error
        original=np.nanmean(errors,axis=1)
        active=[c for c in comparisons if c['horizon']==horizon]
        for c in active:
            a=original[:,budgets.index(c['budget']),MODELS.index(c['model'])]
            b=original[:,budgets.index(c['reference_budget']),MODELS.index(c['reference'])]
            for i,site in enumerate(sites):
                station_rows.append(dict(c,site_id=site,mae_m3=float(a[i]),reference_mae_m3=float(b[i]),
                    skill=float(1-a[i]/b[i]) if b[i]>0 else np.nan,negative_transfer=bool(a[i]>b[i])))
        for block in cfg['bootstrap']['blocks']:
            rng=np.random.default_rng(cfg['bootstrap']['seed']+horizon*100+block)
            replicates=cfg['bootstrap']['replicates']
            draws=np.empty((replicates,len(sites),len(budgets),len(MODELS)))
            for r in range(replicates):
                time_indices=[]
                for episode in range(len(episodes)):
                    starts=rng.integers(0,length-block+1,size=int(np.ceil(length/block)))
                    ix=(starts[:,None]+np.arange(block)[None,:]).ravel()[:length]
                    time_indices.extend((ix+episode*length).tolist())
                station_indices=rng.integers(0,len(sites),size=len(sites))
                draws[r]=np.nanmean(errors[station_indices][:,time_indices],axis=1)
            for c in active:
                a=draws[:,:,budgets.index(c['budget']),MODELS.index(c['model'])]
                b=draws[:,:,budgets.index(c['reference_budget']),MODELS.index(c['reference'])]
                with np.errstate(divide='ignore',invalid='ignore'):
                    samples=np.nanmean(np.where(b>0,1-a/b,np.nan),axis=1)
                a0=original[:,budgets.index(c['budget']),MODELS.index(c['model'])]
                b0=original[:,budgets.index(c['reference_budget']),MODELS.index(c['reference'])]
                point=float(np.nanmean(np.where(b0>0,1-a0/b0,np.nan)))
                low,high=np.nanquantile(samples,[.025,.975])
                rows.append(dict(c,block_days=block,replicates=replicates,mean_station_skill=point,
                                 lower_95=float(low),upper_95=float(high),
                                 winning_stations=int((a0<b0).sum()),negative_transfer_stations=int((a0>b0).sum()),
                                 exploratory_5pct_noninferiority=bool(low>-.05),
                                 pointwise_not_multiplicity_adjusted=True))
    return pd.DataFrame(rows),pd.DataFrame(station_rows)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--run',required=True);ap.add_argument('--output',required=True)
    args=ap.parse_args();root=Path(__file__).resolve().parents[1];out=root/args.output
    out.mkdir(parents=True,exist_ok=False)
    manifest=json.loads((root/args.run/'manifest.json').read_text())
    if manifest['status']!='completed':raise ValueError('All planned seeds/jobs must complete before this primary report')
    cfg=manifest['config'];p,fits,checks=validate_run(root,args.run)
    p.to_csv(out/'predictions_all.csv',index=False);fits.to_csv(out/'training_diagnostics.csv',index=False)
    availability=p.groupby(['site_id','episode','budget','horizon','model','seed']).agg(
        origins=('origin','size'),valid_truths=('truth_m3','count'),predictions=('prediction_m3','count'),
        common_dates=('common_evaluation','sum'),negative_predictions=('prediction_m3',lambda x:int(x.lt(0).sum()))).reset_index()
    availability.to_csv(out/'availability.csv',index=False)
    common=p[p.common_evaluation].copy();daily_frames=[];seed_frames=[]
    group=['site_id','episode','budget','horizon','origin','target_date','model']
    for constraint,column in [('raw','prediction_m3'),('all_models_nonnegative','prediction_nonnegative_m3')]:
        frame=common.copy();error=frame[column]-frame.truth_m3
        frame['absolute_error']=error.abs();frame['squared_error']=error**2;frame['constraint']=constraint
        seed=frame.groupby(['site_id','budget','horizon','model','seed']).agg(n_dates=('origin','size'),
                         mae_m3=('absolute_error','mean'),mse=('squared_error','mean')).reset_index()
        seed['rmse_m3']=np.sqrt(seed.pop('mse'));seed['constraint']=constraint;seed_frames.append(seed)
        daily=frame.groupby(group).agg(absolute_error=('absolute_error','mean'),squared_error=('squared_error','mean'),
            truth_m3=('truth_m3','first'),high_threshold_m3=('high_threshold_m3','first'),seed_count=('seed','nunique')).reset_index()
        daily['constraint']=constraint;daily_frames.append(daily)
    daily=pd.concat(daily_frames,ignore_index=True)
    metric=station_metrics(daily,['constraint','site_id','budget','horizon','model'])
    metric.to_csv(out/'metrics_by_station.csv',index=False)
    pd.concat(seed_frames).to_csv(out/'metrics_by_station_seed.csv',index=False)
    summary=aggregate_station_metrics(metric);summary.to_csv(out/'summary.csv',index=False)
    high=daily[daily.truth_m3.ge(daily.high_threshold_m3)].copy()
    high_metric=station_metrics(high,['constraint','site_id','budget','horizon','model'])
    high_metric.to_csv(out/'high_volume_metrics_by_station.csv',index=False)
    aggregate_station_metrics(high_metric).to_csv(out/'high_volume_summary.csv',index=False)
    ci,station_contrasts=block_intervals(daily[daily.constraint.eq('raw')],cfg)
    ci.to_csv(out/'paired_block_intervals.csv',index=False)
    station_contrasts.to_csv(out/'paired_comparisons_by_station.csv',index=False)
    transfer=station_contrasts[station_contrasts.kind.eq('same_budget_transfer')].groupby(
        ['model','budget','horizon','reference']).agg(stations=('site_id','size'),
        mean_skill_vs_local=('skill','mean'),median_skill_vs_local=('skill','median'),
        negative_transfer_stations=('negative_transfer','sum')).reset_index()
    transfer['negative_transfer_fraction']=transfer.negative_transfer_stations/transfer.stations
    transfer.to_csv(out/'negative_transfer_summary.csv',index=False)
    checks.update(run_manifest_sha256=sha256(root/args.run/'manifest.json'),
        seed_aggregation='mean losses at each station/date, not prediction ensemble and not independent sites',
        intervals='pointwise synchronized calendar blocks plus SiteID cluster bootstrap; conditional exploratory intervals',
        primary_constraint='raw; all-model nonnegative sensitivity separately reported',
        outputs_sha256={p.name:sha256(p) for p in out.iterdir() if p.is_file()})
    write_json(out/'validation.json',checks)
    print(summary[summary.constraint.eq('raw')].to_string(index=False))


if __name__=='__main__':main()
