"""Independent checks on saved V3 real predictions; never fits a model."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from wastewater.common import sha256, write_json


def validate_run(root, run, seeds=None):
    folder=root/run;manifest=json.loads((folder/'manifest.json').read_text());cfg=manifest['config']
    seeds=seeds or cfg['seeds'];frames=[];diagnostics=[];states=[]
    for job in sorted((folder/'jobs').iterdir()):
        if not job.is_dir():continue
        if job.name.startswith('gru_seed') and int(job.name.split('_')[1][4:]) not in seeds:continue
        status=json.loads((job/'status.json').read_text())
        if status['status']!='completed':raise ValueError(f'Uncompleted planned job {job}')
        for name,checksum in status['outputs_sha256'].items():
            if sha256(job/name)!=checksum:raise ValueError(f'Changed result {job/name}')
        p=pd.read_csv(job/'predictions.csv',dtype={'site_id':str});p['job']=job.name;frames.append(p)
        diagnostics.append(json.loads((job/'diagnostics.json').read_text()));states.append(status)
    p=pd.concat(frames,ignore_index=True)
    expected=len(cfg['development_ids'])*len(cfg['origins'])*3*2*60*(5+3*len(seeds))
    assert len(p)==expected
    keys=['site_id','episode','budget','horizon','origin','model','seed']
    assert not p.duplicated(keys).any()
    origin=pd.to_datetime(p.origin);target=pd.to_datetime(p.target_date);end=pd.to_datetime(p.fit_end)
    assert (target-origin).dt.days.eq(p.horizon).all()
    assert target.max()<pd.Timestamp('2024-01-01')
    assert (pd.to_datetime(p.episode)-pd.to_datetime(p.budget_start)).dt.days.eq(p.budget).all()
    assert pd.to_datetime(p.last_train_target).le(end).all()
    assert p.latest_input_date.eq(p.origin).all()
    canonical=pd.read_csv(root/cfg['canonical_csv'],dtype={'site_id':str})
    assert canonical.date.max()<='2023-12-31'
    assert canonical.loc[canonical.site_id.isin(cfg['source_ids']),'date'].max()<='2021-12-31'
    assert np.allclose(canonical.observed_input_m3,canonical.candidate_value_m3,equal_nan=True)
    truth=p[['site_id','target_date','truth_m3']].merge(canonical[['site_id','date','candidate_value_m3']],
          left_on=['site_id','target_date'],right_on=['site_id','date'],validate='many_to_one')
    np.testing.assert_allclose(truth.truth_m3,truth.candidate_value_m3,rtol=0,atol=1e-7,equal_nan=True)
    fits=pd.DataFrame(diagnostics)
    condition=['site_id','episode','budget','horizon']
    assert fits.groupby(condition).training_X_sha256.nunique().eq(1).all()
    assert fits.groupby(condition).evaluation_X_sha256.nunique().eq(1).all()
    assert fits.groupby(condition).scale_m3.nunique().eq(1).all()
    # Independently count allowed labels and verify scales/high-volume thresholds.
    independent=[]
    for d in fits.drop_duplicates(condition).to_dict('records'):
        site=canonical[canonical.site_id.eq(d['site_id'])].set_index('date').observed_input_m3
        left=pd.Timestamp(d['budget_start']);right=pd.Timestamp(d['fit_end']);h=d['horizon']
        history=site.loc[str(left.date()):str(right.date())].dropna()
        positive=history[history>0];scale=float(positive.median()) if len(positive) else 1.
        assert np.isclose(scale,d['scale_m3'])
        n=0
        for date in pd.date_range(left+pd.Timedelta(days=h),right):
            o=date-pd.Timedelta(days=h);l=max(left,o-pd.Timedelta(days=6))
            if pd.notna(site.get(str(date.date()),np.nan)) and site.loc[str(l.date()):str(o.date())].notna().any():n+=1
        assert n==d['training_labels'] and n>=14
        q=site.loc[str((pd.Timestamp(d['episode'])-pd.Timedelta(days=30)).date()):str(right.date())].dropna()
        assert len(q)==d['threshold_observations']
        if len(q)>=14:assert np.isclose(q.quantile(.9),d['high_threshold_m3'])
        independent.append(n)
    # Common date mask across every model, seed AND budget (no selective denominators).
    group=['site_id','episode','horizon','origin','target_date']
    p['finite_prediction']=np.isfinite(p.prediction_m3);p['finite_truth']=np.isfinite(p.truth_m3)
    eligible=p.groupby(group).agg(rows=('model','size'),predictions=('finite_prediction','all'),truth=('finite_truth','all')).reset_index()
    assert eligible.rows.eq(3*(5+3*len(seeds))).all()
    eligible['common_evaluation']=eligible.predictions & eligible.truth
    p=p.merge(eligible[group+['common_evaluation']],on=group,validate='many_to_one')
    p=p.drop(columns=['finite_prediction','finite_truth'])
    checks={'status':'passed','run':str(run),'rows':len(p),'stations':p.site_id.nunique(),'seeds':seeds,
            'all_completed_artifacts_sha256':True,'same_features_and_scales_all_models':True,
            'independent_budget_training_count_and_threshold':True,'same_dates_across_models_seeds_budgets':True,
            'evaluation_truth_matches_cleaned_original':True,'final_period_excluded':True,
            'source_target_disjoint':not bool(set(cfg['source_ids'])&set(cfg['development_ids'])),
            'min_training_labels':min(independent),'max_training_labels':max(independent),
            'common_station_episode_horizon_origins':int(eligible.common_evaluation.sum()),
            'possible_station_episode_horizon_origins':len(eligible),
            'negative_raw_predictions':int(p.prediction_m3.lt(0).sum()),
            'physical_facility_independence_verified':False,'historical_QA_arrival_verified':False}
    return p,fits,checks


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--run',required=True);parser.add_argument('--output',required=True)
    parser.add_argument('--seeds',nargs='+',type=int);args=parser.parse_args();root=Path(__file__).resolve().parents[1]
    _,_,checks=validate_run(root,args.run,args.seeds);write_json(root/args.output,checks)
    print(json.dumps(checks,indent=2))


if __name__=='__main__':main()
