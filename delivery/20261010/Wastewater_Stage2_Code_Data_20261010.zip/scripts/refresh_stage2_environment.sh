#!/usr/bin/env bash
set -euo pipefail
TASK_ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
cd "$TASK_ROOT"
mkdir -p .cache/pip .cache/matplotlib validation
if [[ ! -x .venv-stage2/bin/python ]]; then
  python3 -m venv --system-site-packages .venv-stage2
fi
if ! .venv-stage2/bin/python - <<'PY'
import importlib.metadata
expected = {'numpy':'2.3.5','pandas':'2.2.3','scipy':'1.17.0','scikit-learn':'1.8.0','matplotlib':'3.10.8'}
assert all(importlib.metadata.version(k) == v for k,v in expected.items())
PY
then
  .venv-stage2/bin/python -m pip install --cache-dir .cache/pip --disable-pip-version-check -r requirements.txt
fi
if ! .venv-stage2/bin/python - <<'PY'
import torch
assert torch.__version__ == '2.8.0+cpu'
PY
then
  .venv-stage2/bin/python -m pip install --cache-dir .cache/pip --disable-pip-version-check --index-url https://download.pytorch.org/whl/cpu 'torch==2.8.0+cpu'
fi
export PATH="$TASK_ROOT/.venv-stage2/bin:$PATH"
export MPLCONFIGDIR="$TASK_ROOT/.cache/matplotlib"
bash scripts/check_environment.sh
