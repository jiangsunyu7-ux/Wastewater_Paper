"""Package already completed stage-two experiments without fitting any model.

All ZIP paths are relative to the project root. Import every ZIP into the same
root; the notebook validates and skips each package's SHA256SUMS file, so the
per-package checksum manifests do not overwrite one another.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import tempfile
import zipfile
import zlib
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "deliverables/stage2_20261010"
CHECKS = ROOT / "validation/stage2_package_checks.json"
LIMIT = 24 * 1024 * 1024
EXPECTED_SEEDS = [20261009, 20261010, 20261011]
SKIP_PARTS = {"__pycache__", ".ipynb_checkpoints", ".git", ".cache"}


def digest(path: Path) -> str:
    checksum = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            checksum.update(chunk)
    return checksum.hexdigest()


def read_json(relative: str) -> dict:
    return json.loads((ROOT / relative).read_text(encoding="utf-8"))


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def check_hash(path: Path, expected: str) -> None:
    require(path.is_file(), f"Required file missing: {path.relative_to(ROOT)}")
    require(digest(path) == expected, f"SHA256 changed: {path.relative_to(ROOT)}")


def old_artifact_checks() -> dict:
    """Check the original deliveries and report files against their saved hashes."""
    packages = read_json("validation/package_checks.json")
    checked = {}
    for key in ("stage", "full_audit", "compiled_pdf", "overleaf"):
        record = packages[key]
        path = ROOT / record["path"]
        check_hash(path, record["sha256"])
        checked[record["path"]] = record["sha256"]
    previous = read_json("validation/stage2_old_artifacts_preserved.json")
    reports = {}
    for name, expected in previous["old_report_outputs_unchanged"].items():
        path = ROOT / "reports/development_20261009" / name
        check_hash(path, expected)
        reports[path.relative_to(ROOT).as_posix()] = expected
    audit = read_json("data/derived/wessex_audit_20261009/manifest.json")
    audit_hashes = {}
    for name, expected in audit["outputs_sha256"].items():
        path = ROOT / "data/derived/wessex_audit_20261009" / name
        check_hash(path, expected)
        audit_hashes[path.relative_to(ROOT).as_posix()] = expected
    return {"original_four_deliverables": checked, "original_report_outputs": reports,
            "original_audit_outputs": audit_hashes}


def completed_input_checks() -> dict:
    """Only validated, completed experiments can become delivery packages."""
    full = read_json("runs/shared_v3_20261009/full/manifest.json")
    require(full["status"] == "completed", "Full experiment is not completed")
    require(full["completed_jobs"] == full["expected_jobs"] == 960,
            "Expected all 960 full-development tasks")
    require(full["failed_jobs"] == 0, "Some full-development tasks remain failed")
    require(full["config"]["seeds"] == EXPECTED_SEEDS, "Unexpected fixed seeds")
    validation = read_json("reports/shared_v3_20261009/validation.json")
    require(validation["status"] == "passed", "Full report validation did not pass")
    require(validation["rows"] == 201600 and validation["stations"] == 10,
            "Unexpected full-development prediction cohort")
    require(validation["seeds"] == EXPECTED_SEEDS, "Report lacks the three fixed seeds")
    check_hash(ROOT / "runs/shared_v3_20261009/full/manifest.json",
               validation["run_manifest_sha256"])
    for name, expected in validation["outputs_sha256"].items():
        check_hash(ROOT / "reports/shared_v3_20261009" / name, expected)
    for name, expected in full["provenance"]["core"].items():
        check_hash(ROOT / "src/wastewater" / name, expected)
    check_hash(ROOT / full["config"]["canonical_csv"], full["provenance"]["data"])
    check_hash(ROOT / full["config"]["mapping_csv"], full["provenance"]["mapping"])
    qa = read_json("data/derived/wessex_qa_v3_20261009/manifest.json")
    require(qa["status"] == "completed", "QA-derived data are not completed")
    for name, expected in qa["outputs_sha256"].items():
        check_hash(ROOT / "data/derived/wessex_qa_v3_20261009" / name, expected)
    check_hash(ROOT / "data/derived/wessex_audit_20261009/manifest.json",
               qa["upstream_manifest_sha256"])
    # The million-row original CSV remains on this machine, outside the ZIPs.
    check_hash(ROOT / "wastewater_data/raw/wessex_all_2016_2025.csv", qa["raw_sha256"])
    job_counts = {}
    for label, expected_count in (("full", 960), ("smoke", 96)):
        manifest = read_json(f"runs/shared_v3_20261009/{label}/manifest.json")
        require(manifest["status"] == "completed", f"{label} is not completed")
        jobs = sorted((ROOT / f"runs/shared_v3_20261009/{label}/jobs").iterdir())
        require(len(jobs) == expected_count, f"Unexpected {label} task count")
        for job in jobs:
            require(job.is_dir() and not job.is_symlink(), f"Invalid task path: {job}")
            status = json.loads((job / "status.json").read_text())
            require(status["status"] == "completed", f"Incomplete task: {job.name}")
            for name, expected in status["outputs_sha256"].items():
                check_hash(job / name, expected)
        job_counts[label] = len(jobs)
    notebook_checks = read_json("validation/notebook_core_validation.json")
    require(notebook_checks["status"] == "passed", "Notebook verification did not pass")
    check_hash(ROOT / "notebooks/Wessex_Shared_Development_v3.ipynb",
               notebook_checks["notebook_sha256"])
    require((ROOT / "reports/shared_v3_20261009/ANALYSIS.md").is_file(),
            "Chinese analysis report is not ready")
    figures = ROOT / "figures/shared_v3_20261009"
    require(figures.is_dir() and any(figures.glob("*.pdf")) and any(figures.glob("*.svg")),
            "PDF/SVG development figures are not ready")
    return {"full_manifest_sha256": digest(ROOT / "runs/shared_v3_20261009/full/manifest.json"),
            "report_validation_sha256": digest(ROOT / "reports/shared_v3_20261009/validation.json"),
            "task_counts": job_counts, "prediction_rows": validation["rows"],
            "seeds": EXPECTED_SEEDS, "qa_raw_sha256": qa["raw_sha256"],
            "core_sha256": full["provenance"]["core"]}


def add_file(files: dict[str, Path], relative: str, required: bool = True) -> None:
    path = ROOT / relative
    if not path.is_file():
        require(not required, f"Required package member missing: {relative}")
        return
    require(not path.is_symlink(), f"Symlinks cannot be packaged: {relative}")
    require(path.resolve().is_relative_to(ROOT), f"Path leaves project root: {relative}")
    files[relative] = path


def collect(files: dict[str, Path], relative: str, required: bool = True) -> None:
    path = ROOT / relative
    if not path.is_dir():
        require(not required, f"Required package directory missing: {relative}")
        return
    for source in sorted(path.rglob("*")):
        if any(part in SKIP_PARTS for part in source.relative_to(ROOT).parts):
            continue
        if source.is_file() and source.suffix not in {".pyc", ".pyo"}:
            add_file(files, source.relative_to(ROOT).as_posix())


def payloads() -> tuple[dict, dict, dict]:
    code: dict[str, Path] = {}
    for name in (".gitignore", "README.md", "AGENTS.md", "EXPERIMENT_PROTOCOL.md",
                 "RESEARCH_PLAN.md", "STATUS.md", "WORKFLOW.md", "requirements.txt",
                 "requirements-stage2.txt"):
        add_file(code, name)
    for name in ("src", "tests", "configs", "scripts", "notebooks",
                 "data/derived/wessex_qa_v3_20261009",
                 "data/provenance/stage2_facility_access_20261009"):
        collect(code, name)
    for name in ("DEVELOPMENT_SELECTION_20261009.json", "DEVELOPMENT_STATIONS_20261009.csv",
                 "SMOKE_STATIONS_20261009.csv", "FACILITY_MAPPING.csv",
                 "FACILITY_MAPPING_V3_20261009.csv", "SOURCE_REGISTRY.csv",
                 "SEMANTICS_AND_TIMING_20261009.md"):
        add_file(code, "data/provenance/" + name)
    for name in ("coverage_2016_2021.csv", "eligible_station_ids_2016_2021.json",
                 "reconciliation.json", "conflicting_original_records.csv"):
        add_file(code, "data/provenance/reconciliation_20261009/" + name)
    for name in ("manifest.json", "rules.json", "summary.json"):
        add_file(code, "data/derived/wessex_audit_20261009/" + name)
    for source in sorted((ROOT / "wastewater_data/metadata").glob("wessex_*")):
        add_file(code, source.relative_to(ROOT).as_posix())
    add_file(code, "claim_traceability_v3.csv", required=False)

    runs: dict[str, Path] = {}
    collect(runs, "runs/shared_v3_20261009")
    reports: dict[str, Path] = {}
    collect(reports, "reports/shared_v3_20261009")
    collect(reports, "figures/shared_v3_20261009")
    for pattern in ("stage2*", "notebook_core_validation*.json"):
        for source in sorted((ROOT / "validation").glob(pattern)):
            # Package receipts are emitted after the payloads, avoiding recursion.
            if source.is_file() and source != CHECKS:
                add_file(reports, source.relative_to(ROOT).as_posix())
    return code, runs, reports


def instructions(label: str) -> str:
    common = """# Wessex stage-two development delivery — 2026-10-10

Extract Code_Data, every Runs ZIP, and Reports_Figures into the SAME project ROOT.
Each ZIP contains SHA256SUMS for all its other members. The Colab importer checks
these per-ZIP manifests and skips extracting them; it refuses conflicting existing
files. The three START_HERE_STAGE2_* files have distinct paths. If Runs is split,
every numbered Runs part is required; identical Runs instructions can be merged.

This is treated effluent daily-volume forecasting (m³), using published Good QA
retrospectively. Physical facility independence and historical QA arrival are
unverified. The 10 original development SiteIDs remain fixed. Shared sources use
2016–2021; prediction evaluation uses only 2022–2023. 2024–2025 performance was
not calculated or used to select models. A three-day horizon means the individual
volume on day three, not a three-day sum. These are development point forecasts,
not an independent final test. Raw negative predictions and all completed tasks
are retained; clipping for every model is a separately reported sensitivity.

Read reports/shared_v3_20261009/ANALYSIS.md, EXPERIMENT_PROTOCOL.md, STATUS.md,
and notebooks/README_STAGE2.md. The notebook defaults to the verified CPU setup,
mounts Drive when actually run in Colab, validates configuration/cache signatures,
and supports resumed runs plus failure logs. Its core was checked locally; a live
Colab Drive mount or GPU execution is not claimed. No App, prediction-interval
experiment, final-test experiment, or revised full manuscript is in this stage.

The original million-row CSV, original audit row table, raw DOCX materials, caches,
virtual environments and credentials are excluded. They remain unchanged in the
source workspace / original user data packages. Derived QA-v3 data and metadata
are sufficient to run or verify the delivered stage-two forecasts. Rebuilding
the raw audit requires the original data packages and a NEW output directory.

These ZIPs preserve project-relative paths, including model checkpoints and
provenance. ZIP CRC and every member SHA256 are verified before release.
"""
    details = {
        "CODE": "\nCode_Data: source, tests, configurations, scripts, notebook, protocol, fixed\ncohort evidence, QA-v3 derived data, source registration and provider metadata.\n",
        "RUNS": "\nRuns: all 960 full-development task groups, all 96 two-SiteID smoke groups,\nsource-only hyperparameter searches, source checkpoints, predictions, training\ndiagnostics, job statuses and any retained failed-attempt logs. Smoke and\ninterface checks are excluded from the primary scientific aggregate.\n",
        "REPORTS": "\nReports_Figures: common-date and seed-aware metrics, raw predictions, paired\ncalendar-block intervals, high-volume analysis, actual-result figures, Chinese\nanalysis and independent validation logs. Seeds are not independent facilities;\nreported intervals are conditional exploratory intervals, not general guarantees.\n",
    }
    return common + details[label]


def archive(path: Path, files: dict[str, Path], label: str) -> dict:
    require(not path.exists(), f"Refusing to overwrite archive: {path}")
    members = {}
    readme_name = f"START_HERE_STAGE2_{label}.md"
    readme = instructions(label).encode("utf-8")
    with zipfile.ZipFile(path, "x", zipfile.ZIP_DEFLATED, compresslevel=6) as packed:
        for name, source in sorted(files.items()):
            packed.write(source, arcname=name)
            members[name] = digest(source)
        packed.writestr(readme_name, readme)
        members[readme_name] = hashlib.sha256(readme).hexdigest()
        sums = "".join(f"{checksum}  {name}\n" for name, checksum in sorted(members.items()))
        packed.writestr("SHA256SUMS", sums.encode("utf-8"))
    with zipfile.ZipFile(path) as packed:
        require(packed.testzip() is None, f"ZIP CRC failure: {path.name}")
        require(len(packed.namelist()) == len(set(packed.namelist())), "Duplicate ZIP member")
        require(set(packed.namelist()) == set(members) | {"SHA256SUMS"}, "Unexpected ZIP member")
        for name, expected in members.items():
            require(hashlib.sha256(packed.read(name)).hexdigest() == expected,
                    f"ZIP member hash mismatch: {name}")
    return {"filename": path.name, "bytes": path.stat().st_size, "sha256": digest(path),
            "member_count": len(members) + 1, "crc_and_all_member_sha256_passed": True,
            "payload_member_count": len(files)}


def compressed_estimate(files: dict[str, Path]) -> int:
    total = 0
    for name, path in files.items():
        compressor = zlib.compressobj(6, zlib.DEFLATED, -15)
        size = 0
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                size += len(compressor.compress(chunk))
        size += len(compressor.flush())
        # ZIP headers, checksum line and filename encodings; conservative margin.
        total += size + len(name.encode("utf-8")) * 3 + 256
    return total


def runs_atoms(files: dict[str, Path]) -> list[dict[str, Path]]:
    groups: dict[str, dict[str, Path]] = {}
    for name, path in sorted(files.items()):
        parts = Path(name).parts
        if "jobs" in parts:
            job_index = parts.index("jobs")
            key = "/".join(parts[:job_index + 2])
        else:
            key = "_shared_metadata_and_source"
        groups.setdefault(key, {})[name] = path
    keys = sorted(groups, key=lambda item: (item != "_shared_metadata_and_source", item))
    return [groups[key] for key in keys]


def package_runs(folder: Path, files: dict[str, Path]) -> list[dict]:
    filename = "Wastewater_Stage2_Runs_20261010.zip"
    record = archive(folder / filename, files, "RUNS")
    if record["bytes"] < LIMIT:
        return [record]
    (folder / filename).unlink()  # Only a new temporary candidate; originals untouched.
    groups = []
    current: dict[str, Path] = {}
    current_size = 0
    for atom in runs_atoms(files):
        size = compressed_estimate(atom)
        require(size < 23 * 1024 * 1024, "One complete task/source group exceeds ZIP limit")
        if current and current_size + size > 23 * 1024 * 1024:
            groups.append(current)
            current, current_size = {}, 0
        current.update(atom)
        current_size += size
    if current:
        groups.append(current)
    records = []
    for index, group in enumerate(groups, 1):
        part = archive(folder / f"Wastewater_Stage2_Runs_20261010_Part{index:02d}.zip", group, "RUNS")
        require(part["bytes"] < LIMIT, "Compressed Runs part still exceeds ZIP limit")
        part["part_number"] = index
        part["part_count"] = len(groups)
        records.append(part)
    require(sum(item["payload_member_count"] for item in records) == len(files),
            "Some Runs files were lost while splitting")
    return records


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-only", action="store_true", help="Validate readiness without creating files")
    args = parser.parse_args()
    before = old_artifact_checks()
    completed = completed_input_checks()
    code, runs, reports = payloads()
    require(not (set(code) & set(runs) or set(code) & set(reports) or set(runs) & set(reports)),
            "Payload paths overlap across package types")
    if args.check_only:
        print(json.dumps({"status": "ready", "inputs": completed,
                          "payload_files": {"code": len(code), "runs": len(runs), "reports": len(reports)}}, indent=2))
        return
    require(not OUT.exists(), f"Refusing to replace existing delivery directory: {OUT}")
    require(not CHECKS.exists(), f"Refusing to replace existing package receipt: {CHECKS}")
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="stage2_package_", dir=OUT.parent) as temporary:
        folder = Path(temporary)
        records = [archive(folder / "Wastewater_Stage2_Code_Data_20261010.zip", code, "CODE")]
        records.extend(package_runs(folder, runs))
        records.append(archive(folder / "Wastewater_Stage2_Reports_Figures_20261010.zip", reports, "REPORTS"))
        require(all(item["bytes"] < LIMIT for item in records), "Every ZIP must be smaller than 24 MiB")
        after = old_artifact_checks()
        require(after == before, "An original artifact changed during packaging")
        require(completed_input_checks() == completed,
                "An executed model/data/report artifact changed during packaging")
        checks = {"status": "passed", "created_utc": datetime.now(timezone.utc).isoformat(),
                  "limit_bytes_strict": LIMIT, "all_zip_sizes_below_limit": True,
                  "packages": records, "completed_inputs": completed,
                  "original_artifacts_preserved": after,
                  "model_training_executed_by_packager": False,
                  "github_upload_performed_by_packager": False,
                  "shared_extraction_root": True,
                  "checksum_manifest_import": "validate per ZIP then skip extraction; no cross-package overwrite",
                  "raw_million_row_csv_packaged": False, "raw_docx_packaged": False}
        (folder / "SHA256SUMS").write_text("".join(f"{item['sha256']}  {item['filename']}\n" for item in records))
        (folder / "README.md").write_text(instructions("REPORTS"), encoding="utf-8")
        (folder / "package_checks.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2) + "\n")
        # Publish only after all candidate archives and preserved originals pass.
        os.rename(folder, OUT)
    CHECKS.write_text(json.dumps(checks, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(checks, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
