"""Read-only checks of real V3 checkpoints; never train or compute performance.

Source weights are reconstructed from the frozen source_pool implementation
and compared with an independent calendar count. Checkpoints do not serialize
the weight vector, so this check cannot establish a separately recorded vector.
"""
import argparse
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from wastewater.shared_data import load_series
from wastewater.shared_experiment import source_pool


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def task_seed(seed, task):
    return (int(seed) + int(hashlib.sha256(task.encode()).hexdigest()[:8], 16)) % (2**31 - 1)


def inspect_checkpoint(path, signature, hidden, seed, epochs, n, batch, head_only):
    state = torch.load(path, map_location='cpu', weights_only=False)
    metadata = state['metadata']
    expected = {'signature': signature, 'hidden': hidden, 'seed': seed,
                'epochs': epochs, 'n': n, 'batch_size': batch, 'head_only': head_only}
    for key, value in expected.items():
        require(metadata.get(key) == value, f'{path}: changed {key}')
    require(state['epoch'] == epochs, f'{path}: incomplete epochs')
    require(len(state['losses']) == epochs and np.isfinite(state['losses']).all(),
            f'{path}: invalid loss history')
    model = state['model']
    require(all(torch.isfinite(value).all().item() for value in model.values()),
            f'{path}: nonfinite parameters')
    head = sum(value.numel() for name, value in model.items() if name.startswith('head.'))
    require(head == hidden + 1, f'{path}: unexpected linear head shape')
    steps = [int(value['step'].item()) if torch.is_tensor(value['step']) else int(value['step'])
             for value in state['optimizer']['state'].values()]
    expected_steps = epochs * math.ceil(n / batch)
    require(steps and min(steps) == max(steps) == expected_steps,
            f'{path}: optimizer steps differ from completed minibatches')
    require(len(steps) == (2 if head_only else len(model)),
            f'{path}: optimizer contains unexpected parameter tensors')
    record = {'path': str(path), 'sha256': digest(path), 'seed': seed,
              'epochs': epochs, 'training_samples': n, 'batch_size': batch,
              'minibatches_per_epoch': math.ceil(n / batch),
              'actual_optimizer_steps_min': min(steps),
              'actual_optimizer_steps_max': max(steps),
              'expected_optimizer_steps': expected_steps,
              'total_parameters': sum(value.numel() for value in model.values()),
              'head_parameters': head, 'head_only': head_only,
              'optimizer_parameter_tensors': len(steps),
              'fit_seconds': state['elapsed_seconds']}
    return state, record


def check(root, run):
    folder = root / run
    manifest = read_json(folder / 'manifest.json')
    require(manifest['status'] == 'completed', 'All three planned seeds must finish first')
    cfg = manifest['config']
    require(cfg['seeds'] == [20261009, 20261010, 20261011], 'Unexpected planned seeds')
    signature = manifest['signature']
    for name, value in manifest['provenance']['core'].items():
        require(digest(root / 'src/wastewater' / name) == value, f'Core source changed: {name}')
    canonical_path = root / cfg['canonical_csv']
    require(digest(canonical_path) == manifest['provenance']['data'], 'Canonical hash changed')
    require(digest(root / cfg['mapping_csv']) == manifest['provenance']['mapping'], 'Mapping hash changed')
    audit = read_json(canonical_path.parent / 'manifest.json')
    require(digest(root / 'wastewater_data/raw/wessex_all_2016_2025.csv') == audit['raw_sha256'],
            'Original raw data hash changed')
    canonical = pd.read_csv(canonical_path, dtype={'site_id': str})
    require(canonical.date.max() <= '2023-12-31', 'Final-period data in canonical')
    require(canonical.loc[canonical.site_id.isin(cfg['source_ids']), 'date'].max() <= '2021-12-31',
            'Source data exceeds training cutoff')
    require(not (set(cfg['source_ids']) & set(cfg['development_ids'])), 'Source-target ID overlap')
    source_series = load_series(canonical_path, cfg['source_ids'])
    decision = read_json(root / cfg['source_output'] / 'selection.json')
    require(decision['signature'] == signature, 'Changed source setting selection')
    source_states, source_records, weight_records = {}, [], []
    for horizon in cfg['horizons']:
        _, y, weights, diagnostics = source_pool(source_series, cfg, horizon, cfg['source_training_end'])
        require(np.isclose(weights.sum(), 1.0), 'Source total sample weight differs from one')
        offset = 0
        for site, d in zip(cfg['source_ids'], diagnostics):
            s = source_series[site]
            start = pd.Timestamp(cfg['source_training_start'])
            end = pd.Timestamp(cfg['source_training_end'])
            independent_n = 0
            for target in pd.date_range(start + pd.Timedelta(days=horizon), end):
                origin = target - pd.Timedelta(days=horizon)
                left = max(start, origin - pd.Timedelta(days=6))
                if pd.notna(s.loc[target]) and s.loc[left:origin].notna().any():
                    independent_n += 1
            require(d['training_labels'] == independent_n, f'Source sample count mismatch {site}')
            station_weights = weights[offset:offset + independent_n]
            require(np.allclose(station_weights, 1 / (len(cfg['source_ids']) * independent_n)),
                    f'Source weight mismatch {site}')
            require(np.isclose(station_weights.sum(), 1 / len(cfg['source_ids'])),
                    f'Source station weight mismatch {site}')
            weight_records.append({'site_id': site, 'horizon': horizon,
                                   'training_samples': independent_n,
                                   'sample_weight': float(station_weights[0]),
                                   'station_weight_sum': float(station_weights.sum()),
                                   'last_target': d['last_train_target']})
            offset += independent_n
        require(offset == len(y), 'Source concatenation sample count mismatch')
        hidden = decision['selected'][str(horizon)]['hidden']
        require(hidden == 8, 'Head-nine check expects executed hidden size eight')
        for seed in cfg['seeds']:
            path = root / cfg['source_output'] / f'final_h{horizon}_seed{seed}.pt'
            state, record = inspect_checkpoint(path, signature, hidden,
                task_seed(seed, f'source_h{horizon}'), cfg['gru_source_epochs'], len(y),
                cfg['batch_size'], False)
            require(state['metadata']['lr'] == cfg['gru_learning_rate'], 'Source learning rate mismatch')
            source_states[horizon, seed] = state
            source_records.append(dict(record, horizon=horizon, replicate_seed=seed))
    planned = set()
    target_records, baseline_records = [], []
    for site in cfg['development_ids']:
        for episode in cfg['origins']:
            for budget in cfg['budgets']:
                for horizon in cfg['horizons']:
                    task = f'{site}_{episode}_B{budget}_H{horizon}'
                    fingerprint = hashlib.sha256((signature + manifest['config_sha256'] + task).encode()).hexdigest()
                    base_name = 'baseline_' + task
                    planned.add(base_name)
                    base_status = read_json(folder / 'jobs' / base_name / 'status.json')
                    require(base_status['status'] == 'completed' and base_status['fingerprint'] == fingerprint,
                            f'Invalid completed baseline task {base_name}')
                    for name, checksum in base_status['outputs_sha256'].items():
                        require(digest(folder / 'jobs' / base_name / name) == checksum, f'Changed baseline artifact {base_name}/{name}')
                    baseline_records.append({'job': base_name, 'status_sha256': digest(folder / 'jobs' / base_name / 'status.json'),
                                             'outputs_sha256': base_status['outputs_sha256']})
                    for seed in cfg['seeds']:
                        job_name = f'gru_seed{seed}_' + task
                        planned.add(job_name)
                        job = folder / 'jobs' / job_name
                        status = read_json(job / 'status.json')
                        require(status['status'] == 'completed' and status['fingerprint'] == fingerprint,
                                f'Invalid completed GRU task {job_name}')
                        for name, checksum in status['outputs_sha256'].items():
                            require(digest(job / name) == checksum, f'Changed GRU artifact {job_name}/{name}')
                        diag = read_json(job / 'diagnostics.json')
                        require(diag['replicate_seed'] == seed and diag['training_labels'] >= cfg['min_train_labels'],
                                f'Invalid GRU diagnostic {job_name}')
                        require(pd.Timestamp(diag['last_train_target']) <= pd.Timestamp(diag['fit_end']) < pd.Timestamp(episode),
                                f'Target training label outside budget {job_name}')
                        require((pd.Timestamp(episode) - pd.Timestamp(diag['budget_start'])).days == budget,
                                f'Wrong target calendar budget {job_name}')
                        hidden = decision['selected'][str(horizon)]['hidden']
                        records = {}
                        for kind, head_only, epochs, prefix, diagnostic_key in [
                            ('local', False, cfg['gru_local_epochs'], 'local_', 'local'),
                            ('adapt', True, cfg['gru_adaptation_epochs'], 'adapt_', 'adapted')]:
                            state, record = inspect_checkpoint(job / f'{kind}.pt', fingerprint,
                                hidden, task_seed(seed, prefix + task), epochs, diag['training_labels'],
                                cfg['batch_size'], head_only)
                            expected_lr = cfg['gru_adaptation_lr'] if head_only else cfg['gru_learning_rate']
                            require(state['metadata']['lr'] == expected_lr, f'Wrong learning rate {job_name}/{kind}')
                            require(diag[diagnostic_key]['epochs_completed'] == epochs and
                                    diag[diagnostic_key]['training_samples'] == diag['training_labels'],
                                    f'Checkpoint and diagnostic mismatch {job_name}/{kind}')
                            if head_only:
                                encoder = {name: value for name, value in state['model'].items() if name.startswith('gru.')}
                                require(len(encoder) == 4, f'Unexpected GRU encoder tensors {job_name}')
                                require(all(torch.equal(value, source_states[horizon, seed]['model'][name])
                                            for name, value in encoder.items()), f'Adapted encoder changed {job_name}')
                                require(record['head_parameters'] == 9 and diag['adapted']['trainable_parameters'] == 9,
                                        f'Adaptation trainable head is not nine {job_name}')
                                record['encoder_exactly_equals_source'] = True
                                record['encoder_tensors_compared'] = len(encoder)
                                record['source_checkpoint_sha256'] = digest(root / cfg['source_output'] / f'final_h{horizon}_seed{seed}.pt')
                            records[kind] = record
                        target_records.append({'job': job_name, 'site_id': site, 'episode': episode,
                                               'budget': budget, 'horizon': horizon, 'replicate_seed': seed,
                                               'status_sha256': digest(job / 'status.json'),
                                               'outputs_sha256': status['outputs_sha256'], **records})
    actual = {path.name for path in (folder / 'jobs').iterdir() if path.is_dir()}
    require(actual == planned, 'Task inventory differs from planned cohort/windows/budgets/seeds')
    require(len(source_records) == 6 and len(target_records) == 720 and len(baseline_records) == 240,
            'Unexpected real checkpoint or task counts')
    cost_summary = {}
    for family, records in [('source', source_records),
                            ('local', [row['local'] for row in target_records]),
                            ('adapt', [row['adapt'] for row in target_records])]:
        cost_summary[family] = {
            'fits': len(records),
            'epochs_per_fit': sorted({row['epochs'] for row in records}),
            'minibatches_per_epoch': sorted({row['minibatches_per_epoch'] for row in records}),
            'actual_optimizer_steps_per_fit': sorted({row['actual_optimizer_steps_min'] for row in records}),
            'total_actual_optimizer_steps': sum(row['actual_optimizer_steps_min'] for row in records),
            'training_sample_range': [min(row['training_samples'] for row in records),
                                      max(row['training_samples'] for row in records)],
            'stored_total_fit_seconds': sum(row['fit_seconds'] for row in records)}
    return {'status': 'passed', 'checked_utc': datetime.now(timezone.utc).isoformat(),
            'run': str(run), 'run_manifest_sha256': digest(folder / 'manifest.json'),
            'checker_sha256': digest(__file__), 'training_executed': False,
            'performance_metrics_computed': False, 'source_checkpoints': len(source_records),
            'target_local_checkpoints': len(target_records), 'target_adapt_checkpoints': len(target_records),
            'completed_baseline_tasks': len(baseline_records), 'planned_tasks_verified': len(planned),
            'all_adapt_encoder_tensors_exactly_equal_corresponding_source': True,
            'all_adapt_trainable_heads_have_nine_parameters': True,
            'source_weight_vector_check': 'Reconstructed frozen source_pool output equals independent calendar counts and equal-station weights; actual fit weight vectors were not serialized in checkpoint',
            'source_target_ids_disjoint': True, 'final_period_absent_from_canonical': True,
            'source_training_maximum': '2021-12-31', 'development_data_maximum': canonical.date.max(),
            'physical_facility_independence_verified': False,
            'training_cost_summary': cost_summary,
            'source_weight_records': weight_records, 'source_records': source_records,
            'target_records': target_records, 'baseline_records': baseline_records}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', default='runs/shared_v3_20261009/full')
    parser.add_argument('--output', default='validation/stage2_checkpoint_real_checks.json')
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    output = root / args.output
    require(not output.exists(), 'Preserve prior check: choose a new output file')
    result = check(root, args.run)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ['status', 'source_checkpoints',
        'target_local_checkpoints', 'target_adapt_checkpoints', 'planned_tasks_verified']}, indent=2))


if __name__ == '__main__':
    main()
