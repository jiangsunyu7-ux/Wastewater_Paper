"""Create a new QA-controlled version, preserving every original artifact."""
import json
import re
import shutil
from pathlib import Path

import numpy as np
import pandas as pd

from wastewater.common import sha256, utc_now, write_json


def main():
    root = Path(__file__).resolve().parents[1]
    selection = json.loads((root/'data/provenance/DEVELOPMENT_SELECTION_20261009.json').read_text())
    sources = selection['reserved_source_candidate_ids']
    targets = selection['development_ids']
    ids = sources+targets
    output = root/'data/derived/wessex_qa_v3_20261009'
    output.mkdir(parents=True, exist_ok=False)
    old = root/'data/derived/wessex_audit_20261009'
    provenance = json.loads((old/'manifest.json').read_text())
    assert sha256(old/'daily_candidates.csv') == provenance['outputs_sha256']['daily_candidates.csv']
    frames, names = [], []
    for chunk in pd.read_csv(root/'wastewater_data/raw/wessex_all_2016_2025.csv', dtype={'SiteID':str}, chunksize=100000):
        early=chunk[chunk.Date.le('2021-12-31') & chunk.SiteName.str.contains('WATER RECYCLING CENTRE',na=False)]
        names.append(early[['SiteID','SiteName']].drop_duplicates())
        selected=chunk[chunk.SiteID.isin(ids) & chunk.Date.le('2023-12-31')]
        selected=selected[~selected.SiteID.isin(sources) | selected.Date.le('2021-12-31')]
        frames.append(selected)
    raw=pd.concat(frames,ignore_index=True);names=pd.concat(names).drop_duplicates()
    assert set(raw.Units)=={'m3'}
    # Source quality/coverage rule was written before the original model outcomes.
    coverage=pd.read_csv(root/'data/provenance/reconciliation_20261009/coverage_2016_2021.csv',dtype={'site_id':str})
    print('coverage columns',list(coverage.columns))
    names['name_group']=names.SiteName.str.casefold().str.replace(r'\s+(outfall|outlet).*$', '',regex=True).str.replace(r'\s+',' ',regex=True).str.strip()
    groups=names.groupby('name_group').SiteID.apply(lambda s:sorted(set(s)))
    mappings=[]
    for site in ids:
        station=names[names.SiteID.eq(site)]
        assert len(station)==1
        group=station.name_group.iloc[0];linked=groups[group]
        role='source' if site in sources else 'development'
        other=[s for s in linked if s in ids and (s in sources)!=(site in sources)]
        assert not other, 'Provisional same-name facility crosses source/development partition'
        mappings.append({'site_id':site,'provider_site_name':station.SiteName.iloc[0],'partition':role,
                         'partition_group':group,'linked_same_name_ids':'|'.join(linked),
                         'physical_facility_id':'unknown','outfall_id':'unknown','mapping_verified':False,
                         'evidence':'provider raw SiteID/SiteName + saved official TDV description/schema',
                         'unresolved':'No coordinates/permit identifier or relationships in supplied nonspatial TDV table; live metadata requests denied'})
    pd.DataFrame(mappings).to_csv(output/'facility_mapping.csv',index=False)
    pd.DataFrame(mappings).to_csv(root/'data/provenance/FACILITY_MAPPING_V3_20261009.csv',index=False)
    canonical=pd.read_csv(old/'daily_candidates.csv',dtype={'site_id':str},low_memory=False)
    canonical=canonical[canonical.site_id.isin(ids) & canonical.date.le('2023-12-31')].copy()
    canonical=canonical[~canonical.site_id.isin(sources) | canonical.date.le('2021-12-31')]
    changed=canonical.observed_input_m3.notna() & canonical.candidate_value_m3.isna()
    canonical['input_changed_from_v2']=changed
    canonical['observed_input_m3']=canonical.candidate_value_m3
    canonical['qa_mode']='published_good_only_retrospective'
    canonical.to_csv(output/'daily_candidates.csv',index=False)
    qa=raw.QualityFlag.str.casefold();value=pd.to_numeric(raw.TotalVolume)
    counts={'rows':len(raw),'selected_site_ids':len(ids),'sources':sources,'development':targets,
            'raw_missing_zero':int((qa.eq('missing') & value.eq(0)).sum()),
            'raw_missing_nonzero':int((qa.eq('missing') & value.ne(0)).sum()),
            'raw_good_negative':int((qa.eq('good') & value.lt(0)).sum()),
            'raw_good_zero':int((qa.eq('good') & value.eq(0)).sum()),
            'input_records_masked_relative_to_v2':int(changed.sum()),
            'valid_good_targets':int(canonical.candidate_value_m3.notna().sum()),
            'physical_facility_independence_verified':False}
    raw['rule']=np.where(qa.ne('good'),'non_good_published_QA',np.where(value.lt(0),'negative_volume','accepted_Good_nonnegative'))
    conflicts=raw.duplicated(['SiteID','Date'],keep=False)
    raw.loc[conflicts,'rule']='duplicate_requires_canonical_audit_resolution'
    raw.to_csv(output/'selected_record_rules.csv',index=False)
    write_json(output/'summary.json',counts)
    shutil.copyfile(root/'data/provenance/paper_idea_20261009_extracted.txt',output/'paper_idea_extracted.txt')
    write_json(output/'manifest.json',{'status':'completed','created_utc':utc_now(),'version':'qa_v3_20261009',
         'raw_sha256':provenance['raw_sha256'],'upstream_manifest_sha256':sha256(old/'manifest.json'),
         'upstream_data_sha256':sha256(old/'daily_candidates.csv'),'prepare_script_sha256':sha256(__file__),
         'quality_rule':'Good + finite nonnegative + audited nonconflict; identical for input/train/truth; retain Good zero; no interpolation',
         'availability':'published-quality retrospective oracle; historical QA arrival unverified',
         'source_model_max_date':'2021-12-31','development_max_date':'2023-12-31',
         'outputs_sha256':{p.name:sha256(p) for p in output.iterdir()},'summary':counts})
    print(json.dumps(counts,indent=2))


if __name__=='__main__':main()
