"""Recalculate delivered metrics independently from saved real predictions."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from wastewater.common import sha256, write_json


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--report', default='reports/shared_v3_20261009')
    parser.add_argument('--output', default='validation/stage2_metrics_real_checks.json')
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    folder = root / args.report
    p = pd.read_csv(folder / 'predictions_all.csv', dtype={'site_id': str})
    p = p[p.common_evaluation].copy()
    metrics = pd.read_csv(folder / 'metrics_by_station.csv', dtype={'site_id': str})
    keys = ['site_id', 'budget', 'horizon', 'model']
    checked = 0
    for constraint, column in [('raw', 'prediction_m3'), ('all_models_nonnegative', 'prediction_nonnegative_m3')]:
        # Every seed has exactly the same dates. This averages seed losses,
        # rather than first averaging their predictions into an ensemble.
        direct = p[keys].copy()
        error = p[column].to_numpy() - p.truth_m3.to_numpy()
        direct['absolute'] = np.abs(error)
        direct['squared'] = error * error
        calculated = direct.groupby(keys).agg(mae=('absolute', 'mean'), mse=('squared', 'mean')).reset_index()
        actual = metrics[metrics.constraint.eq(constraint)]
        check = calculated.merge(actual, on=keys, validate='one_to_one')
        assert len(check) == 480
        np.testing.assert_allclose(check.mae, check.mae_m3, rtol=1e-12, atol=1e-7)
        np.testing.assert_allclose(np.sqrt(check.mse), check.rmse_m3, rtol=1e-12, atol=1e-7)
        checked += len(check)
    raw = metrics[metrics.constraint.eq('raw')]
    ci = pd.read_csv(folder / 'paired_block_intervals.csv')
    for comparison in ci.drop_duplicates('id').itertuples(index=False):
        a = raw[raw.model.eq(comparison.model) & raw.budget.eq(comparison.budget) & raw.horizon.eq(comparison.horizon)]
        b = raw[raw.model.eq(comparison.reference) & raw.budget.eq(comparison.reference_budget) & raw.horizon.eq(comparison.horizon)]
        pair = a[['site_id', 'mae_m3']].merge(b[['site_id', 'mae_m3']], on='site_id', suffixes=('_a', '_b'), validate='one_to_one')
        assert len(pair) == 10
        point = (1 - pair.mae_m3_a / pair.mae_m3_b).mean()
        np.testing.assert_allclose(ci.loc[ci.id.eq(comparison.id), 'mean_station_skill'], point, rtol=1e-12, atol=1e-12)
        assert int((pair.mae_m3_a > pair.mae_m3_b).sum()) == comparison.negative_transfer_stations
    # Demonstrate that seed averaging was not silently turned into an ensemble.
    gru = p[p.model.eq('shared_gru')].copy()
    dates = ['site_id', 'episode', 'budget', 'horizon', 'origin']
    gru['squared_error'] = (gru.prediction_m3 - gru.truth_m3) ** 2
    per_date = gru.groupby(dates).agg(prediction=('prediction_m3', 'mean'), truth=('truth_m3', 'first'),
                                     mean_seed_mse=('squared_error', 'mean'), seeds=('seed', 'nunique'))
    assert per_date.seeds.eq(3).all()
    ensemble_mse = (per_date.prediction - per_date.truth) ** 2
    difference = per_date.mean_seed_mse - ensemble_mse
    assert difference.min() >= -1e-5 and difference.max() > 0
    write_json(root / args.output, {
        'status': 'passed', 'metric_rows_independently_recomputed': checked,
        'paired_contrast_points_independently_recomputed': int(ci.id.nunique()),
        'same_date_three_seed_loss_averaging_confirmed': True,
        'prediction_ensemble_used': False,
        'max_shared_gru_mean_seed_mse_minus_ensemble_mse_m6': float(difference.max()),
        'report_input_sha256': {name: sha256(folder / name) for name in
            ['predictions_all.csv', 'metrics_by_station.csv', 'paired_block_intervals.csv']},
    })
    print(json.dumps({'status': 'passed', 'metric_rows': checked, 'contrasts': int(ci.id.nunique())}))


if __name__ == '__main__':
    main()
