"""Populate manuscript numbers and figure copies exclusively from checked real artifacts."""
import json
import shutil
from pathlib import Path

import pandas as pd

from wastewater.common import sha256


def main():
    root=Path(__file__).resolve().parents[1];report=root/'reports/development_20261009';paper=root/'manuscript'
    validation=json.loads((report/'validation.json').read_text())
    for name,digest in validation['outputs_sha256'].items():
        if sha256(report/name)!=digest:raise ValueError('Results changed after verification')
    summary=pd.read_csv(report/'equal_station_summary.csv');summary=summary[summary.extra_delay_days.eq(0)]
    audit=json.loads((root/'data/derived/wessex_audit_20261009/summary.json').read_text())
    p=pd.read_csv(report/'predictions_all.csv',usecols=['model','prediction_m3'])
    tables=paper/'tables';tables.mkdir(exist_ok=True);figures=paper/'figures';figures.mkdir(exist_ok=True)
    values={'AllRows':audit['full_rows'],'WrcRows':audit['subset_rows'],'SiteCount':audit['subset_site_ids'],
            'PositiveCount':audit['old_positive_noduplicate_candidate_count'],'NonnegativeCount':audit['valid_candidate_target_rows'],
            'GoodZeros':audit['subset_zero_by_quality']['good'],'PredictionRows':validation['prediction_rows'],
            'NegativeCount':validation['negative_ridge_predictions'],'RidgeRows':int(p.model.eq('local_ridge').sum())}
    for name,h in [('RidgeNinetyOne',1),('RidgeNinetyThree',3)]:
        row=summary[summary.model.eq('local_ridge') & summary.budget.eq(90) & summary.horizon.eq(h)].iloc[0]
        values[name]=f"{100*row.equal_weight_skill_vs_persistence:.2f}"+r'\%'
    slash=chr(92)
    (tables/'result_macros.tex').write_text('% Generated from checked saved real data/results.\n'+'\n'.join(slash+'newcommand{'+slash+name+'}{'+str(value)+'}' for name,value in values.items())+'\n')
    lines=[r'\begin{table}[htbp]',r'\centering\small',r'\caption{Zero-extra-delay development MAE (m$^3$) and equal-site relative skill. This is an exploratory SiteID cohort, not a final physical-facility test.}',r'\begin{tabular}{rrrrrr}',r'\toprule',r'Budget & Horizon & Persistence & Weekly & Local ridge & Ridge skill \\',r'\midrule']
    for B in [30,90,180]:
        for h in [1,3]:
            g=summary[summary.budget.eq(B) & summary.horizon.eq(h)].set_index('model')
            vals=[f'{B}',f'{h}',f"{g.loc['persistence','equal_weight_mae_m3']:.2f}",f"{g.loc['weekly_persistence','equal_weight_mae_m3']:.2f}",f"{g.loc['local_ridge','equal_weight_mae_m3']:.2f}",f"{100*g.loc['local_ridge','equal_weight_skill_vs_persistence']:.2f}"+r'\%']
            lines.append(' & '.join(vals)+r' \\')
    lines.extend([r'\bottomrule',r'\end{tabular}',r'\label{tab:development}',r'\end{table}'])
    (tables/'baselines_delay0.tex').write_text('\n'.join(lines)+'\n')
    shutil.copyfile(root/'literature/verified_metadata.bib',paper/'references.bib')
    with (paper/'references.bib').open('a') as f:
        f.write('\n@misc{wessex2026,\n author = {{Wessex Water}},\n title = {Wessex Water Wastewater Total Daily Volume Data 2016--2025},\n year = {2026},\n url = {https://www.arcgis.com/sharing/rest/content/items/10b910ef3524448e9a5c8691f802dcd2},\n note = {Supplied provider snapshot; reported download 8 October 2026; CC BY 4.0; original bytes preserved}\n}\n')
    for name in ['budget_error_ratios.pdf','delay_sensitivity.pdf']:
        shutil.copyfile(root/'figures/development_20261009'/name,figures/name)
    print('Manuscript numbers and figures populated from verified development artifacts; no final-test sections synthesized.')


if __name__=='__main__':main()
