"""Independent source/pages recount and pre-2022 coverage; does not fit any model."""
import csv
import itertools
import json
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd

from wastewater.common import sha256, utc_now, write_json


def main():
    root = Path(__file__).resolve().parents[1]
    source = root / "wastewater_data"
    out = root / "data/provenance/reconciliation_20261009"
    out.mkdir(parents=True, exist_ok=False)
    raw_path = source / "raw/wessex_all_2016_2025.csv"
    def page_records():
        for p in sorted((source / "raw/wessex_pages").glob("*.json")):
            data = json.loads(p.read_text())
            for feature in data["features"]:
                yield feature["attributes"]
    count = 0
    ids = set()
    with raw_path.open(newline="", encoding="utf-8") as f:
        for row, attrs in itertools.zip_longest(csv.DictReader(f), page_records()):
            if row is None or attrs is None:
                raise ValueError("Raw CSV and pages have different lengths")
            if int(row["OBJECTID"]) in ids:
                raise ValueError("Duplicated OBJECTID")
            ids.add(int(row["OBJECTID"]))
            for key in ["OBJECTID", "SiteID"]:
                if int(row[key]) != attrs[key]:
                    raise ValueError("Page integer differs from CSV")
            if float(row["TotalVolume"]) != attrs["TotalVolume"]:
                raise ValueError("Page volume differs from CSV float representation")
            for key in ["SiteName", "Date", "Units", "QualityFlag"]:
                if row[key] != attrs[key]:
                    raise ValueError("Page text differs from CSV")
            count += 1
    expected = json.loads((source / "metadata/expected_count.json").read_text())["count"]
    if count != expected:
        raise ValueError("Saved provider count differs from records")
    w = pd.read_csv(raw_path, dtype={"SiteID": "string"})
    subset = w[w.SiteName.str.contains("WATER RECYCLING CENTRE", regex=False)].copy()
    duplicates = subset.duplicated(["SiteID", "Date"], keep=False)
    positive = subset.QualityFlag.eq("Good") & subset.TotalVolume.gt(0) & ~duplicates
    independent = {"all_rows": count, "unique_OBJECTID": len(ids), "wrc_rows": len(subset),
                   "wrc_site_id_count": int(subset.SiteID.nunique()), "quality_flags": dict(Counter(subset.QualityFlag)),
                   "negative_by_flag": dict(Counter(subset.loc[subset.TotalVolume.lt(0), "QualityFlag"])),
                   "zero_by_flag": dict(Counter(subset.loc[subset.TotalVolume.eq(0), "QualityFlag"])),
                   "missing_nonzero": int((subset.QualityFlag.eq("Missing") & subset.TotalVolume.ne(0)).sum()),
                   "duplicate_rows": int(duplicates.sum()), "strict_valid_rows": int(positive.sum())}
    new = json.loads((root / "data/derived/wessex_audit_20261009/summary.json").read_text())
    old = json.loads((source / "audit/summary.json").read_text())
    comparisons = {k: {"recount": v, "prior": old.get(k), "match": v == old.get(k)} for k,v in independent.items() if k in old}
    checks = {"positive_count_matches_prior": independent["strict_valid_rows"] == old["strict_valid_rows"],
              "nonnegative_vs_positive_difference_equals_good_zeros": new["valid_candidate_target_rows"]-independent["strict_valid_rows"] == independent["zero_by_flag"]["Good"],
              "all_existing_audit_counts_match": all(c["match"] for c in comparisons.values())}
    if not all(checks.values()):
        raise ValueError("Unexpected audit reconciliation difference")
    coverage_rows = []
    eligible_ids = []
    for sid, group in subset.groupby("SiteID", sort=True):
        names = group.SiteName.unique()
        if len(names) != 1:
            # Alias ambiguity is an eligibility flag, not silently merged independent plants.
            eligible = False
        else:
            eligible = True
        valid = group.QualityFlag.eq("Good") & group.TotalVolume.ge(0) & ~group.duplicated(["SiteID", "Date"], keep=False)
        for year in range(2016, 2022):
            selected = group[group.Date.str.startswith(str(year))]
            dates = group.loc[valid & group.Date.str.startswith(str(year)), "Date"]
            denominator = 366 if year in [2016, 2020] else 365
            coverage = dates.nunique()/denominator
            coverage_rows.append({"site_id": sid, "site_name": names[0], "year": year,
                                  "valid_nonnegative_dates": dates.nunique(), "calendar_days": denominator,
                                  "coverage": coverage, "source_period_rows": len(selected)})
            eligible &= coverage >= .95
        if eligible:
            eligible_ids.append(sid)
    coverage = pd.DataFrame(coverage_rows)
    coverage.to_csv(out / "coverage_2016_2021.csv", index=False)
    eligible_ids.sort(key=int)
    write_json(out / "eligible_station_ids_2016_2021.json", eligible_ids)
    subset[duplicates].to_csv(out / "conflicting_original_records.csv", index=False)
    hk = pd.read_csv(source / "raw/hk.csv", encoding="utf-16", sep="\t", dtype=str, keep_default_na=False)
    flow = pd.to_numeric(hk["Daily Flow (CuM/d)"], errors="coerce")
    dates = pd.to_datetime(hk["Sampling Date"], format="%Y/%m/%d")
    hk_summary = {"rows": len(hk), "series_names": hk["Sewage Treatment Works"].nunique(),
                  "missing_numeric_flow": int(flow.isna().sum()),
                  "duplicate_series_dates": int(hk.duplicated(["Sewage Treatment Works", "Sampling Date"], keep=False).sum()),
                  "first_date": str(dates.min().date()), "last_date": str(dates.max().date()),
                  "target_comparability": "unverified; not pooled"}
    derived = pd.read_csv(source / "derived/wessex_wrc_original_values.csv", dtype={"SiteID":"string"})
    pd.testing.assert_frame_equal(subset.reset_index(drop=True), derived, check_dtype=False)
    flags = pd.read_csv(source / "derived/wessex_wrc_flagged.csv", dtype={"SiteID":"string"})
    if not np.array_equal(flags.strict_candidate_valid.to_numpy(), positive.to_numpy()):
        raise ValueError("Supplied candidate flags differ from independently computed rule")
    result = {"executed_utc": utc_now(), "raw_sha256": sha256(raw_path), "saved_API_pages": 31,
              "csv_equals_all_page_attributes": True, "saved_provider_count": expected,
              "independent_recount": independent, "prior_comparison": comparisons, "checks": checks,
              "current_good_nonnegative_nonconflicting_targets": new["valid_candidate_target_rows"],
              "intentional_difference": "93 Good zero rows retained in primary rule; positive-only package count reproduced exactly",
              "eligible_stations_pre2022": len(eligible_ids), "hong_kong": hk_summary,
              "provided_derived_values_and_flags_match_raw": True, "models_run_here": False,
              "final_period_usage": "Full-period descriptive audit only; no final-period performance or model selection"}
    write_json(out / "reconciliation.json", result)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
