"""Validate notebook runtime helpers in an isolated copy; never add scientific runs."""
import argparse
import ast
import hashlib
import json
import shutil
import sys
import tempfile
import traceback
import zipfile
from pathlib import Path
from unittest import mock


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-root', default='.')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    project = Path(args.project_root).resolve()
    output = project / args.output
    notebook_path = project / 'notebooks/Wessex_Shared_Development_v3.ipynb'
    if output.exists():
        previous = json.loads(output.read_text())
        if previous.get('status') != 'passed':
            attempt = 1
            while output.with_name(output.stem + f'_failed_attempt_{attempt}.json').exists():
                attempt += 1
            shutil.copy2(output, output.with_name(output.stem + f'_failed_attempt_{attempt}.json'))
        elif previous.get('notebook_sha256') != sha256(notebook_path):
            tag = previous.get('notebook_sha256', 'unknown')[:12]
            archive_report = output.with_name(output.stem + f'_superseded_{tag}.json')
            if not archive_report.exists():
                shutil.copy2(output, archive_report)
    report = {'status': 'running', 'notebook_sha256': sha256(notebook_path),
              'scope': 'isolated local notebook-core verification; excluded from scientific reports',
              'real_Colab_Drive_mount_verified': False, 'GPU_execution_verified': False,
              'checks': {}}
    try:
        notebook = json.loads(notebook_path.read_text())
        assert notebook['nbformat'] == 4
        namespace = {'Path': Path}
        code_cells = 0
        for index, cell in enumerate(notebook['cells']):
            if cell['cell_type'] != 'code':
                continue
            source = ''.join(cell['source'])
            ast.parse(source, filename=f'notebook_cell_{index}')
            code_cells += 1
            if 'core' in cell['metadata'].get('tags', []):
                exec(compile(source, f'notebook_cell_{index}', 'exec'), namespace)
        report['checks']['all_code_cells_parse'] = code_cells
        preflight = namespace['preflight']
        run_logged = namespace['run_logged']
        inspect_status = namespace['inspect_status']
        import_zip = namespace['import_zip']
        preservation_dirs = [project / 'runs/shared_v3_20261009/source',
                             project / 'runs/shared_v3_20261009/smoke']
        originals = {str(p.relative_to(project)): sha256(p) for folder in preservation_dirs
                     for p in folder.rglob('*') if p.is_file()}
        with tempfile.TemporaryDirectory(prefix='wessex_notebook_core_') as tmp:
            root = Path(tmp) / 'project'
            root.mkdir()
            for folder in ['src', 'configs/shared_v3_20261009',
                           'data/derived/wessex_qa_v3_20261009',
                           'runs/shared_v3_20261009/source', 'runs/shared_v3_20261009/smoke']:
                shutil.copytree(project / folder, root / folder,
                                ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
            for filename in ['data/provenance/FACILITY_MAPPING_V3_20261009.csv',
                             'data/provenance/DEVELOPMENT_SELECTION_20261009.json',
                             'data/provenance/reconciliation_20261009/coverage_2016_2021.csv',
                             'scripts/validate_stage2.py']:
                target = root / filename
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(project / filename, target)
            smoke = 'configs/shared_v3_20261009/smoke.json'
            checked = preflight(root, smoke)
            assert checked['expected_jobs'] == 96
            report['checks']['exact_cpu_environment_and_original_config_preflight'] = checked
            # A complete two-station run in the isolated project reads every saved cache.
            cached = run_logged(root, smoke, seeds=[20261009])
            assert cached['experiment_state']['counts_this_call'] == {
                'completed': 0, 'cached': 96, 'failed': 0}
            assert inspect_status(root, smoke)['status'] == 'completed'
            report['checks']['two_original_stations_all_96_tasks_verified_cached'] = True
            import subprocess
            (root / 'validation').mkdir(exist_ok=True)
            verified = subprocess.run(
                [sys.executable, 'scripts/validate_stage2.py', '--run',
                 'runs/shared_v3_20261009/smoke', '--output', 'validation/copied_smoke.json'],
                cwd=root, env=namespace['project_env'](root), text=True, capture_output=True)
            if verified.returncode:
                raise RuntimeError(verified.stderr)
            real_checks = json.loads((root / 'validation/copied_smoke.json').read_text())
            assert real_checks['rows'] == 23040
            report['checks']['independent_saved_two_station_prediction_validation'] = real_checks

            cfg = json.loads((root / smoke).read_text())
            cfg['output'] = 'runs/notebook_interface_only'
            cfg_path = 'configs/shared_v3_20261009/notebook_interface_only.json'
            (root / cfg_path).write_text(json.dumps(cfg, indent=2))
            first = run_logged(root, cfg_path, seeds=[20261009], max_jobs=2)
            assert first['experiment_state']['counts_this_call']['completed'] == 2
            assert inspect_status(root, cfg_path)['status'] == 'partial_or_not_started'
            artifacts = {str(p.relative_to(root)): sha256(p)
                         for p in (root / cfg['output'] / 'jobs').rglob('*') if p.is_file()}
            second = run_logged(root, cfg_path, seeds=[20261009], max_jobs=2)
            assert second['experiment_state']['counts_this_call'] == {
                'completed': 0, 'cached': 2, 'failed': 0}
            assert all(sha256(root / p) == value for p, value in artifacts.items())
            report['checks']['new_partial_task_group_run_then_exact_cache_replay'] = {
                'completed_jobs': 2, 'expected_jobs': 96, 'artifacts_unchanged': True,
                'scope': 'interface-only original first smoke condition; excluded from science'}
            original_cfg = (root / cfg_path).read_bytes()
            changed = dict(cfg, gru_local_epochs=cfg['gru_local_epochs'] + 1)
            (root / cfg_path).write_text(json.dumps(changed, indent=2))
            try:
                preflight(root, cfg_path)
            except ValueError:
                report['checks']['changed_training_configuration_rejected'] = True
            else:
                raise AssertionError('Changed training configuration accepted')
            (root / cfg_path).write_bytes(original_cfg)
            canonical = root / cfg['canonical_csv']
            original_data = canonical.read_bytes()
            canonical.write_bytes(original_data + b'\n')
            try:
                preflight(root, cfg_path)
            except ValueError:
                report['checks']['changed_canonical_hash_rejected'] = True
            else:
                raise AssertionError('Changed canonical hash accepted')
            canonical.write_bytes(original_data)
            prediction_path = next((root / cfg['output'] / 'jobs').glob('*/predictions.csv'))
            original_prediction = prediction_path.read_bytes()
            prediction_path.write_bytes(original_prediction + b'\n')
            try:
                inspect_status(root, cfg_path)
            except ValueError:
                report['checks']['changed_completed_predictions_rejected'] = True
            else:
                raise AssertionError('Changed predictions accepted')
            prediction_path.write_bytes(original_prediction)
            # Failed notebook-level calls retain an explicit log and completion record.
            before_logs = set((root / 'runs/colab_logs').glob('*.json'))
            try:
                run_logged(root, 'configs/shared_v3_20261009/nonexistent.json')
            except FileNotFoundError:
                pass
            else:
                raise AssertionError('Missing configuration accepted')
            failure_record = (set((root / 'runs/colab_logs').glob('*.json')) - before_logs).pop()
            failure = json.loads(failure_record.read_text())
            assert failure['status'] == 'failed_or_interrupted' and failure['error']
            assert failure_record.with_suffix('.log').is_file()
            report['checks']['notebook_failure_log_and_status_retained'] = True

            # Epoch-resume verification uses real, budget-limited QA-v3 smoke inputs.
            sys.path.insert(0, str(root / 'src'))
            import numpy as np
            import torch
            from wastewater.shared_data import load_series
            from wastewater.shared_experiment import target_data
            from wastewater.shared_models import fit_gru, predict_gru
            series = load_series(canonical, cfg['development_ids'])
            data, _, _ = target_data(series, cfg, cfg['development_ids'][0],
                                     cfg['origins'][0], 30, 1)
            checkpoint = root / 'notebook_checks/epoch_resume.pt'
            uninterrupted = root / 'notebook_checks/uninterrupted.pt'
            kwargs = {'hidden': 8, 'seed': 1783, 'epochs': 4, 'learning_rate': .01,
                      'batch_size': 256, 'signature': 'notebook-interface-resume-only'}
            original_save = torch.save
            def interrupt_before_third_epoch_save(obj, filename, *a, **kw):
                if obj.get('epoch') == 3:
                    raise RuntimeError('Deliberate local checkpoint interruption')
                return original_save(obj, filename, *a, **kw)
            with mock.patch('torch.save', side_effect=interrupt_before_third_epoch_save):
                try:
                    fit_gru(data.X, data.y, checkpoint=checkpoint, **kwargs)
                except RuntimeError as exc:
                    assert 'Deliberate' in str(exc)
                else:
                    raise AssertionError('Checkpoint interruption failed')
            state = torch.load(checkpoint, map_location='cpu', weights_only=False)
            assert state['epoch'] == 2
            resumed, diag = fit_gru(data.X, data.y, checkpoint=checkpoint, **kwargs)
            complete, complete_diag = fit_gru(data.X, data.y, checkpoint=uninterrupted, **kwargs)
            assert diag['resumed_from_epoch'] == 2
            np.testing.assert_array_equal(predict_gru(resumed, data.X), predict_gru(complete, data.X))
            np.testing.assert_array_equal(diag['loss_history'], complete_diag['loss_history'])
            report['checks']['epoch_two_interruption_then_resume_matches_uninterrupted'] = {
                'resume_epoch': 2, 'completed_epochs': 4, 'real_budget_limited_training_labels': len(data.y),
                'predictions_and_loss_history_exact': True, 'included_in_scientific_results': False}
            try:
                fit_gru(data.X, data.y, checkpoint=checkpoint, **dict(kwargs, epochs=5))
            except ValueError:
                report['checks']['changed_epoch_checkpoint_metadata_rejected'] = True
            else:
                raise AssertionError('Changed checkpoint metadata accepted')

            # ZIP import is verified independently of any Drive or remote account.
            archive = Path(tmp) / 'fixture.zip'
            content = b'notebook-import-interface-fixture\n'
            content_sha = hashlib.sha256(content).hexdigest()
            with zipfile.ZipFile(archive, 'w') as z:
                z.writestr('sample.txt', content)
                z.writestr('SHA256SUMS', content_sha + '  sample.txt\n')
            import_root = Path(tmp) / 'import_test'
            imported = import_zip(archive, import_root, sha256(archive))
            assert imported['manifest_entries_checked'] == 1 and imported['new_files'] == 1
            assert import_zip(archive, import_root)['identical_files_preserved'] == 1
            assert not (import_root / 'SHA256SUMS').exists()
            second_archive = Path(tmp) / 'second_fixture.zip'
            second_content = b'second-independent-package-fixture\n'
            second_sha = hashlib.sha256(second_content).hexdigest()
            with zipfile.ZipFile(second_archive, 'w') as z:
                z.writestr('data/second.txt', second_content)
                z.writestr('SHA256SUMS', second_sha + '  data/second.txt\n')
            second_import = import_zip(second_archive, import_root, sha256(second_archive))
            assert second_import['manifest_entries_checked'] == 1 and second_import['new_files'] == 1
            assert (import_root / 'sample.txt').read_bytes() == content
            assert (import_root / 'data/second.txt').read_bytes() == second_content
            assert not (import_root / 'SHA256SUMS').exists()
            # A preexisting unrelated checksum file is also preserved, not overwritten.
            (import_root / 'SHA256SUMS').write_text('old-project-checksum-file\n')
            assert import_zip(second_archive, import_root)['identical_files_preserved'] == 1
            assert (import_root / 'SHA256SUMS').read_text() == 'old-project-checksum-file\n'
            report['checks']['two_ZIPs_distinct_SHA256SUMS_verified_merged_without_copying_checksums'] = True
            bad_archive = Path(tmp) / 'bad_checksum_fixture.zip'
            with zipfile.ZipFile(bad_archive, 'w') as z:
                z.writestr('bad_file.txt', content)
                z.writestr('SHA256SUMS', '0' * 64 + '  bad_file.txt\n')
            try:
                import_zip(bad_archive, import_root)
            except ValueError:
                report['checks']['incorrect_package_member_SHA256_rejected_before_payload_copy'] = True
            else:
                raise AssertionError('Incorrect package checksum accepted')
            assert not (import_root / 'bad_file.txt').exists()
            (import_root / 'sample.txt').write_text('Preserve a user modification')
            try:
                import_zip(archive, import_root)
            except ValueError:
                report['checks']['zip_different_existing_file_preserved'] = True
            else:
                raise AssertionError('ZIP importer overwrote user content')
            evil = Path(tmp) / 'path_escape.zip'
            with zipfile.ZipFile(evil, 'w') as z:
                z.writestr('../escape.txt', b'rejected')
            try:
                import_zip(evil, import_root)
            except ValueError:
                report['checks']['zip_path_escape_rejected'] = True
            else:
                raise AssertionError('ZIP importer accepted path traversal')
            report['checks']['zip_crc_manifest_and_identical_reimport_verified'] = True
        assert all(sha256(project / p) == value for p, value in originals.items())
        report['checks']['original_source_and_smoke_artifacts_unchanged'] = len(originals)
        report['status'] = 'passed'
    except BaseException:
        report['status'] = 'failed'
        report['failure'] = traceback.format_exc()
        raise
    finally:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
        print(json.dumps({'status': report['status'], 'output': str(output)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
