#!/usr/bin/env bash
set -euo pipefail
TASK_ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
cd "$TASK_ROOT"
mkdir -p .cache/matplotlib
export MPLCONFIGDIR="$TASK_ROOT/.cache/matplotlib"
python3 - <<'PY'
import importlib.metadata, json, platform, shutil
print(json.dumps({'platform': platform.platform(), 'python': platform.python_version(),
 'dependencies': {p: importlib.metadata.version(p) for p in ['numpy','pandas','scipy','scikit-learn','matplotlib']},
 'pdflatex': bool(shutil.which('pdflatex'))}, indent=2))
PY
PYTHONPATH="$TASK_ROOT/src${PYTHONPATH:+:$PYTHONPATH}" python3 -m unittest discover -s tests -v
