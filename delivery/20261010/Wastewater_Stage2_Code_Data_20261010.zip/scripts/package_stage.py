"""Package checked development artifacts and compile the exact Overleaf archive."""
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'deliverables'


def digest(path):
    with path.open('rb') as stream:
        h = hashlib.sha256()
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def archive(path, files, extra=None):
    members = {}
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, source in sorted(files.items()):
            z.write(source, name)
            members[name] = digest(source)
        for name, data in sorted((extra or {}).items()):
            z.writestr(name, data)
            members[name] = hashlib.sha256(data.encode()).hexdigest()
        z.writestr('SHA256SUMS.txt', ''.join(f'{h}  {n}\n' for n, h in sorted(members.items())))
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        for name, checksum in members.items():
            assert hashlib.sha256(z.read(name)).hexdigest() == checksum
    return {'path': str(path.relative_to(ROOT)), 'bytes': path.stat().st_size,
            'sha256': digest(path), 'member_count': len(members) + 1,
            'crc_and_member_sha256_passed': True}


def collect(prefix, files, predicate=None):
    for p in (ROOT / prefix).rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts and (predicate is None or predicate(p)):
            files[p.relative_to(ROOT).as_posix()] = p


def main():
    OUT.mkdir(exist_ok=True)
    # Exact paper payload; no raw data, logs, caches or prior build products.
    paper = {}
    for prefix in ['main.tex', 'references.bib', 'README.md']:
        paper[prefix] = ROOT / 'manuscript' / prefix
    for directory in ['sections', 'tables', 'figures']:
        for p in (ROOT / 'manuscript' / directory).rglob('*'):
            if p.is_file() and p.suffix in {'.tex', '.pdf'}:
                paper[p.relative_to(ROOT / 'manuscript').as_posix()] = p
    overleaf = archive(OUT / 'Wastewater_Overleaf_Development_20261009.zip', paper)
    logs = []
    with tempfile.TemporaryDirectory(prefix='wastewater_overleaf_', dir='/tmp') as folder:
        unpacked = Path(folder)
        with zipfile.ZipFile(ROOT / overleaf['path']) as z:
            z.extractall(unpacked)
        commands = [['pdflatex', '-halt-on-error', '-interaction=nonstopmode', 'main.tex'],
                    ['bibtex', 'main'],
                    ['pdflatex', '-halt-on-error', '-interaction=nonstopmode', 'main.tex'],
                    ['pdflatex', '-halt-on-error', '-interaction=nonstopmode', 'main.tex']]
        for i, command in enumerate(commands, 1):
            log = ROOT / 'validation' / f'overleaf_zip_compile_{i}.txt'
            with log.open('w') as stream:
                subprocess.run(command, cwd=unpacked, stdout=stream, stderr=subprocess.STDOUT, check=True)
            logs.append(str(log.relative_to(ROOT)))
        text = (unpacked / 'main.log').read_text()
        assert not any(token in text for token in ['Overfull', 'Undefined', 'undefined references', 'undefined citations'])
        info = subprocess.run(['pdfinfo', str(unpacked / 'main.pdf')], text=True, capture_output=True, check=True).stdout
        (ROOT / 'validation' / 'overleaf_zip_pdfinfo.txt').write_text(info)
        assert 'Pages:           6' in info
        shutil.copyfile(unpacked / 'main.pdf', OUT / 'Wastewater_Development_Draft_20261009.pdf')
    overleaf.update(extracted_source_compile_passed=True, pages=6, compile_logs=logs,
                    synced_to_overleaf=False, official_journal_template=False)
    (ROOT / 'validation' / 'overleaf_zip_checks.json').write_text(json.dumps(overleaf, indent=2) + '\n')
    status = ROOT / 'STATUS.md'
    marker = '### 已验证的论文和交付包'
    if marker not in status.read_text():
        with status.open('a') as stream:
            stream.write('''\n### 已验证的论文和交付包\n\n- 英文开发技术稿只写实际三个基线与核查结果，作者/机构/期刊待定，共享、区间和最终实验明确待完成。初次LaTeX生成错误已修复，原失败日志保留。\n- 实际Overleaf ZIP已解压到新临时目录，用pdfLaTeX→BibTeX→pdfLaTeX两次编译通过，6页，无最终未定义引用或Overfull；源包不含原始数据，未同步账号、公开或投稿。核验/命令见 validation/overleaf_zip_checks.json 和 overleaf_zip_compile_*.txt。\n- 正文数字来自已核验结果的自动宏/表，claim_traceability.csv将定量结论关联原件、规则、运行、结果、图和正文；所有模型与配置文件在实测后保持相同hash。\n- KSEE官方HTML恢复HTTP200后，实际读取正文1–4节及表1–4，已补核日采样、出水点、7:3比例及删行；单位/步长/分割实现/完整预算仍未明确。当前8元数据、4摘要、1篇选定全文章节，见 literature/KSEE_FULLTEXT_REVIEW.md；此前零全文为历史记录。\n- deliverables 中阶段结果包包含源程序、配置、全部13次真实运行（冒烟单列）、汇总预测/负结果、日志、来源链、英文开发稿与draw.io/PDF/SVG。为减小传输，不重复原数据；daily_candidates及提供方元数据放入阶段包，完整逐记录审计另有可选审计ZIP；全套原件保留云目录，可用原Part1/2和包内导入脚本重新生成。ZIP内含逐文件SHA256；外部压缩包校验见 validation/package_checks.json。\n''')
    stage = {}
    for name in ['.gitignore', 'README.md', 'AGENTS.md', 'RESEARCH_PLAN.md', 'EXPERIMENT_PROTOCOL.md',
                 'STATUS.md', 'WORKFLOW.md', 'requirements.txt', 'claim_traceability.csv']:
        stage[name] = ROOT / name
    for directory in ['src', 'scripts', 'tests', 'configs', 'data/provenance', 'reports',
                      'runs/development', 'figures', 'literature']:
        collect(directory, stage)
    collect('validation', stage, lambda p: p.name not in {'package_checks.json', 'artifacts_sha256.json'})
    # Keep the first-stage historical snapshot with an explicit historical name.
    stage['validation/initial_scaffold_artifacts_sha256.json'] = ROOT / 'validation/artifacts_sha256.json'
    for name, p in paper.items():
        stage['manuscript/' + name] = p
    stage['manuscript/compiled_development_draft.pdf'] = OUT / 'Wastewater_Development_Draft_20261009.pdf'
    for name in ['summary.json', 'rules.json', 'manifest.json', 'flagged_records.csv', 'daily_candidates.csv']:
        path = ROOT / 'data/derived/wessex_audit_20261009' / name
        stage[path.relative_to(ROOT).as_posix()] = path
    collect('wastewater_data/metadata', stage)
    handoff = ROOT / 'materials/received_20261009/Wastewater_Part3_Codex_Handoff/Codex_Handoff_2026-10-09'
    for name in ['import_and_verify.py', 'manifest_original_58.json', 'manifest_archives.json']:
        stage['handoff/' + name] = handoff / name
    instructions = '''# 本次真实开发阶段交付（2026-10-09）

先读 reports/development_20261009/RESULTS.md、STATUS.md、EXPERIMENT_PROTOCOL.md。
这是10个未核实物理身份SiteID的离线开发结果，不是最终跨厂实验。
全部12次主运行及独立冒烟保留，负结果和687负预测均未裁剪。
论文6页开发稿只写实测基线，共享/区间/最终仍待完成。

阶段包包含原审计daily_candidates、异常记录、规则及提供方元数据，可直接重跑基线。原始CSV/API/HK数据不重复打包，保留在用户Part1/Part2及云目录。完整row_audit另见审计伴随ZIP。若要重跑原数据审计，先导入原件：
将本包解压到新项目目录，再从原Part1/Part2导入（脚本先核验、拒绝覆盖冲突）：
python3 handoff/import_and_verify.py --project-root . --zip /path/Wastewater_Part1_Plan_and_Raw.zip --zip /path/Wastewater_Part2_Derived.zip
原文件存在时可运行 python3 handoff/import_and_verify.py --project-root . 只做逐文件核验。
bash scripts/refresh_environment.sh
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
export MPLCONFIGDIR="$PWD/.cache/matplotlib"
export XDG_CACHE_HOME="$PWD/.cache"

已打包原版本daily_candidates，无需重建即可跑smoke和batch；如重做原数据审计，用新目录避免覆盖：
python3 -m wastewater.audit --raw wastewater_data/raw/wessex_all_2016_2025.csv --config configs/audit.wessex_20261009.json --output data/derived/REPLAY_AUDIT
新输出需与原manifest.outputs_sha256逐文件比对；如需补齐row_audit，只复制缺少文件，不覆写已有原版本。
或者写新版本配置指向REPLAY_AUDIT，不把新版本输出伪称原运行。
按WORKFLOW.md执行smoke→batch→新summary→新figures。
完整原逐记录审计在云目录保留，旧审计参考表随原Part2保留。

Overleaf另用源项目ZIP；本结果包不是Overleaf上传包。
SHA256SUMS.txt覆盖其他每个包内文件。日期和图形/PDF生成元数据可能不同，不承诺重新渲染字节相同。
数据是提供方年度快照，历史观测可用性未验证；延迟情景不能恢复历史修订。
'''
    result = archive(OUT / 'Wastewater_Development_Results_20261009.zip', stage,
                     {'START_HERE.md': instructions})
    assert result['bytes'] < 24 * 1024 * 1024, 'Split stage archive before delivery'
    # Exercise the delivered code, canonical table and metadata in a fresh directory.
    with tempfile.TemporaryDirectory(prefix='wastewater_stage_replay_', dir='/tmp') as folder:
        unpacked = Path(folder)
        with zipfile.ZipFile(ROOT / result['path']) as z:
            z.extractall(unpacked)
        before = set((unpacked / 'runs/development').iterdir())
        env = os.environ.copy()
        env['PYTHONPATH'] = str(unpacked / 'src')
        log = ROOT / 'validation/stage_zip_smoke_command.txt'
        with log.open('w') as stream:
            run = subprocess.run(['python3', '-m', 'wastewater.development', '--config',
                                  'configs/development_20261009/smoke.json'], cwd=unpacked,
                                 env=env, stdout=stream, stderr=subprocess.STDOUT)
        created = set((unpacked / 'runs/development').iterdir()) - before
        assert len(created) == 1
        replay = created.pop()
        replay_copy = ROOT / 'validation/stage_zip_smoke_run'
        if replay_copy.exists():
            shutil.rmtree(replay_copy)
        shutil.copytree(replay, replay_copy)
        assert run.returncode == 0
        assert digest(replay / 'predictions.csv') == digest(ROOT / 'runs/development/20261009T061016Z_04efdd27/predictions.csv')
        replay_checks = {'extracted_stage_smoke_passed': True, 'prediction_bytes_match_original_smoke': True,
                         'prediction_sha256': digest(replay / 'predictions.csv'),
                         'original_run': 'runs/development/20261009T061016Z_04efdd27',
                         'repeat_run_artifacts': 'validation/stage_zip_smoke_run',
                         'scope': 'interface verification only; not added to scientific aggregate'}
    (ROOT / 'validation/stage_zip_replay_checks.json').write_text(json.dumps(replay_checks, indent=2) + '\n')
    if '阶段ZIP真实重跑核验' not in status.read_text():
        with status.open('a') as stream:
            stream.write('\n- 阶段ZIP真实重跑核验：解压到全新临时目录后，用包内代码、daily_candidates和元数据直接执行两站smoke；预测CSV字节与原冒烟严格一致。核验运行保留于validation/stage_zip_smoke_run，不并入科学汇总。\n')
    collect('validation', stage, lambda p: p.name not in {'package_checks.json', 'artifacts_sha256.json'})
    result = archive(OUT / 'Wastewater_Development_Results_20261009.zip', stage, {'START_HERE.md': instructions})
    assert result['bytes'] < 24 * 1024 * 1024
    result.update(extracted_source_smoke_passed=True, predictions_identical_to_original_smoke=True)
    audit_files = {}
    collect('data/derived/wessex_audit_20261009', audit_files)
    audit_package = archive(OUT / 'Wastewater_Full_Audit_20261009.zip', audit_files)
    assert audit_package['bytes'] < 24 * 1024 * 1024
    checks = {'overleaf': overleaf, 'stage': result, 'full_audit': audit_package,
              'compiled_pdf': {'path': 'deliverables/Wastewater_Development_Draft_20261009.pdf',
                               'sha256': digest(OUT / 'Wastewater_Development_Draft_20261009.pdf')},
              'raw_datasets_packaged': False, 'public_release_or_submission': False}
    (ROOT / 'validation/package_checks.json').write_text(json.dumps(checks, indent=2) + '\n')
    print(json.dumps(checks, indent=2))


if __name__ == '__main__':
    main()
