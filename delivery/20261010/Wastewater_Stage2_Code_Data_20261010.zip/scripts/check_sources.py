"""Retrieve official evidence with TLS verification; logs access failures without inventing evidence."""
import argparse
import hashlib
import json
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path


SOURCES = {
    "jwpe_105267_metadata": "https://api.crossref.org/works/10.1016/j.jwpe.2024.105267",
    "jenvman_120324_metadata": "https://api.crossref.org/works/10.1016/j.jenvman.2024.120324",
    "wr033826_metadata": "https://api.crossref.org/works/10.1029/2022WR033826",
    "jh_about": "https://iwaponline.com/jh/pages/About",
    "jh_author_guidelines": "https://iwaponline.com/jh/pages/Author_Guidelines",
    "wst_about": "https://iwaponline.com/wst/pages/About",
    "wst_author_guidelines": "https://iwaponline.com/wst/pages/Author_Guidelines",
}


def fetch(item, output):
    name, url = item
    result = {"name": name, "requested_url": url, "attempt_utc": datetime.now(timezone.utc).isoformat()}
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "WastewaterPaperResearch/0.1"})
        with urllib.request.urlopen(request, timeout=15) as response:
            body = response.read(4 * 1024 * 1024 + 1)
            if len(body) > 4 * 1024 * 1024:
                raise ValueError("Evidence larger than 4 MiB; manual supported retrieval needed")
            extension = ".json" if "crossref.org" in url else ".html"
            filename = name + extension
            (output / filename).write_bytes(body)
            result.update({"http_status": response.status, "resolved_url": response.url,
                           "file": filename, "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest(),
                           "evidence_level": "retrieved_not_reviewed"})
    except Exception as exc:
        result.update({"error": str(exc), "evidence_level": "unverified"})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, help="New directory; preserves earlier attempts")
    args = parser.parse_args()
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=False)
    with ThreadPoolExecutor(max_workers=4) as pool:
        outcomes = list(pool.map(lambda item: fetch(item, output), SOURCES.items()))
    (output / "access_log.json").write_text(json.dumps(outcomes, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(outcomes, ensure_ascii=False, indent=2))
    return 0 if all("file" in r for r in outcomes) else 2


if __name__ == "__main__":
    raise SystemExit(main())
