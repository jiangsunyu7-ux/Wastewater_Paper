#!/usr/bin/env bash
set -euo pipefail
TASK_ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
cd "$TASK_ROOT"
# Existing system scientific packages are sufficient for the present machine.
# Reinstallation, when necessary, is isolated and preserves TLS verification.
if ! python3 - <<'PY'
import importlib.metadata
expected = {'numpy':'2.3.5','pandas':'2.2.3','scipy':'1.17.0','scikit-learn':'1.8.0','matplotlib':'3.10.8'}
assert all(importlib.metadata.version(k) == v for k,v in expected.items())
PY
then
  python3 -m venv .venv
  .venv/bin/python -m pip install --disable-pip-version-check -r requirements.txt
  export PATH="$TASK_ROOT/.venv/bin:$PATH"
fi
bash scripts/check_environment.sh
