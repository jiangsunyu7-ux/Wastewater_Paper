"""Plot checked V3 development reports without fitting models or editing results.

The primary figures use unbounded raw forecasts. GRU seed losses are averaged,
not their predictions. A new output directory is required for every export.
"""
import argparse
import json
import os
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("MPLCONFIGDIR", str(_ROOT / ".cache/matplotlib"))
os.environ.setdefault("XDG_CACHE_HOME", str(_ROOT / ".cache"))
Path(os.environ["XDG_CACHE_HOME"]).mkdir(parents=True, exist_ok=True)

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd

from wastewater.common import sha256, write_json


MODELS = ["local_ridge", "shared_ridge", "shared_ridge_bias", "local_gru",
          "shared_gru", "shared_gru_adapt"]
TRANSFER_MODELS = ["shared_ridge", "shared_ridge_bias", "shared_gru", "shared_gru_adapt"]
LABELS = {
    "persistence": "Persistence", "weekly_persistence": "Weekly persistence",
    "local_ridge": "Local ridge", "shared_ridge": "Shared ridge",
    "shared_ridge_bias": "Shared ridge + bias", "local_gru": "Local GRU",
    "shared_gru": "Shared GRU", "shared_gru_adapt": "Shared GRU + adaptation",
}
SHORT = {"shared_ridge": "Ridge", "shared_ridge_bias": "Ridge + bias",
         "shared_gru": "GRU", "shared_gru_adapt": "GRU + adapt"}
COLORS = {"local_ridge": "#0072B2", "shared_ridge": "#56B4E9",
          "shared_ridge_bias": "#009E73", "local_gru": "#D55E00",
          "shared_gru": "#E69F00", "shared_gru_adapt": "#CC79A7",
          "weekly_persistence": "#777777"}
BUDGETS = [30, 90, 180]
HORIZONS = [1, 3]
REQUIRED = ["summary.csv", "metrics_by_station.csv", "paired_comparisons_by_station.csv",
            "paired_block_intervals.csv", "high_volume_summary.csv",
            "high_volume_metrics_by_station.csv", "negative_transfer_summary.csv"]


def save(fig, output, name):
    for extension in ["pdf", "svg", "png"]:
        fig.savefig(output / f"{name}.{extension}", dpi=180, facecolor="white")
    plt.close(fig)


def checked_sources(report):
    validation = json.loads((report / "validation.json").read_text())
    if validation.get("status") != "passed":
        raise ValueError("Only validated complete development reports may be plotted")
    if not validation.get("final_period_excluded"):
        raise ValueError("Final-period exclusion was not verified")
    if not validation.get("same_dates_across_models_seeds_budgets"):
        raise ValueError("Matched evaluation dates were not verified")
    if validation.get("physical_facility_independence_verified") is not False:
        raise ValueError("This script labels this report as unverified SiteID exploration")
    if len(validation.get("seeds", [])) != 3:
        raise ValueError("This figure set requires the complete three-seed report")
    for name, digest in validation.get("outputs_sha256", {}).items():
        if sha256(report / name) != digest:
            raise ValueError(f"Validated report output changed: {name}")
    data = {name: pd.read_csv(report / name, dtype={"site_id": str}) for name in REQUIRED}
    summary = data["summary.csv"]
    raw = summary[summary.constraint.eq("raw")]
    if set(raw.model) != set(MODELS + ["persistence", "weekly_persistence"]):
        raise ValueError("All eight prespecified model conditions are required")
    if set(raw.budget) != set(BUDGETS) or set(raw.horizon) != set(HORIZONS):
        raise ValueError("All budgets and horizons are required")
    if len(raw) != 48 or not raw.stations.eq(10).all():
        raise ValueError("Expected eight models, three budgets, two horizons, and ten SiteIDs")
    if raw.duplicated(["model", "budget", "horizon"]).any():
        raise ValueError("Duplicate aggregate model conditions")
    metrics = data["metrics_by_station.csv"]
    if metrics[metrics.constraint.eq("raw")].site_id.nunique() != 10:
        raise ValueError("Expected the fixed ten-SiteID cohort")
    return data, validation


def budget_skill(data, output):
    s = data["summary.csv"]
    s = s[s.constraint.eq("raw")]
    fig, axes = plt.subplots(1, 2, figsize=(9.3, 4.1), sharey=True)
    for horizon, ax in zip(HORIZONS, axes):
        for model in MODELS + ["weekly_persistence"]:
            g = s[s.horizon.eq(horizon) & s.model.eq(model)].set_index("budget").loc[BUDGETS]
            style = "--" if model.startswith("local_") else (":" if model == "weekly_persistence" else "-")
            ax.plot(BUDGETS, 100 * g.mean_skill, label=LABELS[model], color=COLORS[model],
                    linestyle=style, marker="o", markersize=4.4, linewidth=1.6)
        ax.axhline(0, color="#222222", linewidth=.9, linestyle="--")
        ax.set_xticks(BUDGETS)
        ax.set_xlabel("Initial local calendar history (days)")
        ax.set_title(f"({chr(97 + HORIZONS.index(horizon))}) {horizon}-day horizon")
    axes[0].set_ylabel("Equal-SiteID mean MAE skill vs persistence (%)")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=3, frameon=False, fontsize=8.3,
               bbox_to_anchor=(.5, -.002), columnspacing=1.3)
    fig.subplots_adjust(left=.09, right=.985, top=.91, bottom=.32, wspace=.16)
    save(fig, output, "budget_skill")


def station_transfer(data, output):
    p = data["paired_comparisons_by_station.csv"]
    p = p[p.kind.eq("same_budget_transfer")].copy()
    sites = sorted(p.site_id.unique(), key=lambda value: int(value))
    if len(p) != 10 * 3 * 2 * 4:
        raise ValueError("Every SiteID/budget/horizon/shared model transfer comparison is required")
    limit = float(np.nanmax(np.abs(100 * p.skill)))
    if not np.isfinite(limit):
        raise ValueError("No finite transfer skills")
    limit = max(limit, 1.)
    norm = TwoSlopeNorm(vmin=-limit, vcenter=0., vmax=limit)
    fig, axes = plt.subplots(2, 3, figsize=(10.1, 8.0), sharey=True)
    image = None
    for i, horizon in enumerate(HORIZONS):
        for j, budget in enumerate(BUDGETS):
            ax = axes[i, j]
            g = p[p.horizon.eq(horizon) & p.budget.eq(budget)]
            values = g.pivot(index="site_id", columns="model", values="skill").loc[sites, TRANSFER_MODELS].to_numpy() * 100
            image = ax.imshow(values, cmap="RdBu", norm=norm, aspect="auto", interpolation="nearest")
            for y in range(len(sites)):
                for x in range(len(TRANSFER_MODELS)):
                    value = values[y, x]
                    ax.text(x, y, f"{value:+.1f}", ha="center", va="center", fontsize=7.1,
                            color="white" if abs(value) > .6 * limit else "#111111")
            ax.set_xticks(range(4), [SHORT[m] for m in TRANSFER_MODELS], rotation=25, ha="right", fontsize=8.2)
            ax.set_yticks(range(len(sites)), sites, fontsize=8.3)
            ax.set_title(f"{horizon}-day horizon; {budget}-day history", fontsize=10)
            if j == 0:
                ax.set_ylabel("Development SiteID")
            ax.grid(False)
            ax.tick_params(length=0)
    fig.subplots_adjust(left=.078, right=.905, top=.93, bottom=.092, hspace=.42, wspace=.19)
    color_ax = fig.add_axes([.932, .19, .016, .61])
    fig.colorbar(image, cax=color_ax).set_label("MAE skill vs corresponding local model (%)", fontsize=9)
    save(fig, output, "station_transfer")


def history_budget_intervals(data, output):
    c = data["paired_block_intervals.csv"]
    c = c[c.kind.eq("history_budget_comparison") & c.block_days.eq(14) & c.budget.eq(30)
          & c.reference_budget.isin([90, 180])].copy()
    if len(c) != 16:
        raise ValueError("Expected all sixteen B30 vs local B90/B180 14-day-block contrasts")
    fig, axes = plt.subplots(2, 2, figsize=(9.3, 5.6), sharex=True, sharey=True)
    for i, horizon in enumerate(HORIZONS):
        for j, reference_budget in enumerate([90, 180]):
            ax = axes[i, j]
            rows = c[c.horizon.eq(horizon) & c.reference_budget.eq(reference_budget)].set_index("model").loc[TRANSFER_MODELS]
            for y, (model, row) in enumerate(rows.iterrows()):
                low, point, high = 100 * row.lower_95, 100 * row.mean_station_skill, 100 * row.upper_95
                ax.plot([low, high], [y, y], color=COLORS[model], linewidth=1.8)
                ax.plot([low, high], [y, y], linestyle="none", marker="|", color=COLORS[model], markersize=6)
                ax.plot(point, y, marker="o", color=COLORS[model], markersize=5)
            ax.axvline(0, color="#222222", linewidth=.9, linestyle="--")
            ax.axvline(-5, color="#999999", linewidth=.7, linestyle=":")
            ax.set_yticks(range(4), [LABELS[m] for m in TRANSFER_MODELS], fontsize=8.3)
            ax.set_ylim(3.6, -.6)
            ax.set_title(f"{horizon}-day horizon: shared B30 vs local B{reference_budget}", fontsize=9.8)
            if i == 1:
                ax.set_xlabel("Equal-SiteID mean MAE skill vs local reference (%)")
    fig.subplots_adjust(left=.215, right=.985, top=.94, bottom=.115, hspace=.34, wspace=.14)
    save(fig, output, "history_budget_intervals")


def high_volume_skill(data, output):
    all_summary = data["summary.csv"]
    all_summary = all_summary[all_summary.constraint.eq("raw") & all_summary.model.isin(MODELS)]
    high = data["high_volume_summary.csv"]
    high = high[high.constraint.eq("raw") & high.model.isin(MODELS)]
    pairs = all_summary.merge(high, on=["model", "budget", "horizon", "constraint"],
                              suffixes=("_all", "_high"), validate="one_to_one")
    if len(pairs) != 36:
        raise ValueError("High-volume comparisons must retain all six learning models/budgets/horizons")
    markers = {30: "o", 90: "s", 180: "^"}
    lower = float(np.nanmin(100 * pairs[["mean_skill_all", "mean_skill_high"]].to_numpy()))
    upper = float(np.nanmax(100 * pairs[["mean_skill_all", "mean_skill_high"]].to_numpy()))
    margin = max((upper - lower) * .08, 2.)
    limits = (min(lower - margin, -2.), max(upper + margin, 2.))
    fig, axes = plt.subplots(1, 2, figsize=(9.3, 4.65), sharex=True, sharey=True)
    for horizon, ax in zip(HORIZONS, axes):
        for row in pairs[pairs.horizon.eq(horizon)].itertuples(index=False):
            ax.scatter(100 * row.mean_skill_all, 100 * row.mean_skill_high, marker=markers[row.budget],
                       color=COLORS[row.model], s=38, linewidths=.6, edgecolors="#333333", zorder=3)
        ax.plot(limits, limits, color="#bbbbbb", linewidth=.8, linestyle=":")
        ax.axvline(0, color="#444444", linewidth=.7)
        ax.axhline(0, color="#444444", linewidth=.7)
        ax.set_xlim(limits); ax.set_ylim(limits)
        ax.set_title(f"{horizon}-day horizon")
        ax.set_xlabel("All common dates: mean MAE skill (%)")
    axes[0].set_ylabel("Historical high-volume dates: mean MAE skill (%)")
    model_handles = [Line2D([0], [0], color=COLORS[m], marker="o", linestyle="none", label=LABELS[m]) for m in MODELS]
    budget_handles = [Line2D([0], [0], color="#333333", marker=markers[b], markerfacecolor="white",
                            linestyle="none", label=f"B{b}") for b in BUDGETS]
    fig.legend(handles=model_handles + budget_handles, loc="lower center", ncol=3, frameon=False,
               fontsize=8.2, bbox_to_anchor=(.5, -.003), columnspacing=1.25)
    fig.subplots_adjust(left=.105, right=.985, top=.91, bottom=.29, wspace=.18)
    save(fig, output, "high_volume_skill")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    report = _ROOT / args.report
    output = _ROOT / args.output
    data, validation = checked_sources(report)
    output.mkdir(parents=True, exist_ok=False)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "svg.fonttype": "none", "pdf.fonttype": 42,
                         "axes.grid": True, "grid.alpha": .17,
                         "savefig.bbox": "tight", "savefig.pad_inches": .08})
    questions = {
        "budget_skill": "Do shared or locally adapted models outperform persistence at each allowed local-history budget?",
        "station_transfer": "Which fixed development SiteIDs gain or lose accuracy after sharing or local adaptation, relative to the matching local backbone?",
        "history_budget_intervals": "Can a shared model using 30 days of local history match a local model using 90 or 180 days, accounting for correlated dates and SiteID sampling?",
        "high_volume_skill": "Do apparent skills over all comparison dates persist on dates exceeding a threshold determined only by permitted historical observations?",
    }
    figure_sources = {
        "budget_skill": ["summary.csv"],
        "station_transfer": ["paired_comparisons_by_station.csv", "negative_transfer_summary.csv"],
        "history_budget_intervals": ["paired_block_intervals.csv"],
        "high_volume_skill": ["summary.csv", "high_volume_summary.csv", "high_volume_metrics_by_station.csv"],
    }
    captions = {
        "budget_skill": "Equal-SiteID mean MAE skill relative to persistence by initial local-history budget and forecast horizon. Positive skill denotes lower MAE. All forecasts are unconstrained raw model outputs; the horizontal zero line denotes persistence. All seven non-persistence conditions are shown, including negative results.",
        "station_transfer": "Per-SiteID MAE skill of each shared model relative to its local backbone on common comparison dates. Shared ridge and ridge with a local residual-bias correction are compared with local ridge; shared GRU and adapted shared GRU are compared with local GRU. Negative cells indicate negative transfer; all ten fixed development SiteIDs and all budgets/horizons are retained. The diverging colour scale spans the observed range without clipping.",
        "history_budget_intervals": "A shared model using B30 local history compared with the matching local backbone using B90 or B180. Points show equal-SiteID mean MAE skill and horizontal segments show pointwise 95% intervals from synchronized noncircular 14-day calendar blocks within each episode and resampled SiteID clusters. The zero line denotes equal MAE; the dotted -5% line is an exploratory tolerance, not proof of noninferiority. These intervals are conditional on a small nonrandom development cohort and are not adjusted for multiplicity. The full report retains the 7- and 28-day block sensitivity intervals.",
        "high_volume_skill": "Equal-SiteID mean skill relative to persistence on all common dates (horizontal axis) and historical high-volume dates (vertical axis). Colours identify all six learning models; marker shapes identify B30/B90/B180. The diagonal denotes equal skill in both subsets. Each SiteID/episode threshold is the 90th percentile of valid Good observations in its permitted 30-day initial history, shared by all models and budgets. This empirical volume threshold does not represent treatment capacity, a permit limit, or an overflow threshold. Points are descriptive; no coverage guarantee or independent final-test claim is made.",
    }
    common_note = ("All figures describe a retrospective 2022–2023 development experiment using published quality flags. "
                   "The ten SiteIDs have not been verified as ten independent physical facilities. "
                   "MAE is in m³ of daily treated effluent volume; skill = 100 × (1 − model MAE/reference MAE). "
                   "For GRUs, absolute/squared errors are averaged across three fixed seeds at each shared evaluation date before SiteID aggregation; "
                   "predictions are not ensembled and seeds are not independent facilities. The 2024–2025 final period is excluded. "
                   "Local learning models use source-validated hyperparameters matching their shared backbone; source and local optimization step counts are not matched. "
                   "Uniform all-model nonnegative-output sensitivity results remain in the source report and are not used to select these primary raw figures.")
    for function in [budget_skill, station_transfer, history_budget_intervals, high_volume_skill]:
        function(data, output)
    text = "# V3 development figure questions and captions\n\n" + common_note + "\n\n"
    for name in questions:
        text += f"## {name}\n\nQuestion: {questions[name]}\n\nCaption: {captions[name]}\n\nSources: "
        text += ", ".join(f"`{args.report}/{p}`" for p in figure_sources[name]) + ".\n\n"
    (output / "FIGURE_CAPTIONS.md").write_text(text)
    write_json(output / "figure_provenance.json", {
        "stage": "development", "analysis_unit": "SiteID exploratory", "primary_constraint": "raw",
        "source_report": args.report, "plot_script_sha256": sha256(Path(__file__)),
        "validation_sha256": sha256(report / "validation.json"), "seeds": validation["seeds"],
        "seed_aggregation": validation["seed_aggregation"], "physical_facility_independence_verified": False,
        "questions": questions, "captions": captions, "common_caption_note": common_note,
        "figure_sources": {name: {file: sha256(report / file) for file in files} for name, files in figure_sources.items()},
        "source_outputs_sha256": {file: sha256(report / file) for file in REQUIRED},
        "outputs_sha256": {p.name: sha256(p) for p in output.iterdir() if p.is_file()},
    })
    print(f"Saved four real-result figure sets and source/export hashes to {output}")


if __name__ == "__main__":
    main()
