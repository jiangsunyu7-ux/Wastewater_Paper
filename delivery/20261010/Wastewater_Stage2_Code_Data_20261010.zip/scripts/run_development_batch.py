"""Execute predeclared development configs; retain every successful/incomplete/failed run."""
import argparse
import json
import os
import subprocess
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

from wastewater.common import sha256, write_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    batch = json.loads((root / args.manifest).read_text())
    batch_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "_" + uuid.uuid4().hex[:8]
    output = root / "runs/development/batches" / batch_id
    output.mkdir(parents=True, exist_ok=False)
    results = []
    env = dict(os.environ)
    env["PYTHONPATH"] = str(root / "src")
    for number, config in enumerate(batch["configs"], 1):
        print(f"START {number}/{len(batch['configs'])} {config}", flush=True)
        cfg = json.loads((root / config).read_text())
        run_root = root / cfg["output_root"]
        before = set(run_root.iterdir())
        process = subprocess.run([sys.executable, "-m", "wastewater.development", "--config", config],
                                 cwd=root, env=env, capture_output=True, text=True)
        new_dirs = [p for p in set(run_root.iterdir()) - before if (p / "manifest.json").is_file()]
        log = output / f"command_{number:02d}.log"
        log.write_text(process.stdout + "\nSTDERR:\n" + process.stderr)
        result = {"config": config, "config_sha256": sha256(root / config), "exit_code": process.returncode,
                  "command_log": str(log.relative_to(root)), "run_dir": None, "status": "unidentified_failure"}
        if len(new_dirs) == 1:
            result["run_dir"] = str(new_dirs[0].relative_to(root))
            result["status"] = json.loads((new_dirs[0] / "manifest.json").read_text())["status"]
        results.append(result)
        write_json(output / "batch_index.json", {"batch_id": batch_id, "manifest": args.manifest,
                                                "manifest_sha256": sha256(root / args.manifest), "runs": results})
        print(f"END {number} exit={process.returncode} status={result['status']} {result['run_dir']}", flush=True)
    print(f"BATCH_INDEX={output.relative_to(root)}/batch_index.json", flush=True)
    return 0 if all(r["exit_code"] == 0 for r in results) else 2


if __name__ == "__main__":
    raise SystemExit(main())
