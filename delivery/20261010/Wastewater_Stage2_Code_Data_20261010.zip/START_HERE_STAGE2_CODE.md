# Wessex stage-two development delivery — 2026-10-10

Extract Code_Data, every Runs ZIP, and Reports_Figures into the SAME project ROOT.
Each ZIP contains SHA256SUMS for all its other members. The Colab importer checks
these per-ZIP manifests and skips extracting them; it refuses conflicting existing
files. The three START_HERE_STAGE2_* files have distinct paths. If Runs is split,
every numbered Runs part is required; identical Runs instructions can be merged.

This is treated effluent daily-volume forecasting (m³), using published Good QA
retrospectively. Physical facility independence and historical QA arrival are
unverified. The 10 original development SiteIDs remain fixed. Shared sources use
2016–2021; prediction evaluation uses only 2022–2023. 2024–2025 performance was
not calculated or used to select models. A three-day horizon means the individual
volume on day three, not a three-day sum. These are development point forecasts,
not an independent final test. Raw negative predictions and all completed tasks
are retained; clipping for every model is a separately reported sensitivity.

Read reports/shared_v3_20261009/ANALYSIS.md, EXPERIMENT_PROTOCOL.md, STATUS.md,
and notebooks/README_STAGE2.md. The notebook defaults to the verified CPU setup,
mounts Drive when actually run in Colab, validates configuration/cache signatures,
and supports resumed runs plus failure logs. Its core was checked locally; a live
Colab Drive mount or GPU execution is not claimed. No App, prediction-interval
experiment, final-test experiment, or revised full manuscript is in this stage.

The original million-row CSV, original audit row table, raw DOCX materials, caches,
virtual environments and credentials are excluded. They remain unchanged in the
source workspace / original user data packages. Derived QA-v3 data and metadata
are sufficient to run or verify the delivered stage-two forecasts. Rebuilding
the raw audit requires the original data packages and a NEW output directory.

These ZIPs preserve project-relative paths, including model checkpoints and
provenance. ZIP CRC and every member SHA256 are verified before release.

Code_Data: source, tests, configurations, scripts, notebook, protocol, fixed
cohort evidence, QA-v3 derived data, source registration and provider metadata.
