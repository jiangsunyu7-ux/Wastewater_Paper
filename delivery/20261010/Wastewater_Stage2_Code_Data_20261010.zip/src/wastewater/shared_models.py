"""Small matched-information ridge/GRU models with resumable training."""
import copy
import hashlib
import json
import time
from pathlib import Path

import numpy as np
import torch
from sklearn.linear_model import Ridge
from torch import nn


def stable_seed(seed, task):
    return (int(seed)+int(hashlib.sha256(task.encode()).hexdigest()[:8], 16)) % (2**31-1)


def fit_ridge(X, y, alpha, weights=None):
    model=Ridge(alpha=float(alpha))
    weights=np.ones(len(y))/len(y) if weights is None else np.asarray(weights)
    model.fit(X.reshape(len(X), -1).astype(float), y, sample_weight=weights)
    return model


class CompactGRU(nn.Module):
    def __init__(self, hidden):
        super().__init__()
        self.gru=nn.GRU(input_size=6, hidden_size=hidden, num_layers=1, batch_first=True)
        self.head=nn.Linear(hidden, 1)
        # Start at the normalized history median, using the same initialization rule everywhere.
        nn.init.zeros_(self.head.weight)
        nn.init.ones_(self.head.bias)

    def forward(self, x):
        output, _=self.gru(x)
        return self.head(output[:, -1]).squeeze(-1)


def predict_gru(model, X):
    model.eval()
    with torch.no_grad():
        return model(torch.as_tensor(X, dtype=torch.float32)).cpu().numpy().astype(float)


def fit_gru(X, y, hidden, seed, epochs, learning_rate, checkpoint, weights=None,
            initial=None, head_only=False, batch_size=256, signature=''):
    """CPU-deterministic epoch checkpoints; no evaluation labels/early stopping."""
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.manual_seed(int(seed))
    model=CompactGRU(int(hidden))
    if initial is not None:
        model.load_state_dict(copy.deepcopy(initial))
    if head_only:
        for p in model.gru.parameters():p.requires_grad=False
    optimizer=torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],
                               lr=learning_rate, weight_decay=0.001)
    X=torch.as_tensor(X, dtype=torch.float32)
    y=torch.as_tensor(y, dtype=torch.float32)
    w=np.ones(len(y))/len(y) if weights is None else np.asarray(weights, dtype=float)
    if not np.isclose(w.sum(), 1.0) or not np.all(w>0):raise ValueError('Weights must sum to one')
    # Equal-facility objective; random minibatch mean is unbiased for the full weighted loss.
    w=torch.as_tensor(w*len(y), dtype=torch.float32)
    checkpoint=Path(checkpoint);checkpoint.parent.mkdir(parents=True, exist_ok=True)
    generator=torch.Generator().manual_seed(int(seed))
    metadata={'signature':signature,'hidden':hidden,'seed':seed,'epochs':epochs,'lr':learning_rate,
              'head_only':head_only,'n':len(y),'batch_size':batch_size}
    start=0; losses=[]; elapsed_prior=0.0
    if checkpoint.exists():
        state=torch.load(checkpoint, map_location='cpu', weights_only=False)
        if state['metadata'] != metadata:raise ValueError('Changed training specification; use new output directory')
        model.load_state_dict(state['model']);optimizer.load_state_dict(state['optimizer'])
        generator.set_state(state['generator_state']);start=state['epoch'];losses=state['losses']
        elapsed_prior=state['elapsed_seconds']
    started=time.perf_counter()
    for epoch in range(start, epochs):
        model.train();order=torch.randperm(len(y),generator=generator);total=0.0
        for indices in order.split(batch_size):
            optimizer.zero_grad(set_to_none=True)
            prediction=model(X[indices]);loss=((prediction-y[indices])**2*w[indices]).mean()
            if not torch.isfinite(loss):raise FloatingPointError('Nonfinite training loss')
            loss.backward();nn.utils.clip_grad_norm_(model.parameters(), 1.0);optimizer.step()
            total+=float(loss.detach())*len(indices)/len(y)
        losses.append(total)
        state={'metadata':metadata,'model':model.state_dict(),'optimizer':optimizer.state_dict(),
               'generator_state':generator.get_state(),'epoch':epoch+1,'losses':losses,
               'elapsed_seconds':elapsed_prior+time.perf_counter()-started}
        temporary=checkpoint.with_suffix('.tmp');torch.save(state,temporary);temporary.replace(checkpoint)
    return model, {'epochs_completed':epochs,'resumed_from_epoch':start,'loss_history':losses,
                   'fit_seconds':elapsed_prior+time.perf_counter()-started,
                   'total_parameters':sum(p.numel() for p in model.parameters()),
                   'trainable_parameters':sum(p.numel() for p in model.parameters() if p.requires_grad),
                   'head_only':head_only,'training_samples':len(y),'seed':seed}
