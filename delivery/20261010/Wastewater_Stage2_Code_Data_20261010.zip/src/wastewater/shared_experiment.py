"""Versioned, resumable QA-controlled source/local development experiments."""
import argparse
import hashlib
import json
import time
import traceback
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from .common import runtime_manifest, sha256, utc_now, write_json
from .shared_data import build_samples, load_series, scale_from_history, train_samples
from .shared_models import fit_gru, fit_ridge, predict_gru, stable_seed


METHOD_KEYS=['source_ids','source_training_start','source_training_end','source_selection_train_end',
             'source_selection_validation_start','sequence_length','ridge_alphas','gru_hidden_candidates',
             'gru_source_epochs','gru_local_epochs','gru_adaptation_epochs','gru_learning_rate',
             'gru_adaptation_lr','gru_adaptation','batch_size','selection_seed','selection_score','source_weight']


def execution_signature(root, cfg):
    canonical=root/cfg['canonical_csv'];manifest=json.loads((canonical.parent/'manifest.json').read_text())
    if manifest['status']!='completed' or sha256(canonical)!=manifest['outputs_sha256'][canonical.name]:
        raise ValueError('Canonical hash differs from completed QA audit')
    core={name:sha256(root/'src/wastewater'/name) for name in ['shared_data.py','shared_models.py','shared_experiment.py']}
    info={'data':sha256(canonical),'mapping':sha256(root/cfg['mapping_csv']),
          'core':core,'method':{k:cfg[k] for k in METHOD_KEYS},'torch':torch.__version__}
    return hashlib.sha256(json.dumps(info,sort_keys=True).encode()).hexdigest(),info


def validate(cfg, root):
    if cfg['stage']!='development' or cfg['qa_mode']!='published_good_only_retrospective' or cfg['verified_real_time']:
        raise ValueError('Only explicitly retrospective development is supported')
    if cfg['source_training_end']!='2021-12-31' or cfg['source_selection_train_end']!='2020-12-31':
        raise ValueError('Source temporal boundaries changed')
    if set(cfg['source_ids']) & set(cfg['development_ids']):raise ValueError('Source/target overlap')
    old=json.loads((root/'data/provenance/DEVELOPMENT_SELECTION_20261009.json').read_text())
    if cfg['source_ids']!=old['reserved_source_candidate_ids']:raise ValueError('Unrecorded source selection')
    if cfg['development_ids'] not in (old['development_ids'],old['smoke_ids']):raise ValueError('Changed development cohort')
    if cfg['origins']!=old['origins'] or cfg['evaluation_days']!=60:raise ValueError('Changed original windows')
    if cfg['budgets']!=[30,90,180] or cfg['horizons']!=[1,3]:raise ValueError('Changed budgets/horizons')
    if cfg['extra_delay_days']!=0 or cfg['sequence_length']!=7 or cfg['min_train_labels']<14:raise ValueError('Changed method')
    for date in cfg['origins']:
        if pd.Timestamp(date)+pd.Timedelta(days=cfg['evaluation_days']-1+3)>pd.Timestamp('2023-12-31'):
            raise ValueError('Final-period evaluation is forbidden')
    coverage=pd.read_csv(root/'data/provenance/reconciliation_20261009/coverage_2016_2021.csv',dtype={'site_id':str})
    source_cov=coverage[coverage.site_id.isin(cfg['source_ids'])]
    if len(source_cov)!=18 or not source_cov.coverage.ge(.95).all():raise ValueError('Source historical coverage rule fails')
    mapping=pd.read_csv(root/cfg['mapping_csv'],dtype={'site_id':str})
    if mapping.groupby('partition_group').partition.nunique().gt(1).any():raise ValueError('Linked facility spans partitions')
    for part,ids in [('source',cfg['source_ids']),('development',cfg['development_ids'])]:
        if not set(ids)<=set(mapping.loc[mapping.partition.eq(part),'site_id']):raise ValueError('Mapping role mismatch')


def source_pool(series, cfg, horizon, end):
    xs=[];ys=[];ws=[];diagnostics=[]
    for site in cfg['source_ids']:
        scale=scale_from_history(series[site],cfg['source_training_start'],end)
        data=train_samples(series[site],cfg['source_training_start'],end,horizon,scale)
        if len(data.y)<14:raise ValueError('Insufficient source labels')
        xs.append(data.X);ys.append(data.y);ws.append(np.ones(len(data.y))/(len(cfg['source_ids'])*len(data.y)))
        diagnostics.append({'site_id':site,'scale_m3':scale,'training_labels':len(data.y),
                            'last_train_target':str(data.targets.max().date()),'weight_sum':1/len(cfg['source_ids'])})
    return np.concatenate(xs),np.concatenate(ys),np.concatenate(ws),diagnostics


def select_settings(root, cfg, series, signature):
    folder=root/cfg['source_output'];folder.mkdir(parents=True,exist_ok=True)
    saved=folder/'selection.json'
    if saved.exists():
        decision=json.loads(saved.read_text())
        if decision['signature']!=signature:raise ValueError('Source signature changed; start a new version')
        return decision
    started=time.perf_counter();rows=[];selected={};training_diagnostics=[]
    for horizon in cfg['horizons']:
        X,y,w,ds=source_pool(series,cfg,horizon,cfg['source_selection_train_end'])
        validation=[]
        for site in cfg['source_ids']:
            scale=scale_from_history(series[site],cfg['source_training_start'],cfg['source_selection_train_end'])
            origins=pd.date_range(cfg['source_selection_validation_start'],pd.Timestamp(cfg['source_training_end'])-pd.Timedelta(days=horizon))
            validation.append(build_samples(series[site],origins,horizon,cfg['source_training_start'],scale))
        def score(model,kind):
            scores=[]
            for data in validation:
                pred=model.predict(data.X.reshape(len(data.X),-1)) if kind=='ridge' else predict_gru(model,data.X)
                valid=np.isfinite(data.y) & data.X[:,:,1].sum(axis=1).astype(bool)
                scores.append(float(np.mean(np.abs(pred[valid]-data.y[valid]))))
            return float(np.mean(scores)),scores
        for alpha in cfg['ridge_alphas']:
            t=time.perf_counter();model=fit_ridge(X,y,alpha,w);value,scores=score(model,'ridge')
            rows.append({'horizon':horizon,'family':'ridge','setting':alpha,'selection_mae':value,
                         'source_scores':scores,'seconds':time.perf_counter()-t})
        for hidden in cfg['gru_hidden_candidates']:
            t=time.perf_counter()
            model,diag=fit_gru(X,y,hidden,stable_seed(cfg['selection_seed'],f'select_h{horizon}_hidden{hidden}'),
                cfg['gru_source_epochs'],cfg['gru_learning_rate'],folder/f'select_h{horizon}_hidden{hidden}.pt',
                weights=w,batch_size=cfg['batch_size'],signature=signature)
            value,scores=score(model,'gru')
            rows.append({'horizon':horizon,'family':'gru','setting':hidden,'selection_mae':value,
                         'source_scores':scores,'seconds':time.perf_counter()-t})
            training_diagnostics.append({'horizon':horizon,'hidden':hidden,**diag})
        ridge=min((r for r in rows if r['horizon']==horizon and r['family']=='ridge'),key=lambda r:(r['selection_mae'],r['setting']))
        gru=min((r for r in rows if r['horizon']==horizon and r['family']=='gru'),key=lambda r:(r['selection_mae'],r['setting']))
        selected[str(horizon)]={'alpha':ridge['setting'],'hidden':gru['setting']}
    pd.DataFrame(rows).to_csv(folder/'search_results.csv',index=False)
    decision={'signature':signature,'selected':selected,'total_seconds':time.perf_counter()-started,
              'selection_fit_end':cfg['source_selection_train_end'],'validation_end':'2021-12-31',
              'no_target_data_used':True,'search':rows,'training_diagnostics':training_diagnostics,'completed_utc':utc_now()}
    write_json(saved,decision);return decision


def target_data(series, cfg, site, date, budget, horizon):
    start=pd.Timestamp(date);left=start-pd.Timedelta(days=budget);end=start-pd.Timedelta(days=1)
    s=series[site];scale=scale_from_history(s,left,end)
    train=train_samples(s,left,end,horizon,scale)
    if len(train.y)<cfg['min_train_labels']:raise ValueError(f'Insufficient target labels {site}/{date}/{budget}/{horizon}')
    test=build_samples(s,pd.date_range(start,periods=cfg['evaluation_days']),horizon,left,scale)
    qhistory=s.loc[start-pd.Timedelta(days=30):end].dropna()
    threshold=float(qhistory.quantile(cfg['high_volume_quantile'])) if len(qhistory)>=14 else None
    diag={'site_id':site,'episode':date,'budget':budget,'horizon':horizon,'budget_start':str(left.date()),
          'fit_end':str(end.date()),'scale_m3':scale,'scale_observed_count':int(s.loc[left:end].notna().sum()),
          'training_labels':len(train.y),'first_train_target':str(train.targets.min().date()),
          'last_train_target':str(train.targets.max().date()),'high_threshold_m3':threshold,
          'threshold_history_days':30,'threshold_observations':len(qhistory),
          'training_X_sha256':hashlib.sha256(train.X.tobytes()).hexdigest(),
          'evaluation_X_sha256':hashlib.sha256(test.X.tobytes()).hexdigest()}
    return train,test,diag


def prediction_frame(test, diag, outputs, seed):
    rows=[];available=test.X[:,:,1].sum(axis=1)>0
    for model,values in outputs.items():
        for i,(origin,target) in enumerate(zip(test.origins,test.targets)):
            prediction=float(values[i])
            if model not in ['persistence','weekly_persistence'] and not available[i]:prediction=np.nan
            truth=float(test.y[i]*test.scale)
            rows.append({'site_id':diag['site_id'],'episode':diag['episode'],'budget':diag['budget'],
                         'horizon':diag['horizon'],'origin':str(origin.date()),'target_date':str(target.date()),
                         'model':model,'seed':seed,'truth_m3':truth,'prediction_m3':prediction,
                         'prediction_nonnegative_m3':max(0,prediction) if np.isfinite(prediction) else np.nan,
                         'budget_start':diag['budget_start'],'fit_end':diag['fit_end'],
                         'last_train_target':diag['last_train_target'],'latest_input_date':str(origin.date()),
                         'scale_m3':test.scale,'training_labels':diag['training_labels'],
                         'high_threshold_m3':diag['high_threshold_m3'],
                         'threshold_observations':diag['threshold_observations'],
                         'analysis_unit':'station_exploratory','qa_mode':'published_good_only_retrospective'})
    return pd.DataFrame(rows)


def run_job(folder, fingerprint, operation):
    folder.mkdir(parents=True,exist_ok=True);status_file=folder/'status.json'
    if status_file.exists():
        status=json.loads(status_file.read_text())
        if status['fingerprint']!=fingerprint:raise ValueError('Changed job configuration/code/data; use a new version')
        if status['status']=='completed':
            for name,h in status['outputs_sha256'].items():
                if sha256(folder/name)!=h:raise ValueError('Completed artifact changed')
            return 'cached'
        attempt=status.get('attempt',1)+1
    else:attempt=1
    status={'status':'running','fingerprint':fingerprint,'started_utc':utc_now(),'attempt':attempt}
    write_json(status_file,status);started=time.perf_counter()
    try:
        predictions,diagnostics=operation(folder)
        predictions.to_csv(folder/'predictions.csv',index=False)
        write_json(folder/'diagnostics.json',diagnostics)
        status.update(status='completed',seconds=time.perf_counter()-started,finished_utc=utc_now(),
                      outputs_sha256={p.name:sha256(p) for p in folder.iterdir() if p.name not in ['status.json'] and p.is_file()})
        write_json(status_file,status);return 'completed'
    except Exception as exc:
        (folder/f'failure_attempt_{attempt}.txt').write_text(traceback.format_exc())
        status.update(status='failed',error=str(exc),seconds=time.perf_counter()-started,finished_utc=utc_now())
        write_json(status_file,status);return 'failed'


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--config',required=True)
    parser.add_argument('--seeds',type=int,nargs='+');parser.add_argument('--max-jobs',type=int)
    args=parser.parse_args();root=Path(__file__).resolve().parents[2];cfg_path=root/args.config
    cfg=json.loads(cfg_path.read_text());validate(cfg,root)
    seeds=args.seeds if args.seeds else cfg['seeds']
    if not set(seeds)<=set(cfg['seeds']):raise ValueError('Unplanned seed')
    signature,info=execution_signature(root,cfg)
    output=root/cfg['output'];output.mkdir(parents=True,exist_ok=True)
    manifest_path=output/'manifest.json'
    config_hash=sha256(cfg_path)
    if manifest_path.exists():
        prior=json.loads(manifest_path.read_text())
        if prior['signature']!=signature or prior['config_sha256']!=config_hash:raise ValueError('Run specification changed; new output required')
    manifest={'status':'running','signature':signature,'provenance':info,'config':cfg,'config_sha256':config_hash,
              'runtime':runtime_manifest(root),'started_utc':utc_now(),'selected_seeds_this_call':seeds}
    write_json(manifest_path,manifest)
    source_series=load_series(root/cfg['canonical_csv'],cfg['source_ids'])
    series=load_series(root/cfg['canonical_csv'],cfg['development_ids'])
    decision=select_settings(root,cfg,source_series,signature)
    manifest['selection_sha256']=sha256(root/cfg['source_output']/'selection.json')
    source_ridge={};source_gru={};source_diagnostics=[]
    for horizon in cfg['horizons']:
        X,y,w,ds=source_pool(source_series,cfg,horizon,cfg['source_training_end'])
        setting=decision['selected'][str(horizon)]
        source_ridge[horizon]=fit_ridge(X,y,setting['alpha'],w)
        for seed in seeds:
            model,diag=fit_gru(X,y,setting['hidden'],stable_seed(seed,f'source_h{horizon}'),
                cfg['gru_source_epochs'],cfg['gru_learning_rate'],root/cfg['source_output']/f'final_h{horizon}_seed{seed}.pt',
                weights=w,batch_size=cfg['batch_size'],signature=signature)
            source_gru[horizon,seed]=model
            source_diagnostics.append({'horizon':horizon,'replicate_seed':seed,'sites':ds,**diag})
    write_json(output/'source_diagnostics.json',source_diagnostics)
    counts={'completed':0,'cached':0,'failed':0};executed=0
    for site in cfg['development_ids']:
        for date in cfg['origins']:
            for budget in cfg['budgets']:
                for horizon in cfg['horizons']:
                    train,test,diag=target_data(series,cfg,site,date,budget,horizon)
                    task=f'{site}_{date}_B{budget}_H{horizon}';shared=source_ridge[horizon]
                    def baseline_job(folder):
                        t=time.perf_counter();local=fit_ridge(train.X,train.y,decision['selected'][str(horizon)]['alpha'])
                        shared_train=shared.predict(train.X.reshape(len(train.X),-1));bias=float(np.mean(train.y-shared_train))
                        sp=shared.predict(test.X.reshape(len(test.X),-1))*test.scale
                        pred={'persistence':test.persistence,'weekly_persistence':test.weekly,
                              'local_ridge':local.predict(test.X.reshape(len(test.X),-1))*test.scale,
                              'shared_ridge':sp,'shared_ridge_bias':sp+bias*test.scale}
                        np.savez(folder/'ridge_parameters.npz',local_coef=local.coef_,local_intercept=local.intercept_,
                                 shared_coef=shared.coef_,shared_intercept=shared.intercept_,bias_m3=bias*test.scale)
                        return prediction_frame(test,diag,pred,0),dict(diag,bias_m3=bias*test.scale,fit_seconds=time.perf_counter()-t)
                    fingerprint=hashlib.sha256((signature+config_hash+task).encode()).hexdigest()
                    state=run_job(output/'jobs'/('baseline_'+task),fingerprint,baseline_job);counts[state]+=1;executed+=1
                    for seed in seeds:
                        def gru_job(folder):
                            settings=decision['selected'][str(horizon)];shared=source_gru[horizon,seed]
                            local,ld=fit_gru(train.X,train.y,settings['hidden'],stable_seed(seed,'local_'+task),
                                cfg['gru_local_epochs'],cfg['gru_learning_rate'],folder/'local.pt',
                                batch_size=cfg['batch_size'],signature=fingerprint)
                            adapted,ad=fit_gru(train.X,train.y,settings['hidden'],stable_seed(seed,'adapt_'+task),
                                cfg['gru_adaptation_epochs'],cfg['gru_adaptation_lr'],folder/'adapt.pt',
                                initial=shared.state_dict(),head_only=True,batch_size=cfg['batch_size'],signature=fingerprint)
                            pred={'local_gru':predict_gru(local,test.X)*test.scale,
                                  'shared_gru':predict_gru(shared,test.X)*test.scale,
                                  'shared_gru_adapt':predict_gru(adapted,test.X)*test.scale}
                            return prediction_frame(test,diag,pred,seed),dict(diag,local=ld,adapted=ad,replicate_seed=seed)
                        state=run_job(output/'jobs'/(f'gru_seed{seed}_'+task),fingerprint,gru_job);counts[state]+=1;executed+=1
                    if args.max_jobs and executed>=args.max_jobs:break
                if args.max_jobs and executed>=args.max_jobs:break
            if args.max_jobs and executed>=args.max_jobs:break
        print(f'site={site} progress={counts}',flush=True)
        if args.max_jobs and executed>=args.max_jobs:break
    statuses=[json.loads(p.read_text()) for p in (output/'jobs').glob('*/status.json')]
    expected=len(cfg['development_ids'])*len(cfg['origins'])*len(cfg['budgets'])*len(cfg['horizons'])*(1+len(cfg['seeds']))
    completed=sum(s['status']=='completed' for s in statuses)
    manifest.update(status='completed' if completed==expected else 'partial',finished_utc=utc_now(),
                    counts_this_call=counts,completed_jobs=completed,expected_jobs=expected,
                    failed_jobs=sum(s['status']=='failed' for s in statuses),source_diagnostics=source_diagnostics,
                    physical_facility_independence_verified=False,online_QA_availability_verified=False)
    write_json(manifest_path,manifest)
    print(json.dumps({k:manifest[k] for k in ['status','completed_jobs','expected_jobs','failed_jobs']},indent=2))
    if counts['failed']:raise SystemExit(2)


if __name__=='__main__':main()
