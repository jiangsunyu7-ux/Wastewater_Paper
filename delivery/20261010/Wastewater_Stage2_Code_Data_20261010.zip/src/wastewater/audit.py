"""Explicit-schema raw CSV audit; never guesses units or facility identity."""
import argparse
import json
import math
import traceback
from pathlib import Path

import numpy as np
import pandas as pd

from .common import runtime_manifest, sha256, utc_now, write_json


RULES = {
    "outside_name_subset": "Not in the explicitly configured literal name subset.",
    "invalid_site": "Missing/blank station ID.",
    "invalid_date": "Date cannot be parsed under explicit date format.",
    "invalid_value": "Value non-numeric or non-finite; not input or truth.",
    "negative_value": "Negative daily volume; not input or truth even if Good.",
    "unaccepted_quality": "Retrospective QA not in explicit accepted set; not evaluation truth.",
    "invalid_unit": "Unit differs from explicitly configured raw unit; not input or truth.",
    "duplicate_identical": "Same station/date/numeric value/QA; all source rows retained, one daily record.",
    "conflicting_station_day": "Different value/QA on same station/date; entire group quarantined.",
}


def audit_frame(raw, cfg):
    cols = cfg["columns"]
    required = [cols[k] for k in ["site", "date", "value", "quality", "name"]]
    missing = set(required) - set(raw.columns)
    if missing:
        raise ValueError(f"Configured raw columns absent: {sorted(missing)}")
    multiplier = float(cfg["value_multiplier_to_m3"])
    if not math.isfinite(multiplier) or multiplier <= 0:
        raise ValueError("Unit multiplier must be finite and positive, with documented semantics")
    out = pd.DataFrame({"source_record": np.arange(1, len(raw) + 1),
                        "site_id": raw[cols["site"]].astype("string").str.strip(),
                        "site_name": raw[cols["name"]].astype("string"),
                        "raw_date": raw[cols["date"]], "raw_value": raw[cols["value"]],
                        "raw_quality": raw[cols["quality"]]})
    out["date"] = pd.to_datetime(out.raw_date, format=cfg["date_format"], errors="coerce").dt.normalize()
    # CSV reader uses nullable StringDtype; force NaN instead of propagating pd.NA
    # into boolean finiteness masks (which would silently miss bad numeric rows).
    out["numeric_m3"] = pd.to_numeric(out.raw_value, errors="coerce").astype(float) * multiplier
    out["quality_normalized"] = out.raw_quality.astype("string").fillna("").str.strip().str.casefold()
    quality = {str(x).strip().casefold() for x in cfg["valid_target_quality"]}
    if not quality:
        raise ValueError("An explicit nonempty accepted QA set is required")
    out["quality_accepted"] = out.quality_normalized.isin(quality)
    unit_ok = pd.Series(True, index=out.index)
    if "unit" in cols:
        if cols["unit"] not in raw.columns or not cfg.get("expected_unit"):
            raise ValueError("Explicit existing unit column and expected_unit required")
        out["raw_unit"] = raw[cols["unit"]]
        unit_ok = out.raw_unit.astype("string").str.strip().eq(cfg["expected_unit"]).fillna(False)
    literal = cfg["name_filter_literal"]
    if not isinstance(literal, str) or not literal.strip():
        raise ValueError("A nonempty literal name filter is required")
    out["included_subset"] = out.site_name.str.contains(literal, regex=False, case=False, na=False)
    masks = {
        "outside_name_subset": ~out.included_subset,
        "invalid_site": out.site_id.isna() | out.site_id.eq("").fillna(True),
        "invalid_date": out.date.isna(),
        "invalid_value": ~np.isfinite(out.numeric_m3),
        "negative_value": out.numeric_m3.lt(0),
        "unaccepted_quality": ~out.quality_accepted,
        "invalid_unit": ~unit_ok,
    }
    codes = [[] for _ in range(len(out))]
    for rule, mask in masks.items():
        for idx in out.index[mask]:
            codes[idx].append(rule)
    valid_key = out.included_subset & ~masks["invalid_site"] & ~masks["invalid_date"]
    selected = out[valid_key].copy()
    keys = ["site_id", "date"]
    variant_columns = keys + ["numeric_m3", "quality_normalized"]
    if "raw_unit" in selected:
        variant_columns.append("raw_unit")
    variants = selected.drop_duplicates(variant_columns)
    conflict_keys = pd.MultiIndex.from_frame(variants.loc[variants.duplicated(keys, keep=False), keys]).unique()
    selected_index = pd.MultiIndex.from_frame(selected[keys])
    conflict_mask = selected_index.isin(conflict_keys)
    duplicate_mask = selected.duplicated(keys, keep=False).to_numpy() & ~conflict_mask
    for idx in selected.index[conflict_mask]:
        codes[idx].append("conflicting_station_day")
    for idx in selected.index[duplicate_mask]:
        codes[idx].append("duplicate_identical")
    conflict_days = len(conflict_keys)
    duplicate_days = len(selected.loc[duplicate_mask, keys].drop_duplicates())
    first = selected.drop_duplicates(keys).copy()
    first["conflict"] = pd.MultiIndex.from_frame(first[keys]).isin(conflict_keys).astype(int)
    numerical_ok = np.isfinite(first.numeric_m3) & first.numeric_m3.ge(0) & first.conflict.eq(0) & unit_ok.loc[first.index]
    truth_ok = numerical_ok & first.quality_accepted
    first["candidate_value_m3"] = first.numeric_m3.where(truth_ok)
    first["observed_input_m3"] = first.numeric_m3.where(numerical_ok)
    first["target_quality_valid"] = truth_ok.astype(int)
    first["source_records"] = first.source_record.astype(str)
    # Only duplicated groups require aggregation, avoiding a Python loop per day in a million-row source.
    duplicate_rows = selected[selected.duplicated(keys, keep=False)]
    if len(duplicate_rows):
        provenance = duplicate_rows.groupby(keys).source_record.agg(lambda s: "|".join(s.astype(str)))
        first_index = pd.MultiIndex.from_frame(first[keys])
        aggregated = provenance.reindex(first_index)
        first.loc[aggregated.notna().to_numpy(), "source_records"] = aggregated.dropna().to_numpy()
    first["date"] = first.date.dt.strftime("%Y-%m-%d")
    out["rules"] = ["|".join(x) for x in codes]
    daily_cols = ["site_id", "date", "candidate_value_m3", "observed_input_m3", "target_quality_valid", "conflict", "source_records"]
    daily = first[daily_cols].sort_values(["site_id", "date"]).reset_index(drop=True)
    counts = {k: int(v.sum()) for k, v in masks.items()}
    counts.update({"conflicting_station_days": conflict_days, "identical_duplicate_days": duplicate_days})
    finite_raw = np.isfinite(out.numeric_m3)
    subset = out[out.included_subset]
    subset_dup = subset.duplicated(["site_id", "date"], keep=False)
    strict_old = subset.quality_accepted & subset.numeric_m3.gt(0) & ~subset_dup & subset.date.notna() & subset.site_id.notna() & unit_ok.loc[subset.index]
    summary = {"full_rows": int(len(out)), "subset_rows": int(out.included_subset.sum()),
               "subset_site_ids": int(out.loc[out.included_subset & ~masks["invalid_site"], "site_id"].nunique()),
               "date_min": str(out.date.min()), "date_max": str(out.date.max()),
               "good_negative_rows": int((out.quality_normalized.eq("good") & out.numeric_m3.lt(0)).sum()),
               "missing_nonzero_rows": int((out.quality_normalized.eq("missing") & finite_raw & out.numeric_m3.ne(0)).sum()),
               "quality_counts": {str(k): int(v) for k, v in out.quality_normalized.value_counts(dropna=False).items()},
               "subset_quality_counts": {str(k): int(v) for k, v in subset.quality_normalized.value_counts(dropna=False).items()},
               "subset_negative_by_quality": {str(k): int(v) for k, v in subset.loc[subset.numeric_m3.lt(0), "quality_normalized"].value_counts().items()},
               "subset_zero_by_quality": {str(k): int(v) for k, v in subset.loc[subset.numeric_m3.eq(0), "quality_normalized"].value_counts().items()},
               "subset_missing_nonzero": int((subset.quality_normalized.eq("missing") & np.isfinite(subset.numeric_m3) & subset.numeric_m3.ne(0)).sum()),
               "subset_duplicate_records": int(subset_dup.sum()),
               "old_positive_noduplicate_candidate_count": int(strict_old.sum()),
               "zero_target_policy": "Include accepted-QA zero values; no evidence all zero values are invalid. Report positive-only audit separately.",
               "rule_counts": counts, "daily_candidate_rows": int(len(daily)),
               "valid_candidate_target_rows": int(daily.target_quality_valid.sum()) if len(daily) else 0,
               "physical_facility_count": None,
               "note": "Station IDs are not facilities; dates without records are restored in the modeling calendar."}
    return out, daily, summary


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--raw", required=True)
    ap.add_argument("--config", required=True)
    ap.add_argument("--output", required=True, help="New output directory; never overwrites")
    args = ap.parse_args()
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=False)
    manifest = {"status": "running", "started_utc": utc_now(), "command_args": vars(args),
                "runtime": runtime_manifest(Path(__file__).resolve().parents[2])}
    try:
        cfg = json.loads(Path(args.config).read_text())
        manifest.update({"raw_sha256": sha256(args.raw), "config_sha256": sha256(args.config), "config": cfg})
        write_json(output / "manifest.json", manifest)
        raw = pd.read_csv(args.raw, dtype="string", encoding=cfg["encoding"], sep=cfg["separator"])
        audit, daily, summary = audit_frame(raw, cfg)
        if sha256(args.raw) != manifest["raw_sha256"]:
            raise ValueError("Raw file changed during audit; source integrity cannot be established")
        audit.to_csv(output / "row_audit.csv", index=False)
        audit[audit.rules.ne("")].to_csv(output / "flagged_records.csv", index=False)
        daily.to_csv(output / "daily_candidates.csv", index=False)
        write_json(output / "summary.json", summary)
        write_json(output / "rules.json", RULES)
        manifest.update({"status": "completed", "finished_utc": utc_now(), "summary": summary,
                         "outputs_sha256": {p.name: sha256(p) for p in output.iterdir() if p.name != "manifest.json"}})
        write_json(output / "manifest.json", manifest)
        print(json.dumps(summary, ensure_ascii=False, indent=2))
    except Exception as exc:
        manifest.update({"status": "failed", "finished_utc": utc_now(), "error": str(exc)})
        write_json(output / "manifest.json", manifest)
        (output / "failure.txt").write_text(traceback.format_exc())
        raise


if __name__ == "__main__":
    main()
