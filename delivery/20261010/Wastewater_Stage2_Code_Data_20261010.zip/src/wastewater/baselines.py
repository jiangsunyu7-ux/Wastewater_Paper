"""Calendar-aware fixed-fit baselines for explicitly isolated development sites."""
from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


LAGS = (0, 1, 2, 3, 6, 7)
FEATURES = tuple(f"lag_{i}" for i in LAGS) + ("past_7_mean", "weekday_sin", "weekday_cos")
MODELS = ("persistence", "weekly_persistence", "local_ridge")


def daily_calendar(rows, left, right):
    rows = rows.copy()
    rows["date"] = pd.to_datetime(rows["date"], format="%Y-%m-%d", errors="raise")
    if rows.date.duplicated().any():
        raise ValueError("Duplicate canonical dates require re-audit, not row selection")
    for name in ["candidate_value_m3", "observed_input_m3"]:
        rows[name] = pd.to_numeric(rows[name], errors="raise")
        bad = rows[name].notna() & (~np.isfinite(rows[name]) | rows[name].lt(0))
        if bad.any():
            raise ValueError(f"Unquarantined invalid values in {name}")
    quality = pd.to_numeric(rows["target_quality_valid"], errors="raise")
    if not quality.isin([0, 1]).all():
        raise ValueError("Quality-valid flag must be 0 or 1")
    if (quality.eq(0) & rows.candidate_value_m3.notna()).any():
        raise ValueError("Unaccepted QA record supplied as evaluation truth")
    if "conflict" in rows.columns:
        conflict = pd.to_numeric(rows["conflict"], errors="raise")
        if not conflict.isin([0, 1]).all() or (conflict.eq(1) & rows.observed_input_m3.notna()).any():
            raise ValueError("Conflicting records must remain quarantined as inputs")
    rows = rows.set_index("date").sort_index()
    return rows.reindex(pd.date_range(pd.Timestamp(left), pd.Timestamp(right), freq="D"))


def at(series, date, left, known_through):
    date = pd.Timestamp(date)
    if date < left or date > known_through or date not in series.index:
        return np.nan
    v = series.loc[date]
    return float(v) if pd.notna(v) else np.nan


def features_at(series, origin, horizon, left, delay_days=0):
    origin = pd.Timestamp(origin)
    last = origin - pd.Timedelta(days=delay_days)
    values = [at(series, last - pd.Timedelta(days=l), left, last) for l in LAGS]
    past = [at(series, last - pd.Timedelta(days=l), left, last) for l in range(7)]
    observed = [v for v in past if np.isfinite(v)]
    values.append(float(np.mean(observed)) if observed else np.nan)
    weekday = (origin + pd.Timedelta(days=horizon)).dayofweek
    values.extend([float(np.sin(2 * np.pi * weekday / 7)), float(np.cos(2 * np.pi * weekday / 7))])
    return values


def persistence_at(series, origin, left, delay_days=0, max_age=7):
    last = pd.Timestamp(origin) - pd.Timedelta(days=delay_days)
    for age in range(max_age + 1):
        v = at(series, last - pd.Timedelta(days=age), left, last)
        if np.isfinite(v):
            return v, age + delay_days
    return np.nan, np.nan


def weekly_at(series, origin, horizon, left, delay_days=0):
    target_last_week = pd.Timestamp(origin) + pd.Timedelta(days=horizon - 7)
    last = pd.Timestamp(origin) - pd.Timedelta(days=delay_days)
    return at(series, target_last_week, left, last)


@dataclass
class TrainingSet:
    X: np.ndarray
    y: np.ndarray
    origins: list
    targets: list


def training_set(calendar, deployment, budget, horizon, delay_days=0):
    deployment = pd.Timestamp(deployment)
    left = deployment - pd.Timedelta(days=budget)
    # Labels must have arrived by initial fit time too, not just lie before deployment.
    last_truth = deployment - pd.Timedelta(days=1 + delay_days)
    X, y, origins, targets = [], [], [], []
    for origin in pd.date_range(left, last_truth, freq="D"):
        target = origin + pd.Timedelta(days=horizon)
        if target > last_truth:
            continue
        # Retrospective QA is unavailable at fitting. Train on the arrived raw observation,
        # not a target subset chosen using a later quality flag; evaluate on QA truth later.
        truth = at(calendar.observed_input_m3, target, left, last_truth)
        features = features_at(calendar.observed_input_m3, origin, horizon, left, delay_days)
        # A purely calendar-only sample does not validate a water-history predictor.
        if np.isfinite(truth) and np.isfinite(features[:len(LAGS) + 1]).any():
            X.append(features)
            y.append(truth)
            origins.append(origin)
            targets.append(target)
    return TrainingSet(np.asarray(X, dtype=float).reshape(-1, len(FEATURES)), np.asarray(y), origins, targets)


def ridge_pipeline(alpha):
    # Includes missing indicators; training-only fit, never evaluation targets.
    return make_pipeline(SimpleImputer(strategy="median", add_indicator=True, keep_empty_features=True),
                         StandardScaler(), Ridge(alpha=alpha))


def run_site(calendar, facility_id, site_id, cfg):
    deployment = pd.Timestamp(cfg["deployment_date"])
    delay = cfg["availability"]["delay_days"]
    outputs, fit_records = [], []
    for budget in cfg["budgets"]:
        left = deployment - pd.Timedelta(days=budget)
        for horizon in cfg["horizons"]:
            train = training_set(calendar, deployment, budget, horizon, delay)
            ridge = None
            if len(train.y) >= cfg["min_train_labels"]:
                ridge = ridge_pipeline(cfg["ridge_alpha"])
                ridge.fit(train.X, train.y)
            fit_records.append({"facility_id": facility_id, "site_id": site_id, "budget": budget,
                                "horizon": horizon, "training_labels": len(train.y),
                                "history_left": left.date().isoformat(),
                                "last_train_target": str(max(train.targets).date()) if train.targets else None,
                                "ridge_status": "fitted" if ridge is not None else "insufficient_training_labels"})
            for origin in pd.date_range(deployment, periods=cfg["evaluation_days"], freq="D"):
                target = origin + pd.Timedelta(days=horizon)
                truth = at(calendar.candidate_value_m3, target, left, target)
                pers, age = persistence_at(calendar.observed_input_m3, origin, left, delay)
                weekly = weekly_at(calendar.observed_input_m3, origin, horizon, left, delay)
                x = np.asarray(features_at(calendar.observed_input_m3, origin, horizon, left, delay)).reshape(1, -1)
                # Do not make a ridge prediction using only imputed constants/calendar when no history exists.
                pred = float(ridge.predict(x)[0]) if ridge is not None and np.isfinite(x[:, :len(LAGS) + 1]).any() else np.nan
                predictions = dict(zip(MODELS, [pers, weekly, pred]))
                common = bool(np.isfinite(truth) and all(np.isfinite(v) for v in predictions.values()))
                for model, value in predictions.items():
                    outputs.append({"facility_id": facility_id, "site_id": site_id, "budget": budget,
                                    "horizon": horizon, "origin": origin.date().isoformat(),
                                    "target_date": target.date().isoformat(), "model": model,
                                    "truth_m3": truth, "prediction_m3": value,
                                    "common_evaluation": common, "persistence_age_days": age,
                                    "training_labels": len(train.y),
                                    "issue_date": (origin + pd.Timedelta(days=1)).date().isoformat(),
                                    "latest_input_date": (origin - pd.Timedelta(days=delay)).date().isoformat(),
                                    "budget_start": left.date().isoformat(),
                                    "fit_end": (deployment - pd.Timedelta(days=1)).date().isoformat(),
                                    "latest_allowed_train_label": (deployment - pd.Timedelta(days=1+delay)).date().isoformat(),
                                    "last_train_target": str(max(train.targets).date()) if train.targets else None,
                                    "extra_delay_days": delay, "calibration_end": None})
    return pd.DataFrame(outputs), pd.DataFrame(fit_records)


def paired_metrics(predictions):
    common = predictions[predictions.common_evaluation.eq(True)].copy()
    rows = []
    for keys, group in common.groupby(["facility_id", "budget", "horizon", "model"]):
        errors = group.prediction_m3.to_numpy() - group.truth_m3.to_numpy()
        rows.append(dict(zip(["facility_id", "budget", "horizon", "model"], keys),
                         n_evaluation=len(errors), mae_m3=float(np.mean(np.abs(errors))),
                         rmse_m3=float(np.sqrt(np.mean(errors ** 2)))))
    cols = ["facility_id", "budget", "horizon", "model", "n_evaluation", "mae_m3", "rmse_m3"]
    metrics = pd.DataFrame(rows, columns=cols)
    for model in ["persistence", "weekly_persistence"]:
        refs = metrics[metrics.model.eq(model)][["facility_id", "budget", "horizon", "mae_m3"]]
        metrics = metrics.merge(refs.rename(columns={"mae_m3": f"{model}_mae"}),
                                on=["facility_id", "budget", "horizon"], how="left", validate="many_to_one")
        denominator = metrics[f"{model}_mae"]
        metrics[f"improvement_vs_{model}"] = (denominator - metrics.mae_m3) / denominator.where(denominator.gt(0))
    available = []
    for keys, g in predictions.groupby(["facility_id", "budget", "horizon", "model"]):
        truth_valid = g.truth_m3.notna()
        available.append(dict(zip(["facility_id", "budget", "horizon", "model"], keys),
                              origins=len(g), observed_targets=int(truth_valid.sum()),
                              model_predictions=int(g.prediction_m3.notna().sum()),
                              common_dates=int(g.common_evaluation.sum()),
                              common_fraction_of_observed_targets=float(g.common_evaluation.sum()/truth_valid.sum()) if truth_valid.any() else None))
    summary_rows = []
    for keys, g in metrics.groupby(["budget", "horizon", "model"]):
        row = dict(zip(["budget", "horizon", "model"], keys), facilities=len(g))
        for metric in ["mae_m3", "rmse_m3", "improvement_vs_persistence", "improvement_vs_weekly_persistence"]:
            v = g[metric].dropna()
            row[f"equal_weight_{metric}"] = float(v.mean()) if len(v) else np.nan
            row[f"facilities_defined_{metric}"] = len(v)
        summary_rows.append(row)
    return metrics, pd.DataFrame(available), pd.DataFrame(summary_rows)
