"""Fail-closed, development-only command line runner (not a final-test runner)."""
import argparse
import json
import logging
import math
import sys
import traceback
import uuid
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from .baselines import daily_calendar, paired_metrics, run_site
from .common import runtime_manifest, sha256, utc_now, write_json


def validate_config(cfg, root):
    if cfg.get("stage") != "development":
        raise ValueError("This entrypoint rejects non-development experiments")
    unit = cfg.get("analysis_unit", "physical_facility")
    if unit not in {"physical_facility", "station_exploratory"}:
        raise ValueError("Unknown analysis_unit")
    for name, allowed in [("budgets", {30, 90, 180}), ("horizons", {1, 3})]:
        values = cfg.get(name, [])
        if not values or len(set(values)) != len(values) or any(type(v) is not int or v not in allowed for v in values):
            raise ValueError(f"Invalid or repeated {name}")
    if type(cfg.get("evaluation_days")) is not int or cfg["evaluation_days"] <= 0:
        raise ValueError("Positive integer evaluation_days required")
    if type(cfg.get("min_train_labels")) is not int or cfg["min_train_labels"] < 14:
        raise ValueError("At least 14 training labels required")
    if not math.isfinite(float(cfg["ridge_alpha"])) or cfg["ridge_alpha"] <= 0:
        raise ValueError("Positive finite fixed ridge_alpha required")
    pd.Timestamp(cfg["deployment_date"])
    if pd.Timestamp(cfg["deployment_date"]) + pd.Timedelta(days=cfg["evaluation_days"] - 1 + max(cfg["horizons"])) > pd.Timestamp("2023-12-31"):
        raise ValueError("Development entrypoint reserves 2024-2025 and rejects evaluation labels in that period")
    semantics = cfg["target_semantics"]
    if semantics.get("reviewed") is not True or semantics.get("measurement_location") != "treated_effluent" or semantics.get("record_semantics") != "daily_volume":
        raise ValueError("Reviewed treated-effluent daily-volume semantics required")
    availability = cfg["availability"]
    if unit == "physical_facility":
        if availability.get("reviewed") is not True or availability.get("mode") != "fixed_delay_assumption":
            raise ValueError("Reviewed fixed-delay availability assumption required; annual publication is not online availability")
    else:
        if availability.get("mode") != "retrospective_snapshot_delay" or availability.get("assumption_documented") is not True or availability.get("verified_real_time") is not False:
            raise ValueError("Station exploration requires an explicit unverified retrospective snapshot timing scenario")
    if type(availability.get("delay_days")) is not int or availability["delay_days"] < 0:
        raise ValueError("Nonnegative integer delay_days required")
    for evidence in [semantics["evidence_path"], availability["evidence_path"]]:
        if not (root / evidence).is_file():
            raise ValueError(f"Evidence file absent: {evidence}")


def validate_mapping(mapping, root, analysis_unit="physical_facility"):
    required = {"site_id", "facility_id", "role", "measurement_location", "independence_evidence", "mapping_reviewed"}
    if not required.issubset(mapping.columns) or mapping.empty:
        raise ValueError("A nonempty explicitly reviewed development mapping is required")
    if mapping[list(required)].isna().any().any() or mapping[list(required)].apply(lambda s: s.str.strip().eq("")).any().any():
        raise ValueError("Blank mapping fields are not permitted")
    if not mapping.role.eq("development").all():
        raise ValueError("Development mapping must not contain source or final-test facilities")
    if analysis_unit == "physical_facility":
        if not mapping.mapping_reviewed.str.lower().eq("true").all():
            raise ValueError("Facility identities require explicit reviewed=true")
    else:
        if not mapping.mapping_reviewed.str.lower().eq("false").all() or not mapping.facility_id.eq("station:" + mapping.site_id).all():
            raise ValueError("Exploratory stations must use unverified station:ID keys, not claim facility identities")
    if not mapping.measurement_location.eq("treated_effluent").all():
        raise ValueError("Mapping contains non-effluent measurements")
    if mapping.site_id.duplicated().any() or mapping.facility_id.duplicated().any():
        raise ValueError("Multi-measurement/overlapping mappings need supported aggregation and re-audit")
    for evidence in mapping.independence_evidence:
        if not (root / evidence).is_file():
            raise ValueError(f"Facility evidence file absent: {evidence}")


def load_development_rows(path, ids, max_date=None):
    # Source and test series are never retained or passed into feature/metric code.
    pieces = []
    for chunk in pd.read_csv(path, dtype={"site_id": "string"}, chunksize=100000):
        mask = chunk.site_id.isin(ids)
        if max_date is not None:
            mask &= chunk.date.le(max_date)
        pieces.append(chunk[mask].copy())
    selected = pd.concat(pieces, ignore_index=True) if pieces else pd.DataFrame()
    if selected.empty or set(selected.site_id.unique()) != set(ids):
        raise ValueError("Some explicitly selected development stations have no canonical records")
    return selected


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    root = Path(__file__).resolve().parents[2]
    cfg_path = (Path.cwd() / args.config).resolve()
    cfg = json.loads(cfg_path.read_text())
    # Always retain failed attempts, including validation failures.
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "_" + uuid.uuid4().hex[:8]
    output = root / cfg.get("output_root", "runs/development") / run_id
    output.mkdir(parents=True, exist_ok=False)
    logger = logging.getLogger("wastewater.development")
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.FileHandler(output / "run.log"))
    logger.addHandler(logging.StreamHandler(sys.stdout))
    manifest = {"status": "running", "started_utc": utc_now(), "stage": cfg.get("stage"),
                "config": cfg, "config_sha256": sha256(cfg_path), "runtime": runtime_manifest(root),
                "command": [sys.executable, "-m", "wastewater.development", "--config", str(cfg_path)]}
    write_json(output / "manifest.json", manifest)
    try:
        validate_config(cfg, root)
        mapping_path, data_path = root / cfg["mapping_csv"], root / cfg["canonical_csv"]
        mapping = pd.read_csv(mapping_path, dtype="string")
        unit = cfg.get("analysis_unit", "physical_facility")
        validate_mapping(mapping, root, unit)
        manifest["data_sha256"] = sha256(data_path)
        processing_manifest_path = data_path.parent / "manifest.json"
        processing_manifest = json.loads(processing_manifest_path.read_text())
        if processing_manifest.get("status") != "completed" or processing_manifest.get("outputs_sha256", {}).get(data_path.name) != manifest["data_sha256"]:
            raise ValueError("Canonical data must match a completed audit manifest; re-audit edited derivatives")
        manifest["processing_manifest_sha256"] = sha256(processing_manifest_path)
        # Retain the upstream raw/config/code chain, even when outputs are moved together.
        manifest["processing_provenance"] = processing_manifest
        manifest["mapping_sha256"] = sha256(mapping_path)
        evidence_files = {cfg[k]["evidence_path"] for k in ["target_semantics", "availability"]}
        evidence_files.update(mapping.independence_evidence)
        manifest["evidence_sha256"] = {p: sha256(root / p) for p in sorted(evidence_files)}
        write_json(output / "manifest.json", manifest)
        rows = load_development_rows(data_path, mapping.site_id, max_date="2023-12-31")
        manifest["model_input_max_date"] = "2023-12-31"
        predictions, fit_records = [], []
        deployment = pd.Timestamp(cfg["deployment_date"])
        for row in mapping.itertuples(index=False):
            site_rows = rows[rows.site_id.eq(row.site_id)]
            calendar = daily_calendar(site_rows, deployment - pd.Timedelta(days=max(cfg["budgets"])),
                                      deployment + pd.Timedelta(days=cfg["evaluation_days"] - 1 + max(cfg["horizons"])))
            p, f = run_site(calendar, row.facility_id, row.site_id, cfg)
            predictions.append(p)
            fit_records.append(f)
            logger.info("facility=%s predictions=%s", row.facility_id, len(p))
        predictions = pd.concat(predictions, ignore_index=True)
        fits = pd.concat(fit_records, ignore_index=True)
        metrics, availability, summary = paired_metrics(predictions)
        predictions.to_csv(output / "predictions.csv", index=False)
        fits.to_csv(output / "fit_records.csv", index=False)
        metrics.to_csv(output / "metrics_by_facility.csv", index=False)
        availability.to_csv(output / "availability.csv", index=False)
        summary.to_csv(output / "equal_weight_summary.csv", index=False)
        if unit == "station_exploratory":
            # Keep API-compatible surrogate keys but label the scientific unit explicitly.
            for frame in [predictions, fits, metrics, availability, summary]:
                frame["analysis_unit"] = "station_exploratory"
            predictions.to_csv(output / "predictions.csv", index=False)
            fits.to_csv(output / "fit_records.csv", index=False)
            (output / "metrics_by_facility.csv").unlink()
            metrics.rename(columns={"facility_id": "station_group_key"}).to_csv(output / "metrics_by_station.csv", index=False)
            availability.to_csv(output / "availability.csv", index=False)
            summary.rename(columns={k: k.replace("facilities", "stations") for k in summary if "facilities" in k}).to_csv(output / "equal_weight_summary.csv", index=False)
            manifest["analysis_unit"] = unit
            manifest["facility_independence_verified"] = False
            manifest["real_time_availability_verified"] = False
        if sha256(data_path) != manifest["data_sha256"] or sha256(mapping_path) != manifest["mapping_sha256"]:
            raise ValueError("Input data or mapping changed during the run")
        incomplete = fits.ridge_status.ne("fitted").any() or metrics.empty
        if not metrics.empty:
            incomplete = bool(incomplete or metrics.n_evaluation.min() < 28 or len(metrics) != len(fits) * 3)
        manifest.update({"status": "incomplete" if incomplete else "completed", "finished_utc": utc_now(),
                         "readiness_note": "Development results only; no cross-plant or online-deployment claim. Fewer than 28 common dates is insufficient for the proposed feasibility gate.",
                         "outputs_sha256": {p.name: sha256(p) for p in output.iterdir() if p.name != "manifest.json"}})
        logger.info("status=%s run=%s", manifest["status"], output)
        # Flush log before hashing it; do not claim a stale hash after writing the final message.
        for handler in logger.handlers:
            handler.flush()
        manifest["outputs_sha256"]["run.log"] = sha256(output / "run.log")
        write_json(output / "manifest.json", manifest)
        if incomplete:
            raise SystemExit(2)
    except Exception as exc:
        logger.exception("Development run failed")
        manifest.update({"status": "failed", "finished_utc": utc_now(), "error": str(exc)})
        write_json(output / "manifest.json", manifest)
        (output / "failure.txt").write_text(traceback.format_exc())
        raise


if __name__ == "__main__":
    main()
