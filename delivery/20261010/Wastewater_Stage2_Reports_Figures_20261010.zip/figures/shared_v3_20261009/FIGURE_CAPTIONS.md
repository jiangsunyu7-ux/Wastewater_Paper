# V3 development figure questions and captions

All figures describe a retrospective 2022–2023 development experiment using published quality flags. The ten SiteIDs have not been verified as ten independent physical facilities. MAE is in m³ of daily treated effluent volume; skill = 100 × (1 − model MAE/reference MAE). For GRUs, absolute/squared errors are averaged across three fixed seeds at each shared evaluation date before SiteID aggregation; predictions are not ensembled and seeds are not independent facilities. The 2024–2025 final period is excluded. Local learning models use source-validated hyperparameters matching their shared backbone; source and local optimization step counts are not matched. Uniform all-model nonnegative-output sensitivity results remain in the source report and are not used to select these primary raw figures.

## budget_skill

Question: Do shared or locally adapted models outperform persistence at each allowed local-history budget?

Caption: Equal-SiteID mean MAE skill relative to persistence by initial local-history budget and forecast horizon. Positive skill denotes lower MAE. All forecasts are unconstrained raw model outputs; the horizontal zero line denotes persistence. All seven non-persistence conditions are shown, including negative results.

Sources: `reports/shared_v3_20261009/summary.csv`.

## station_transfer

Question: Which fixed development SiteIDs gain or lose accuracy after sharing or local adaptation, relative to the matching local backbone?

Caption: Per-SiteID MAE skill of each shared model relative to its local backbone on common comparison dates. Shared ridge and ridge with a local residual-bias correction are compared with local ridge; shared GRU and adapted shared GRU are compared with local GRU. Negative cells indicate negative transfer; all ten fixed development SiteIDs and all budgets/horizons are retained. The diverging colour scale spans the observed range without clipping.

Sources: `reports/shared_v3_20261009/paired_comparisons_by_station.csv`, `reports/shared_v3_20261009/negative_transfer_summary.csv`.

## history_budget_intervals

Question: Can a shared model using 30 days of local history match a local model using 90 or 180 days, accounting for correlated dates and SiteID sampling?

Caption: A shared model using B30 local history compared with the matching local backbone using B90 or B180. Points show equal-SiteID mean MAE skill and horizontal segments show pointwise 95% intervals from synchronized noncircular 14-day calendar blocks within each episode and resampled SiteID clusters. The zero line denotes equal MAE; the dotted -5% line is an exploratory tolerance, not proof of noninferiority. These intervals are conditional on a small nonrandom development cohort and are not adjusted for multiplicity. The full report retains the 7- and 28-day block sensitivity intervals.

Sources: `reports/shared_v3_20261009/paired_block_intervals.csv`.

## high_volume_skill

Question: Do apparent skills over all comparison dates persist on dates exceeding a threshold determined only by permitted historical observations?

Caption: Equal-SiteID mean skill relative to persistence on all common dates (horizontal axis) and historical high-volume dates (vertical axis). Colours identify all six learning models; marker shapes identify B30/B90/B180. The diagonal denotes equal skill in both subsets. Each SiteID/episode threshold is the 90th percentile of valid Good observations in its permitted 30-day initial history, shared by all models and budgets. This empirical volume threshold does not represent treatment capacity, a permit limit, or an overflow threshold. Points are descriptive; no coverage guarantee or independent final-test claim is made.

Sources: `reports/shared_v3_20261009/summary.csv`, `reports/shared_v3_20261009/high_volume_summary.csv`, `reports/shared_v3_20261009/high_volume_metrics_by_station.csv`.

